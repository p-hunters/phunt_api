# -*- coding: utf-8 -*-

# 仕様:
# - Google Colabでのみ実行を想定したパッケージ
# - Workspaceドメインのユーザーのみがアクセス可能
# - ロールをアサインして一時的なクレデンシャルを取得し、環境変数に保存する

import os
import google.auth
import google.auth.transport.requests
import requests
from .exceptions import AuthenticationError
import boto3
import json
from functools import wraps
from dotenv import load_dotenv

class PHuntAuth:
    def __init__(self, workspace_domain='p-hunter.com'):
        self.workspace_domain = workspace_domain
        self.base_creds = {
            'aws_access_key_id': 'AKIA4OVGUVMZ4G7O2NVR',
            'aws_secret_access_key': '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',
            'region_name': 'ap-northeast-1'
        }
        self.tmp_creds = None

    def assume_role_and_update_s3_policy(self, email):
        # STSクライアントを作成
        sts_client = boto3.client('sts', **self.base_creds)
        role_arn = 'arn:aws:iam::856121715507:role/phunt-assumed-role'        
        bucket_name = 'porory-data'
        prefix = 'data'

        # 指定したロールをアサイン
        assumed_role = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName='PHuntSession_' + email
        )

        # 一時的な認証情報を取得
        credentials = assumed_role['Credentials']

        # アサインしたロールの認証情報でS3クライアントを作成
        s3_client = boto3.client(
            's3',
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )

        # バケットポリシーを取得
        try:
            policy = s3_client.get_bucket_policy(Bucket=bucket_name)
            policy_json = json.loads(policy['Policy'])
        except Exception as e:
            # print(f"バケットポリシーが存在しません")
            policy_json = {
                "Version": "2012-10-17",
                "Statement": []
            }

        # 新しいポリシーステートメントを作成
        new_statement = {
            "Sid": f"AllowPHuntSession_{email}",
            "Effect": "Allow",
            "Principal": {
                "AWS": role_arn
            },
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:ListBucket"
            ],
            "Resource": [
                f"arn:aws:s3:::{bucket_name}/{prefix}/PHuntSession_{email}/*",
                f"arn:aws:s3:::{bucket_name}/phunt/data/dataset/*",
                f"arn:aws:s3:::{bucket_name}/phunt/sample/dataset/*",
                f"arn:aws:s3:::{bucket_name}"  # バケット自体へのアクセス権限を追加
            ],
            "Condition": {
                "StringEquals": {
                    "aws:PrincipalTag/aws:RoleSessionName": 'PHuntSession_' + email
                }
            }
        }

        # 既存のステートメントに新しいステートメントを追加
        statements = policy_json["Statement"]
        updated = False
        for statement in statements:
            if statement["Sid"] == f"AllowPHuntSession_{email}":
                statement = new_statement
                updated = True
                # print(f"バケットポリシーが更新されました: {bucket_name}, Sid: {statement['Sid']}")
                break
        if not updated:
            statements.append(new_statement)
            # print(f"バケットポリシーが更新されました: {bucket_name}, Sid: {new_statement['Sid']}")
        # 更新したポリシーを適用
        s3_client.put_bucket_policy(
            Bucket=bucket_name,
            Policy=json.dumps(policy_json)
        )

        print(f"バケットポリシーが更新されました: {bucket_name}")
        self.tmp_creds = credentials
        self.set_environment_variables(credentials)
        return credentials

    def login(self):
        try:
            # Google Colabでの実行を確認
            if not self.is_running_on_colab():
                raise AuthenticationError("この関数はGoogle Colab上で実行する必要があります。")

            # ユーザー認証
            import google.colab
            google.colab.auth.authenticate_user()

            # 資格情報を取得
            try:
                creds, _ = google.auth.default()
            except ValueError as e:
                raise AuthenticationError(f"認証情報の取得に失敗しました: {str(e)}")

            request = google.auth.transport.requests.Request()
            creds.refresh(request)

            # ア��セストークンを使用してユーザー情報を取得
            email = self.get_user_email(creds.token)

            # Workspaceドメインであることを確認
            self.verify_workspace_domain(email)

            # 一時的なクレデンシャルを取得
            temp_credentials = self.assume_role_and_update_s3_policy(email)

            # 環境変数として保存
            self.set_environment_variables(temp_credentials)
            tmp_creds = {
                'aws_access_key_id': temp_credentials['AccessKeyId'],
                'aws_secret_access_key': temp_credentials['SecretAccessKey'],
                'aws_session_token': temp_credentials['SessionToken'],
                'region_name': temp_credentials.get('Region', 'ap-northeast-1')
            }
            return tmp_creds
        except Exception as e:
            raise AuthenticationError(f"認証中にエラーが発生しました: {str(e)}")

    def is_running_on_colab(self):
        try:
            import google.colab
            return True
        except ImportError:
            return False

    def get_user_email(self, access_token):
        response = requests.get(
            'https://www.googleapis.com/oauth2/v1/userinfo',
            params={'alt': 'json'},
            headers={'Authorization': f'Bearer {access_token}'}
        )
        if response.status_code == 200:
            return response.json()['email']
        else:
            raise Exception(f'ユーザー情報の取得に失敗しました。レスポンス: {response.content}')

    def verify_workspace_domain(self, email):
        if not email.endswith(f'@{self.workspace_domain}'):
            raise AuthenticationError("Workspaceドメインのユーザーのみがアクセスできます。")

    def set_environment_variables(self, credentials):
        os.environ['PHUNT_ACCESS_KEY'] = credentials['AccessKeyId']
        os.environ['PHUNT_SECRET_KEY'] = credentials['SecretAccessKey']
        os.environ['PHUNT_SESSION_TOKEN'] = credentials['SessionToken']
        os.environ['AWS_ACCESS_KEY_ID'] = credentials['AccessKeyId']
        os.environ['AWS_SECRET_ACCESS_KEY'] = credentials['SecretAccessKey']
        os.environ['AWS_SESSION_TOKEN'] = credentials['SessionToken']
        os.environ['AWS_REGION'] = credentials.get('Region', 'ap-northeast-1')

    @classmethod
    def login_required(cls, func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            if not self.is_logged_in():
                raise AuthenticationError("この操作にはログインが必要です。login()メソッドを先に呼び出してください。")
            return func(self, *args, **kwargs)
        return wrapper

    def is_logged_in(self):
        return self.tmp_creds is not None

if __name__ == "__main__":
    auth = PHuntAuth()
    creds = auth.assume_role_and_update_s3_policy('shin@p-hunter.com')
    print(creds)
    # auth.login()
