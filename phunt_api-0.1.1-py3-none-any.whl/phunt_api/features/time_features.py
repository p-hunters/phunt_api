import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
from phunt_api.features.goto_detect import GotoDateDetector


# =============================================================================
#  Constants & Configuration
# =============================================================================

# Market Sessions (UTC times, before DST adjustment)
DEFAULT_SESSIONS = {
    'tokyo': {'start': time(0, 0), 'end': time(9, 0)},
    'london': {'start': time(8, 0), 'end': time(16, 0)},
    'ny': {'start': time(13, 0), 'end': time(22, 0)},
    'sydney': {'start': time(22, 0), 'end': time(7, 0)},  # crosses midnight
    'frankfurt': {'start': time(7, 0), 'end': time(15, 0)}
}

# Lunch breaks by market (UTC)
DEFAULT_LUNCH_TIMES = {
    'tokyo': [4, 5],     # UTC 4-5 (JST 13-14)
    'london': [12, 13],  # UTC 12-13 (BST/GMT 12-13)
    'ny': [17, 18],      # UTC 17-18 (EST/EDT 12-13)
    'sydney': [3, 4],    # UTC 3-4 (AEST 13-14)
    'frankfurt': [11, 12]  # UTC 11-12 (CET/CEST 12-13)
}

# High volatility periods (UTC)
HIGH_VOL_PERIODS = {
    'tokyo_london_overlap': {'start': time(7, 0), 'end': time(9, 0)},
    'london_ny_overlap': {'start': time(13, 0), 'end': time(16, 0)},
    'sydney_tokyo_overlap': {'start': time(0, 0), 'end': time(2, 0)}
}

# Important fixed times (UTC)
IMPORTANT_TIMES = {
    'london_fix': time(15, 0),      # 16:00 London/15:00 UTC
    'ny_fix': time(14, 0),          # 10:00 NY/14:00 UTC
    'tokyo_fix': time(9, 30),       # 18:30 Tokyo/9:30 UTC
    'ecb_usual_time': time(12, 45), # ECB announcements
    'fomc_usual_time': time(18, 0)  # FOMC announcements
}

# DST transition dates (example - should be updated yearly)
DST_TRANSITIONS = {
    'us': {
        'start': {'month': 3, 'week': 2, 'weekday': 6},  # Second Sunday in March
        'end': {'month': 11, 'week': 1, 'weekday': 6}    # First Sunday in November
    },
    'uk': {
        'start': {'month': 3, 'week': -1, 'weekday': 6}, # Last Sunday in March
        'end': {'month': 10, 'week': -1, 'weekday': 6}   # Last Sunday in October
    }
}


# =============================================================================
#  DST & Session Utilities
# =============================================================================

def is_dst_in_bulk(timestamps: pd.DatetimeIndex, zone: str) -> pd.Series:
    """Vectorized check of DST for a given timezone."""
    # Convert timestamps to specified timezone
    converted = timestamps.tz_convert(zone) if timestamps.tz else timestamps.tz_localize(zone)
    # Get DST offset for each timestamp
    return pd.Series([t.dst().total_seconds() != 0 for t in converted], index=timestamps)


def get_sessions_for_all_timestamps(timestamps: pd.DatetimeIndex) -> pd.DataFrame:
    """
    For each timestamp, determine the session start/end times for Tokyo, London, and NY
    considering DST. Returns a DataFrame of session boundaries (local times in UTC).
    
    Notes:
        - This function replicates get_market_hours logic in a vectorized manner.
        - The result can then be used to check whether each timestamp is in session.
    
    Args:
        timestamps (pd.DatetimeIndex): Timestamps in UTC or naive (assumed UTC)
    
    Returns:
        pd.DataFrame: Columns [tokyo_start, tokyo_end, london_start, london_end, ny_start, ny_end]
                      Each cell is a time object in UTC perspective.
    """
    # ベースの空DataFrame作成
    df = pd.DataFrame(index=timestamps, columns=[
        'tokyo_start', 'tokyo_end',
        'london_start', 'london_end',
        'ny_start', 'ny_end'
    ], dtype='object')
    
    # ロンドンとNYのDSTをベクトル的に判定
    is_london_dst = is_dst_in_bulk(timestamps, "Europe/London")
    is_ny_dst = is_dst_in_bulk(timestamps, "America/New_York")
    
    # Tokyo: no DST
    # デフォルトは UTCで 0:00～9:00 と仮定
    df['tokyo_start'] = time(0, 0)
    df['tokyo_end'] = time(9, 0)
    
    # London
    # is_london_dst == True の場合は 7:00～15:00 (BST), else 8:00～16:00 (GMT)
    df.loc[is_london_dst, 'london_start'] = time(7, 0)
    df.loc[is_london_dst, 'london_end'] = time(15, 0)
    df.loc[~is_london_dst, 'london_start'] = time(8, 0)
    df.loc[~is_london_dst, 'london_end'] = time(16, 0)
    
    # New York
    # is_ny_dst == True の場合 12:00～21:00 (EDT), else 13:00～22:00 (EST)
    df.loc[is_ny_dst, 'ny_start'] = time(12, 0)
    df.loc[is_ny_dst, 'ny_end'] = time(21, 0)
    df.loc[~is_ny_dst, 'ny_start'] = time(13, 0)
    df.loc[~is_ny_dst, 'ny_end'] = time(22, 0)
    
    return df


def is_session_active_vec(timestamps: pd.Series, session_start_times: pd.Series, session_end_times: pd.Series) -> pd.Series:
    """Vectorized session checker."""
    # Ensure all series have the same index
    ts_series = pd.Series(timestamps)
    current_times = pd.Series([t.time() for t in timestamps], index=timestamps)
    session_start_times = pd.Series(session_start_times.values, index=timestamps)
    session_end_times = pd.Series(session_end_times.values, index=timestamps)
    
    def _is_active(start_t: pd.Series, end_t: pd.Series, current_t: pd.Series) -> pd.Series:
        mask = pd.Series(False, index=current_t.index)
        for i in range(len(current_t)):
            if start_t.iloc[i] <= end_t.iloc[i]:
                mask.iloc[i] = (current_t.iloc[i] >= start_t.iloc[i]) and (current_t.iloc[i] <= end_t.iloc[i])
            else:
                mask.iloc[i] = (current_t.iloc[i] >= start_t.iloc[i]) or (current_t.iloc[i] <= end_t.iloc[i])
        return mask
    
    return _is_active(session_start_times, session_end_times, current_times)


# =============================================================================
#  Session Feature Calculation
# =============================================================================

def calculate_session_features(
    timestamps: pd.DatetimeIndex,
    sessions: Optional[Dict[str, Dict[str, time]]] = None,
    peak_vol_hour: int = 14,
    lunch_times: Dict[str, List[int]] = None
) -> pd.DataFrame:
    """
    Calculate trading session-related features in a more vectorized manner.
    
    If 'sessions' is None, use dynamic get_market_hours logic (DST-aware) for
    Tokyo, London, and NY sessions. Otherwise, use the provided session dict.
    
    Args:
        timestamps (pd.DatetimeIndex): Timestamps in (assumed) UTC
        sessions (Optional[Dict[str, Dict[str, time]]]): 
            Example:
                {
                  'tokyo': {'start': time(0,0), 'end': time(9,0)},
                  'london': {'start': time(8,0), 'end': time(16,0)},
                  'ny': {'start': time(13,0), 'end': time(22,0)}
                }
            If None, automatically compute via DST logic.
        peak_vol_hour (int): Example default = 14 (UTC) as peak volatility
        lunch_times (Dict[str, List[int]]): e.g. {'tokyo': [3,4], 'london': [12,13], 'ny': [17,18]}
    
    Returns:
        pd.DataFrame: Session-based features
    """
    if lunch_times is None:
        lunch_times = DEFAULT_LUNCH_TIMES
    
    features = pd.DataFrame(index=timestamps)
    
    if sessions is None:
        # Get dynamic session times (DST-aware)
        session_info_df = get_sessions_for_all_timestamps(timestamps)
    else:
        # Use provided static sessions
        session_info_df = pd.DataFrame(index=timestamps)
        for sess_name, sess_times in sessions.items():
            session_info_df[f'{sess_name}_start'] = sess_times['start']
            session_info_df[f'{sess_name}_end'] = sess_times['end']
    
    # Calculate session flags
    session_names = ['tokyo', 'london', 'ny']
    for sess_name in session_names:
        start_col = f'{sess_name}_start'
        end_col = f'{sess_name}_end'
        
        if start_col in session_info_df.columns and end_col in session_info_df.columns:
            features[f'{sess_name}_session'] = is_session_active_vec(
                timestamps,
                session_info_df[start_col],
                session_info_df[end_col]
            )
    
    # Calculate session overlaps
    for i, sess1 in enumerate(session_names):
        for j, sess2 in enumerate(session_names):
            if j <= i:  # Avoid duplicates and self-overlaps
                continue
            
            overlap_name = f'{sess1}_{sess2}_overlap'
            features[overlap_name] = (
                features.get(f'{sess1}_session', False) &
                features.get(f'{sess2}_session', False)
            )
    
    # Calculate active sessions count
    session_cols = [f'{sess}_session' for sess in session_names]
    features['active_sessions'] = features[session_cols].sum(axis=1)
    
    # Add lunch break flags
    for sess_name, lunch_hours in lunch_times.items():
        if f'{sess_name}_session' in features.columns:
            features[f'is_lunch_time_{sess_name}'] = (
                features[f'{sess_name}_session'] &
                timestamps.hour.isin(lunch_hours)
            )
    
    # High volatility flags
    features['is_high_volatility_period'] = (
        features.get('tokyo_london_overlap', False) |
        features.get('london_ny_overlap', False) |
        (timestamps.hour == peak_vol_hour)
    )
    
    return features


# =============================================================================
#  Time-Based Feature Calculation
# =============================================================================

def calculate_time_features(timestamps: pd.DatetimeIndex) -> pd.DataFrame:
    """
    Calculate time-based features (day_of_week, cyclical encoding, etc.)
    
    Args:
        timestamps (pd.DatetimeIndex): DatetimeIndex of timestamps
    
    Returns:
        pd.DataFrame: Basic time-based features
    """
    features = pd.DataFrame(index=timestamps)
    
    # Basic time features
    features['hour'] = timestamps.hour
    features['minute'] = timestamps.minute
    features['day_of_week'] = timestamps.dayofweek
    features['day_of_month'] = timestamps.day
    features['day_of_year'] = timestamps.dayofyear
    features['week_of_year'] = timestamps.isocalendar().week.astype(int)
    features['week_of_month'] = (timestamps.day - 1) // 7 + 1
    features['month'] = timestamps.month
    features['quarter'] = timestamps.quarter
    features['days_in_month'] = timestamps.days_in_month
    
    # Additional end-of-period flags
    features['is_month_end'] = timestamps.is_month_end
    features['is_quarter_end'] = timestamps.is_quarter_end
    features['is_year_end'] = timestamps.is_year_end
    
    # Day offsets to end of month / end of year
    month_end = timestamps + pd.offsets.MonthEnd(0)
    year_end = timestamps + pd.offsets.YearEnd(0)
    features['days_to_month_end'] = (month_end - timestamps).days
    features['days_to_year_end'] = (year_end - timestamps).days
    
    # Derived flags
    features['is_weekend'] = (timestamps.dayofweek >= 5)
    features['is_monday'] = (timestamps.dayofweek == 0)
    features['is_friday'] = (timestamps.dayofweek == 4)
    
    # Time of day features
    total_minutes = features['hour'] * 60 + features['minute']
    features['time_of_day'] = total_minutes / (24 * 60)  # Normalized
    
    # Day period (example cut)
    features['is_morning'] = (4 <= timestamps.hour) & (timestamps.hour < 12)
    features['is_afternoon'] = (12 <= timestamps.hour) & (timestamps.hour < 17)
    features['is_evening'] = (17 <= timestamps.hour) & (timestamps.hour < 21)
    features['is_night'] = (timestamps.hour >= 21) | (timestamps.hour < 4)
    
    # Year period features (simple example)
    features['is_summer'] = timestamps.month.isin([6, 7, 8])
    features['is_winter'] = timestamps.month.isin([12, 1, 2])
    
    # Cyclical encoding
    # minute
    features['minute_sin'] = np.sin(2 * np.pi * features['minute'] / 60)
    features['minute_cos'] = np.cos(2 * np.pi * features['minute'] / 60)
    # hour
    features['hour_sin'] = np.sin(2 * np.pi * features['hour'] / 24)
    features['hour_cos'] = np.cos(2 * np.pi * features['hour'] / 24)
    # day_of_month
    features['day_sin'] = np.sin(
        2 * np.pi * features['day_of_month'] / features['days_in_month'].clip(lower=1)
    )
    features['day_cos'] = np.cos(
        2 * np.pi * features['day_of_month'] / features['days_in_month'].clip(lower=1)
    )
    # month
    features['month_sin'] = np.sin(2 * np.pi * features['month'] / 12)
    features['month_cos'] = np.cos(2 * np.pi * features['month'] / 12)
    # day_of_week
    features['day_of_week_sin'] = np.sin(2 * np.pi * features['day_of_week'] / 7)
    features['day_of_week_cos'] = np.cos(2 * np.pi * features['day_of_week'] / 7)
    # week_of_year
    features['week_of_year_sin'] = np.sin(2 * np.pi * features['week_of_year'] / 52)
    features['week_of_year_cos'] = np.cos(2 * np.pi * features['week_of_year'] / 52)
    # day_of_year (1~365 or 366)
    features['day_of_year_sin'] = np.sin(2 * np.pi * features['day_of_year'] / 365)
    features['day_of_year_cos'] = np.cos(2 * np.pi * features['day_of_year'] / 365)
    
    return features


def calculate_advanced_time_features(timestamps: pd.DatetimeIndex) -> pd.DataFrame:
    """
    Calculate advanced time-based features including:
    - Market timing features
    - Volatility regime indicators
    - Cross-session effects
    - Periodic patterns
    
    Args:
        timestamps: DatetimeIndex of timestamps (UTC)
    
    Returns:
        DataFrame with advanced time features
    """
    features = pd.DataFrame(index=timestamps)
    
    # Basic time components
    features['hour'] = timestamps.hour
    features['minute'] = timestamps.minute
    features['second'] = timestamps.second
    features['day_of_week'] = timestamps.dayofweek
    features['day_of_month'] = timestamps.day
    features['day_of_year'] = timestamps.dayofyear
    features['week_of_year'] = timestamps.isocalendar().week.astype(int)
    features['month'] = timestamps.month
    features['quarter'] = timestamps.quarter
    
    # Calculate minutes since day start
    minutes_since_day = features['hour'] * 60 + features['minute']
    features['day_progress'] = minutes_since_day / (24 * 60)  # 0 to 1
    
    # Market timing features
    for fix_name, fix_time in IMPORTANT_TIMES.items():
        fix_minutes = fix_time.hour * 60 + fix_time.minute
        current_minutes = features['hour'] * 60 + features['minute']
        features[f'minutes_to_{fix_name}'] = fix_minutes - current_minutes
        features[f'minutes_from_{fix_name}'] = current_minutes - fix_minutes
        features[f'near_{fix_name}_5min'] = abs(features[f'minutes_to_{fix_name}']) <= 5
        features[f'near_{fix_name}_15min'] = abs(features[f'minutes_to_{fix_name}']) <= 15
    
    # High volatility period flags
    for period_name, period in HIGH_VOL_PERIODS.items():
        ts_series = pd.Series(timestamps)
        current_time = ts_series.dt.time
        if period['start'] <= period['end']:
            features[f'in_{period_name}'] = (
                (current_time >= period['start']) & 
                (current_time <= period['end'])
            )
        else:
            features[f'in_{period_name}'] = (
                (current_time >= period['start']) | 
                (current_time <= period['end'])
            )
    
    # Intraday progression features
    features['trading_day_progress'] = (minutes_since_day - 8 * 60) / (14 * 60)
    
    # Advanced periodic features
    features['minute_of_day'] = minutes_since_day
    features['minute_of_day_sin'] = np.sin(2 * np.pi * minutes_since_day / (24 * 60))
    features['minute_of_day_cos'] = np.cos(2 * np.pi * minutes_since_day / (24 * 60))
    
    # Week progress
    week_progress = (features['day_of_week'] * 24 * 60 + minutes_since_day) / (7 * 24 * 60)
    features['week_progress'] = week_progress
    features['week_progress_sin'] = np.sin(2 * np.pi * week_progress)
    features['week_progress_cos'] = np.cos(2 * np.pi * week_progress)
    
    # Month progress
    month_progress = (features['day_of_month'] - 1 + features['day_progress']) / timestamps.days_in_month
    features['month_progress'] = month_progress
    features['month_progress_sin'] = np.sin(2 * np.pi * month_progress)
    features['month_progress_cos'] = np.cos(2 * np.pi * month_progress)
    
    # Quarter progress
    days_in_quarter = pd.Series([92 if q in [1,2] else 91 if q == 3 else 92 
                               for q in features['quarter']])
    quarter_day = ((features['month'] - 1) % 3) * 30 + features['day_of_month']
    quarter_progress = (quarter_day - 1 + features['day_progress']) / days_in_quarter
    features['quarter_progress'] = quarter_progress
    features['quarter_progress_sin'] = np.sin(2 * np.pi * quarter_progress)
    features['quarter_progress_cos'] = np.cos(2 * np.pi * quarter_progress)
    
    # Market timing flags
    features['is_pre_london'] = (
        (features['hour'] >= 6) & 
        (features['hour'] < 8)
    )
    features['is_pre_ny'] = (
        (features['hour'] >= 11) & 
        (features['hour'] < 13)
    )
    features['is_post_tokyo'] = (
        (features['hour'] >= 8) & 
        (features['hour'] < 10)
    )
    
    # Day type flags
    features['is_monday'] = features['day_of_week'] == 0
    features['is_friday'] = features['day_of_week'] == 4
    features['is_weekend'] = features['day_of_week'] >= 5
    
    # Month/quarter boundaries
    features['is_month_start'] = timestamps.is_month_start
    features['is_month_end'] = timestamps.is_month_end
    features['is_quarter_start'] = timestamps.is_quarter_start
    features['is_quarter_end'] = timestamps.is_quarter_end
    features['is_year_start'] = timestamps.is_year_start
    features['is_year_end'] = timestamps.is_year_end
    
    return features


# =============================================================================
#  Holiday & Economic Calendar
# =============================================================================

def calculate_holiday_features(
    timestamps: pd.DatetimeIndex,
    holiday_calendar: pd.DataFrame
) -> pd.DataFrame:
    """
    Calculate holiday-related features.
    
    Args:
        timestamps (pd.DatetimeIndex): Timestamps
        holiday_calendar (pd.DataFrame): 
            Index: holiday dates (datetime)
            Columns (optional): additional info about holidays
    
    Returns:
        pd.DataFrame: Holiday features
    """
    features = pd.DataFrame(index=timestamps)
    
    # Ensure holiday_calendar index is datetime
    if not pd.api.types.is_datetime64_any_dtype(holiday_calendar.index):
        holiday_calendar.index = pd.to_datetime(holiday_calendar.index)
    
    # Basic holiday flags
    features['is_holiday'] = timestamps.normalize().isin(holiday_calendar.index.normalize())
    
    # Days before/after holiday
    holiday_dates = holiday_calendar.index.normalize()
    for days in [1, 2, 3]:
        # Before holiday
        before_holiday_dates = holiday_dates - pd.Timedelta(days=days)
        features[f'days_before_holiday_{days}'] = timestamps.normalize().isin(before_holiday_dates)
        # After holiday
        after_holiday_dates = holiday_dates + pd.Timedelta(days=days)
        features[f'days_after_holiday_{days}'] = timestamps.normalize().isin(after_holiday_dates)
    
    # 例: 祝日の連休や振替休日を追加で判定したい場合などはここで拡張
    
    return features


def calculate_economic_calendar_features(
    timestamps: pd.DatetimeIndex,
    economic_calendar: pd.DataFrame,
    impact_windows: List[int] = [5, 15]
) -> pd.DataFrame:
    """Calculate economic calendar features."""
    features = pd.DataFrame(index=timestamps)
    
    # Ensure both timestamps and economic_calendar are tz-aware
    if not timestamps.tz:
        timestamps = timestamps.tz_localize('UTC')
    
    if not pd.api.types.is_datetime64_any_dtype(economic_calendar.index):
        economic_calendar.index = pd.to_datetime(economic_calendar.index)
    
    if not economic_calendar.index.tz:
        economic_calendar.index = economic_calendar.index.tz_localize('UTC')
    
    # Ensure timestamps and economic_calendar have the same timezone
    if economic_calendar.index.tz != timestamps.tz:
        economic_calendar.index = economic_calendar.index.tz_convert(timestamps.tz)
    
    for importance in economic_calendar['importance'].unique():
        events = economic_calendar[
            economic_calendar['importance'].str.lower() == importance.lower()
        ]
        
        for window in impact_windows:
            before_col = f'{importance}_impact_before_{window}min'
            after_col = f'{importance}_impact_after_{window}min'
            features[before_col] = False
            features[after_col] = False
            
            for event_time in events.index:
                start_before = event_time - pd.Timedelta(minutes=window)
                end_before = event_time
                start_after = event_time
                end_after = event_time + pd.Timedelta(minutes=window)
                
                mask_before = (timestamps >= start_before) & (timestamps <= end_before)
                mask_after = (timestamps >= start_after) & (timestamps <= end_after)
                
                features.loc[mask_before, before_col] = True
                features.loc[mask_after, after_col] = True
    
    return features


# =============================================================================
#  Composite Function
# =============================================================================

def calculate_goto_features(timestamps: pd.DatetimeIndex) -> pd.DataFrame:
    """
    Calculate goto date (5th, 10th, 15th, 20th, 25th, 30th) related features.
    All calculations are based on JST (Japan Standard Time).
    
    Args:
        timestamps (pd.DatetimeIndex): Timestamps in any timezone
        
    Returns:
        pd.DataFrame: Goto date related features
    """
    features = pd.DataFrame(index=timestamps)
    
    # Convert timestamps to JST for goto date calculation
    if not timestamps.tz:
        jst_timestamps = timestamps.tz_localize('UTC').tz_convert('Asia/Tokyo')
    else:
        jst_timestamps = timestamps.tz_convert('Asia/Tokyo')
    
    # Initialize GotoDateDetector
    detector = GotoDateDetector()
    
    # Calculate basic goto features
    features['is_gotobi'] = False
    features['is_gotobi_candidate'] = False  # 5, 10, 15, 20, 25, 30日
    features['days_to_next_gotobi'] = -1
    features['days_from_prev_gotobi'] = -1
    
    # Calculate features for each timestamp
    for ts in timestamps:
        jst_ts = ts.tz_localize('UTC').tz_convert('Asia/Tokyo') if not ts.tz else ts.tz_convert('Asia/Tokyo')
        unix_ts = int(jst_ts.timestamp())
        
        # Check if current date is gotobi
        features.at[ts, 'is_gotobi'] = detector.is_valid_gotobi(unix_ts)
        
        # Check if current date is a potential gotobi (5の倍数日)
        features.at[ts, 'is_gotobi_candidate'] = detector.is_gotobi(jst_ts.day)
        
        # Calculate days to next and from previous gotobi
        current_date = jst_ts.date()
        
        # Find next gotobi
        next_date = current_date
        days_to_next = 0
        while days_to_next < 31:  # Maximum one month search
            next_date += timedelta(days=1)
            next_ts = int(datetime.combine(next_date, time(9, 0)).replace(tzinfo=detector.jst).timestamp())
            if detector.is_valid_gotobi(next_ts):
                features.at[ts, 'days_to_next_gotobi'] = days_to_next + 1
                break
            days_to_next += 1
            
        # Find previous gotobi
        prev_date = current_date
        days_from_prev = 0
        while days_from_prev < 31:  # Maximum one month search
            prev_date -= timedelta(days=1)
            prev_ts = int(datetime.combine(prev_date, time(9, 0)).replace(tzinfo=detector.jst).timestamp())
            if detector.is_valid_gotobi(prev_ts):
                features.at[ts, 'days_from_prev_gotobi'] = days_from_prev + 1
                break
            days_from_prev += 1
    
    return features


def calculate_all_time_features(
    timestamps: pd.DatetimeIndex,
    holiday_calendar: Optional[pd.DataFrame] = None,
    economic_calendar: Optional[pd.DataFrame] = None,
    news_events: Optional[pd.DataFrame] = None,
    volatility_data: Optional[pd.DataFrame] = None,
    sessions: Optional[Dict[str, Dict[str, time]]] = None,
    impact_windows: List[int] = [5, 15, 30, 60],
    peak_vol_hour: int = 14,
    lunch_times: Optional[Dict[str, List[int]]] = None
) -> pd.DataFrame:
    """
    Calculate all time and event related features in a comprehensive manner.
    
    Args:
        timestamps: DatetimeIndex of timestamps (UTC)
        holiday_calendar: Optional DataFrame with holiday information
        economic_calendar: Optional DataFrame with economic events
        news_events: Optional DataFrame with unscheduled news/events
        volatility_data: Optional DataFrame with historical volatility info
        sessions: Optional dictionary of trading sessions
        impact_windows: List of time windows for events
        peak_vol_hour: Hour with typically high volatility (UTC)
        lunch_times: Optional dictionary of lunch break hours by market
    
    Returns:
        DataFrame with all time/event features
    """
    # 1. Basic time features
    features = calculate_time_features(timestamps)
    
    # 2. Advanced time features
    advanced_features = calculate_advanced_time_features(timestamps)
    # Remove duplicate columns before concatenation
    duplicate_cols = features.columns.intersection(advanced_features.columns)
    advanced_features = advanced_features.drop(columns=duplicate_cols)
    features = pd.concat([features, advanced_features], axis=1)
    
    # 3. Session features (with DST support)
    session_features = calculate_session_features(
        timestamps,
        sessions=sessions,
        peak_vol_hour=peak_vol_hour,
        lunch_times=lunch_times or DEFAULT_LUNCH_TIMES
    )
    # Remove duplicate columns before concatenation
    duplicate_cols = features.columns.intersection(session_features.columns)
    session_features = session_features.drop(columns=duplicate_cols)
    features = pd.concat([features, session_features], axis=1)
    
    # 4. Goto date features
    goto_features = calculate_goto_features(timestamps)
    # Remove duplicate columns before concatenation
    duplicate_cols = features.columns.intersection(goto_features.columns)
    goto_features = goto_features.drop(columns=duplicate_cols)
    features = pd.concat([features, goto_features], axis=1)
    
    # 5. Holiday features
    if holiday_calendar is not None:
        holiday_features = calculate_holiday_features(timestamps, holiday_calendar)
        # Remove duplicate columns before concatenation
        duplicate_cols = features.columns.intersection(holiday_features.columns)
        holiday_features = holiday_features.drop(columns=duplicate_cols)
        features = pd.concat([features, holiday_features], axis=1)
    
    # 6. Economic calendar and news features
    if economic_calendar is not None:
        event_features = calculate_economic_calendar_features(
            timestamps,
            economic_calendar,
            impact_windows=impact_windows
        )
        # Remove duplicate columns before concatenation
        duplicate_cols = features.columns.intersection(event_features.columns)
        event_features = event_features.drop(columns=duplicate_cols)
        features = pd.concat([features, event_features], axis=1)
    
    # 7. Volatility regime features
    if volatility_data is not None:
        vol_features = calculate_volatility_regime_features(
            timestamps,
            volatility_data=volatility_data
        )
        # Remove duplicate columns before concatenation
        duplicate_cols = features.columns.intersection(vol_features.columns)
        vol_features = vol_features.drop(columns=duplicate_cols)
        features = pd.concat([features, vol_features], axis=1)
    
    return features


# =============================================================================
#  Legacy Functions for DST
# =============================================================================

def is_dst_london(dt: datetime) -> bool:
    """Check if London is in DST (single datetime version)."""
    london_time = dt.astimezone(ZoneInfo("Europe/London"))
    return london_time.dst() != timedelta(0)


def is_dst_newyork(dt: datetime) -> bool:
    """Check if New York is in DST (single datetime version)."""
    ny_time = dt.astimezone(ZoneInfo("America/New_York"))
    return ny_time.dst() != timedelta(0)


def get_market_hours(dt: datetime) -> dict:
    """
    Original single-timestamp version of get_market_hours (for reference).
    Automatically adjusts session times for Tokyo, London, NY based on DST.
    """
    # Tokyo (no DST)
    tokyo_start = 0   # UTC 0:00
    tokyo_end = 9     # UTC 9:00
    
    # London
    if is_dst_london(dt):
        london_start, london_end = 7, 15  # BST
    else:
        london_start, london_end = 8, 16  # GMT
    
    # New York
    if is_dst_newyork(dt):
        ny_start, ny_end = 12, 21  # EDT
    else:
        ny_start, ny_end = 13, 22  # EST
    
    return {
        'tokyo': {'start': time(tokyo_start, 0), 'end': time(tokyo_end, 0)},
        'london': {'start': time(london_start, 0), 'end': time(london_end, 0)},
        'ny': {'start': time(ny_start, 0), 'end': time(ny_end, 0)}
    }


def calculate_event_features(
    timestamps: pd.DatetimeIndex,
    economic_calendar: pd.DataFrame,
    news_events: Optional[pd.DataFrame] = None,
    impact_windows: List[int] = [5, 15, 30, 60],
    importance_levels: List[str] = ['high', 'medium', 'low']
) -> pd.DataFrame:
    """
    Calculate features related to economic events and news.
    
    Args:
        timestamps: DatetimeIndex of timestamps
        economic_calendar: DataFrame with scheduled economic events
            Required columns: ['datetime', 'importance', 'event', 'currency']
        news_events: Optional DataFrame with unscheduled news/events
            Required columns: ['datetime', 'importance', 'event', 'impact_score']
        impact_windows: List of minutes before/after event to consider
        importance_levels: List of importance levels to consider
    
    Returns:
        DataFrame with event-related features
    """
    features = pd.DataFrame(index=timestamps)
    
    # Ensure datetime index
    if not pd.api.types.is_datetime64_any_dtype(economic_calendar.index):
        economic_calendar.index = pd.to_datetime(economic_calendar.index)
    
    # Process scheduled economic events
    for importance in importance_levels:
        # Filter events by importance
        events = economic_calendar[
            economic_calendar['importance'].str.lower() == importance.lower()
        ]
        
        # Create features for different time windows
        for window in impact_windows:
            before_col = f'{importance}_event_before_{window}min'
            after_col = f'{importance}_event_after_{window}min'
            features[before_col] = False
            features[after_col] = False
            
            for event_time in events.index:
                # Time windows
                before_window = (
                    timestamps >= event_time - pd.Timedelta(minutes=window)
                ) & (timestamps <= event_time)
                after_window = (
                    timestamps >= event_time
                ) & (timestamps <= event_time + pd.Timedelta(minutes=window))
                
                # Set flags
                features.loc[before_window, before_col] = True
                features.loc[after_window, after_col] = True
        
        # Count upcoming events (next 24h)
        features[f'upcoming_{importance}_events_24h'] = 0
        for ts in timestamps:
            next_24h = (
                (events.index > ts) & 
                (events.index <= ts + pd.Timedelta(hours=24))
            )
            features.at[ts, f'upcoming_{importance}_events_24h'] = next_24h.sum()
    
    # Process unscheduled news events if provided
    if news_events is not None:
        if not pd.api.types.is_datetime64_any_dtype(news_events.index):
            news_events.index = pd.to_datetime(news_events.index)
        
        # Create impact score features
        for window in impact_windows:
            col = f'news_impact_score_{window}min'
            features[col] = 0.0
            
            for event_time, event in news_events.iterrows():
                # Time window
                time_window = (
                    timestamps >= event_time
                ) & (timestamps <= event_time + pd.Timedelta(minutes=window))
                
                # Add impact score (decay with time)
                if 'impact_score' in event:
                    time_since_event = (
                        timestamps[time_window] - event_time
                    ).total_seconds() / 60
                    decay_factor = 1 - (time_since_event / window)
                    features.loc[time_window, col] += event['impact_score'] * decay_factor
    
    # Add features for specific event types
    currency_events = {
        'USD': ['NFP', 'CPI', 'FOMC'],
        'EUR': ['ECB', 'CPI', 'PMI'],
        'GBP': ['BOE', 'CPI', 'GDP'],
        'JPY': ['BOJ', 'CPI', 'GDP']
    }
    
    for currency, events in currency_events.items():
        for event in events:
            # Filter relevant events
            relevant_events = economic_calendar[
                (economic_calendar['currency'] == currency) &
                (economic_calendar['event'].str.contains(event, case=False))
            ]
            
            # Create event window features
            for window in impact_windows:
                col = f'{currency}_{event}_window_{window}min'
                features[col] = False
                
                for event_time in relevant_events.index:
                    event_window = (
                        timestamps >= event_time - pd.Timedelta(minutes=window)
                    ) & (timestamps <= event_time + pd.Timedelta(minutes=window))
                    features.loc[event_window, col] = True
    
    return features


def calculate_volatility_regime_features(timestamps: pd.DatetimeIndex, volatility_data: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """Calculate volatility regime features."""
    features = pd.DataFrame(index=timestamps)
    
    # Basic time-based volatility expectations
    features['is_monday'] = (timestamps.dayofweek == 0)
    features['is_friday'] = (timestamps.dayofweek == 4)
    
    # Expected high volatility periods
    features['expected_high_vol'] = (
        features['is_monday'] |  # Monday effect
        features['is_friday'] |  # Friday effect
        (timestamps.hour == 14)  # Example peak volatility hour (14:00 UTC)
    )
    
    if volatility_data is not None:
        if not pd.api.types.is_datetime64_any_dtype(volatility_data.index):
            volatility_data.index = pd.to_datetime(volatility_data.index)
        
        # Ensure timezone awareness
        if not volatility_data.index.tz and timestamps.tz:
            volatility_data.index = volatility_data.index.tz_localize(timestamps.tz)
        elif volatility_data.index.tz and volatility_data.index.tz != timestamps.tz:
            volatility_data.index = volatility_data.index.tz_convert(timestamps.tz)
        
        # Resample volatility data to match timestamps if needed
        vol_resampled = volatility_data.reindex(timestamps, method='ffill')
        
        # Add volatility regime indicators if available
        if 'regime' in vol_resampled.columns:
            features['volatility_regime'] = vol_resampled['regime']
        
        # Add rolling volatility levels if available
        if 'volatility' in vol_resampled.columns:
            features['historical_volatility'] = vol_resampled['volatility']
            
            # Categorize current volatility level
            vol_quantiles = vol_resampled['volatility'].quantile([0.25, 0.75])
            features['vol_regime'] = 'medium'
            features.loc[
                vol_resampled['volatility'] <= vol_quantiles[0.25], 
                'vol_regime'
            ] = 'low'
            features.loc[
                vol_resampled['volatility'] >= vol_quantiles[0.75], 
                'vol_regime'
            ] = 'high'
    
    return features


def test_timezone_handling():
    """Test handling of different timezone inputs."""
    # Create timestamps with different timezones
    timestamps_utc = pd.date_range('2024-01-01', periods=24, freq='h', tz='UTC')
    timestamps_est = timestamps_utc.tz_convert('America/New_York')
    
    features_utc = calculate_time_features(timestamps_utc)
    features_est = calculate_time_features(timestamps_est)
    
    # Convert to UTC for comparison
    features_est_utc = features_est.copy()
    features_est_utc.index = features_est_utc.index.tz_convert('UTC')
    
    # Hours should be different due to timezone conversion
    assert not (features_utc['hour'].reset_index(drop=True) == 
                features_est['hour'].reset_index(drop=True)).all()


if __name__ == "__main__":
    # Example usage
    from phunt_api import PHuntAPI
    import pandas as pd
    
    # Create sample data
    api = PHuntAPI(debug=True)
    df = api.get_dataset("USDJPY_1MIN")
    timestamps = pd.DatetimeIndex(df.index)
    
    # Create sample calendars
    holiday_calendar = pd.DataFrame(
        index=pd.date_range(timestamps.min(), timestamps.max(), freq='D')
    )
    economic_calendar = pd.DataFrame({
        'importance': ['high', 'medium', 'low'],
        'event': ['FOMC', 'CPI', 'PMI'],
        'currency': ['USD', 'USD', 'EUR']
    }, index=pd.date_range(timestamps.min(), timestamps.max(), freq='D'))
    
    # Calculate features
    features = calculate_all_time_features(
        timestamps,
        holiday_calendar=holiday_calendar,
        economic_calendar=economic_calendar
    )
    
    print("Feature columns:", features.columns.tolist())
    print("\nSample features:")
    print(features.head())
