import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from .price_features import (
    calculate_returns,
    calculate_moving_averages,
    calculate_bollinger_bands,
    calculate_volatility,
    calculate_statistical_moments,
    calculate_rolling_correlation,
    calculate_rolling_beta,
    calculate_range_position,
    calculate_relative_high_position,
    calculate_relative_low_position,
    calculate_rsi,
    calculate_macd,
    calculate_atr,
    calculate_obv,
    calculate_vwap,
    calculate_price_features
)

# =============================================================================
#  Fixtures
# =============================================================================

@pytest.fixture
def sample_price_series():
    """Create a sample price series for testing."""
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    # Generate synthetic prices with some trend and noise
    prices = 100 * (1 + np.random.randn(len(dates)) * 0.02).cumprod()
    return pd.Series(prices, index=dates)

@pytest.fixture
def sample_ohlc_data():
    """Create sample OHLC data for testing."""
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    n = len(dates)
    
    # Generate synthetic OHLC data
    base_price = 100 * (1 + np.random.randn(n) * 0.02).cumprod()
    high = base_price * (1 + abs(np.random.randn(n) * 0.01))
    low = base_price * (1 - abs(np.random.randn(n) * 0.01))
    close = base_price * (1 + np.random.randn(n) * 0.005)
    volume = np.random.randint(1000, 10000, n)
    
    return pd.DataFrame({
        'open': base_price,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume
    }, index=dates)

@pytest.fixture
def sample_benchmark_returns():
    """Create sample benchmark returns for testing."""
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    returns = np.random.randn(len(dates)) * 0.01
    return pd.Series(returns, index=dates)

# =============================================================================
#  Test Basic Features
# =============================================================================

def test_calculate_returns(sample_price_series):
    """Test return calculation function."""
    periods = [1, 5, 10]
    returns = calculate_returns(sample_price_series, periods=periods)
    
    assert isinstance(returns, pd.DataFrame)
    assert all(f'return_{p}' in returns.columns for p in periods)
    assert len(returns) == len(sample_price_series)
    
    # Test arithmetic returns
    arith_returns = calculate_returns(sample_price_series, periods=1, method='arithmetic')
    assert not arith_returns.isnull().all().iloc[0]
    
    # Test log returns
    log_returns = calculate_returns(sample_price_series, periods=1, method='log')
    assert not log_returns.isnull().all().iloc[0]
    
    # Test invalid method
    with pytest.raises(ValueError):
        calculate_returns(sample_price_series, periods=1, method='invalid')

def test_calculate_moving_averages(sample_price_series):
    """Test moving average calculation."""
    windows = [5, 10, 20]
    mas = calculate_moving_averages(sample_price_series, windows=windows)
    
    assert isinstance(mas, pd.DataFrame)
    assert all(f'ma_{w}' in mas.columns for w in windows)
    assert len(mas) == len(sample_price_series)
    
    # Test single window
    single_ma = calculate_moving_averages(sample_price_series, windows=5)
    assert 'ma_5' in single_ma.columns
    
    # Verify calculation
    window = 5
    manual_ma = sample_price_series.rolling(window=window).mean()
    pd.testing.assert_series_equal(
        mas[f'ma_{window}'],
        manual_ma,
        check_names=False
    )

def test_calculate_bollinger_bands(sample_price_series):
    """Test Bollinger Bands calculation."""
    window = 20
    num_std = 2.0
    bb = calculate_bollinger_bands(sample_price_series, window=window, num_std=num_std)
    
    assert isinstance(bb, pd.DataFrame)
    assert all(col in bb.columns for col in ['bb_middle', 'bb_upper', 'bb_lower'])
    assert len(bb) == len(sample_price_series)
    
    # Verify calculations
    ma = sample_price_series.rolling(window=window).mean()
    std = sample_price_series.rolling(window=window).std()
    
    pd.testing.assert_series_equal(bb['bb_middle'], ma, check_names=False)
    pd.testing.assert_series_equal(
        bb['bb_upper'],
        ma + (std * num_std),
        check_names=False
    )
    pd.testing.assert_series_equal(
        bb['bb_lower'],
        ma - (std * num_std),
        check_names=False
    )

def test_calculate_volatility(sample_price_series):
    """Test volatility calculation."""
    windows = [5, 10, 20]
    vol = calculate_volatility(sample_price_series, windows=windows)
    
    assert isinstance(vol, pd.DataFrame)
    assert all(f'volatility_{w}' in vol.columns for w in windows)
    assert len(vol) == len(sample_price_series)
    
    # Test both return methods
    vol_arith = calculate_volatility(sample_price_series, windows=5, returns_method='arithmetic')
    vol_log = calculate_volatility(sample_price_series, windows=5, returns_method='log')
    
    assert not vol_arith.isnull().all().iloc[0]
    assert not vol_log.isnull().all().iloc[0]

# =============================================================================
#  Test Statistical Features
# =============================================================================

def test_calculate_statistical_moments(sample_price_series):
    """Test statistical moments calculation."""
    returns = sample_price_series.pct_change()
    windows = [20, 60]
    moments = calculate_statistical_moments(returns, windows=windows)
    
    assert isinstance(moments, pd.DataFrame)
    expected_cols = [
        'rolling_mean', 'rolling_var', 'rolling_skew',
        'rolling_kurt', 'rolling_jb'
    ]
    assert all(
        f'{col}_{w}' in moments.columns
        for col in expected_cols
        for w in windows
    )

def test_calculate_rolling_correlation(sample_price_series, sample_benchmark_returns):
    """Test rolling correlation calculation."""
    windows = [20, 60]
    corr = calculate_rolling_correlation(
        sample_price_series,
        sample_benchmark_returns,
        windows=windows
    )
    
    assert isinstance(corr, pd.DataFrame)
    assert all(f'rolling_corr_{w}' in corr.columns for w in windows)
    assert len(corr) == len(sample_price_series)
    
    # Verify correlation is between -1 and 1
    for w in windows:
        assert corr[f'rolling_corr_{w}'].dropna().between(-1, 1).all()

def test_calculate_rolling_beta(sample_price_series, sample_benchmark_returns):
    """Test rolling beta calculation."""
    windows = [20, 60]
    beta = calculate_rolling_beta(
        sample_price_series.pct_change(),
        sample_benchmark_returns,
        windows=windows
    )
    
    assert isinstance(beta, pd.DataFrame)
    assert all(f'rolling_beta_{w}' in beta.columns for w in windows)
    assert all(f'rolling_r2_{w}' in beta.columns for w in windows)
    
    # Verify R-squared is between 0 and 1
    for w in windows:
        assert beta[f'rolling_r2_{w}'].dropna().between(0, 1).all()

# =============================================================================
#  Test Range-Based Features
# =============================================================================

def test_calculate_range_position(sample_ohlc_data):
    """Test range position calculation."""
    window = 20
    range_pos = calculate_range_position(sample_ohlc_data, window=window)
    
    assert isinstance(range_pos, pd.Series)
    assert len(range_pos) == len(sample_ohlc_data)
    
    # Verify values are between 0 and 1
    assert range_pos.dropna().between(0, 1).all()

def test_calculate_relative_positions(sample_ohlc_data):
    """Test relative high/low position calculations."""
    window = 20
    
    high_pos = calculate_relative_high_position(sample_ohlc_data, window=window)
    low_pos = calculate_relative_low_position(sample_ohlc_data, window=window)
    
    assert isinstance(high_pos, pd.Series)
    assert isinstance(low_pos, pd.Series)
    
    # Verify high position is <= 1 (current price / highest high)
    assert high_pos.dropna().le(1).all()
    
    # Verify low position is >= 1 (current price / lowest low)
    assert low_pos.dropna().ge(1).all()

# =============================================================================
#  Test Technical Indicators
# =============================================================================

def test_calculate_rsi(sample_price_series):
    """Test RSI calculation."""
    window = 14
    rsi = calculate_rsi(sample_price_series, window=window)
    
    assert isinstance(rsi, pd.Series)
    assert len(rsi) == len(sample_price_series)
    
    # Verify RSI is between 0 and 100
    assert rsi.dropna().between(0, 100).all()

def test_calculate_macd(sample_price_series):
    """Test MACD calculation."""
    macd = calculate_macd(sample_price_series)
    
    assert isinstance(macd, pd.DataFrame)
    assert all(col in macd.columns for col in ['macd', 'macd_signal', 'macd_hist'])
    assert len(macd) == len(sample_price_series)
    
    # Verify histogram is MACD - Signal
    pd.testing.assert_series_equal(
        macd['macd_hist'],
        macd['macd'] - macd['macd_signal'],
        check_names=False
    )

def test_calculate_atr(sample_ohlc_data):
    """Test ATR calculation."""
    window = 14
    atr = calculate_atr(sample_ohlc_data, window=window)
    
    assert isinstance(atr, pd.Series)
    assert len(atr) == len(sample_ohlc_data)
    
    # Verify ATR is non-negative
    assert atr.dropna().ge(0).all()

def test_calculate_obv(sample_ohlc_data):
    """Test OBV calculation."""
    obv = calculate_obv(sample_ohlc_data)
    
    assert isinstance(obv, pd.Series)
    assert len(obv) == len(sample_ohlc_data)

def test_calculate_vwap(sample_ohlc_data):
    """Test VWAP calculation."""
    window = 20
    vwap = calculate_vwap(sample_ohlc_data, window=window)
    
    assert isinstance(vwap, pd.Series)
    assert len(vwap) == len(sample_ohlc_data)

# =============================================================================
#  Test Main Feature Aggregation
# =============================================================================

def test_calculate_price_features(
    sample_price_series,
    sample_ohlc_data,
    sample_benchmark_returns
):
    """Test main price feature calculation function."""
    features = calculate_price_features(
        sample_price_series,
        ohlc=sample_ohlc_data,
        benchmark_returns=sample_benchmark_returns
    )
    
    assert isinstance(features, pd.DataFrame)
    assert len(features) == len(sample_price_series)
    
    # Test without OHLC data
    features_no_ohlc = calculate_price_features(
        sample_price_series,
        benchmark_returns=sample_benchmark_returns
    )
    assert isinstance(features_no_ohlc, pd.DataFrame)
    
    # Test without benchmark returns
    features_no_bench = calculate_price_features(
        sample_price_series,
        ohlc=sample_ohlc_data
    )
    assert isinstance(features_no_bench, pd.DataFrame)

# =============================================================================
#  Test Edge Cases
# =============================================================================

def test_empty_series():
    """Test behavior with empty series."""
    empty_series = pd.Series([], dtype=float)
    
    # Test basic features
    returns = calculate_returns(empty_series)
    assert len(returns) == 0
    
    mas = calculate_moving_averages(empty_series)
    assert len(mas) == 0
    
    bb = calculate_bollinger_bands(empty_series)
    assert len(bb) == 0

def test_single_value():
    """Test behavior with single value."""
    single_value = pd.Series([100.0], index=[pd.Timestamp('2024-01-01')])
    
    # Test basic features
    returns = calculate_returns(single_value)
    assert len(returns) == 1
    assert returns.iloc[0].isnull().all()
    
    mas = calculate_moving_averages(single_value)
    assert len(mas) == 1
    assert mas.iloc[0].isnull().all()

def test_nan_handling():
    """Test handling of NaN values."""
    # Create a longer series with some NaN values but enough valid data for calculations
    prices = pd.Series([
        100.0, 101.0, np.nan, 102.0, 103.0, 104.0, 105.0, np.nan,
        107.0, 108.0, 109.0, 110.0, np.nan, 112.0, 113.0
    ])
    
    # Test returns calculation
    returns = calculate_returns(prices, periods=[1, 2])
    # Verify that we have some valid values
    assert not returns.isnull().all().all()  # Not all columns should be all NaN
    assert returns.notna().any().all()       # Each column should have some valid values
    
    # Test moving averages with smaller windows
    mas = calculate_moving_averages(prices, windows=[2, 3])
    # Verify that we have some valid values
    assert not mas.isnull().all().all()      # Not all columns should be all NaN
    assert mas.notna().any().all()           # Each column should have some valid values
    
    # Test Bollinger Bands with smaller window
    bb = calculate_bollinger_bands(prices, window=3)
    # Verify that we have some valid values
    assert not bb.isnull().all().all()       # Not all columns should be all NaN
    assert bb.notna().any().all()            # Each column should have some valid values
    
    # Additional verification: check specific known positions
    # After consecutive valid values, we should have valid MAs
    assert not np.isnan(mas['ma_2'].iloc[4])  # Should have valid 2-period MA
    assert not np.isnan(mas['ma_3'].iloc[6])  # Should have valid 3-period MA
    
    # Verify that NaN values are properly propagated
    assert np.isnan(mas['ma_2'].iloc[2])    # NaN input should result in NaN output
    assert np.isnan(bb['bb_middle'].iloc[2])

# =============================================================================
#  Additional Test Cases
# =============================================================================

def test_returns_with_zero_prices():
    """Test return calculation with zero prices."""
    prices = pd.Series([0.0, 0.0, 0.0, 1.0, 2.0])
    returns = calculate_returns(prices, periods=[1, 2])
    
    # First return should be NaN (0/0)
    assert np.isnan(returns['return_1'].iloc[0])
    # Return from 0 to positive should be inf
    assert np.isinf(returns['return_1'].iloc[3])

def test_moving_averages_with_constant_price():
    """Test moving averages with constant price series."""
    constant_price = pd.Series([100.0] * 10)
    mas = calculate_moving_averages(constant_price, windows=[2, 3, 5])
    
    # All MAs should equal the constant price after window-1 periods
    for window in [2, 3, 5]:
        assert (mas[f'ma_{window}'].iloc[window:] == 100.0).all()

def test_bollinger_bands_with_constant_price():
    """Test Bollinger Bands with constant price series."""
    constant_price = pd.Series([100.0] * 30)
    bb = calculate_bollinger_bands(constant_price, window=20, num_std=2.0)
    
    # For constant price, all bands should be equal after window-1 periods
    assert (bb['bb_middle'].iloc[19:] == bb['bb_upper'].iloc[19:]).all()
    assert (bb['bb_middle'].iloc[19:] == bb['bb_lower'].iloc[19:]).all()

def test_volatility_edge_cases():
    """Test volatility calculation with edge cases."""
    # Test with constant prices (should give zero volatility)
    constant_price = pd.Series([100.0] * 30)
    vol = calculate_volatility(constant_price, windows=[5, 10])
    
    # Skip initial NaN values and check that remaining values are 0
    assert vol['volatility_5'].iloc[5:].eq(0).all()
    assert vol['volatility_10'].iloc[10:].eq(0).all()
    
    # Test with extreme price changes
    extreme_prices = pd.Series([100.0, 200.0, 50.0, 300.0, 25.0])
    vol_extreme = calculate_volatility(extreme_prices, windows=[2])
    # Skip first value (NaN) and check that remaining values are positive
    assert not vol_extreme.iloc[2:].isnull().all().all()
    assert (vol_extreme.iloc[2:] > 0).all().all()

def test_statistical_moments_edge_cases():
    """Test statistical moments with edge cases."""
    # Test with constant returns (should give zero skewness and kurtosis)
    constant_returns = pd.Series([0.01] * 30)
    moments = calculate_statistical_moments(constant_returns, windows=[10])
    
    # Skip initial NaN values and check that remaining values are close to 0
    assert moments['rolling_skew_10'].iloc[9:].abs().lt(1e-10).all()
    assert moments['rolling_kurt_10'].iloc[9:].abs().lt(1e-10).all()
    
    # Test with non-constant returns
    varying_returns = pd.Series([0.01, -0.01, 0.02, -0.02] * 10)
    moments_varying = calculate_statistical_moments(varying_returns, windows=[10])
    assert not moments_varying.isnull().all().all()

def test_correlation_edge_cases():
    """Test correlation calculation with edge cases."""
    # Test with perfectly correlated series
    x = pd.Series(range(30))
    y = pd.Series(range(30))
    corr = calculate_rolling_correlation(x, y, windows=[5])
    assert corr['rolling_corr_5'].iloc[4:].round(10).eq(1.0).all()
    
    # Test with perfectly negatively correlated series
    y_neg = pd.Series(range(30, 0, -1))
    corr_neg = calculate_rolling_correlation(x, y_neg, windows=[5])
    assert corr_neg['rolling_corr_5'].iloc[4:].round(10).eq(-1.0).all()

def test_beta_edge_cases():
    """Test beta calculation with edge cases."""
    # Test with zero variance benchmark (should give NaN beta)
    asset_returns = pd.Series([0.01, -0.01, 0.02, -0.02] * 10)
    bench_returns = pd.Series([0.0] * 40)
    beta = calculate_rolling_beta(asset_returns, bench_returns, windows=[5])
    assert beta['rolling_beta_5'].isnull().all()

def test_rsi_edge_cases():
    """Test RSI calculation with edge cases."""
    # Test with all positive changes
    up_prices = pd.Series([100.0 + i for i in range(20)])
    rsi_up = calculate_rsi(up_prices, window=14)
    assert rsi_up.iloc[-1] == 100  # Should be 100 for all positive changes
    
    # Test with all negative changes
    down_prices = pd.Series([100.0 - i for i in range(20)])
    rsi_down = calculate_rsi(down_prices, window=14)
    assert rsi_down.iloc[-1] == 0  # Should be 0 for all negative changes
    
    # Test with constant prices
    constant_prices = pd.Series([100.0] * 20)
    rsi_constant = calculate_rsi(constant_prices, window=14)
    assert rsi_constant.iloc[-1] == 50  # Should be 50 for constant prices

def test_macd_edge_cases():
    """Test MACD calculation with edge cases."""
    # Test with constant price (should give zero MACD and signal)
    constant_price = pd.Series([100.0] * 50)
    macd = calculate_macd(constant_price)
    assert (macd['macd'].iloc[25:] == 0).all()
    assert (macd['macd_signal'].iloc[33:] == 0).all()

def test_atr_edge_cases():
    """Test ATR calculation with edge cases."""
    # Test with constant OHLC (should give zero ATR)
    constant_data = pd.DataFrame({
        'high': [100.0] * 20,
        'low': [100.0] * 20,
        'close': [100.0] * 20
    })
    atr = calculate_atr(constant_data, window=14)
    assert (atr.iloc[13:] == 0).all()

def test_obv_edge_cases():
    """Test OBV calculation with edge cases."""
    # Test with constant price but varying volume
    data = pd.DataFrame({
        'close': [100.0] * 10,
        'volume': range(1000, 1100, 10)
    })
    obv = calculate_obv(data)
    assert (obv == 0).all()  # No price change means no OBV change

def test_vwap_edge_cases():
    """Test VWAP calculation with edge cases."""
    # Test with zero volume
    data = pd.DataFrame({
        'high': [100.0] * 10,
        'low': [99.0] * 10,
        'close': [99.5] * 10,
        'volume': [0.0] * 10
    })
    vwap = calculate_vwap(data)
    assert vwap.isnull().all()  # Should be NaN when volume is zero

def test_price_features_input_validation():
    """Test input validation in price features calculation."""
    # Test with invalid price series
    with pytest.raises(TypeError, match="prices must be a pandas Series"):
        calculate_price_features([1, 2, 3])  # List instead of Series
    
    # Test with invalid OHLC data
    invalid_ohlc = pd.DataFrame({'close': [1, 2, 3]})  # Missing required columns
    with pytest.raises(ValueError, match="OHLC data is missing required columns"):
        calculate_price_features(
            pd.Series([1, 2, 3]),
            ohlc=invalid_ohlc
        )

if __name__ == '__main__':
    pytest.main([__file__]) 