import pytest
import pandas as pd
import numpy as np
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

from .time_features import (
    is_dst_in_bulk,
    get_sessions_for_all_timestamps,
    is_session_active_vec,
    calculate_session_features,
    calculate_time_features,
    calculate_advanced_time_features,
    calculate_holiday_features,
    calculate_economic_calendar_features,
    calculate_all_time_features,
    calculate_goto_features,
    is_dst_london,
    is_dst_newyork,
    get_market_hours
)

# =============================================================================
#  Fixtures
# =============================================================================

@pytest.fixture
def sample_timestamps():
    """Create a sample DatetimeIndex for testing."""
    return pd.date_range(
        start='2024-01-01',
        end='2024-01-07',
        freq='h',
        tz='UTC'
    )

@pytest.fixture
def sample_holiday_calendar():
    """Create a sample holiday calendar for testing."""
    dates = pd.date_range('2024-01-01', '2024-01-07', freq='D')
    holidays = pd.DataFrame(
        index=dates,
        data={
            'holiday_name': ['New Year', None, None, None, 'Friday Holiday', None, None]
        }
    )
    return holidays

@pytest.fixture
def sample_economic_calendar():
    """Create a sample economic calendar for testing."""
    events = pd.DataFrame([
        {'importance': 'high', 'event': 'FOMC', 'currency': 'USD'},
        {'importance': 'medium', 'event': 'CPI', 'currency': 'EUR'},
        {'importance': 'low', 'event': 'PMI', 'currency': 'GBP'}
    ], index=pd.date_range('2024-01-01', '2024-01-03', freq='D'))
    return events

@pytest.fixture
def sample_sessions():
    """Create sample trading sessions for testing."""
    return {
        'tokyo': {'start': time(0, 0), 'end': time(9, 0)},
        'london': {'start': time(8, 0), 'end': time(16, 0)},
        'ny': {'start': time(13, 0), 'end': time(22, 0)}
    }

@pytest.fixture
def goto_test_timestamps():
    """Create timestamps specifically for testing goto date features."""
    # Include various scenarios:
    # - Regular gotobi (5, 10, 15, 20, 25, 30)
    # - Month end
    # - Holidays (weekends and Japanese holidays)
    dates = [
        '2024-01-05',  # Regular gotobi (Friday)
        '2024-01-06',  # Weekend
        '2024-01-07',  # Weekend
        '2024-01-10',  # Regular gotobi (Wednesday)
        '2024-01-15',  # Regular gotobi (Monday)
        '2024-01-20',  # Regular gotobi (Saturday)
        '2024-01-22',  # Monday after weekend gotobi
        '2024-01-25',  # Regular gotobi (Thursday)
        '2024-01-30',  # Regular gotobi (Tuesday)
        '2024-01-31',  # Month end (Wednesday)
    ]
    return pd.DatetimeIndex([
        pd.Timestamp(date).tz_localize('UTC')
        for date in dates
    ])

# =============================================================================
#  Test DST Functions
# =============================================================================

def test_is_dst_in_bulk():
    """Test bulk DST checking function."""
    timestamps = pd.date_range(
        '2024-03-01',
        '2024-04-01',
        freq='D',
        tz='UTC'
    )
    
    # Test London DST
    london_dst = is_dst_in_bulk(timestamps, "Europe/London")
    assert isinstance(london_dst, pd.Series)
    assert not london_dst.iloc[0]  # March 1st - not DST
    
    # Test NY DST
    ny_dst = is_dst_in_bulk(timestamps, "America/New_York")
    assert isinstance(ny_dst, pd.Series)
    assert not ny_dst.iloc[0]  # March 1st - not DST

def test_is_dst_london():
    """Test London DST checking for single timestamp."""
    winter_date = datetime(2024, 1, 1, tzinfo=ZoneInfo('UTC'))
    summer_date = datetime(2024, 7, 1, tzinfo=ZoneInfo('UTC'))
    
    assert not is_dst_london(winter_date)
    assert is_dst_london(summer_date)

def test_is_dst_newyork():
    """Test New York DST checking for single timestamp."""
    winter_date = datetime(2024, 1, 1, tzinfo=ZoneInfo('UTC'))
    summer_date = datetime(2024, 7, 1, tzinfo=ZoneInfo('UTC'))
    
    assert not is_dst_newyork(winter_date)
    assert is_dst_newyork(summer_date)

# =============================================================================
#  Test Session Functions
# =============================================================================

def test_get_sessions_for_all_timestamps(sample_timestamps):
    """Test getting session times for multiple timestamps."""
    session_info = get_sessions_for_all_timestamps(sample_timestamps)
    
    assert isinstance(session_info, pd.DataFrame)
    assert all(col in session_info.columns for col in [
        'tokyo_start', 'tokyo_end',
        'london_start', 'london_end',
        'ny_start', 'ny_end'
    ])

def test_is_session_active_vec(sample_timestamps):
    """Test vectorized session activity checking."""
    session_start = pd.Series([time(8, 0)] * len(sample_timestamps))
    session_end = pd.Series([time(16, 0)] * len(sample_timestamps))
    
    is_active = is_session_active_vec(
        sample_timestamps,
        session_start,
        session_end
    )
    
    assert isinstance(is_active, pd.Series)
    assert is_active.dtype == bool

def test_calculate_session_features(sample_timestamps, sample_sessions):
    """Test calculation of session-based features."""
    features = calculate_session_features(
        sample_timestamps,
        sessions=sample_sessions
    )
    
    assert isinstance(features, pd.DataFrame)
    assert 'tokyo_session' in features.columns
    assert 'london_session' in features.columns
    assert 'ny_session' in features.columns
    assert 'active_sessions' in features.columns

# =============================================================================
#  Test Time Feature Functions
# =============================================================================

def test_calculate_time_features(sample_timestamps):
    """Test calculation of basic time features."""
    features = calculate_time_features(sample_timestamps)
    
    assert isinstance(features, pd.DataFrame)
    expected_columns = [
        'hour', 'minute', 'day_of_week', 'day_of_month',
        'day_of_year', 'week_of_year', 'month', 'quarter'
    ]
    assert all(col in features.columns for col in expected_columns)
    
    # Test specific values
    assert features['hour'].min() >= 0
    assert features['hour'].max() <= 23
    assert features['minute'].min() >= 0
    assert features['minute'].max() <= 59
    assert features['day_of_week'].min() >= 0
    assert features['day_of_week'].max() <= 6

def test_calculate_advanced_time_features(sample_timestamps):
    """Test calculation of advanced time features."""
    features = calculate_advanced_time_features(sample_timestamps)
    
    assert isinstance(features, pd.DataFrame)
    expected_columns = [
        'hour', 'minute', 'day_of_week',
        'day_progress', 'trading_day_progress',
        'is_pre_london', 'is_pre_ny'
    ]
    assert all(col in features.columns for col in expected_columns)

# =============================================================================
#  Test Calendar Feature Functions
# =============================================================================

def test_calculate_holiday_features(sample_timestamps, sample_holiday_calendar):
    """Test calculation of holiday-related features."""
    features = calculate_holiday_features(
        sample_timestamps,
        sample_holiday_calendar
    )
    
    assert isinstance(features, pd.DataFrame)
    assert 'is_holiday' in features.columns
    assert 'days_before_holiday_1' in features.columns
    assert 'days_after_holiday_1' in features.columns

def test_calculate_economic_calendar_features(sample_timestamps, sample_economic_calendar):
    """Test calculation of economic calendar features."""
    features = calculate_economic_calendar_features(
        sample_timestamps,
        sample_economic_calendar,
        impact_windows=[5, 15]
    )
    
    assert isinstance(features, pd.DataFrame)
    expected_prefixes = ['high_impact', 'medium_impact', 'low_impact']
    expected_suffixes = ['before_5min', 'after_5min', 'before_15min', 'after_15min']
    
    for prefix in expected_prefixes:
        for suffix in expected_suffixes:
            assert f'{prefix}_{suffix}' in features.columns

# =============================================================================
#  Test Combined Feature Function
# =============================================================================

def test_calculate_all_time_features(
    sample_timestamps,
    sample_holiday_calendar,
    sample_economic_calendar,
    sample_sessions
):
    """Test calculation of all time-related features."""
    features = calculate_all_time_features(
        sample_timestamps,
        holiday_calendar=sample_holiday_calendar,
        economic_calendar=sample_economic_calendar,
        sessions=sample_sessions
    )
    
    assert isinstance(features, pd.DataFrame)
    
    # Check for presence of features from different categories
    basic_time_cols = ['hour', 'minute', 'day_of_week']
    session_cols = ['tokyo_session', 'london_session', 'ny_session']
    holiday_cols = ['is_holiday']
    
    for col in basic_time_cols + session_cols + holiday_cols:
        assert col in features.columns
    
    # Check data types and ranges
    assert features['hour'].dtype in [np.int64, np.int32]
    assert features['hour'].min() >= 0
    assert features['hour'].max() <= 23
    
    assert features['is_holiday'].dtype == bool
    
    # Check for duplicate columns
    assert len(features.columns) == len(set(features.columns))

# =============================================================================
#  Test Goto Date Features
# =============================================================================

def test_calculate_goto_features(goto_test_timestamps):
    """Test calculation of goto date features."""
    features = calculate_goto_features(goto_test_timestamps)
    
    assert isinstance(features, pd.DataFrame)
    expected_columns = [
        'is_gotobi',
        'is_gotobi_candidate',
        'days_to_next_gotobi',
        'days_from_prev_gotobi'
    ]
    assert all(col in features.columns for col in expected_columns)
    
    # Test specific dates
    # January 5, 2024 (Friday) - Regular gotobi
    assert features.loc[goto_test_timestamps[0], 'is_gotobi']
    assert features.loc[goto_test_timestamps[0], 'is_gotobi_candidate']
    
    # January 6-7, 2024 (Weekend) - Not gotobi
    assert not features.loc[goto_test_timestamps[1], 'is_gotobi']
    assert not features.loc[goto_test_timestamps[2], 'is_gotobi']
    
    # January 10, 2024 (Wednesday) - Regular gotobi
    assert features.loc[goto_test_timestamps[3], 'is_gotobi']
    assert features.loc[goto_test_timestamps[3], 'is_gotobi_candidate']
    
    # January 20, 2024 (Saturday) - Not gotobi (weekend)
    assert not features.loc[goto_test_timestamps[5], 'is_gotobi']
    assert features.loc[goto_test_timestamps[5], 'is_gotobi_candidate']
    
    # Test days calculation
    assert all(features['days_to_next_gotobi'] >= 0)
    assert all(features['days_from_prev_gotobi'] >= 0)
    assert all(features['days_to_next_gotobi'] <= 31)  # Maximum one month
    assert all(features['days_from_prev_gotobi'] <= 31)  # Maximum one month

def test_goto_features_timezone_handling():
    """Test goto date features with different timezone inputs."""
    # Create timestamps in different timezones
    dates = ['2024-01-05', '2024-01-06']  # Jan 5 is gotobi
    
    utc_timestamps = pd.DatetimeIndex([
        pd.Timestamp(date).tz_localize('UTC')
        for date in dates
    ])
    jst_timestamps = pd.DatetimeIndex([
        pd.Timestamp(date).tz_localize('Asia/Tokyo')
        for date in dates
    ])
    
    # Calculate features for both
    utc_features = calculate_goto_features(utc_timestamps)
    jst_features = calculate_goto_features(jst_timestamps)
    
    # Results should be the same regardless of input timezone
    pd.testing.assert_series_equal(
        utc_features['is_gotobi'],
        jst_features['is_gotobi']
    )
    pd.testing.assert_series_equal(
        utc_features['is_gotobi_candidate'],
        jst_features['is_gotobi_candidate']
    )

def test_goto_features_edge_cases():
    """Test goto date features with edge cases."""
    # Empty timestamps
    empty_timestamps = pd.DatetimeIndex([])
    empty_features = calculate_goto_features(empty_timestamps)
    assert len(empty_features) == 0
    
    # Single timestamp
    single_timestamp = pd.DatetimeIndex([pd.Timestamp('2024-01-05').tz_localize('UTC')])
    single_features = calculate_goto_features(single_timestamp)
    assert len(single_features) == 1
    assert single_features['is_gotobi'].iloc[0]  # Jan 5 is gotobi
    
    # Month end
    month_end = pd.DatetimeIndex([pd.Timestamp('2024-01-31').tz_localize('UTC')])
    month_end_features = calculate_goto_features(month_end)
    assert month_end_features['is_gotobi'].iloc[0]  # Month end should be gotobi

def test_goto_features_in_all_time_features(goto_test_timestamps):
    """Test goto date features are correctly included in all time features."""
    features = calculate_all_time_features(goto_test_timestamps)
    
    # Check if goto features are present
    goto_columns = [
        'is_gotobi',
        'is_gotobi_candidate',
        'days_to_next_gotobi',
        'days_from_prev_gotobi'
    ]
    assert all(col in features.columns for col in goto_columns)
    
    # Verify some specific values
    assert features.loc[goto_test_timestamps[0], 'is_gotobi']  # Jan 5
    assert not features.loc[goto_test_timestamps[1], 'is_gotobi']  # Jan 6 (weekend)

# =============================================================================
#  Edge Cases and Error Handling
# =============================================================================

def test_empty_timestamps():
    """Test behavior with empty timestamp input."""
    empty_timestamps = pd.DatetimeIndex([])
    
    features = calculate_time_features(empty_timestamps)
    assert len(features) == 0
    
    session_features = calculate_session_features(empty_timestamps)
    assert len(session_features) == 0

def test_single_timestamp():
    """Test behavior with single timestamp input."""
    single_timestamp = pd.DatetimeIndex([pd.Timestamp('2024-01-01')])
    
    features = calculate_time_features(single_timestamp)
    assert len(features) == 1
    
    session_features = calculate_session_features(single_timestamp)
    assert len(session_features) == 1

def test_timezone_handling():
    """Test handling of different timezone inputs."""
    # Create timestamps with different timezones
    timestamps_utc = pd.date_range('2024-01-01', periods=24, freq='h', tz='UTC')
    timestamps_est = timestamps_utc.tz_convert('America/New_York')
    
    features_utc = calculate_time_features(timestamps_utc)
    features_est = calculate_time_features(timestamps_est)
    
    # Reset index for comparison
    features_utc_hour = features_utc['hour'].reset_index(drop=True)
    features_est_hour = features_est['hour'].reset_index(drop=True)
    
    # Hours should be different due to timezone conversion
    assert not (features_utc_hour == features_est_hour).all()

if __name__ == '__main__':
    pytest.main([__file__]) 