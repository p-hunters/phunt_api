import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Tuple

from phunt_api.targets.validators import (
    validate_price_series,
    validate_horizons,
    validate_windows,
    validate_high_low_data,
    validate_benchmarks
)

from phunt_api.targets.utils import (
    calculate_daily_returns,
    calculate_future_return,
    calculate_rolling_volatility
)

from phunt_api.targets.returns import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns
)

from phunt_api.targets.technical import (
    calculate_momentum_targets,
    calculate_range_targets,
    calculate_mean_reversion_targets,
    calculate_price_patterns
)

from phunt_api.targets.volatility import calculate_volatility_targets
from phunt_api.targets.relative import calculate_relative_returns

from phunt_api.targets import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_momentum_targets,
    calculate_risk_adjusted_returns,
    calculate_range_targets,
    calculate_mean_reversion_targets,
    calculate_relative_returns,
    calculate_volatility_targets,
    calculate_multiclass_direction,
    calculate_sr_breakout,
    calculate_targets
)

# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_dates():
    """Generate sample dates for testing."""
    start_date = datetime(2020, 1, 1)
    dates = [start_date + timedelta(days=x) for x in range(100)]
    return pd.DatetimeIndex(dates)

@pytest.fixture
def sample_prices(sample_dates):
    """Generate sample price series for testing."""
    np.random.seed(42)
    prices = 100 * (1 + np.random.randn(len(sample_dates)).cumsum() * 0.02)
    return pd.Series(prices, index=sample_dates)

@pytest.fixture
def sample_benchmarks(sample_dates):
    """Generate sample benchmark price series for testing."""
    np.random.seed(43)
    bench1 = 100 * (1 + np.random.randn(len(sample_dates)).cumsum() * 0.015)
    bench2 = 100 * (1 + np.random.randn(len(sample_dates)).cumsum() * 0.025)
    
    return {
        'bench1': pd.Series(bench1, index=sample_dates),
        'bench2': pd.Series(bench2, index=sample_dates)
    }

@pytest.fixture
def sample_high_low(sample_prices):
    """Generate sample high-low price data for testing."""
    high = sample_prices * (1 + abs(np.random.randn(len(sample_prices)) * 0.01))
    low = sample_prices * (1 - abs(np.random.randn(len(sample_prices)) * 0.01))
    return high, low

# =============================================================================
# Test Data Quality and Parameter Validation
# =============================================================================

def test_input_validation():
    """Test input validation for price series."""
    # Create invalid inputs
    invalid_prices = pd.Series([1, 2, np.nan, 4, 5])
    negative_prices = pd.Series([-1, -2, -3, -4, -5])
    zero_prices = pd.Series([0, 1, 2, 0, 3])
    
    # Test with invalid prices
    with pytest.raises(ValueError):
        calculate_future_returns(invalid_prices)
    with pytest.raises(ValueError):
        calculate_future_returns(negative_prices)
    with pytest.raises(ValueError):
        calculate_future_returns(zero_prices)

def test_parameter_validation():
    """Test parameter validation."""
    valid_prices = pd.Series([1, 2, 3, 4, 5])
    
    # Test invalid horizons
    with pytest.raises(ValueError):
        calculate_future_returns(valid_prices, horizons=[-1])
    with pytest.raises(ValueError):
        calculate_future_returns(valid_prices, horizons=[0])
    
    # Test invalid method
    with pytest.raises(ValueError):
        calculate_future_returns(valid_prices, method='invalid')
    
    # Test invalid thresholds
    with pytest.raises(ValueError):
        calculate_volatility_targets(valid_prices, regime_thresholds=[(1.0, 0.5)])  # reversed thresholds

# =============================================================================
# Test Target Calculations
# =============================================================================

def test_future_returns(sample_prices):
    """Test future returns calculation."""
    horizons = [1, 5, 10]
    future_rets = calculate_future_returns(sample_prices, horizons=horizons)
    
    # Check output structure
    assert isinstance(future_rets, pd.DataFrame)
    assert all(f'future_return_{h}' in future_rets.columns for h in horizons)
    
    # Check return calculation
    for h in horizons:
        manual_rets = -(sample_prices.shift(-h) / sample_prices - 1)
        pd.testing.assert_series_equal(
            future_rets[f'future_return_{h}'].iloc[:-h],
            manual_rets.iloc[:-h],
            check_names=False
        )

def test_direction_labels(sample_prices):
    """Test direction label calculation."""
    horizons = [1, 5]
    threshold = 0.001
    
    direction = calculate_direction_labels(
        sample_prices, 
        horizons=horizons,
        threshold=threshold
    )
    
    # Check output structure
    assert isinstance(direction, pd.DataFrame)
    assert all(f'direction_{h}' in direction.columns for h in horizons)
    
    # Check direction calculation
    for h in horizons:
        future_rets = -(sample_prices.shift(-h) / sample_prices - 1)
        expected_direction = (future_rets > threshold).astype(int)
        pd.testing.assert_series_equal(
            direction[f'direction_{h}'].iloc[:-h],
            expected_direction.iloc[:-h],
            check_names=False
        )

def test_volatility_adjusted_returns(sample_prices):
    """Test volatility-adjusted returns calculation."""
    horizons = [1, 5]
    vol_window = 20
    
    vol_adj_rets = calculate_volatility_adjusted_returns(
        sample_prices,
        horizons=horizons,
        vol_window=vol_window
    )
    
    # Check output structure
    assert isinstance(vol_adj_rets, pd.DataFrame)
    assert all(f'vol_adj_return_{h}' in vol_adj_rets.columns for h in horizons)
    
    # Check calculation
    returns = sample_prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window).std()
    
    for h in horizons:
        future_rets = -(sample_prices.shift(-h) / sample_prices - 1)
        expected_vol_adj = future_rets / rolling_vol
        pd.testing.assert_series_equal(
            vol_adj_rets[f'vol_adj_return_{h}'].iloc[vol_window:-h],
            expected_vol_adj.iloc[vol_window:-h],
            check_names=False
        )

def test_volatility_targets(sample_prices, sample_high_low):
    """Test volatility target calculation."""
    horizons = [1, 5]
    vol_windows = [20, 50]
    high_prices, low_prices = sample_high_low
    
    # Test with standard method
    vol_targets = calculate_volatility_targets(
        sample_prices,
        horizons=horizons,
        vol_windows=vol_windows
    )
    
    # Check output structure
    assert isinstance(vol_targets, pd.DataFrame)
    expected_cols = [
        f'future_vol_{w}_{h}' for w in vol_windows for h in horizons
    ] + [
        f'hist_vol_{w}_{h}' for w in vol_windows for h in horizons
    ]
    assert all(col in vol_targets.columns for col in expected_cols)
    
    # Test with Parkinson method
    vol_targets_park = calculate_volatility_targets(
        sample_prices,
        horizons=horizons,
        vol_windows=vol_windows,
        method='parkinson',
        high_low_data=(high_prices, low_prices)
    )
    
    # Parkinson should give different estimates than standard method
    assert not np.allclose(
        vol_targets['hist_vol_20_1'].dropna(),
        vol_targets_park['hist_vol_20_1'].dropna()
    )

def test_sr_breakout(sample_prices):
    """Test support/resistance breakout calculation."""
    horizons = [1, 5]
    sr_windows = [20, 50]
    
    breakout = calculate_sr_breakout(
        sample_prices,
        horizons=horizons,
        sr_windows=sr_windows
    )
    
    # Check output structure
    assert isinstance(breakout, pd.DataFrame)
    
    # Check expected columns exist
    for w in sr_windows:
        for h in horizons:
            assert f'resistance_dist_{w}_{h}' in breakout.columns
            assert f'support_dist_{w}_{h}' in breakout.columns
            assert f'resistance_breakout_{w}_{h}' in breakout.columns
            assert f'support_breakout_{w}_{h}' in breakout.columns
    
    # Check breakout signals are binary
    breakout_cols = [col for col in breakout.columns if 'breakout' in col]
    for col in breakout_cols:
        values = breakout[col].dropna().unique()
        assert all(v in [0, 1] for v in values)

def test_regime_detection(sample_prices):
    """Test volatility regime detection."""
    # We know there's a high vol regime from 300:500 and low vol regime from 700:800
    vol_targets = calculate_volatility_targets(
        sample_prices,
        horizons=[1],
        vol_windows=[50],
        regime_thresholds=[(0.5, 1.5)]
    )
    
    regime = vol_targets['current_vol_regime_50_1']
    
    # Check high volatility period
    assert (regime[350:450] == 2).mean() > 0.7  # Should be mostly high regime
    
    # Check low volatility period
    assert (regime[720:780] == 0).mean() > 0.7  # Should be mostly low regime

def test_jump_detection(sample_prices):
    """Test jump detection."""
    # We know there are jumps at indices 100, 300, 600
    vol_targets = calculate_volatility_targets(
        sample_prices,
        horizons=[1],
        vol_windows=[20],
        jump_threshold=3.0
    )
    
    jumps = vol_targets['jump_intensity_20_1']
    
    # Check jump points
    for jp in [100, 300, 600]:
        assert jumps[jp:jp+5].max() > 0  # Should detect jump within 5 points

def test_integration(sample_prices, sample_benchmarks, sample_high_low):
    """Test full target calculation integration."""
    high_prices, low_prices = sample_high_low
    targets = calculate_targets(
        prices=sample_prices,
        horizons=[1, 5],
        benchmarks=sample_benchmarks,
        high_low_data=(high_prices, low_prices)
    )
    
    # Check that we have all expected target types
    assert any(col.startswith('future_return_') for col in targets.columns)
    assert any(col.startswith('direction_') for col in targets.columns)
    assert any(col.startswith('vol_adj_return_') for col in targets.columns)
    assert any(col.startswith('future_vol_') for col in targets.columns)
    
    # Check data quality
    assert targets.index.equals(sample_prices.index)
    assert not targets.isnull().all().any()  # No completely null columns
    assert (targets.isnull().mean() < 0.2).all()  # Less than 20% nulls in any column

# =============================================================================
# Test Edge Cases
# =============================================================================

def test_constant_price():
    """Test behavior with constant prices."""
    dates = pd.date_range('2024-01-01', periods=100, freq='1min')
    constant_prices = pd.Series(100.0, index=dates)
    
    targets = calculate_targets(constant_prices, horizons=[1])
    
    # Check that we don't have NaN/inf values
    assert not targets.isnull().all().any()
    assert not np.isinf(targets).any().any()
    
    # Volatility should be zero
    vol_cols = [col for col in targets.columns if 'vol' in col]
    for col in vol_cols:
        assert (targets[col] == 0).all() or targets[col].isnull().all()

def test_single_jump():
    """Test behavior with a single large jump."""
    dates = pd.date_range('2024-01-01', periods=100, freq='1min')
    prices = pd.Series(100.0, index=dates)
    prices[50] = 150.0  # 50% jump
    
    targets = calculate_targets(prices, horizons=[1])
    
    # Check that targets are bounded
    assert targets.max().max() < 1e3
    assert targets.min().min() > -1e3

def test_missing_data():
    """Test behavior with missing data points."""
    dates = pd.date_range('2024-01-01', periods=100, freq='1min')
    prices = pd.Series(np.random.randn(100).cumsum(), index=dates)
    prices[10:20] = np.nan  # Add missing data
    
    with pytest.raises(ValueError):
        calculate_targets(prices, horizons=[1])

def test_extreme_parameters():
    """Test behavior with extreme parameter values."""
    dates = pd.date_range('2024-01-01', periods=1000, freq='1min')
    # Use exponential of random walk to ensure positive prices
    prices = pd.Series(np.exp(np.random.randn(1000).cumsum()), index=dates)
    
    # Test with very large windows
    targets = calculate_targets(
        prices,
        horizons=[1],
        vol_window=500,
        risk_window=500
    )
    
    assert not targets.isnull().all().any()
    assert (targets.isnull().mean() < 0.2).all()

# =============================================================================
# Validator Tests
# =============================================================================

def test_validate_price_series(sample_prices):
    """Test price series validation."""
    # Valid case
    validate_price_series(sample_prices)
    
    # Invalid cases
    with pytest.raises(ValueError, match="Prices must be a pandas Series"):
        validate_price_series([1, 2, 3])
    
    with pytest.raises(ValueError, match="Price series must contain numeric values"):
        validate_price_series(pd.Series(['a', 'b', 'c']))
    
    with pytest.raises(ValueError, match="Price series contains missing values"):
        invalid_prices = sample_prices.copy()
        invalid_prices.iloc[0] = np.nan
        validate_price_series(invalid_prices)
    
    with pytest.raises(ValueError, match="Price series contains zero or negative values"):
        invalid_prices = sample_prices.copy()
        invalid_prices.iloc[0] = 0
        validate_price_series(invalid_prices)

def test_validate_horizons():
    """Test horizon validation."""
    # Valid cases
    validate_horizons(5)
    validate_horizons([1, 5, 10])
    
    # Invalid cases
    with pytest.raises(ValueError, match="All horizons must be integers"):
        validate_horizons([1, 2.5, 3])
    
    with pytest.raises(ValueError, match="All horizons must be positive"):
        validate_horizons([1, -1, 3])
    
    with pytest.raises(ValueError, match="Duplicate horizons are not allowed"):
        validate_horizons([1, 1, 2])

# =============================================================================
# Utils Tests
# =============================================================================

def test_calculate_daily_returns(sample_prices):
    """Test daily returns calculation."""
    # Arithmetic returns
    arith_returns = calculate_daily_returns(sample_prices, 'arithmetic')
    assert isinstance(arith_returns, pd.Series)
    assert len(arith_returns) == len(sample_prices)
    assert np.isclose(arith_returns.iloc[1], 
                     sample_prices.iloc[1] / sample_prices.iloc[0] - 1)
    
    # Log returns
    log_returns = calculate_daily_returns(sample_prices, 'log')
    assert isinstance(log_returns, pd.Series)
    assert len(log_returns) == len(sample_prices)
    assert np.isclose(log_returns.iloc[1], 
                     np.log(sample_prices.iloc[1] / sample_prices.iloc[0]))
    
    # Invalid method
    with pytest.raises(ValueError, match="Method must be 'arithmetic' or 'log'"):
        calculate_daily_returns(sample_prices, 'invalid')

# =============================================================================
# Returns Tests
# =============================================================================

def test_calculate_future_returns(sample_prices):
    """Test future returns calculation."""
    horizons = [1, 5]
    future_rets = calculate_future_returns(sample_prices, horizons)
    
    assert isinstance(future_rets, pd.DataFrame)
    assert all(f'future_return_{h}' in future_rets.columns for h in horizons)
    assert len(future_rets) == len(sample_prices)
    
    # Test normalization
    future_rets_norm = calculate_future_returns(sample_prices, horizons, normalize=True)
    future_rets_no_norm = calculate_future_returns(sample_prices, horizons, normalize=False)
    
    assert not np.allclose(
        future_rets_norm['future_return_1'].dropna(),
        future_rets_no_norm['future_return_1'].dropna()
    )

# =============================================================================
# Technical Tests
# =============================================================================

def test_calculate_momentum_targets(sample_prices):
    """Test momentum targets calculation."""
    momentum_windows = [5, 10]
    horizons = [1, 5]
    
    momentum_targets = calculate_momentum_targets(
        sample_prices,
        momentum_windows=momentum_windows,
        prediction_horizons=horizons
    )
    
    assert isinstance(momentum_targets, pd.DataFrame)
    expected_cols = [
        f'momentum_accel_w{w}_h{h}'
        for w in momentum_windows
        for h in horizons
    ]
    assert all(col in momentum_targets.columns for col in expected_cols)

# =============================================================================
# Relative Tests
# =============================================================================

def test_calculate_relative_returns(sample_prices, sample_benchmarks):
    """Test relative returns calculation."""
    horizons = [1, 5]
    relative_rets = calculate_relative_returns(
        sample_prices,
        sample_benchmarks,
        horizons=horizons
    )
    
    assert isinstance(relative_rets, pd.DataFrame)
    
    # Check for expected columns
    for name in sample_benchmarks.keys():
        for h in horizons:
            assert f'relative_return_{name}_{h}' in relative_rets.columns
            assert f'correlation_{name}_{h}' in relative_rets.columns
            assert f'beta_{name}_{h}' in relative_rets.columns
    
    # Test normalization
    relative_rets_norm = calculate_relative_returns(
        sample_prices,
        sample_benchmarks,
        horizons=horizons,
        normalize=True
    )
    relative_rets_no_norm = calculate_relative_returns(
        sample_prices,
        sample_benchmarks,
        horizons=horizons,
        normalize=False
    )
    
    assert not np.allclose(
        relative_rets_norm[f'relative_return_bench1_1'].dropna(),
        relative_rets_no_norm[f'relative_return_bench1_1'].dropna()
    )

# =============================================================================
# Integration Tests
# =============================================================================

def test_all_targets_integration(sample_prices, sample_benchmarks, sample_high_low):
    """Test that all target calculations work together."""
    horizons = [1, 5]
    high_prices, low_prices = sample_high_low
    
    # Calculate all types of targets
    future_rets = calculate_future_returns(sample_prices, horizons)
    direction_labs = calculate_direction_labels(sample_prices, horizons)
    vol_adj_rets = calculate_volatility_adjusted_returns(sample_prices, horizons)
    risk_adj_rets = calculate_risk_adjusted_returns(sample_prices, horizons)
    momentum_targs = calculate_momentum_targets(sample_prices, prediction_horizons=horizons)
    range_targs = calculate_range_targets(sample_prices, horizons)
    reversion_targs = calculate_mean_reversion_targets(sample_prices, horizons)
    vol_targs = calculate_volatility_targets(
        sample_prices,
        horizons,
        high_low_data=(high_prices, low_prices)
    )
    relative_targs = calculate_relative_returns(sample_prices, sample_benchmarks, horizons)
    
    # Verify all results are DataFrames with the expected length
    all_results = [
        future_rets, direction_labs, vol_adj_rets, risk_adj_rets,
        momentum_targs, range_targs, reversion_targs, vol_targs, relative_targs
    ]
    
    assert all(isinstance(df, pd.DataFrame) for df in all_results)
    assert all(len(df) == len(sample_prices) for df in all_results)

# =============================================================================
# Classification Tests
# =============================================================================

def test_multiclass_direction(sample_prices):
    """Test multiclass direction calculation."""
    horizons = [1, 5]
    thresholds = [(-0.02, -0.005), (0.005, 0.02)]
    
    direction = calculate_multiclass_direction(
        sample_prices,
        horizons=horizons,
        thresholds=thresholds
    )
    
    # Check output structure
    assert isinstance(direction, pd.DataFrame)
    assert all(f'multiclass_direction_{h}' in direction.columns for h in horizons)
    
    # Check class values are in expected range (-2 to 2)
    for h in horizons:
        classes = direction[f'multiclass_direction_{h}'].dropna().unique()
        assert all(c in [-2, -1, 0, 1, 2] for c in classes)
    
    # Check probability columns
    for h in horizons:
        for i in [-2, -1, 0, 1, 2]:
            prob_col = f'direction_prob_{i}_{h}'
            assert prob_col in direction.columns
            assert (direction[prob_col] >= 0).all() and (direction[prob_col] <= 1).all()

def test_calculate_price_patterns(sample_prices):
    """Test price pattern calculation."""
    horizons = [1, 5]
    pattern_windows = [20, 50]
    
    patterns = calculate_price_patterns(
        sample_prices,
        horizons=horizons,
        pattern_windows=pattern_windows
    )
    
    # Check output structure
    assert isinstance(patterns, pd.DataFrame)
    
    # Check pattern signals are binary
    pattern_cols = [col for col in patterns.columns if any(x in col for x in [
        'head_shoulders', 'double_top', 'double_bottom',
        'asc_triangle', 'desc_triangle', 'sym_triangle'
    ]) and not 'similarity' in col]
    
    for col in pattern_cols:
        values = patterns[col].dropna().unique()
        assert all(v in [0, 1] for v in values)
    
    # Check similarity scores are between 0 and 1
    similarity_cols = [col for col in patterns.columns if 'similarity' in col]
    for col in similarity_cols:
        values = patterns[col].dropna()
        assert (values >= 0).all() and (values <= 1).all() 