import numpy as np
import pandas as pd
from typing import Union, List, Optional, Dict, Tuple

def calculate_multiclass_direction(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    thresholds: Union[Tuple[float, float], List[Tuple[float, float]]] = [
        (-0.02, -0.005),  # Strong down, down thresholds
        (0.005, 0.02)     # Up, strong up thresholds
    ],
    vol_normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5
) -> pd.DataFrame:
    """
    Calculate multi-class direction labels for future price movements.
    Classes: strong down (-2), down (-1), neutral (0), up (1), strong up (2)
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate direction for
        thresholds (Union[Tuple[float, float], List[Tuple[float, float]]]): 
            Thresholds for class boundaries. First tuple is for down moves, second for up moves.
            Each tuple contains (strong_threshold, weak_threshold)
        vol_normalize (bool): Whether to normalize returns by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
    
    Returns:
        pd.DataFrame: DataFrame with multi-class direction labels
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    
    if isinstance(thresholds[0], float):
        thresholds = [thresholds]
    
    direction_labels = pd.DataFrame(index=prices.index)
    
    # Calculate volatility if needed
    if vol_normalize:
        returns = prices.pct_change().fillna(0)
        rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    for horizon in horizons:
        # Calculate future returns (positive when price goes up)
        future_returns = (prices.shift(-horizon) / prices - 1)
        
        if vol_normalize:
            future_returns = future_returns / rolling_vol
        
        # Initialize with neutral class
        labels = pd.Series(0, index=prices.index)
        
        # Unpack thresholds
        down_thresholds, up_thresholds = thresholds
        strong_down, weak_down = down_thresholds
        weak_up, strong_up = up_thresholds
        
        # Strong down
        labels[future_returns <= strong_down] = -2
        # Down
        labels[(future_returns > strong_down) & (future_returns <= weak_down)] = -1
        # Up
        labels[(future_returns >= weak_up) & (future_returns < strong_up)] = 1
        # Strong up
        labels[future_returns >= strong_up] = 2
        
        direction_labels[f'multiclass_direction_{horizon}'] = labels
        
        # Calculate class probabilities based on historical distribution
        valid_labels = labels.dropna()
        for i in [-2, -1, 0, 1, 2]:
            prob = (valid_labels == i).astype(float).rolling(
                window=vol_window,
                min_periods=min_periods
            ).mean()
            direction_labels[f'direction_prob_{i}_{horizon}'] = prob
        
        # Calculate trend strength
        trend_strength = abs(labels).rolling(
            window=vol_window,
            min_periods=min_periods
        ).mean()
        direction_labels[f'trend_strength_{horizon}'] = trend_strength
        
        # Calculate directional consistency
        rolling_direction = labels.rolling(window=vol_window, min_periods=min_periods)
        direction_consistency = (
            (rolling_direction.max() * rolling_direction.min() >= 0)
        ).astype(int)
        direction_labels[f'direction_consistency_{horizon}'] = direction_consistency
        
        # Calculate transition probabilities
        for i in [-2, -1, 0, 1, 2]:
            for j in [-2, -1, 0, 1, 2]:
                current_state = (labels == i)
                next_state = (labels.shift(-1) == j)
                trans_prob = (
                    (current_state & next_state)
                    .rolling(window=vol_window, min_periods=min_periods)
                    .mean()
                    / (current_state.rolling(window=vol_window, min_periods=min_periods).mean() + 1e-10)
                )
                direction_labels[f'trans_prob_{i}to{j}_{horizon}'] = trans_prob
    
    return direction_labels 

def calculate_sr_breakout(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    sr_windows: Union[int, List[int]] = [20, 50, 100],
    pivot_threshold: float = 0.01,
    breakout_threshold: float = 0.003,
    vol_normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_pivot_distance: int = 5
) -> pd.DataFrame:
    """
    Calculate support/resistance breakout prediction targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate breakouts for
        sr_windows (Union[int, List[int]]): Windows for support/resistance calculation
        pivot_threshold (float): Minimum price change to identify pivot points
        breakout_threshold (float): Minimum move to confirm breakout
        vol_normalize (bool): Whether to normalize by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        min_pivot_distance (int): Minimum distance between pivot points
    
    Returns:
        pd.DataFrame: DataFrame with breakout prediction targets
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(sr_windows, int):
        sr_windows = [sr_windows]
    
    breakout_targets = pd.DataFrame(index=prices.index)
    
    # Calculate volatility if needed
    returns = prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    def find_pivot_points(window_prices: pd.Series) -> Tuple[float, float]:
        """Find nearest support and resistance levels."""
        if len(window_prices) < min_pivot_distance * 2 + 1:
            return np.nan, np.nan
            
        highs = []
        lows = []
        
        for i in range(min_pivot_distance, len(window_prices) - min_pivot_distance):
            left_window = window_prices.iloc[i-min_pivot_distance:i]
            right_window = window_prices.iloc[i+1:i+min_pivot_distance+1]
            current_price = window_prices.iloc[i]
            
            # High pivot
            if (current_price > left_window.max()) and (current_price > right_window.max()):
                if vol_normalize:
                    if (current_price - left_window.max()) / rolling_vol.iloc[i] > pivot_threshold:
                        highs.append(current_price)
                else:
                    if (current_price - left_window.max()) / current_price > pivot_threshold:
                        highs.append(current_price)
            
            # Low pivot
            if (current_price < left_window.min()) and (current_price < right_window.min()):
                if vol_normalize:
                    if (left_window.min() - current_price) / rolling_vol.iloc[i] > pivot_threshold:
                        lows.append(current_price)
                else:
                    if (left_window.min() - current_price) / current_price > pivot_threshold:
                        lows.append(current_price)
        
        current_price = window_prices.iloc[-1]
        resistance = min([h for h in highs if h > current_price], default=np.nan)
        support = max([l for l in lows if l < current_price], default=np.nan)
        
        return resistance, support
    
    for window in sr_windows:
        # Initialize columns for this window
        resistance_col = f'nearest_resistance'
        support_col = f'nearest_support'
        breakout_targets[resistance_col] = np.nan
        breakout_targets[support_col] = np.nan
        
        # Rolling window analysis
        for i in range(window, len(prices)):
            window_prices = prices.iloc[i-window:i]
            resistance, support = find_pivot_points(window_prices)
            
            breakout_targets.loc[prices.index[i], resistance_col] = resistance
            breakout_targets.loc[prices.index[i], support_col] = support
        
        # Calculate distances
        resistance_dist = (breakout_targets[resistance_col] - prices) / prices
        support_dist = (prices - breakout_targets[support_col]) / prices
        
        if vol_normalize:
            resistance_dist = resistance_dist / rolling_vol
            support_dist = support_dist / rolling_vol
        
        # Store results
        breakout_targets[f'resistance_dist_{window}'] = resistance_dist
        breakout_targets[f'support_dist_{window}'] = support_dist
        
        for horizon in horizons:
            # Future price movement
            future_prices = pd.DataFrame({
                'price': prices,
                'future_price': prices.shift(-horizon)
            })
            
            # Create rolling windows of future prices
            price_windows = []
            for i in range(horizon):
                price_windows.append(prices.shift(-(i+1)))
            
            future_prices_all = pd.concat(
                [future_prices] + [pd.DataFrame({'price_'+str(i+1): p}) 
                                 for i, p in enumerate(price_windows)], 
                axis=1
            )
            
            future_high = future_prices_all.max(axis=1)
            future_low = future_prices_all.min(axis=1)
            
            # Breakout predictions
            resistance_breakout = (
                (future_high - breakout_targets[resistance_col]) / 
                breakout_targets[resistance_col].replace(0, np.nan)
            ) > breakout_threshold
            
            support_breakout = (
                (breakout_targets[support_col] - future_low) / 
                breakout_targets[support_col].replace(0, np.nan)
            ) > breakout_threshold
            
            # Store results
            breakout_targets[f'resistance_breakout_{window}_{horizon}'] = resistance_breakout.astype(int)
            breakout_targets[f'support_breakout_{window}_{horizon}'] = support_breakout.astype(int)
    
    return breakout_targets 

def calculate_trend_reversal(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    trend_windows: Union[int, List[int]] = [10, 20, 50],
    reversal_threshold: float = 0.02,
    momentum_threshold: float = 0.01,
    vol_normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5
) -> pd.DataFrame:
    """
    Calculate trend reversal prediction targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate reversals for
        trend_windows (Union[int, List[int]]): Windows for trend calculation
        reversal_threshold (float): Minimum price change to confirm reversal
        momentum_threshold (float): Threshold for momentum indicators
        vol_normalize (bool): Whether to normalize by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
    
    Returns:
        pd.DataFrame: DataFrame with trend reversal prediction targets
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(trend_windows, int):
        trend_windows = [trend_windows]
    
    reversal_targets = pd.DataFrame(index=prices.index)
    
    # Calculate returns and volatility
    returns = prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    for window in trend_windows:
        # Calculate trend indicators
        sma = prices.rolling(window=window, min_periods=min_periods).mean()
        ema = prices.ewm(span=window, min_periods=min_periods).mean()
        
        # Calculate momentum indicators
        momentum = prices.pct_change(window)
        roc = prices / prices.shift(window) - 1
        
        # Identify potential reversal points
        for horizon in horizons:
            # Future returns for confirmation
            future_returns = prices.pct_change(horizon).shift(-horizon)
            
            if vol_normalize:
                momentum = momentum / rolling_vol
                roc = roc / rolling_vol
                future_returns = future_returns / rolling_vol
            
            # Uptrend conditions
            uptrend = (
                (prices > sma) & 
                (prices > ema) & 
                (momentum > momentum_threshold)
            )
            
            # Downtrend conditions
            downtrend = (
                (prices < sma) & 
                (prices < ema) & 
                (momentum < -momentum_threshold)
            )
            
            # Reversal signals
            bullish_reversal = (
                downtrend & 
                (roc > momentum_threshold) & 
                (future_returns > reversal_threshold)
            )
            
            bearish_reversal = (
                uptrend & 
                (roc < -momentum_threshold) & 
                (future_returns < -reversal_threshold)
            )
            
            # Store results
            reversal_targets[f'uptrend_{window}_{horizon}'] = uptrend.astype(int)
            reversal_targets[f'downtrend_{window}_{horizon}'] = downtrend.astype(int)
            reversal_targets[f'bullish_reversal_{window}_{horizon}'] = bullish_reversal.astype(int)
            reversal_targets[f'bearish_reversal_{window}_{horizon}'] = bearish_reversal.astype(int)
            
            # Calculate reversal probabilities
            for trend_type in ['bullish', 'bearish']:
                reversal_series = reversal_targets[f'{trend_type}_reversal_{window}_{horizon}']
                prob = reversal_series.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                reversal_targets[f'{trend_type}_reversal_prob_{window}_{horizon}'] = prob
            
            # Calculate reversal strength
            bullish_strength = future_returns.copy()
            bearish_strength = -future_returns.copy()
            
            bullish_strength[~bullish_reversal] = 0
            bearish_strength[~bearish_reversal] = 0
            
            reversal_targets[f'bullish_reversal_strength_{window}_{horizon}'] = bullish_strength
            reversal_targets[f'bearish_reversal_strength_{window}_{horizon}'] = bearish_strength
            
            # Calculate trend persistence
            trend_persistence = (
                (uptrend | downtrend)
                .rolling(window=vol_window, min_periods=min_periods)
                .mean()
            )
            reversal_targets[f'trend_persistence_{window}_{horizon}'] = trend_persistence
            
            # Calculate reversal confirmation time
            bullish_conf_time = pd.Series(np.nan, index=prices.index)
            bearish_conf_time = pd.Series(np.nan, index=prices.index)
            
            for i in range(len(prices) - horizon):
                if bullish_reversal.iloc[i]:
                    for j in range(1, horizon + 1):
                        if i + j >= len(prices):
                            break
                        if prices.iloc[i + j] > prices.iloc[i] * (1 + reversal_threshold):
                            bullish_conf_time.iloc[i] = j
                            break
                
                if bearish_reversal.iloc[i]:
                    for j in range(1, horizon + 1):
                        if i + j >= len(prices):
                            break
                        if prices.iloc[i + j] < prices.iloc[i] * (1 - reversal_threshold):
                            bearish_conf_time.iloc[i] = j
                            break
            
            reversal_targets[f'bullish_conf_time_{window}_{horizon}'] = bullish_conf_time
            reversal_targets[f'bearish_conf_time_{window}_{horizon}'] = bearish_conf_time
    
    return reversal_targets 

def calculate_volatility_regime(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_windows: Union[int, List[int]] = [20, 50, 100],
    regime_thresholds: Union[Tuple[float, float], List[Tuple[float, float]]] = [
        (0.5, 1.5)  # (low_to_medium, medium_to_high) in terms of historical std
    ],
    vol_of_vol_window: int = 50,
    min_periods: int = 5,
    use_parkinson: bool = True,
    use_garman_klass: bool = True,
    high_low_data: Optional[Tuple[pd.Series, pd.Series]] = None
) -> pd.DataFrame:
    """
    Calculate volatility regime classification targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate regimes for
        vol_windows (Union[int, List[int]]): Windows for volatility calculation
        regime_thresholds (Union[Tuple[float, float], List[Tuple[float, float]]]): 
            Thresholds for regime boundaries in terms of historical standard deviations.
            Each tuple contains (low_to_medium, medium_to_high) thresholds
        vol_of_vol_window (int): Window for calculating volatility of volatility
        min_periods (int): Minimum number of observations required
        use_parkinson (bool): Whether to use Parkinson volatility estimator (requires high-low data)
        use_garman_klass (bool): Whether to use Garman-Klass volatility estimator (requires high-low data)
        high_low_data (Optional[Tuple[pd.Series, pd.Series]]): High and low price series if available
    
    Returns:
        pd.DataFrame: DataFrame with volatility regime classifications and related metrics
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(vol_windows, int):
        vol_windows = [vol_windows]
    if isinstance(regime_thresholds[0], float):
        regime_thresholds = [regime_thresholds]
    
    regime_targets = pd.DataFrame(index=prices.index)
    
    # Calculate returns
    returns = prices.pct_change()
    log_returns = np.log(prices / prices.shift(1))
    
    # Calculate Parkinson and Garman-Klass volatility if high-low data available
    if high_low_data is not None and (use_parkinson or use_garman_klass):
        high_prices, low_prices = high_low_data
        log_high_low = np.log(high_prices / low_prices)
        
        if use_parkinson:
            # Parkinson volatility estimator
            parkinson_vol = np.sqrt(
                (1 / (4 * np.log(2))) * (log_high_low ** 2)
            )
        
        if use_garman_klass:
            # Garman-Klass volatility estimator
            log_co = np.log(prices / prices.shift(1))  # Close-to-open
            log_ho = np.log(high_prices / prices.shift(1))  # High-to-open
            log_lo = np.log(low_prices / prices.shift(1))  # Low-to-open
            
            garman_klass_vol = np.sqrt(
                0.5 * (log_high_low ** 2) -
                (2 * np.log(2) - 1) * (log_co ** 2)
            )
    
    for window in vol_windows:
        # Calculate different volatility measures
        rolling_vol = returns.rolling(window=window, min_periods=min_periods).std()
        rolling_vol_log = log_returns.rolling(window=window, min_periods=min_periods).std()
        
        # Add Parkinson and Garman-Klass if available
        if high_low_data is not None:
            if use_parkinson:
                rolling_park_vol = parkinson_vol.rolling(
                    window=window, 
                    min_periods=min_periods
                ).mean()
            if use_garman_klass:
                rolling_gk_vol = garman_klass_vol.rolling(
                    window=window, 
                    min_periods=min_periods
                ).mean()
        
        # Calculate volatility of volatility
        vol_of_vol = rolling_vol.rolling(
            window=vol_of_vol_window, 
            min_periods=min_periods
        ).std()
        
        # Calculate historical percentiles for adaptive thresholds
        vol_percentiles = rolling_vol.rolling(
            window=vol_of_vol_window, 
            min_periods=min_periods
        ).quantile([0.25, 0.75])
        
        for horizon in horizons:
            # Future volatility for prediction targets
            future_vol = returns.rolling(window=horizon).std().shift(-horizon)
            
            # Combine different volatility measures
            if high_low_data is not None and (use_parkinson or use_garman_klass):
                combined_vol = pd.DataFrame({
                    'std_vol': rolling_vol,
                    'log_vol': rolling_vol_log,
                    'park_vol': rolling_park_vol if use_parkinson else pd.Series(np.nan, index=prices.index),
                    'gk_vol': rolling_gk_vol if use_garman_klass else pd.Series(np.nan, index=prices.index)
                }).mean(axis=1)
            else:
                combined_vol = rolling_vol
            
            # Normalize volatility
            normalized_vol = (combined_vol - combined_vol.mean()) / combined_vol.std()
            
            for low_thresh, high_thresh in regime_thresholds:
                # Classify regimes (0: low, 1: medium, 2: high)
                vol_regime = pd.Series(1, index=prices.index)  # Initialize as medium
                vol_regime[normalized_vol <= -low_thresh] = 0  # Low regime
                vol_regime[normalized_vol >= high_thresh] = 2  # High regime
                
                regime_targets[f'vol_regime_{window}_{horizon}'] = vol_regime
                
                # Calculate regime probabilities
                for i in range(3):  # 0, 1, 2 for low, medium, high
                    prob = (vol_regime == i).rolling(
                        window=window, 
                        min_periods=min_periods
                    ).mean()
                    regime_targets[f'vol_regime_prob_{i}_{window}_{horizon}'] = prob
            
            # Store additional metrics
            regime_targets[f'vol_level_{window}_{horizon}'] = combined_vol
            regime_targets[f'vol_zscore_{window}_{horizon}'] = normalized_vol
            regime_targets[f'vol_of_vol_{window}_{horizon}'] = vol_of_vol
            regime_targets[f'future_vol_{window}_{horizon}'] = future_vol
            
            # Calculate regime transition probabilities
            current_regime = vol_regime
            future_regime = vol_regime.shift(-1)
            
            for i in range(3):  # From regime
                for j in range(3):  # To regime
                    current_state = (current_regime == i)
                    next_state = (future_regime == j)
                    trans_prob = (
                        (current_state & next_state)
                        .rolling(window=window, min_periods=min_periods)
                        .mean()
                        / (current_state.rolling(window=window, min_periods=min_periods).mean() + 1e-10)
                    )
                    regime_targets[f'vol_regime_trans_{i}to{j}_{window}_{horizon}'] = trans_prob
            
            # Calculate regime persistence
            regime_persistence = (
                (current_regime == future_regime)
                .rolling(window=window, min_periods=min_periods)
                .mean()
            )
            regime_targets[f'vol_regime_persistence_{window}_{horizon}'] = regime_persistence
            
            # Predict regime changes
            regime_change = (future_regime != current_regime).astype(int)
            regime_targets[f'vol_regime_change_{window}_{horizon}'] = regime_change
            
            # Calculate regime stability
            regime_stability = (
                1 - vol_of_vol / (combined_vol + 1e-10)
            ).rolling(window=window, min_periods=min_periods).mean()
            regime_targets[f'vol_regime_stability_{window}_{horizon}'] = regime_stability
    
    return regime_targets 

def calculate_price_patterns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    pattern_windows: Union[int, List[int]] = [20, 50, 100],
    similarity_threshold: float = 0.85,
    vol_normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_pattern_size: int = 10,
    high_low_data: Optional[Tuple[pd.Series, pd.Series]] = None
) -> pd.DataFrame:
    """
    Calculate price pattern classification targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate patterns for
        pattern_windows (Union[int, List[int]]): Windows for pattern detection
        similarity_threshold (float): Threshold for pattern matching (0 to 1)
        vol_normalize (bool): Whether to normalize by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        min_pattern_size (int): Minimum size for pattern detection
        high_low_data (Optional[Tuple[pd.Series, pd.Series]]): High and low price series if available
    
    Returns:
        pd.DataFrame: DataFrame with price pattern classifications and related metrics
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(pattern_windows, int):
        pattern_windows = [pattern_windows]
    
    pattern_targets = pd.DataFrame(index=prices.index)
    
    # Calculate returns and volatility
    returns = prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    def normalize_pattern(pattern: np.ndarray) -> np.ndarray:
        """Normalize pattern to range [0, 1] for comparison."""
        pattern_min = pattern.min()
        pattern_max = pattern.max()
        if pattern_max - pattern_min > 0:
            return (pattern - pattern_min) / (pattern_max - pattern_min)
        return pattern - pattern_min
    
    def calculate_pattern_similarity(pattern1: np.ndarray, pattern2: np.ndarray) -> float:
        """Calculate similarity between two patterns using correlation."""
        if len(pattern1) != len(pattern2):
            return 0.0
        norm_pattern1 = normalize_pattern(pattern1)
        norm_pattern2 = normalize_pattern(pattern2)
        correlation = np.corrcoef(norm_pattern1, norm_pattern2)[0, 1]
        return max(0, correlation)  # Handle NaN cases
    
    def detect_head_and_shoulders(window_prices: pd.Series) -> Tuple[bool, bool, float]:
        """Detect head and shoulders (both regular and inverse) patterns."""
        if len(window_prices) < min_pattern_size:
            return False, False, 0.0
        
        # Create ideal H&S pattern template
        template_size = len(window_prices)
        template = np.zeros(template_size)
        t = np.linspace(0, 1, template_size)
        
        # Regular H&S template (shoulders at 0.8, head at 1.0)
        hs_template = 0.8 + 0.2 * np.sin(2 * np.pi * t) + 0.2 * np.sin(4 * np.pi * t)
        # Inverse H&S template (shoulders at 0.2, head at 0.0)
        ihs_template = 0.2 - 0.2 * np.sin(2 * np.pi * t) - 0.2 * np.sin(4 * np.pi * t)
        
        # Normalize price series
        norm_prices = normalize_pattern(window_prices.values)
        
        # Calculate similarities
        hs_similarity = calculate_pattern_similarity(norm_prices, hs_template)
        ihs_similarity = calculate_pattern_similarity(norm_prices, ihs_template)
        
        max_similarity = max(hs_similarity, ihs_similarity)
        is_hs = hs_similarity > similarity_threshold and hs_similarity > ihs_similarity
        is_ihs = ihs_similarity > similarity_threshold and ihs_similarity > hs_similarity
        
        return is_hs, is_ihs, max_similarity
    
    def detect_double_pattern(window_prices: pd.Series) -> Tuple[bool, bool, float]:
        """Detect double top and bottom patterns."""
        if len(window_prices) < min_pattern_size:
            return False, False, 0.0
        
        # Create ideal double pattern templates
        template_size = len(window_prices)
        t = np.linspace(0, 1, template_size)
        
        # Double top template
        dt_template = 1 - 0.5 * (np.sin(2 * np.pi * t) + 1) * (1 - np.abs(2 * t - 1))
        # Double bottom template
        db_template = 0.5 * (np.sin(2 * np.pi * t) + 1) * (1 - np.abs(2 * t - 1))
        
        # Normalize price series
        norm_prices = normalize_pattern(window_prices.values)
        
        # Calculate similarities
        dt_similarity = calculate_pattern_similarity(norm_prices, dt_template)
        db_similarity = calculate_pattern_similarity(norm_prices, db_template)
        
        max_similarity = max(dt_similarity, db_similarity)
        is_dt = dt_similarity > similarity_threshold and dt_similarity > db_similarity
        is_db = db_similarity > similarity_threshold and db_similarity > dt_similarity
        
        return is_dt, is_db, max_similarity
    
    def detect_triangle_pattern(window_prices: pd.Series) -> Tuple[bool, bool, bool, float]:
        """Detect ascending, descending, and symmetric triangle patterns."""
        if len(window_prices) < min_pattern_size:
            return False, False, False, 0.0
        
        # Create ideal triangle pattern templates
        template_size = len(window_prices)
        t = np.linspace(0, 1, template_size)
        
        # Triangle templates
        asc_template = 0.2 + 0.8 * (1 - t) + 0.2 * t  # Ascending
        desc_template = 0.8 - 0.6 * t  # Descending
        sym_template = 0.5 + 0.5 * (1 - 2 * np.abs(t - 0.5))  # Symmetric
        
        # Normalize price series
        norm_prices = normalize_pattern(window_prices.values)
        
        # Calculate similarities
        asc_similarity = calculate_pattern_similarity(norm_prices, asc_template)
        desc_similarity = calculate_pattern_similarity(norm_prices, desc_template)
        sym_similarity = calculate_pattern_similarity(norm_prices, sym_template)
        
        max_similarity = max(asc_similarity, desc_similarity, sym_similarity)
        is_asc = asc_similarity > similarity_threshold and asc_similarity == max_similarity
        is_desc = desc_similarity > similarity_threshold and desc_similarity == max_similarity
        is_sym = sym_similarity > similarity_threshold and sym_similarity == max_similarity
        
        return is_asc, is_desc, is_sym, max_similarity
    
    for window in pattern_windows:
        for horizon in horizons:
            # Rolling window analysis
            for i in range(window, len(prices)):
                window_prices = prices.iloc[i-window:i]
                
                # Detect patterns
                is_hs, is_ihs, hs_similarity = detect_head_and_shoulders(window_prices)
                is_dt, is_db, double_similarity = detect_double_pattern(window_prices)
                is_asc, is_desc, is_sym, triangle_similarity = detect_triangle_pattern(window_prices)
                
                # Store pattern flags
                pattern_targets.loc[prices.index[i], f'head_shoulders_{window}_{horizon}'] = int(is_hs)
                pattern_targets.loc[prices.index[i], f'inv_head_shoulders_{window}_{horizon}'] = int(is_ihs)
                pattern_targets.loc[prices.index[i], f'double_top_{window}_{horizon}'] = int(is_dt)
                pattern_targets.loc[prices.index[i], f'double_bottom_{window}_{horizon}'] = int(is_db)
                pattern_targets.loc[prices.index[i], f'asc_triangle_{window}_{horizon}'] = int(is_asc)
                pattern_targets.loc[prices.index[i], f'desc_triangle_{window}_{horizon}'] = int(is_desc)
                pattern_targets.loc[prices.index[i], f'sym_triangle_{window}_{horizon}'] = int(is_sym)
                
                # Store pattern similarities
                pattern_targets.loc[prices.index[i], f'hs_similarity_{window}_{horizon}'] = hs_similarity
                pattern_targets.loc[prices.index[i], f'double_similarity_{window}_{horizon}'] = double_similarity
                pattern_targets.loc[prices.index[i], f'triangle_similarity_{window}_{horizon}'] = triangle_similarity
            
            # Calculate pattern completion probabilities
            future_returns = prices.pct_change(horizon).shift(-horizon)
            if vol_normalize:
                future_returns = future_returns / rolling_vol
            
            for pattern in ['head_shoulders', 'inv_head_shoulders', 'double_top', 'double_bottom',
                          'asc_triangle', 'desc_triangle', 'sym_triangle']:
                pattern_series = pattern_targets[f'{pattern}_{window}_{horizon}']
                
                # Calculate success rate (pattern followed by expected move)
                if pattern in ['head_shoulders', 'double_top', 'desc_triangle']:
                    success = (pattern_series == 1) & (future_returns < 0)
                elif pattern in ['inv_head_shoulders', 'double_bottom', 'asc_triangle']:
                    success = (pattern_series == 1) & (future_returns > 0)
                else:  # Symmetric triangle
                    success = (pattern_series == 1) & (abs(future_returns) > rolling_vol)
                
                success_rate = success.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                pattern_targets[f'{pattern}_success_{window}_{horizon}'] = success_rate
                
                # Calculate pattern frequency
                pattern_freq = pattern_series.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                pattern_targets[f'{pattern}_freq_{window}_{horizon}'] = pattern_freq
                
                # Calculate average return after pattern
                pattern_returns = future_returns.copy()
                pattern_returns[pattern_series != 1] = 0
                avg_return = pattern_returns.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                pattern_targets[f'{pattern}_return_{window}_{horizon}'] = avg_return
    
    return pattern_targets 