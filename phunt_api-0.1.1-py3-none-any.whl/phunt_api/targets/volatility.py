import numpy as np
import pandas as pd
from typing import Union, List, Optional, Tuple
from .validators import validate_price_series, validate_horizons, validate_windows, validate_high_low_data
from .utils import calculate_daily_returns, calculate_rolling_volatility

def calculate_volatility_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_windows: Union[int, List[int]] = [20, 50, 100],
    regime_thresholds: List[Tuple[float, float]] = [(0.5, 1.5)],
    jump_threshold: float = 3.0,
    min_periods: int = 5
) -> pd.DataFrame:
    """
    Calculate volatility-based prediction targets.
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(vol_windows, int):
        vol_windows = [vol_windows]
    
    vol_targets = pd.DataFrame(index=prices.index)
    
    # Calculate daily returns
    returns = prices.pct_change()
    
    for window in vol_windows:
        # Calculate historical volatility
        hist_vol = returns.rolling(window=window, min_periods=min_periods).std()
        
        # Calculate EWMA volatility
        ewma_vol = returns.ewm(span=window, min_periods=min_periods).std()
        
        # Calculate volatility of volatility
        vol_of_vol = hist_vol.pct_change().rolling(window=window, min_periods=min_periods).std()
        
        for horizon in horizons:
            # Calculate future volatility
            future_returns = prices.pct_change().shift(-horizon)
            future_vol = future_returns.rolling(window=window, min_periods=min_periods).std()
            
            # Store basic volatility measures
            vol_targets[f'future_vol_{window}_{horizon}'] = future_vol
            vol_targets[f'hist_vol_{window}_{horizon}'] = hist_vol
            vol_targets[f'ewma_vol_{window}_{horizon}'] = ewma_vol
            vol_targets[f'vol_of_vol_{window}_{horizon}'] = vol_of_vol
            
            # Volatility regimes
            for low_thresh, high_thresh in regime_thresholds:
                # Current regime
                current_regime = pd.Series(0, index=prices.index)  # Low vol regime
                current_regime[hist_vol > (hist_vol.rolling(window=window).mean() * high_thresh)] = 2  # High vol
                current_regime[(hist_vol <= (hist_vol.rolling(window=window).mean() * high_thresh)) & 
                             (hist_vol >= (hist_vol.rolling(window=window).mean() * low_thresh))] = 1  # Normal vol
                
                # Future regime
                future_regime = pd.Series(0, index=prices.index)  # Low vol regime
                future_regime[future_vol > (future_vol.rolling(window=window).mean() * high_thresh)] = 2  # High vol
                future_regime[(future_vol <= (future_vol.rolling(window=window).mean() * high_thresh)) & 
                            (future_vol >= (future_vol.rolling(window=window).mean() * low_thresh))] = 1  # Normal vol
                
                vol_targets[f'current_vol_regime_{window}_{horizon}'] = current_regime
                vol_targets[f'future_vol_regime_{window}_{horizon}'] = future_regime
                
                # Calculate regime transition probabilities
                for i in [0, 1, 2]:  # Current regime
                    for j in [0, 1, 2]:  # Future regime
                        current_state = (current_regime == i)
                        next_state = (future_regime == j)
                        trans_prob = (
                            (current_state & next_state)
                            .rolling(window=window, min_periods=min_periods)
                            .mean()
                            / (current_state.rolling(window=window, min_periods=min_periods).mean() + 1e-10)
                        )
                        vol_targets[f'vol_regime_trans_{i}to{j}_{window}_{horizon}'] = trans_prob.fillna(0)
            
            # Jump detection
            abs_returns = abs(returns)
            rolling_mean = abs_returns.rolling(window=window, min_periods=min_periods).mean()
            rolling_std = abs_returns.rolling(window=window, min_periods=min_periods).std()
            jump_intensity = ((abs_returns - rolling_mean) / rolling_std).fillna(0)
            jump_intensity[jump_intensity < jump_threshold] = 0
            
            # Future jumps
            future_abs_returns = abs(future_returns)
            future_jumps = (future_abs_returns > (rolling_mean + jump_threshold * rolling_std)).astype(int)
            
            vol_targets[f'jump_intensity_{window}_{horizon}'] = jump_intensity
            vol_targets[f'future_jumps_{window}_{horizon}'] = future_jumps
            
            # Volatility term structure
            vol_term_structure = future_vol / hist_vol - 1
            vol_targets[f'vol_term_structure_{window}_{horizon}'] = vol_term_structure
            
            # Future realized range
            future_prices = pd.concat([prices.shift(-i) for i in range(horizon+1)], axis=1)
            future_range = (future_prices.max(axis=1) - future_prices.min(axis=1)) / prices
            vol_targets[f'future_range_{window}_{horizon}'] = future_range
            
            # Volatility changes
            vol_change = hist_vol.pct_change()
            future_vol_change = future_vol.pct_change()
            
            vol_targets[f'vol_change_{window}_{horizon}'] = vol_change
            vol_targets[f'future_vol_change_{window}_{horizon}'] = future_vol_change
    
    return vol_targets 