from dataclasses import dataclass
import subprocess
import logging
import sys
from typing import Optional
import os

# ロギングの設定
log_level = os.getenv("PHUNT_LOG_LEVEL", "INFO")
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

@dataclass
class FeastUIConfig:
    """Feast UIの設定クラス"""
    host: str = "0.0.0.0"
    port: int = 8888

class FeastUIServer:
    """Feast UIサーバーのメインクラス"""
    def __init__(self, config: FeastUIConfig):
        self.config = config
        self._process: Optional[subprocess.Popen] = None
        
    def run(self, block: bool = True) -> None:
        """Feast UIを起動"""
        try:
            cmd = [
                "feast", "ui",
                "--host", self.config.host,
                "--port", str(self.config.port)
            ]

            # 既存のプロセスを終了
            self.stop()

            # 新しいプロセスを開始
            logger.info(f"Starting Feast UI on {self.config.host}:{self.config.port}")
            self._process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )

            logger.info(f"Feast UI started (PID: {self._process.pid})")
            logger.info(f"\n=== Feast UI Access Information ===")
            logger.info(f"URL: http://{self.config.host}:{self.config.port}")
            logger.info("================================\n")

            if block:
                try:
                    while True:
                        if self._process:
                            self._process.wait()
                        else:
                            break
                except KeyboardInterrupt:
                    logger.info("\nShutting down Feast UI...")
                    self.stop()

        except Exception as e:
            logger.error(f"Failed to start Feast UI: {str(e)}", exc_info=True)
            raise

    def stop(self) -> None:
        """Feast UIを停止"""
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
                logger.info("Feast UI stopped")
            except subprocess.TimeoutExpired:
                self._process.kill()
                logger.info("Feast UI forcefully terminated")
            finally:
                self._process = None

    def __del__(self):
        """デストラクタ：プロセスのクリーンアップ"""
        self.stop() 