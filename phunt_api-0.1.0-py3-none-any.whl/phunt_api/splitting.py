import pandas as pd
from typing import Tuple, Optional
from .schemas.dataset import SplitConfig, SplitMethod

class DatasetSplitter:
    @staticmethod
    def split(df: pd.DataFrame, config: SplitConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Splits the dataframe based on the provided configuration.
        """
        if config.method == SplitMethod.TIME_SERIES:
            return DatasetSplitter._split_time_series(df, config)
        elif config.method == SplitMethod.RANDOM:
            return DatasetSplitter._split_random(df, config)
        else:
            raise ValueError(f"Unsupported split method: {config.method}")

    @staticmethod
    def _split_time_series(df: pd.DataFrame, config: SplitConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
        # Ensure data is sorted by time if possible
        # Assuming index is datetime or 'ts'/'date' column exists
        
        # Legacy support for test_year
        if config.test_year:
            if 'date' in df.columns:
                date_col = df['date']
            elif isinstance(df.index, pd.DatetimeIndex):
                date_col = df.index
            else:
                 # Try to find a date column
                date_col_name = next((col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()), None)
                if date_col_name:
                     date_col = pd.to_datetime(df[date_col_name])
                else:
                    raise ValueError("Cannot perform time-based split without a date column or index.")

            if not isinstance(date_col, (pd.DatetimeIndex, pd.Series)):
                 date_col = pd.to_datetime(date_col)

            # Handle Series vs Index for .dt accessor
            if isinstance(date_col, pd.DatetimeIndex):
                 years = date_col.year
            else:
                 years = date_col.dt.year
            
            test_mask = years == config.test_year
            return df[~test_mask], df[test_mask]

        # Standard time series split
        split_idx = int(len(df) * config.train_ratio)
        return df.iloc[:split_idx], df.iloc[split_idx + config.gap:]

    @staticmethod
    def _split_random(df: pd.DataFrame, config: SplitConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
        # Simple random split
        train_df = df.sample(frac=config.train_ratio, random_state=42)
        test_df = df.drop(train_df.index)
        return train_df, test_df
