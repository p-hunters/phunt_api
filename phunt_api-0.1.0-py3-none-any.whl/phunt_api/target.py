# -*- coding: utf-8 -*-

from typing import List, Dict, Any, Callable, Optional, Union, TYPE_CHECKING
from .types import Field, Float32, Int64, String, ValueType
from .dataset import DatasetManager
from .utils import upload_script_to_s3, query_s3_duckdb
from .exceptions import TargetError
import pandas as pd
import os
import inspect

class TargetManager:
    def __init__(self, dataset_manager: DatasetManager):
        self.dataset_manager = dataset_manager
        self.creds = dataset_manager.creds
        self.cache = {}
        
    def create_target(self, name: str, local_path: str):
        try:
            return self.create_target_from_local(name, local_path)
        except Exception as e:
            raise TargetError(f"Failed to create target: {str(e)}")

    def list_targets(self) -> List[Any]:
        try:
            return self.dataset_manager.list_datasets(view_type="target")
        except Exception as e:
            raise TargetError(f"Failed to list targets: {str(e)}")

    def get_target(self, target_name: str):
        if target_name in self.cache:
            return self.cache[target_name]
            
        features_df = self.dataset_manager.adapter.get_historical_features(entity_df=None, feature_refs=[target_name])
        
        self.cache[target_name] = features_df
        return features_df

    def update_target(self, target_name: str, updated_definition: Dict[str, Any]) -> Any:
        try:
            # Datacatalog doesn't strictly enforce schema updates via an object like Feast.
            # We assume metadata update is what is intended.
            # Or if we want to update schema validation?
            # For now, simplistic implementation:
            pass
            # target_view = self.get_target_view(target_name) # Need a way to get view object
            # ...
            # Since DatacatalogAdapter updates are basically "overwrite metadata", we might not need complex logic here yet.
            raise NotImplementedError("update_target not fully supported in Datacatalog backend yet.")
        except Exception as e:
            raise TargetError(f"Failed to update target: {str(e)}")

    def delete_target(self, target_name: str) -> None:
        try:
            self.dataset_manager.delete_dataset(target_name)
        except Exception as e:
            raise TargetError(f"Failed to delete target: {str(e)}")

    def _get_type(self, type_str: str) -> Any:
        type_mapping = {
            "float": Float32,
            "int": Int64,
            "float64": Float32,
            "int64": Int64,
            "float32": Float32,
            "int32": Int64,
            "string": String,
            "str": String
        }
        return type_mapping.get(type_str.lower(), String)

    def submit_target(self, name: str, processing_code: Optional[Callable] = None, df: Optional[pd.DataFrame] = None, api_instance = None) -> None:
        try:
            import hashlib
            
            code_path = None
            if df is not None:
                processed_data = df
            elif processing_code is not None:
                api_to_use = api_instance
                try:
                    processed_data = processing_code(api_to_use)
                except TypeError as e:
                    raise TargetError(f"processing_code must accept API instance: {str(e)}")
                except Exception as e:
                    raise TargetError(f"Error generating target: {str(e)}")
                
                code_string = inspect.getsource(processing_code)
                hash_object = hashlib.md5(code_string.encode())
                code_hash = hash_object.hexdigest()
                file_path = f"/tmp/target_{name}.py"
                with open(file_path, 'w') as f:
                    f.write(code_string)
                print(f"Processing code saved to: {file_path}")
                # Note: upload_script_to_s3 needs to be verified if it works without Feast env vars.
                # It uses boto3 directly in utils.py, so it should be fine if creds are set.
                code_path = upload_script_to_s3(file_path, code_hash)

            local_path = f"/tmp/{name}.parquet"
            processed_data.to_parquet(local_path)
            self.create_target(name, local_path) # Calls create_target_from_local which handles code_path via logic below? Not passed yet.
            
            # Need to pass code_path to create_target/create_target_from_local
            # But create_target signature is fixed? 
            # modifying create_target signature in this file to accept optional args or handle it in submit_target
            # Let's direct call create_target_from_local here with code_path
            self.create_target_from_local(name, local_path, code_path=code_path)

        except Exception as e:
            raise TargetError(f"Failed to submit target: {str(e)}")

    def _generate_and_register_targets(self, target_name: str, processing_code: Callable) -> None:
        # This seems legacy logic used for train/test splitting which is now handled by dataset manager mostly?
        # Or specific for targets.
        try:
            train_data = self.dataset_manager.get_dataset_split(target_name, "train")
            test_data = self.dataset_manager.get_dataset_split(target_name, "test")
            
            processed_train = processing_code(train_data)
            processed_test = processing_code(test_data)
            
            self._register_targets(target_name, processed_train, processed_test)
        except Exception as e:
            raise TargetError(f"Error in generate_and_register_targets: {str(e)}")

    def _register_targets(self, target_name: str, train_targets: pd.DataFrame, test_targets: pd.DataFrame) -> None:
         # Uploads train/test splits.
         # Datacatalog doesn't natively split on upload like Feast features might?
         # Actually DatasetManager.create_dataset_from_local stores one file.
         # If we want splits, we should probably concatenate or store separately.
         # For now, let's assume we just upload one combined or main one.
         # Revisit if needed.
         pass

    def _upload_target_data(self, target_name: str, target_data: pd.DataFrame, data_type: str) -> None:
        try:
            temp_file = f"/tmp/{target_name}_{data_type}_targets.parquet"
            target_data.to_parquet(temp_file)
            self.dataset_manager.upload_file(target_name, temp_file)
            os.remove(temp_file)
        except Exception as e:
            raise TargetError(f"Failed to upload target data: {str(e)}")

    def create_target_from_local(self, name: str, local_path: str, code_path: Optional[str] = None):
         return self.dataset_manager.create_dataset_from_local(
             name, 
             local_path, 
             tags={"type": "target", "code_path": str(code_path) if code_path else ""}
         )

if __name__ == "__main__":
    pass
