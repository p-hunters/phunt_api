# -*- coding: utf-8 -*-

from typing import List, Dict, Any, Callable
from feast import FeatureView, Field
from feast.types import Float32, Int64
from .dataset import DatasetManager, PublicDatasetManager, FeastManager
from .utils import create_from_local_base, upload_script_to_s3, query_s3_duckdb
from .exceptions import TargetError
import pandas as pd
import os
import inspect

class TargetManager:
    def __init__(self, dataset_manager: DatasetManager):
        self.dataset_manager = dataset_manager
        self.feast_manager = FeastManager(dataset_manager.repo_path)
        self.creds = dataset_manager.creds
        self.cache = {}
    def create_target(self, name: str, local_path: str):
        try:
            return self.create_target_from_local(name, local_path)
        except Exception as e:
            raise TargetError(f"目的変数の作成中にエラーが発生しました: {str(e)}")

    def list_targets(self) -> List[FeatureView]:
        try:
            return self.dataset_manager.list_datasets(view_type="target")
        except Exception as e:
            raise TargetError(f"目的変数のリスト取得中にエラーが発生しました: {str(e)}")

    def get_target(self, target_name: str):
        if target_name in self.cache:
            return self.cache[target_name]
        feature_view = self.feast_manager.get_feature_view(target_name)
        print(feature_view)
        entity_df = self._get_entity_df_for_feature_view(feature_view)
        print(entity_df)
        features_df = self.feast_manager.get_historical_features(target_name, entity_df)
        self.cache[target_name] = features_df
        return features_df

    def _get_entity_df_for_feature_view(self, feature_view):
        path_to_parquet = f'{feature_view.batch_source.name}'
        entity_df = query_s3_duckdb(path_to_parquet, self.creds)
        return entity_df

    def update_target(self, target_name: str, updated_definition: Dict[str, Any]) -> FeatureView:
        try:
            target_view = self.get_target(target_name)
            updated_schema = [
                Field(name=field_name, dtype=self._get_feast_type(field_type))
                for field_name, field_type in updated_definition.items()
            ]
            target_view.schema = updated_schema
            self.dataset_manager.update_dataset(target_view)
            return target_view
        except Exception as e:
            raise TargetError(f"目的変数の更新中にエラーが発生しました: {str(e)}")

    def delete_target(self, target_name: str) -> None:
        try:
            self.dataset_manager.delete_dataset(target_name)
        except Exception as e:
            raise TargetError(f"目的変数の削除中にエラーが発生しました: {str(e)}")

    def _get_feast_type(self, type_str: str) -> Any:
        type_mapping = {
            "float": Float32,
            "int": Int64,
            "float64": Float32,
            "int64": Int64,
            "float32": Float32,
            "int32": Int64,
        }
        return type_mapping.get(type_str.lower(), Float32)

    def submit_target(self, name: str, processing_code: Callable = None, df: pd.DataFrame = None, api_instance = None) -> None:
        try:
            import hashlib
            
            code_path = None
            if df is not None:
                processed_data = df
            elif processing_code is not None:
                # 引数で提供されたAPIインスタンスがあればそれを使用
                api_to_use = api_instance
                
                # APIインスタンスがない場合は処理コードを直接実行
                # 注意: 従来の動作を維持するためですが、実際にはapiを渡すべきです
                processed_data = processing_code(api_to_use) if api_to_use else processing_code()
                
                code_string = inspect.getsource(processing_code)
                hash_object = hashlib.md5(code_string.encode())
                code_hash = hash_object.hexdigest()
                file_path = f"/tmp/target_{name}.py"
                with open(file_path, 'w') as f:
                    f.write(code_string)
                print(f"Processing code saved to: {file_path}")
                code_path = upload_script_to_s3(file_path, code_hash)

            local_path = f"/tmp/{name}.parquet"
            processed_data.to_parquet(local_path)
            self.create_target(name, local_path)

        except Exception as e:
            raise TargetError(f"目的変数の登録中にエラーが発生しました: {str(e)}")

    def _generate_and_register_targets(self, target_name: str, processing_code: Callable) -> None:
        try:
            train_data = self.dataset_manager.get_dataset_split(target_name, "train")
            test_data = self.dataset_manager.get_dataset_split(target_name, "test")
            
            processed_train = processing_code(train_data)
            processed_test = processing_code(test_data)
            
            self._register_targets(target_name, processed_train, processed_test)
        except Exception as e:
            raise TargetError(f"目的変数の生成と登録中にエラーが発生しました: {str(e)}")

    def _register_targets(self, target_name: str, train_targets: pd.DataFrame, test_targets: pd.DataFrame) -> None:
        try:
            target_view = self.get_target(target_name)
            new_schema = [
                Field(name=col, dtype=self._get_feast_type(str(train_targets[col].dtype)))
                for col in train_targets.columns
            ]
            target_view.schema = new_schema
            self.dataset_manager.update_dataset(target_view)
            
            self._upload_target_data(target_name, train_targets, "train")
            self._upload_target_data(target_name, test_targets, "test")
        except Exception as e:
            raise TargetError(f"目的変数の登録中にエラーが発生しました: {str(e)}")

    def _upload_target_data(self, target_name: str, target_data: pd.DataFrame, data_type: str) -> None:
        try:
            temp_file = f"/tmp/{target_name}_{data_type}_targets.parquet"
            target_data.to_parquet(temp_file)
            self.dataset_manager.upload_file(target_name, temp_file)
            os.remove(temp_file)
        except Exception as e:
            raise TargetError(f"目的変数データのアップロード中にエラーが発生しました: {str(e)}")

    def create_target_from_local(self, name: str, local_path: str):
        return create_from_local_base(self.feast_manager, name, local_path, "target", self.dataset_manager.sample_ratio)

if __name__ == "__main__":
    try:
        # 使用例（内部用）
        dataset_manager = DatasetManager("/path/to/feast/repo")
        internal_target_manager = TargetManager(dataset_manager)

        # 使用例（公開用）
        public_dataset_manager = PublicDatasetManager("/path/to/feast/repo")
        public_target_manager = PublicTargetManager(public_dataset_manager)

        # 目的変数作成の例
        def create_return_target(data):
            data['next_day_return'] = data['close'].pct_change(-1)  # 翌日のリターン
            return data[['next_day_return']]

        # 公開APIを使用した目的変数の登録
        public_target_manager.submit_target("stock_return", "stock", create_return_target)

        # 目的変数のリスト取得（公開API）
        target_list = public_target_manager.list_targets()
        print(f"登録された目的変数: {target_list}")

    except TargetError as e:
        print(f"目的変数操作中にエラーが発生しました: {str(e)}")
