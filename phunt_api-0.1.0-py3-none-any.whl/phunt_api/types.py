from dataclasses import dataclass
from typing import Any, List, Optional, Dict

@dataclass
class Field:
    name: str
    dtype: Any

# Simple replacement for Feast types
class ValueType:
    STRING = "STRING"
    INT32 = "INT32"
    INT64 = "INT64"
    FLOAT = "FLOAT"
    DOUBLE = "DOUBLE"
    BOOL = "BOOL"
    UNIX_TIMESTAMP = "UNIX_TIMESTAMP"
    BYTES = "BYTES"

# Type aliases for compatibility/cleaning
String = ValueType.STRING
Int32 = ValueType.INT32
Int64 = ValueType.INT64
Float32 = ValueType.FLOAT
Float64 = ValueType.DOUBLE
Bool = ValueType.BOOL
UnixTimestamp = ValueType.UNIX_TIMESTAMP
Bytes = ValueType.BYTES

@dataclass
class Entity:
    name: str
    value_type: Any = ValueType.STRING
    description: str = ""
    join_key: str = ""

@dataclass
class FeatureView:
    name: str
    entities: List[str]
    ttl: Optional[Any] = None
    tags: Optional[Dict[str, str]] = None
    online: bool = True
    batch_source: Any = None
    schema: Optional[List[Field]] = None
