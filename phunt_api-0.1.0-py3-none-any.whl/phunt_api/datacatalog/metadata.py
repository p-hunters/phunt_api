import boto3
import json
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

class MetadataManager:
    """
    Manages feature metadata in S3 (JSON format).
    """
    def __init__(self, bucket_name: str, region: str = "ap-northeast-1"):
        self.bucket = bucket_name
        self.s3 = boto3.client("s3", region_name=region)
        self.prefix = "features/metadata"

    def register_feature(self, metadata: Dict[str, Any]):
        """
        Register or update feature metadata in S3.
        
        Args:
            metadata: Dictionary containing feature metadata.
                      Must include: feature_id, feature_name, feature_group
        """
        # Ensure timestamp
        now = datetime.utcnow().timestamp()
        if "created_at" not in metadata:
            metadata["created_at"] = now
        metadata["updated_at"] = now
        
        feature_id = metadata.get("feature_id")
        if not feature_id:
             # Fallback to name if ID not provided
             feature_id = metadata.get("feature_name")
        
        if not feature_id:
            raise ValueError("Metadata must contain 'feature_id' or 'feature_name'")
            
        key = f"{self.prefix}/{feature_id}.json"
        
        try:
            self.s3.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=json.dumps(metadata, default=str),
                ContentType="application/json"
            )
        except Exception as e:
            raise Exception(f"Failed to save metadata to {key}: {str(e)}")

    def get_feature(self, feature_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve feature metadata.
        """
        key = f"{self.prefix}/{feature_id}.json"
        try:
            response = self.s3.get_object(Bucket=self.bucket, Key=key)
            content = response['Body'].read().decode('utf-8')
            return json.loads(content)
        except self.s3.exceptions.NoSuchKey:
            return None
        except Exception as e:
            print(f"Error loading metadata for {feature_id}: {e}")
            return None

    def list_features(self) -> List[Dict[str, Any]]:
        """
        List all registered features.
        """
        features = []
        try:
            # List objects in metadata prefix
            paginator = self.s3.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=self.bucket, Prefix=self.prefix)
            
            for page in pages:
                if 'Contents' not in page:
                    continue
                    
                for obj in page['Contents']:
                    if obj['Key'].endswith('.json'):
                        # Ideally we read them all? Or just return IDs?
                        # For listing, we probably want basic info.
                        # Reading all might be slow if many features. 
                        # But for now, let's read them to return full list.
                        try:
                            resp = self.s3.get_object(Bucket=self.bucket, Key=obj['Key'])
                            content = resp['Body'].read().decode('utf-8')
                            features.append(json.loads(content))
                        except:
                            continue
                            
            return features
        except Exception as e:
            print(f"Error listing features: {e}")
            return []
            
    def search_features(self, query: str = "") -> List[Dict[str, Any]]:
        """
        Search features using Athena.
        """
        if not query:
            return self.list_features()
            
        # Initialize Athena Client
        athena = boto3.client("athena", region_name=self.s3.meta.region_name)
        
        # SQL Query
        # Note: feature_registry table created by TF
        sql = f"""
        SELECT feature_id, feature_name, feature_group, description, tags, updated_at
        FROM "phunt_datacatalog"."feature_registry"
        WHERE feature_name LIKE '%{query}%' 
           OR description LIKE '%{query}%'
           OR feature_group LIKE '%{query}%'
        """
        
        try:
            # Start Query
            response = athena.start_query_execution(
                QueryString=sql,
                QueryExecutionContext={'Database': 'phunt_datacatalog'},
                ResultConfiguration={'OutputLocation': f's3://{self.bucket}/athena-results/'}
            )
            query_execution_id = response['QueryExecutionId']
            
            # Wait for results
            while True:
                status = athena.get_query_execution(QueryExecutionId=query_execution_id)
                state = status['QueryExecution']['Status']['State']
                
                if state in ['SUCCEEDED']:
                    break
                elif state in ['FAILED', 'CANCELLED']:
                    raise Exception(f"Athena Query Failed: {status['QueryExecution']['Status']['StateChangeReason']}")
                    
                time.sleep(0.5)
                
            # Get Results
            results_resp = athena.get_query_results(QueryExecutionId=query_execution_id)
            
            # Parse Results (Skip header)
            # Athena returns structured rows
            cols = [col['Label'] for col in results_resp['ResultSet']['ResultSetMetadata']['ColumnInfo']]
            rows = results_resp['ResultSet']['Rows'][1:] # Skip header
            
            features = []
            for row in rows:
                data = row['Data']
                feature = {}
                for i, col_name in enumerate(cols):
                    # Handle different types securely? 
                    # Athena returns strings mostly in VarChar
                    val = data[i].get('VarCharValue')
                    
                    if col_name == 'tags' and val:
                         # Attempt to parse tags
                         try:
                             # 1. Try JSON load
                             feature[col_name] = json.loads(val)
                         except:
                             # 2. Athena Map format often: "{key=value, k2=v2}"
                             # This is hard to parse reliably with regex if values contain commas, but simple try:
                             if val.startswith('{') and val.endswith('}'):
                                 try:
                                     # Very naive parser for {k=v} style
                                     content = val[1:-1]
                                     if not content:
                                         feature[col_name] = {}
                                     else:
                                         # Replace = with : and keys with quotes (unsafe but worth a try for display)
                                         # Better: Just leave as string if JSON fails.
                                         feature[col_name] = val
                                 except:
                                     feature[col_name] = val
                             else:
                                 feature[col_name] = val
                    else:
                        feature[col_name] = val
                        
                features.append(feature)
                
            return features
            
        except Exception as e:
            print(f"Search failed: {e}")
            return []
