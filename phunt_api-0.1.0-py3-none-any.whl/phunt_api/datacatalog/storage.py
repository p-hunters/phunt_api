import pandas as pd
import awswrangler as wr
import os
from typing import Optional, Dict
import boto3
from ..exceptions import DatasetError

class ParquetStorage:
    """
    Handles internal Parquet file storage on S3, ensuring NautilusTrader compatibility.
    """
    def __init__(self, bucket_name: str):
        self.bucket = bucket_name
        
    def save(self, df: pd.DataFrame, key: str, partition_cols: Optional[list] = None) -> str:
        """
        Save DataFrame to S3 as Parquet.
        
        Args:
            df: DataFrame to save.
            key: S3 key (path) without bucket.
            partition_cols: List of columns to partition by.
            
        Returns:
            s3_path: Full S3 path of the saved file.
        """
        s3_path = f"s3://{self.bucket}/{key}"
        
        # Ensure Nautilus compatibility features here if needed (e.g. compression)
        # Nautilus uses zstd by default
        
        try:
            wr.s3.to_parquet(
                df=df,
                path=s3_path,
                dataset=True, # Create a directory (dataset) style structure
                mode="overwrite",
                partition_cols=partition_cols,
                compression="zstd"
            )
            return s3_path
        except Exception as e:
            raise DatasetError(f"Failed to save parquet to {s3_path}: {str(e)}")

    def load(self, key: str) -> pd.DataFrame:
        """
        Load DataFrame from S3 Parquet.
        
        Args:
            key: S3 key (path) or full s3:// path.
            
        Returns:
            pd.DataFrame
        """
        if key.startswith("s3://"):
            path = key
        else:
            path = f"s3://{self.bucket}/{key}"
            
        try:
            return wr.s3.read_parquet(path=path)
        except Exception as e:
             raise DatasetError(f"Failed to load parquet from {path}: {str(e)}")
