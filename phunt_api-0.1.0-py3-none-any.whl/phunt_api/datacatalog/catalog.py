from typing import Optional, Dict, List, Any
import pandas as pd
from .storage import ParquetStorage
from .metadata import MetadataManager
from ..exceptions import DatasetError

class DataCatalog:
    """
    Main interface for the PHunt Data Catalog.
    Combines storage (S3/Parquet) and metadata (Glue) operations.
    """
    def __init__(self, bucket_name: str, glue_database: str, region: str = "ap-northeast-1"):
        self.storage = ParquetStorage(bucket_name)
        self.metadata = MetadataManager(bucket_name, region)
        self.bucket_name = bucket_name

    def save_feature(self, 
                     feature_id: str, 
                     df: pd.DataFrame, 
                     metadata: Dict[str, Any],
                     partition_cols: Optional[List[str]] = None) -> str:
        """
        Save a feature dataframe and register its metadata.
        
        Args:
            feature_id: Unique identifier for the feature.
            df: DataFrame containing the feature data.
            metadata: Metadata dictionary.
            partition_cols: Columns to partition by.
            
        Returns:
            s3_path: Path where data was saved.
        """
        # 1. Construct S3 Key
        # Structure: features/data/{group}/{name}/{start}_{end}.parquet
        group = metadata.get("feature_group", "default")
        name = metadata.get("feature_name", feature_id)
        
        # Try to find time range from df
        start_ts = "0"
        end_ts = "0"
        
        if "ts" in df.columns:
            start_ts = str(df["ts"].min())
            end_ts = str(df["ts"].max())
        elif df.index.name == "ts":
             start_ts = str(df.index.min())
             end_ts = str(df.index.max())
             
        key = f"features/data/{group}/{name}/{start_ts}_{end_ts}.parquet"
        
        # 2. Save Data
        s3_path = self.storage.save(df, key, partition_cols)
        
        # 3. Register Metadata
        metadata["feature_id"] = feature_id
        metadata["s3_location"] = s3_path
        self.metadata.register_feature(metadata)
        
        return s3_path

    def load_feature(self, feature_id: str) -> pd.DataFrame:
        """
        Load a feature by ID. 
        """
        metadata = self.metadata.get_feature(feature_id)
        if not metadata:
            raise DatasetError(f"Feature {feature_id} not found in catalog.")
            
        s3_path = metadata.get("s3_location")
        if not s3_path:
             raise DatasetError(f"Metadata for {feature_id} missing s3_location.")
             
        return self.storage.load(s3_path)

    def load_from_path(self, key: str) -> pd.DataFrame:
        return self.storage.load(key)
