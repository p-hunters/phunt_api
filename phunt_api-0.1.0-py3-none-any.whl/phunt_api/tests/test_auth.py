import unittest
from unittest.mock import patch, MagicMock, mock_open
from datetime import datetime, timezone, timedelta
import os
import json
import tempfile
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from phunt_api.auth import PHuntAuth
from phunt_api.exceptions import AuthenticationError
import requests

class TestPHuntAuth(unittest.TestCase):
    def setUp(self):
        """テスト環境のセットアップ"""
        self.temp_dir = tempfile.mkdtemp()
        self.cert_path = os.path.join(self.temp_dir, "client.crt")
        self.key_path = os.path.join(self.temp_dir, "client.key")
        self.ca_path = os.path.join(self.temp_dir, "ca.crt")
        
        # テスト用の証明書を生成
        self._generate_test_certificates()
        
        # 環境変数をクリア
        for var in ["PHUNT_CERT_PATH", "PHUNT_KEY_PATH", "PHUNT_CA_PATH"]:
            if var in os.environ:
                del os.environ[var]

    def tearDown(self):
        """テスト環境のクリーンアップ"""
        import shutil
        shutil.rmtree(self.temp_dir)

    def _generate_test_certificates(self):
        """テスト用の証明書を生成"""
        # 秘密鍵の生成
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        
        # 証明書の生成
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"test.p-hunter.com")
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.utcnow()
        ).not_valid_after(
            datetime.utcnow() + timedelta(days=10)
        ).add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True
        ).sign(private_key, default_backend())
        
        # 証明書と鍵をファイルに保存
        with open(self.cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        
        with open(self.key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        with open(self.ca_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))

    def test_init_with_paths(self):
        """パスを指定して初期化するテスト"""
        auth = PHuntAuth(
            cert_path=self.cert_path,
            key_path=self.key_path,
            ca_path=self.ca_path,
            debug=True
        )
        self.assertEqual(auth.cert_path, self.cert_path)
        self.assertEqual(auth.key_path, self.key_path)
        self.assertEqual(auth.ca_path, self.ca_path)

    def test_init_with_env_vars(self):
        """環境変数から初期化するテスト"""
        os.environ["PHUNT_CERT_PATH"] = self.cert_path
        os.environ["PHUNT_KEY_PATH"] = self.key_path
        os.environ["PHUNT_CA_PATH"] = self.ca_path
        
        auth = PHuntAuth(debug=True)
        self.assertEqual(auth.cert_path, self.cert_path)
        self.assertEqual(auth.key_path, self.key_path)
        self.assertEqual(auth.ca_path, self.ca_path)

    def test_init_without_certs_dev(self):
        """証明書なしで初期化するテスト（開発環境）"""
        auth = PHuntAuth(
            auth_server_url="http://localhost:8000",
            debug=True
        )
        self.assertIsNone(auth.cert_path)
        self.assertIsNone(auth.key_path)
        self.assertIsNone(auth.ca_path)

    def test_certificate_expiration(self):
        """証明書の有効期限チェックのテスト"""
        # 有効期限切れの証明書を生成
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"test.p-hunter.com")
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.utcnow() - timedelta(days=20)
        ).not_valid_after(
            datetime.utcnow() - timedelta(days=10)
        ).add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True
        ).sign(private_key, default_backend())
        
        expired_cert_path = os.path.join(self.temp_dir, "expired.crt")
        with open(expired_cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        
        auth = PHuntAuth(
            cert_path=expired_cert_path,
            key_path=self.key_path,
            ca_path=self.ca_path,
            debug=True
        )
        
        with self.assertRaises(AuthenticationError):
            auth._validate_certificates()

    @patch('requests.post')
    def test_login_success_dev(self, mock_post):
        """開発環境でのログイン成功テスト"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_key_id": "test_key",
            "secret_access_key": "test_secret",
            "session_token": "test_token",
            "expiration": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        }
        mock_post.return_value = mock_response
        
        auth = PHuntAuth(
            auth_server_url="http://localhost:8000",
            debug=True
        )
        credentials = auth.login()
        
        self.assertEqual(credentials["access_key_id"], "test_key")
        self.assertEqual(credentials["secret_access_key"], "test_secret")
        self.assertEqual(credentials["session_token"], "test_token")

    def test_is_logged_in(self):
        """ログイン状態の確認テスト"""
        auth = PHuntAuth(debug=True)
        
        # 未ログイン状態
        self.assertFalse(auth.is_logged_in())
        
        # ログイン状態をシミュレート
        auth._credentials = {
            "access_key_id": "test_key",
            "secret_access_key": "test_secret",
            "session_token": "test_token",
            "expiration": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        }
        self.assertTrue(auth.is_logged_in())
        
        # 有効期限切れ
        auth._credentials["expiration"] = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self.assertFalse(auth.is_logged_in())

    def test_auth_event_logging(self):
        """認証イベントのログ記録テスト"""
        auth = PHuntAuth(debug=True)
        
        with self.assertLogs(logger='phunt_api.auth', level='INFO') as log:
            auth._log_auth_event(
                event_type="test_event",
                details={"test": "data"},
                success=True
            )
            
        self.assertTrue(any("test_event" in record.message for record in log.records))
        self.assertTrue(any("test" in record.message for record in log.records))
        self.assertTrue(any("data" in record.message for record in log.records))

    @patch('requests.post')
    def test_server_error_handling(self, mock_post):
        """サーバーエラー処理のテスト"""
        mock_post.side_effect = requests.exceptions.RequestException("Connection failed")
        
        auth = PHuntAuth(
            auth_server_url="http://localhost:8000",
            debug=True
        )
        
        with self.assertRaises(AuthenticationError):
            auth.login()

        with patch('requests.post', return_value=mock_response):
            with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=False):
                credentials = self.auth.login()
                
                self.assertEqual(credentials['aws_access_key_id'], 'test_access_key')
                self.assertEqual(credentials['aws_secret_access_key'], 'test_secret_key')
                self.assertEqual(credentials['aws_session_token'], 'test_session_token')
                self.assertTrue('expiration' in credentials)
                
                # 環境変数の確認
                self.assertEqual(os.environ['AWS_ACCESS_KEY_ID'], 'test_access_key')
                self.assertEqual(os.environ['AWS_SECRET_ACCESS_KEY'], 'test_secret_key')
                self.assertEqual(os.environ['AWS_SESSION_TOKEN'], 'test_session_token')

    @patch('google.colab.auth.authenticate_user')
    @patch('google.auth.default')
    @patch('requests.get')
    @patch('boto3.client')
    def test_login_success_colab(self, mock_boto3_client, mock_requests_get, mock_auth_default, mock_authenticate):
        """Google Colab環境でのログイン成功テスト"""
        # Google認証のモック
        mock_credentials = MagicMock()
        mock_credentials.token = 'test_token'
        mock_auth_default.return_value = (mock_credentials, None)
        
        # ユーザー情報のモック
        mock_userinfo_response = MagicMock()
        mock_userinfo_response.status_code = 200
        mock_userinfo_response.json.return_value = {'email': 'test@p-hunter.com'}
        mock_requests_get.return_value = mock_userinfo_response
        
        # AWS STSのモック
        mock_sts = MagicMock()
        mock_sts.assume_role.return_value = {
            'Credentials': {
                'AccessKeyId': 'test_access_key',
                'SecretAccessKey': 'test_secret_key',
                'SessionToken': 'test_session_token',
                'Expiration': datetime.now(timezone.utc) + timedelta(hours=1)
            }
        }
        mock_boto3_client.return_value = mock_sts
        
        # S3クライアントのモック
        mock_s3 = MagicMock()
        mock_s3.get_bucket_policy.return_value = {'Policy': json.dumps({
            'Version': '2012-10-17',
            'Statement': []
        })}
        mock_boto3_client.return_value = mock_s3
        
        with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=True):
            credentials = self.auth.login()
            
            self.assertEqual(credentials['aws_access_key_id'], 'test_access_key')
            self.assertEqual(credentials['aws_secret_access_key'], 'test_secret_key')
            self.assertEqual(credentials['aws_session_token'], 'test_session_token')
            self.assertTrue('expiration' in credentials)
            
            # 環境変数の確認
            self.assertEqual(os.environ['AWS_ACCESS_KEY_ID'], 'test_access_key')
            self.assertEqual(os.environ['AWS_SECRET_ACCESS_KEY'], 'test_secret_key')
            self.assertEqual(os.environ['AWS_SESSION_TOKEN'], 'test_session_token')

    def test_login_invalid_domain_colab(self):
        """無効なドメインでのGoogle Colab認証テスト"""
        mock_userinfo_response = MagicMock()
        mock_userinfo_response.status_code = 200
        mock_userinfo_response.json.return_value = {'email': 'test@invalid.com'}
        
        with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=True):
            with patch('requests.get', return_value=mock_userinfo_response):
                with patch('google.colab.auth.authenticate_user'):
                    with patch('google.auth.default', return_value=(MagicMock(), None)):
                        with self.assertRaises(AuthenticationError) as context:
                            self.auth.login()
                        self.assertIn("Workspaceドメインのユーザーのみがアクセスできます", str(context.exception))

    def test_is_logged_in(self):
        """ログイン状態の確認テスト"""
        # 有効な一時的クレデンシャル
        self.auth.tmp_creds = {
            'access_key_id': 'test_access_key',
            'secret_access_key': 'test_secret_key',
            'session_token': 'test_session_token',
            'expiration': (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        }
        self.assertTrue(self.auth.is_logged_in())
        
        # 期限切れの一時的クレデンシャル
        self.auth.tmp_creds = {
            'access_key_id': 'test_access_key',
            'secret_access_key': 'test_secret_key',
            'session_token': 'test_session_token',
            'expiration': (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        }
        self.assertFalse(self.auth.is_logged_in())
        
        # クレデンシャルなし
        self.auth.tmp_creds = None
        self.assertFalse(self.auth.is_logged_in())

    def test_auth_event_logging(self):
        """認証イベントのログ記録テスト"""
        with patch('logging.getLogger') as mock_logger:
            mock_logger_instance = MagicMock()
            mock_logger.return_value = mock_logger_instance
            
            # ログイン成功イベント
            self.auth._log_auth_event('test_event', {'test': 'data'})
            mock_logger_instance.info.assert_called_once()
            
            # ログイン失敗イベント
            self.auth._log_auth_event('test_error', {'error': 'test'}, success=False)
            mock_logger_instance.error.assert_called_once()

    @patch('requests.post')
    def test_server_error_handling(self, mock_post):
        """サーバーエラー処理のテスト"""
        mock_post.side_effect = requests.exceptions.RequestException("Connection error")
        
        with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=False):
            with self.assertRaises(AuthenticationError) as context:
                self.auth.login()
            self.assertIn("認証サーバーからのクレデンシャル取得に失敗しました", str(context.exception))

if __name__ == '__main__':
    unittest.main() 