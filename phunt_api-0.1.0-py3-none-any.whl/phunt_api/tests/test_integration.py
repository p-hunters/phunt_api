import unittest
import os
import json
import tempfile
import boto3
import requests
from pathlib import Path
from datetime import datetime, timezone, timedelta
from unittest.mock import patch, MagicMock
from phunt_api.auth import PHuntAuth
from phunt_api.exceptions import AuthenticationError
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

class TestPHuntAuthIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """テストクラス全体の前準備"""
        # テスト用の一時ディレクトリを作成
        cls.temp_dir = tempfile.mkdtemp()
        cls.auth_server_url = "https://localhost:8443"
        
        # テスト用のバケット名とプレフィックス
        cls.bucket_name = "phunt-data"
        cls.prefix = "users"
        
        # テスト用のAWS認証情報
        cls.aws_credentials = {
            'access_key_id': 'test_access_key',
            'secret_access_key': 'test_secret_key',
            'session_token': 'test_session_token',
            'expiration': (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        }
        
        # テスト用の証明書を生成
        cls._generate_test_certificates()

    @classmethod
    def _generate_test_certificates(cls):
        """テスト用の証明書を生成"""
        # 秘密鍵の生成
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        
        # 証明書の生成
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"test.example.com")
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.now(timezone.utc)
        ).not_valid_after(
            datetime.now(timezone.utc) + timedelta(days=10)
        ).sign(private_key, hashes.SHA256(), default_backend())
        
        # 証明書と秘密鍵をファイルに保存
        cls.cert_path = Path(cls.temp_dir) / "client.crt"
        cls.key_path = Path(cls.temp_dir) / "client.key"
        cls.ca_path = Path(cls.temp_dir) / "ca.crt"
        
        with open(cls.cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        
        with open(cls.key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        with open(cls.ca_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))

    @classmethod
    def tearDownClass(cls):
        """テストクラス全体の後処理"""
        # 一時ディレクトリの削除
        import shutil
        shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """各テストケースの前準備"""
        # 環境変数のクリア
        self._clear_environment_variables()

    def tearDown(self):
        """各テストケースの後処理"""
        # 環境変数のクリア
        self._clear_environment_variables()

    def _clear_environment_variables(self):
        """環境変数をクリア"""
        env_vars = [
            'PHUNT_CLIENT_CERT', 'PHUNT_CLIENT_KEY', 'PHUNT_CA_CERT',
            'PHUNT_ACCESS_KEY', 'PHUNT_SECRET_KEY', 'PHUNT_SESSION_TOKEN',
            'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'AWS_SESSION_TOKEN'
        ]
        for var in env_vars:
            if var in os.environ:
                del os.environ[var]

    def test_dev_auth_flow(self):
        """開発環境での認証フローの統合テスト"""
        with patch('requests.post') as mock_post:
            # 認証サーバーのレスポンスをモック
            mock_post.return_value.status_code = 200
            mock_post.return_value.json.return_value = self.aws_credentials
            
            # PHuntAuthのインスタンスを作成
            auth = PHuntAuth(
                auth_server_url=self.auth_server_url,
                cert_path=str(self.cert_path),
                key_path=str(self.key_path),
                ca_path=str(self.ca_path)
            )
            
            # 認証を実行
            with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=False):
                creds = auth.login()
            
            # クレデンシャルの検証
            self.assertEqual(creds['aws_access_key_id'], self.aws_credentials['access_key_id'])
            self.assertEqual(creds['aws_secret_access_key'], self.aws_credentials['secret_access_key'])
            self.assertEqual(creds['aws_session_token'], self.aws_credentials['session_token'])
            
            # 環境変数の検証
            self.assertEqual(os.environ['AWS_ACCESS_KEY_ID'], self.aws_credentials['access_key_id'])
            self.assertEqual(os.environ['AWS_SECRET_ACCESS_KEY'], self.aws_credentials['secret_access_key'])
            self.assertEqual(os.environ['AWS_SESSION_TOKEN'], self.aws_credentials['session_token'])
            
            # ログイン状態の検証
            self.assertTrue(auth.is_logged_in())

    def test_colab_auth_flow(self):
        """Google Colab環境での認証フローの統合テスト"""
        # Google認証のモック
        mock_credentials = MagicMock()
        mock_credentials.token = 'test_token'
        
        # Google Colabのモック
        mock_colab = MagicMock()
        mock_colab.auth = MagicMock()
        mock_colab.auth.authenticate_user = MagicMock()
        
        with patch.dict('sys.modules', {
            'google.colab': mock_colab,
            'google.auth': MagicMock()
        }):
            with patch('google.auth.default', return_value=(mock_credentials, None)):
                with patch('requests.get') as mock_requests_get:
                    with patch('boto3.client') as mock_boto3_client:
                        # ユーザー情報のモック
                        mock_requests_get.return_value.status_code = 200
                        mock_requests_get.return_value.json.return_value = {'email': 'test@p-hunter.com'}
                        
                        # AWS STSのモック
                        mock_sts = MagicMock()
                        mock_sts.assume_role.return_value = {
                            'Credentials': {
                                'AccessKeyId': self.aws_credentials['access_key_id'],
                                'SecretAccessKey': self.aws_credentials['secret_access_key'],
                                'SessionToken': self.aws_credentials['session_token'],
                                'Expiration': datetime.now(timezone.utc) + timedelta(hours=1)
                            }
                        }
                        
                        # S3クライアントのモック
                        mock_s3 = MagicMock()
                        mock_s3.get_bucket_policy.return_value = {'Policy': json.dumps({
                            'Version': '2012-10-17',
                            'Statement': []
                        })}
                        
                        # boto3.clientの呼び出し順序に応じて異なるモックを返す
                        mock_boto3_client.side_effect = [mock_sts, mock_s3]
                        
                        # PHuntAuthのインスタンスを作成
                        with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=True):
                            auth = PHuntAuth()
                            creds = auth.login()
                        
                        # クレデンシャルの検証
                        self.assertEqual(creds['aws_access_key_id'], self.aws_credentials['access_key_id'])
                        self.assertEqual(creds['aws_secret_access_key'], self.aws_credentials['secret_access_key'])
                        self.assertEqual(creds['aws_session_token'], self.aws_credentials['session_token'])
                        
                        # S3バケットポリシーの更新を検証
                        mock_s3.put_bucket_policy.assert_called_once()
                        policy_arg = json.loads(mock_s3.put_bucket_policy.call_args[1]['Policy'])
                        self.assertEqual(policy_arg['Version'], '2012-10-17')
                        self.assertEqual(len(policy_arg['Statement']), 1)
                        
                        statement = policy_arg['Statement'][0]
                        self.assertEqual(statement['Effect'], 'Allow')
                        self.assertIn('s3:GetObject', statement['Action'])
                        self.assertIn('s3:PutObject', statement['Action'])
                        self.assertIn('s3:ListBucket', statement['Action'])
                        
                        # ログイン状態の検証
                        self.assertTrue(auth.is_logged_in())

    def test_credential_expiration(self):
        """クレデンシャルの有効期限管理のテスト"""
        auth = PHuntAuth(
            cert_path=str(self.cert_path),
            key_path=str(self.key_path),
            ca_path=str(self.ca_path)
        )
        
        # 期限切れ間近のクレデンシャルをセット
        auth.tmp_creds = {
            'access_key_id': 'test_key',
            'secret_access_key': 'test_secret',
            'session_token': 'test_token',
            'expiration': (datetime.now(timezone.utc) + timedelta(minutes=4)).isoformat()
        }
        
        # 警告が出ることを確認
        with self.assertLogs(level='WARNING') as log:
            is_logged_in = auth.is_logged_in()
            self.assertTrue(is_logged_in)
            self.assertTrue(any('有効期限が近づいています' in message for message in log.output))
        
        # 期限切れのクレデンシャルをセット
        auth.tmp_creds = {
            'access_key_id': 'test_key',
            'secret_access_key': 'test_secret',
            'session_token': 'test_token',
            'expiration': (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        }
        
        # ログイン状態がFalseになることを確認
        self.assertFalse(auth.is_logged_in())

    def test_error_handling(self):
        """エラーハンドリングの統合テスト"""
        # 認証サーバーエラーのテスト
        with patch('requests.post') as mock_post:
            mock_post.side_effect = requests.exceptions.ConnectionError("Connection failed")
            
            auth = PHuntAuth(
                auth_server_url=self.auth_server_url,
                cert_path=str(self.cert_path),
                key_path=str(self.key_path),
                ca_path=str(self.ca_path)
            )
            
            with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=False):
                with self.assertRaises(AuthenticationError) as context:
                    auth.login()
                self.assertIn("認証サーバーからのクレデンシャル取得に失敗しました", str(context.exception))
        
        # Google認証エラーのテスト
        mock_colab = MagicMock()
        mock_colab.auth = MagicMock()
        mock_colab.auth.authenticate_user = MagicMock()
        
        with patch.dict('sys.modules', {
            'google.colab': mock_colab,
            'google.auth': MagicMock()
        }):
            with patch('google.auth.default', return_value=(MagicMock(), None)):
                with patch('requests.get') as mock_get:
                    mock_get.return_value.status_code = 401
                    mock_get.return_value.content = b'Unauthorized'
                    
                    with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=True):
                        auth = PHuntAuth()
                        with self.assertRaises(AuthenticationError) as context:
                            auth.login()
                        self.assertIn("ユーザー情報の取得に失敗しました", str(context.exception))

    def test_s3_policy_update_error(self):
        """S3バケットポリシー更新エラーのテスト"""
        # STSクライアントのモック
        mock_sts = MagicMock()
        mock_sts.assume_role.return_value = {
            'Credentials': {
                'AccessKeyId': self.aws_credentials['access_key_id'],
                'SecretAccessKey': self.aws_credentials['secret_access_key'],
                'SessionToken': self.aws_credentials['session_token'],
                'Expiration': datetime.now(timezone.utc) + timedelta(hours=1)
            }
        }
        
        # S3クライアントのモック（エラーを発生させる）
        mock_s3 = MagicMock()
        mock_s3.put_bucket_policy.side_effect = Exception("Failed to update bucket policy")
        
        # Google Colabのモック
        mock_colab = MagicMock()
        mock_colab.auth = MagicMock()
        mock_colab.auth.authenticate_user = MagicMock()
        
        with patch.dict('sys.modules', {
            'google.colab': mock_colab,
            'google.auth': MagicMock()
        }):
            with patch('google.auth.default', return_value=(MagicMock(), None)):
                with patch('requests.get') as mock_get:
                    with patch('boto3.client') as mock_boto3_client:
                        mock_get.return_value.status_code = 200
                        mock_get.return_value.json.return_value = {'email': 'test@p-hunter.com'}
                        mock_boto3_client.side_effect = [mock_sts, mock_s3]
                        
                        with patch('phunt_api.auth.PHuntAuth._is_running_on_colab', return_value=True):
                            auth = PHuntAuth()
                            with self.assertRaises(AuthenticationError) as context:
                                auth.login()
                            self.assertIn("S3バケットポリシーの更新に失敗しました", str(context.exception))

if __name__ == '__main__':
    unittest.main() 