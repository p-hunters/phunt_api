import unittest
import os
import tempfile
import shutil
import time
import requests
import multiprocessing
import signal
import uvicorn
from unittest.mock import patch, MagicMock
from phunt_api.auth_server.service import AuthServer, AuthServerConfig
from phunt_api.feast_ui.service import FeastUIServer, FeastUIConfig

def run_auth_server(config: AuthServerConfig, ready_event: multiprocessing.Event):
    """認証サーバーを別プロセスで実行"""
    try:
        server = AuthServer(config)
        # サーバーの準備が整ったことを通知
        ready_event.set()
        server.run()
    except KeyboardInterrupt:
        pass

class TestAuthServer(unittest.TestCase):
    def setUp(self):
        """テスト環境のセットアップ"""
        self.config = AuthServerConfig(
            host="127.0.0.1",
            port=8000,
            workers=1,
            reload=False
        )
        self.server = AuthServer(self.config)
        self.ready_event = multiprocessing.Event()
        self.process = None

    def tearDown(self):
        """テスト環境のクリーンアップ"""
        if self.process:
            self.process.terminate()
            self.process.join(timeout=5)
            if self.process.is_alive():
                os.kill(self.process.pid, signal.SIGKILL)

    def test_auth_server_config(self):
        """認証サーバーの設定テスト"""
        self.assertEqual(self.config.host, "127.0.0.1")
        self.assertEqual(self.config.port, 8000)
        self.assertEqual(self.config.workers, 1)
        self.assertFalse(self.config.reload)

    def test_auth_server_start_and_health_check(self):
        """認証サーバーの起動とヘルスチェックテスト"""
        # サーバーを別プロセスで起動
        self.process = multiprocessing.Process(
            target=run_auth_server,
            args=(self.config, self.ready_event)
        )
        self.process.start()

        # サーバーの準備完了を待機
        self.ready_event.wait(timeout=10)
        time.sleep(2)  # サーバーの起動を待機

        try:
            # ヘルスチェックエンドポイントをテスト
            response = requests.get(f"http://{self.config.host}:{self.config.port}/health")
            self.assertEqual(response.status_code, 200)
            data = response.json()
            self.assertEqual(data["status"], "healthy")
            self.assertTrue("timestamp" in data)
        except requests.RequestException as e:
            self.fail(f"ヘルスチェックに失敗: {str(e)}")

class TestFeastUI(unittest.TestCase):
    def setUp(self):
        """テスト環境のセットアップ"""
        self.config = FeastUIConfig(
            host="127.0.0.1",
            port=8888
        )
        self.server = FeastUIServer(self.config)

    def tearDown(self):
        """テスト環境のクリーンアップ"""
        self.server.stop()

    def test_feast_ui_config(self):
        """Feast UIの設定テスト"""
        self.assertEqual(self.config.host, "127.0.0.1")
        self.assertEqual(self.config.port, 8888)

    def test_feast_ui_lifecycle(self):
        """Feast UIのライフサイクルテスト"""
        # サーバーを起動
        self.server.run(block=False)
        time.sleep(2)  # プロセスの起動を待機

        # プロセスが実行中であることを確認
        self.assertIsNotNone(self.server._process)
        self.assertTrue(self.server._process.pid > 0)

        # サーバーを停止
        self.server.stop()
        time.sleep(1)  # プロセスの終了を待機

        # プロセスが終了していることを確認
        self.assertIsNone(self.server._process)

class TestServiceIntegration(unittest.TestCase):
    def setUp(self):
        """テスト環境のセットアップ"""
        self.auth_config = AuthServerConfig(
            host="127.0.0.1",
            port=8000,
            workers=1,
            reload=False
        )
        self.feast_config = FeastUIConfig(
            host="127.0.0.1",
            port=8888
        )
        self.auth_server = AuthServer(self.auth_config)
        self.feast_ui = FeastUIServer(self.feast_config)
        self.ready_event = multiprocessing.Event()
        self.auth_process = None

    def tearDown(self):
        """テスト環境のクリーンアップ"""
        if self.auth_process:
            self.auth_process.terminate()
            self.auth_process.join(timeout=5)
            if self.auth_process.is_alive():
                os.kill(self.auth_process.pid, signal.SIGKILL)
        self.feast_ui.stop()

    def test_services_startup_and_health(self):
        """両サービスの起動とヘルスチェックテスト"""
        # 認証サーバーを別プロセスで起動
        self.auth_process = multiprocessing.Process(
            target=run_auth_server,
            args=(self.auth_config, self.ready_event)
        )
        self.auth_process.start()

        # 認証サーバーの準備完了を待機
        self.ready_event.wait(timeout=10)
        time.sleep(2)  # サーバーの起動を待機

        try:
            # 認証サーバーのヘルスチェック
            response = requests.get(f"http://{self.auth_config.host}:{self.auth_config.port}/health")
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["status"], "healthy")

            # Feast UIを起動
            self.feast_ui.run(block=False)
            time.sleep(2)  # UIの起動を待機

            # Feast UIのプロセスが実行中であることを確認
            self.assertIsNotNone(self.feast_ui._process)
            self.assertTrue(self.feast_ui._process.pid > 0)

        except requests.RequestException as e:
            self.fail(f"サービスのヘルスチェックに失敗: {str(e)}")
        except Exception as e:
            self.fail(f"テスト実行中にエラーが発生: {str(e)}")

if __name__ == '__main__':
    unittest.main() 