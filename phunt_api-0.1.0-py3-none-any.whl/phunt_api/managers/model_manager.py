"""
Model manager for PHuntAPI.
"""

from typing import Optional, List, Dict, Any, Tuple, Callable
import pandas as pd
import mlflow
from mlflow.tracking import MlflowClient

from .base import BaseManager
from ..exceptions import ModelError
from ..misc.decorators import handle_api_exceptions


class ModelManager(BaseManager):
    """Manages model operations for PHuntAPI.
    
    This manager handles all model-related operations including:
    - Submitting and registering models
    - Listing available models
    - Loading models and their configurations
    - Model serving and deployment
    - MLflow integration
    """
    
    def __init__(self, auth_provider: Any, debug: bool = False):
        """Initialize the model manager.
        
        Args:
            auth_provider: Authentication provider instance
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self._models = {}  # Simple model storage
        self._mlflow_client = None
        
    def initialize(self) -> None:
        """Initialize the model manager."""
        self.logger.debug("Initializing ModelManager")
        # No legacy manager needed
        
    @handle_api_exceptions
    def submit_model(self, model_name: str, model_code: Callable,
                    feature_names: List[str], target_name: str,
                    model_type: str = "classification",
                    description: str = "", hyperparameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """Submit a new model.
        
        Args:
            model_name: Name for the model
            model_code: Function that trains and returns the model
            feature_names: List of feature names used by the model
            target_name: Name of the target variable
            model_type: Type of model (classification/regression)
            description: Model description
            hyperparameters: Model hyperparameters
            
        Returns:
            Dictionary containing submission result
            
        Raises:
            ModelError: If model cannot be submitted
        """
        self.require_auth()
        
        try:
            # Store the model
            self._models[model_name] = {
                'code': model_code,
                'feature_names': feature_names,
                'target_name': target_name,
                'model_type': model_type,
                'description': description,
                'hyperparameters': hyperparameters or {},
                'model': None  # Will be set when trained
            }
            
            return {
                'status': 'success',
                'model_name': model_name,
                'message': f"Model '{model_name}' submitted successfully"
            }
        except Exception as e:
            raise ModelError(f"Failed to submit model: {str(e)}")
            
    @handle_api_exceptions
    def list_models(self) -> pd.DataFrame:
        """List all available models.
        
        Returns:
            DataFrame containing model information
            
        Raises:
            ModelError: If models cannot be listed
        """
        self.require_auth()
        
        try:
            # Return DataFrame of models
            return pd.DataFrame([
                {
                    'name': name,
                    'type': info['model_type'],
                    'description': info['description'],
                    'features': len(info['feature_names'])
                }
                for name, info in self._models.items()
            ])
        except Exception as e:
            raise ModelError(f"Failed to list models: {str(e)}")
            
    @handle_api_exceptions
    def load_model(self, model_name: str, version: Optional[str] = None) -> Tuple[Any, List[str]]:
        """Load a model and its feature names.
        
        Args:
            model_name: Name of the model to load
            version: Model version (defaults to latest)
            
        Returns:
            Tuple of (model object, feature names list)
            
        Raises:
            ModelError: If model cannot be loaded
        """
        self.require_auth()
        
        try:
            if model_name not in self._models:
                raise ModelError(f"Model '{model_name}' not found")
                
            model_info = self._models[model_name]
            return model_info.get('model'), model_info['feature_names']
        except Exception as e:
            raise ModelError(f"Failed to load model: {str(e)}")
            
    @handle_api_exceptions
    def get_mlflow_client(self) -> MlflowClient:
        """Get MLflow client instance.
        
        Returns:
            MLflow client for advanced operations
            
        Raises:
            ModelError: If MLflow client cannot be created
        """
        self.require_auth()
        
        try:
            if self._mlflow_client is None:
                # Use default MLflow settings for now
                self._mlflow_client = MlflowClient()
                
            return self._mlflow_client
        except Exception as e:
            raise ModelError(f"Failed to get MLflow client: {str(e)}")
            
    @handle_api_exceptions
    def serve_model(self, model_name: str, input_data: pd.DataFrame,
                   version: Optional[str] = None) -> pd.DataFrame:
        """Serve predictions using a trained model.
        
        Args:
            model_name: Name of the model to use
            input_data: Input dataframe for predictions
            version: Model version (defaults to latest)
            
        Returns:
            DataFrame containing predictions
            
        Raises:
            ModelError: If predictions cannot be generated
        """
        self.require_auth()
        
        try:
            # Load the model
            model, feature_names = self.load_model(model_name, version)
            
            # Ensure required features are present
            missing_features = set(feature_names) - set(input_data.columns)
            if missing_features:
                raise ModelError(f"Missing required features: {missing_features}")
                
            # Make predictions
            X = input_data[feature_names]
            predictions = model.predict(X)
            
            # Return predictions as DataFrame
            result = input_data.copy()
            result['prediction'] = predictions
            
            # Add prediction probabilities if available
            if hasattr(model, 'predict_proba'):
                proba = model.predict_proba(X)
                for i in range(proba.shape[1]):
                    result[f'proba_class_{i}'] = proba[:, i]
                    
            return result
            
        except Exception as e:
            raise ModelError(f"Failed to serve model: {str(e)}")
            
    def cleanup(self) -> None:
        """Cleanup model manager resources."""
        self.logger.debug("Cleaning up ModelManager")
        self._mlflow_client = None