"""
NautilusTrader Data Catalog manager for PHuntAPI.
"""

from typing import Optional, Dict, Any, List
import pandas as pd
import os
from pathlib import Path

from .base import BaseManager
from ..exceptions import PHuntAPIException

try:
    from nautilus_trader.persistence.catalog.parquet import ParquetDataCatalog
    from nautilus_trader.model.data import Bar, BarType, QuoteTick, TradeTick
    from nautilus_trader.model.identifiers import InstrumentId
    from nautilus_trader.model.objects import Price, Quantity
    NAUTILUS_AVAILABLE = True
except ImportError:
    NAUTILUS_AVAILABLE = False


class NautilusCatalogManager(BaseManager):
    """Manages NautilusTrader Data Catalog operations.
    
    This manager provides integration with NautilusTrader's ParquetDataCatalog,
    enabling storage and retrieval of trading data (Bars, Ticks) on S3.
    """
    
    def __init__(self, auth_provider: Any, catalog_path: str = "s3://phunt-data-856121715507/nautilus/catalog", debug: bool = False):
        """Initialize the Nautilus catalog manager.
        
        Args:
            auth_provider: Authentication provider instance
            catalog_path: S3 path for the catalog root
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.catalog_path = catalog_path
        self._catalog = None
        
    def initialize(self) -> None:
        """Initialize the manager."""
        self.logger.debug("Initializing NautilusCatalogManager")
        if not NAUTILUS_AVAILABLE:
            self.logger.warning("nautilus_trader not installed. NautilusCatalogManager will be disabled.")
            return

    def _get_storage_options(self) -> Dict[str, Any]:
        """Get S3 storage options from auth provider."""
        opts = {}
        if hasattr(self.auth_provider, 'get_credentials'):
            creds = self.auth_provider.get_credentials()
            # Check for temporary credentials (STS)
            if creds:
                if 'access_key_id' in creds:
                    opts['key'] = creds['access_key_id']
                if 'secret_access_key' in creds:
                    opts['secret'] = creds['secret_access_key']
                if 'session_token' in creds:
                    opts['token'] = creds['session_token']
                
                # If using environment variables as fallback (AuthManager might handle this logic,
                # but explicit passing is safer for s3fs)
                if not opts:
                    if os.environ.get('AWS_ACCESS_KEY_ID'):
                        opts['key'] = os.environ.get('AWS_ACCESS_KEY_ID')
                        opts['secret'] = os.environ.get('AWS_SECRET_ACCESS_KEY')
                        if os.environ.get('AWS_SESSION_TOKEN'):
                            opts['token'] = os.environ.get('AWS_SESSION_TOKEN')
                            
        # Common options
        opts['client_kwargs'] = {'region_name': 'ap-northeast-1'} # s3fs might use this
        return opts

    def get_catalog(self) -> Optional['ParquetDataCatalog']:
        """Get or initialize the ParquetDataCatalog instance.
        
        Returns:
            ParquetDataCatalog instance or None if nautilus_trader is missing.
        """
        if not NAUTILUS_AVAILABLE:
            return None
            
        if self._catalog is None:
            self.require_auth()
            storage_options = self._get_storage_options()
            
            self.logger.info(f"Initializing ParquetDataCatalog at {self.catalog_path}")
            self._catalog = ParquetDataCatalog(
                path=self.catalog_path,
                fs_protocol="s3",
                fs_storage_options=storage_options
            )
            
        return self._catalog

    def ingest_bars(self, instrument_id: str, bars_df: pd.DataFrame, 
                   bar_type_spec: str = "1-MINUTE-LAST-EXTERNAL",
                   chunk_size: int = 100_000):
        """Ingest bars from a DataFrame into the catalog.
        
        Args:
            instrument_id: Instrument ID (e.g., 'EURUSD.SIM')
            bars_df: DataFrame containing bar data. Must have OHLCV columns.
                     Index must be datetime or timestamp.
            bar_type_spec: Bar type specification string (e.g. '1-MINUTE-LAST-EXTERNAL')
            chunk_size: Number of bars to process per chunk (not used for direct write currently, 
                        but good for future optimization)
        """
        if not NAUTILUS_AVAILABLE:
            raise PHuntAPIException("nautilus_trader not installed")
            
        import shutil
        import subprocess
        import tempfile
        import time
        
        # Use a local temporary catalog for writing to avoid DataFusion S3 issues
        timestamp = int(time.time())
        local_tmp_dir = Path(tempfile.gettempdir()) / f"nautilus_ingest_{timestamp}"
        if local_tmp_dir.exists():
            shutil.rmtree(local_tmp_dir)
        local_tmp_dir.mkdir(parents=True)
        
        self.logger.info(f"Using local temporary catalog at {local_tmp_dir}")
        local_catalog = ParquetDataCatalog(str(local_tmp_dir))
        
        # Parse Instrument ID
        try:
            instr_id = InstrumentId.from_str(instrument_id)
        except ValueError as e:
            raise PHuntAPIException(f"Invalid instrument ID: {instrument_id}") from e

        # Construct BarType
        try:
            # Format: {instrument_id}-{bar_size}-{price_type}-{aggregation_source}
            # The user might pass just "1-MINUTE-LAST-EXTERNAL" or the full string
            if instrument_id not in bar_type_spec:
                full_spec = f"{instrument_id}-{bar_type_spec}"
            else:
                full_spec = bar_type_spec
                
            bar_type = BarType.from_str(full_spec)
        except ValueError as e:
            raise PHuntAPIException(f"Invalid BarType spec: {bar_type_spec}") from e

        self.logger.info(f"Ingesting {len(bars_df)} bars for {bar_type}...")
        
        # Conversion Logic
        nautilus_bars = []
        for idx, row in bars_df.iterrows():
            # Index handling
            ts = idx if isinstance(idx, pd.Timestamp) else pd.Timestamp(idx)
            # Nanoseconds conversion (Pandas timestamp value is nanos)
            ts_ns = int(ts.value)
            
            try:
                # Format with fixed precision to match instrument spec (usually 5 for FX)
                # TODO: Allow passing precision spec
                bar = Bar(
                    bar_type=bar_type,
                    open=Price.from_str(f"{row['open']:.5f}"),
                    high=Price.from_str(f"{row['high']:.5f}"),
                    low=Price.from_str(f"{row['low']:.5f}"),
                    close=Price.from_str(f"{row['close']:.5f}"),
                    volume=Quantity.from_str(f"{row.get('volume', 0):.0f}"),
                    ts_event=ts_ns,
                    ts_init=ts_ns,
                )
                nautilus_bars.append(bar)
            except Exception as e:
                self.logger.warning(f"Skipping bar at {ts}: {e}")
                continue

        if not nautilus_bars:
            self.logger.warning("No bars created.")
            return

        # Write to local catalog
        self.logger.info(f"Writing {len(nautilus_bars)} bars to local catalog...")
        local_catalog.write_data(nautilus_bars)
        
        # Sync to S3
        self.logger.info(f"Syncing to S3 catalog at {self.catalog_path}...")
        try:
            # Prepare Environment with Credentials
            env = os.environ.copy()
            if hasattr(self.auth_provider, 'get_credentials'):
                creds = self.auth_provider.get_credentials()
                if creds:
                    if 'access_key_id' in creds:
                        env['AWS_ACCESS_KEY_ID'] = creds['access_key_id']
                    if 'secret_access_key' in creds:
                        env['AWS_SECRET_ACCESS_KEY'] = creds['secret_access_key']
                    if 'session_token' in creds:
                        env['AWS_SESSION_TOKEN'] = creds['session_token']
        
            cmd = f"aws s3 sync {local_tmp_dir} {self.catalog_path}"
            # Pass env explicitly
            subprocess.run(cmd, shell=True, check=True, env=env)
            self.logger.info("S3 Sync complete.")
        except subprocess.CalledProcessError as e:
             raise PHuntAPIException(f"Failed to sync to S3: {e}")
        finally:
            # Cleanup
            self.logger.debug(f"Cleaning up {local_tmp_dir}")
            shutil.rmtree(local_tmp_dir)

        self.logger.info("Ingestion complete.")

    def load_bars(self, instrument_ids: List[str], start: Optional[pd.Timestamp] = None, 
                 end: Optional[pd.Timestamp] = None, 
                 bar_type_specs: Optional[List[str]] = None) -> List[Any]:
        """Load bars from the catalog, syncing from S3 to local if needed.
        
        This method bypasses direct S3 reading issues by syncing the relevant data 
        to a local temporary catalog first.
        
        Args:
            instrument_ids: List of instrument IDs (e.g. ['EURUSD.SIM'])
            start: Start timestamp
            end: End timestamp
            bar_type_specs: List of bar type specs (e.g. ['1-MINUTE-LAST-EXTERNAL']). 
                            If not provided, assumes default matching.
                            
        Returns:
            List of Nautilus Bar objects.
        """
        if not NAUTILUS_AVAILABLE:
            raise PHuntAPIException("nautilus_trader not installed")
            
        import shutil
        import subprocess
        import tempfile
        import time
        
        # Prepare local temp dir
        timestamp = int(time.time())
        local_tmp_dir = Path(tempfile.gettempdir()) / f"nautilus_load_{timestamp}"
        if local_tmp_dir.exists():
            shutil.rmtree(local_tmp_dir)
        local_tmp_dir.mkdir(parents=True)
        
        try:
            self.logger.info(f"Syncing data from S3 to local temp {local_tmp_dir}...")
            
            # Prepare Environment with Credentials
            env = os.environ.copy()
            if hasattr(self.auth_provider, 'get_credentials'):
                creds = self.auth_provider.get_credentials()
                if creds:
                    if 'access_key_id' in creds:
                        env['AWS_ACCESS_KEY_ID'] = creds['access_key_id']
                    if 'secret_access_key' in creds:
                        env['AWS_SECRET_ACCESS_KEY'] = creds['secret_access_key']
                    if 'session_token' in creds:
                        env['AWS_SESSION_TOKEN'] = creds['session_token']
            
            # We sync specific instrument paths to minimize traffic if possible.
            # Nautilus structure: host/data/bar/{instrument_id}-{spec}/...
            # We iterate instruments and try to sync their folders.
            
            # Note: If bar_type_specs is NOT provided, strictly we don't know the folder name without listing.
            # But we can try to sync the whole 'data/bar' if we want to be safe, or 'data/bar/{instrument}*'
            
            # For efficiency in this specific user case, we assume we sync the known path structure.
            # If we don't know the exact spec, we might over-sync.
            
            # Construct includes/excludes or just multiple sync commands?
            # s3://bucket/nautilus/catalog/data/bar/
            
            # Strategy: Sync data/bar structure filtering by instrument ID in path
            # aws s3 sync s3://... local_dir --exclude "*" --include "*EURUSD.SIM*"
            
            base_s3 = self.catalog_path.rstrip('/')
            
            # Build include patterns
            includes = []
            for instr in instrument_ids:
                includes.append(f"*{instr}*")
                
            include_flags = ""
            for pattern in includes:
                include_flags += f' --include "{pattern}"'
                
            cmd = f"aws s3 sync {base_s3} {local_tmp_dir} --exclude '*' {include_flags}"
            
            subprocess.run(cmd, shell=True, check=True, env=env)
            
            # Now read from local catalog
            local_catalog = ParquetDataCatalog(str(local_tmp_dir))
            
            # Construct BarTypes
            if bar_type_specs:
                bar_types = []
                for i, instr in enumerate(instrument_ids):
                    # Handle matching spec if lists are same len, else apply first spec to all?
                    # Simplify: require user to match or pass full strings
                    spec = bar_type_specs[i] if i < len(bar_type_specs) else bar_type_specs[0]
                    if instr not in spec:
                         full = f"{instr}-{spec}"
                    else:
                         full = spec
                    bar_types.append(BarType.from_str(full))
            else:
                # If no spec, we can't easily guess without listing what we synced.
                # But local_catalog.instruments() works if we synced metadata? 
                # ParquetDataCatalog doesn't always have metadata separate.
                # Let's assume standard default for now or require spec.
                # Actually, let's try to infer or just assume simple 1-min for now if not passed
                raise PHuntAPIException("bar_type_specs currently required for loading")

            self.logger.info("Reading bars from local catalog...")
            bars = local_catalog.bars(
                instrument_ids=instrument_ids,
                start=start,
                end=end,
                bar_types=bar_types
            )
            return bars
            
        except subprocess.CalledProcessError as e:
             raise PHuntAPIException(f"Failed to sync from S3: {e}")
        finally:
             if local_tmp_dir.exists():
                 shutil.rmtree(local_tmp_dir)

    def cleanup(self) -> None:
        """Cleanup resources."""
        self._catalog = None
