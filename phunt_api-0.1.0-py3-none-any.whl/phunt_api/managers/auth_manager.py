"""
Authentication manager for PHuntAPI.
"""

from typing import Optional, Dict, Any
import os
from datetime import datetime, timedelta

from .base import BaseManager
from ..auth import PHuntAuth
from ..exceptions import AuthenticationError


class AuthManager(BaseManager):
    """Manages authentication and authorization for PHuntAPI.
    
    This manager handles all authentication-related operations including:
    - User login/logout
    - Token management
    - GCP credential management
    - Authentication state validation
    """
    
    def __init__(self, debug: bool = False, api_key: Optional[str] = None, mock: bool = False, headless: bool = False):
        """Initialize the authentication manager.
        
        Args:
            debug: Enable debug mode
            api_key: API key
            mock: Use mock auth
            headless: Headless mode
        """
        # AuthManager doesn't need auth_provider since it IS the auth provider
        super().__init__(auth_provider=None, debug=debug)
        self._phunt_auth = PHuntAuth(debug=debug, api_key=api_key, mock=mock, headless=headless)
        self._tmp_creds = None
        self._gcp_token_expiry = None
        
    def initialize(self) -> None:
        """Initialize the authentication manager."""
        self.logger.debug("Initializing AuthManager")
        
        # If using mock auth or API key, login immediately
        if self._phunt_auth.mock or self._phunt_auth.api_key:
            self.logger.info("Auto-login triggered by mock/api_key configuration")
            self.login()
        
    @property
    def phunt_auth(self) -> PHuntAuth:
        """Get the underlying PHuntAuth instance."""
        return self._phunt_auth
        
    def login(self, **kwargs) -> Any:
        """Perform user login.
        
        Returns:
            Authentication credentials
        """
        self.logger.debug("Attempting login")
        self._tmp_creds = self._phunt_auth.login(**kwargs)
        
        # GCP認証情報の有効期限を設定
        if self._tmp_creds and 'gcp_access_token' in self._tmp_creds:
            self._gcp_token_expiry = datetime.now() + timedelta(minutes=15)
            
        return self._tmp_creds
        
    def is_logged_in(self) -> bool:
        """Check if user is currently logged in.
        
        Returns:
            True if user is logged in, False otherwise
        """
        return self._phunt_auth.is_logged_in()
        
    def has_gcp_access_token(self) -> bool:
        """Check if GCP access token is available.
        
        Returns:
            True if GCP token is available, False otherwise
        """
        return (self._tmp_creds is not None and 
                'gcp_access_token' in self._tmp_creds and
                self._tmp_creds['gcp_access_token'] is not None)
                
    def get_gcp_access_token(self) -> Optional[str]:
        """Get the current GCP access token.
        
        Returns:
            GCP access token if available, None otherwise
        """
        if not self.has_gcp_access_token():
            return None
        return self._tmp_creds.get('gcp_access_token')
        
    def refresh_gcp_access_token_if_needed(self) -> None:
        """Refresh GCP access token if it's about to expire."""
        if not self.has_gcp_access_token():
            return
            
        if self._gcp_token_expiry and datetime.now() >= self._gcp_token_expiry:
            self.logger.debug("Refreshing GCP access token")
            # Re-login to get fresh token
            self.login()
            
    def get_gcp_service_account_email(self) -> Optional[str]:
        """Get the GCP service account email.
        
        Returns:
            Service account email if available, None otherwise
        """
        if not self._tmp_creds:
            return None
        return self._tmp_creds.get('gcp_service_account_email')
        
    def get_credentials(self) -> Optional[Dict[str, Any]]:
        """Get all current credentials.
        
        Returns:
            Dictionary of credentials if available, None otherwise
        """
        return self._tmp_creds
        
    def cleanup(self) -> None:
        """Cleanup authentication resources."""
        self.logger.debug("Cleaning up AuthManager")
        self._tmp_creds = None
        self._gcp_token_expiry = None