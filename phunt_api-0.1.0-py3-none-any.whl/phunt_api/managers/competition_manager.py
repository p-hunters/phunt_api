# -*- coding: utf-8 -*-
"""
Competition manager for PHuntAPI.
"""

from typing import List, Dict, Optional, Any
import os

from .base import BaseManager
from .base import BaseManager
from ..competitions.manager import CompetitionManager as CoreCompetitionManager
from ..competitions.repository import FileCompetitionRepository
from ..competitions.models import Competition, CompetitionStatus, LeaderboardEntry, DiscussionPost
from ..exceptions import CompetitionError
from ..misc.decorators import handle_api_exceptions


class CompetitionManager(BaseManager):
    """Manages competition operations for PHuntAPI.
    
    This manager handles all competition-related operations including:
    - Creating and managing competitions
    - Managing competition resources (datasets, models, features)
    - Managing leaderboards
    - Managing rules and discussions
    """
    
    def __init__(self, auth_provider: Any, repo_path: str = ".", debug: bool = False):
        """Initialize the competition manager.
        
        Args:
            auth_provider: Authentication provider instance
            repo_path: Repository path for storing competition data
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.repo_path = repo_path
        self._core_manager = None
        
    def initialize(self) -> None:
        """Initialize the competition manager."""
        self.logger.debug("Initializing CompetitionManager")
        
        # Set up storage path for competitions
        storage_path = os.path.join(self.repo_path, "competitions")
        repository = FileCompetitionRepository(storage_path)
        self._core_manager = CoreCompetitionManager(repository=repository)
        
    @handle_api_exceptions
    def create_competition(
        self,
        competition_id: str,
        name: str,
        description: str,
        problem_description: str,
        problem_type: str = "classification",
        created_by: str = "",
        **kwargs
    ) -> Competition:
        """Create a new competition.
        
        Args:
            competition_id: Unique identifier for the competition
            name: Competition name
            description: Competition description
            problem_description: Detailed problem description
            problem_type: Type of problem (classification/regression/time_series)
            created_by: ID of the user creating the competition
            **kwargs: Additional competition attributes
            
        Returns:
            Created Competition object
            
        Raises:
            CompetitionError: If competition cannot be created
        """
        self.require_auth()
        
        try:
            return self._core_manager.create_competition(
                competition_id=competition_id,
                name=name,
                description=description,
                problem_description=problem_description,
                problem_type=problem_type,
                created_by=created_by,
                **kwargs
            )
        except Exception as e:
            raise CompetitionError(f"Failed to create competition: {str(e)}")
    
    @handle_api_exceptions
    def get_competition(self, competition_id: str) -> Competition:
        """Get a competition by ID.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            Competition object
            
        Raises:
            CompetitionError: If competition is not found
        """
        self.require_auth()
        
        try:
            return self._core_manager.get_competition(competition_id)
        except Exception as e:
            raise CompetitionError(f"Failed to get competition: {str(e)}")
    
    @handle_api_exceptions
    def list_competitions(
        self,
        status: Optional[CompetitionStatus] = None,
        tags: Optional[List[str]] = None
    ) -> List[Competition]:
        """List all competitions, optionally filtered.
        
        Args:
            status: Filter by competition status
            tags: Filter by tags (competition must have all specified tags)
            
        Returns:
            List of Competition objects
        """
        self.require_auth()
        
        try:
            return self._core_manager.list_competitions(status=status, tags=tags)
        except Exception as e:
            raise CompetitionError(f"Failed to list competitions: {str(e)}")
    
    @handle_api_exceptions
    def update_competition(
        self,
        competition_id: str,
        **kwargs
    ) -> Competition:
        """Update competition attributes.
        
        Args:
            competition_id: Competition identifier
            **kwargs: Attributes to update (name, description, status, etc.)
            
        Returns:
            Updated Competition object
            
        Raises:
            CompetitionError: If competition is not found or cannot be updated
        """
        self.require_auth()
        
        try:
            return self._core_manager.update_competition(competition_id, **kwargs)
        except Exception as e:
            raise CompetitionError(f"Failed to update competition: {str(e)}")
    
    @handle_api_exceptions
    def delete_competition(self, competition_id: str) -> None:
        """Delete a competition.
        
        Args:
            competition_id: Competition identifier
            
        Raises:
            CompetitionError: If competition is not found or cannot be deleted
        """
        self.require_auth()
        
        try:
            self._core_manager.delete_competition(competition_id)
        except Exception as e:
            raise CompetitionError(f"Failed to delete competition: {str(e)}")
    
    # ========== Resource Management Methods ==========
    
    @handle_api_exceptions
    def add_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Add a dataset to a competition.
        
        Args:
            competition_id: Competition identifier
            dataset_name: Name of the dataset to add
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.add_dataset(competition_id, dataset_name)
        except Exception as e:
            raise CompetitionError(f"Failed to add dataset: {str(e)}")
    
    @handle_api_exceptions
    def remove_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Remove a dataset from a competition.
        
        Args:
            competition_id: Competition identifier
            dataset_name: Name of the dataset to remove
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.remove_dataset(competition_id, dataset_name)
        except Exception as e:
            raise CompetitionError(f"Failed to remove dataset: {str(e)}")
    
    @handle_api_exceptions
    def add_model(self, competition_id: str, model_name: str) -> Competition:
        """Add a model to a competition.
        
        Args:
            competition_id: Competition identifier
            model_name: Name of the model to add
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.add_model(competition_id, model_name)
        except Exception as e:
            raise CompetitionError(f"Failed to add model: {str(e)}")
    
    @handle_api_exceptions
    def remove_model(self, competition_id: str, model_name: str) -> Competition:
        """Remove a model from a competition.
        
        Args:
            competition_id: Competition identifier
            model_name: Name of the model to remove
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.remove_model(competition_id, model_name)
        except Exception as e:
            raise CompetitionError(f"Failed to remove model: {str(e)}")
    
    @handle_api_exceptions
    def add_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Add a feature to a competition.
        
        Args:
            competition_id: Competition identifier
            feature_name: Name of the feature to add
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.add_feature(competition_id, feature_name)
        except Exception as e:
            raise CompetitionError(f"Failed to add feature: {str(e)}")
    
    @handle_api_exceptions
    def remove_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Remove a feature from a competition.
        
        Args:
            competition_id: Competition identifier
            feature_name: Name of the feature to remove
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.remove_feature(competition_id, feature_name)
        except Exception as e:
            raise CompetitionError(f"Failed to remove feature: {str(e)}")
    
    # ========== Leaderboard Methods ==========
    
    @handle_api_exceptions
    def add_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str,
        participant_name: str,
        score: float,
        model_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add an entry to the competition leaderboard.
        
        Args:
            competition_id: Competition identifier
            participant_id: ID of the participant
            participant_name: Name of the participant
            score: Score achieved
            model_name: Name of the model used
            metadata: Additional metadata
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.add_leaderboard_entry(
                competition_id=competition_id,
                participant_id=participant_id,
                participant_name=participant_name,
                score=score,
                model_name=model_name,
                metadata=metadata
            )
        except Exception as e:
            raise CompetitionError(f"Failed to add leaderboard entry: {str(e)}")
    
    @handle_api_exceptions
    def get_leaderboard(
        self,
        competition_id: str,
        top_n: Optional[int] = None
    ) -> List[LeaderboardEntry]:
        """Get leaderboard for a competition.
        
        Args:
            competition_id: Competition identifier
            top_n: Return only top N entries (None for all)
            
        Returns:
            List of leaderboard entries
        """
        self.require_auth()
        
        try:
            return self._core_manager.get_leaderboard(competition_id, top_n)
        except Exception as e:
            raise CompetitionError(f"Failed to get leaderboard: {str(e)}")
    
    @handle_api_exceptions
    def remove_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str
    ) -> Competition:
        """Remove an entry from the leaderboard.
        
        Args:
            competition_id: Competition identifier
            participant_id: ID of the participant whose entry to remove
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.remove_leaderboard_entry(competition_id, participant_id)
        except Exception as e:
            raise CompetitionError(f"Failed to remove leaderboard entry: {str(e)}")
    
    # ========== Rules Methods ==========
    
    @handle_api_exceptions
    def update_rules(
        self,
        competition_id: str,
        rules: Dict[str, Any]
    ) -> Competition:
        """Update competition rules.
        
        Args:
            competition_id: Competition identifier
            rules: Dictionary of rules
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.update_rules(competition_id, rules)
        except Exception as e:
            raise CompetitionError(f"Failed to update rules: {str(e)}")
    
    @handle_api_exceptions
    def get_rules(self, competition_id: str) -> Dict[str, Any]:
        """Get competition rules.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            Dictionary of rules
        """
        self.require_auth()
        
        try:
            return self._core_manager.get_rules(competition_id)
        except Exception as e:
            raise CompetitionError(f"Failed to get rules: {str(e)}")
    
    # ========== Discussion Methods ==========
    
    @handle_api_exceptions
    def add_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        author_id: str,
        author_name: str,
        content: str,
        parent_post_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add a discussion post to the competition.
        
        Args:
            competition_id: Competition identifier
            post_id: Unique identifier for the post
            author_id: ID of the author
            author_name: Name of the author
            content: Post content
            parent_post_id: ID of parent post (for replies)
            metadata: Additional metadata
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.add_discussion_post(
                competition_id=competition_id,
                post_id=post_id,
                author_id=author_id,
                author_name=author_name,
                content=content,
                parent_post_id=parent_post_id,
                metadata=metadata
            )
        except Exception as e:
            raise CompetitionError(f"Failed to add discussion post: {str(e)}")
    
    @handle_api_exceptions
    def get_discussion(self, competition_id: str) -> List[DiscussionPost]:
        """Get all discussion posts for a competition.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            List of discussion posts
        """
        self.require_auth()
        
        try:
            return self._core_manager.get_discussion(competition_id)
        except Exception as e:
            raise CompetitionError(f"Failed to get discussion: {str(e)}")
    
    @handle_api_exceptions
    def update_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        content: str
    ) -> Competition:
        """Update a discussion post.
        
        Args:
            competition_id: Competition identifier
            post_id: ID of the post to update
            content: New content
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.update_discussion_post(
                competition_id, post_id, content
            )
        except Exception as e:
            raise CompetitionError(f"Failed to update discussion post: {str(e)}")
    
    @handle_api_exceptions
    def delete_discussion_post(
        self,
        competition_id: str,
        post_id: str
    ) -> Competition:
        """Delete a discussion post.
        
        Args:
            competition_id: Competition identifier
            post_id: ID of the post to delete
            
        Returns:
            Updated Competition object
        """
        self.require_auth()
        
        try:
            return self._core_manager.delete_discussion_post(competition_id, post_id)
        except Exception as e:
            raise CompetitionError(f"Failed to delete discussion post: {str(e)}")
    
    def cleanup(self) -> None:
        """Cleanup competition manager resources."""
        self.logger.debug("Cleaning up CompetitionManager")
        self._legacy_manager = None

