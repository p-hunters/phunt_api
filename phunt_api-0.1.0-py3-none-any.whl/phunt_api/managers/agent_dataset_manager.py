from typing import List, Optional, Any, Dict, Tuple
import pandas as pd
from datetime import datetime

from .base import BaseManager
from .dataset_manager import DatasetManager
from ..schemas.dataset import DatasetMetadata, ColumnSchema, DataType, SplitConfig
from ..splitting import DatasetSplitter
from ..exceptions import DatasetError
from ..misc.decorators import handle_api_exceptions

class AgentDatasetManager(BaseManager):
    """
    A simplified and type-safe dataset manager for autonomous agents.
    Wraps the underlying DatasetManager to provide high-level abstractions.
    """

    def __init__(self, auth_provider: Any, repo_path: str = ".", debug: bool = False):
        super().__init__(auth_provider=auth_provider, debug=debug)
        self._manager = DatasetManager(auth_provider, repo_path, debug)

    def initialize(self) -> None:
        """Initialize the underlying manager."""
        self._manager.initialize()

    @handle_api_exceptions
    def list_datasets(self) -> List[DatasetMetadata]:
        """
        List all available datasets with rich metadata.
        """
        self.require_auth()
        
        raw_datasets = self._manager.list_datasets()
        # raw_datasets is likely a list of FeatureView objects from Feast
        
        metadata_list = []
        for ds in raw_datasets:
            # Extract info from FeatureView
            # Note: This depends on the exact structure of the object returned by list_datasets
            # Assuming it's a Feast FeatureView-like object
            
            name = getattr(ds, 'name', 'unknown')
            
            # Extract schema
            columns = []
            if hasattr(ds, 'schema'):
                for field in ds.schema:
                    # Map Feast types to our DataType
                    # This is a simplification; Feast types are more complex
                    dtype = DataType.STRING # Default
                    if 'INT' in str(field.dtype).upper():
                        dtype = DataType.INTEGER
                    elif 'FLOAT' in str(field.dtype).upper():
                        dtype = DataType.FLOAT
                    elif 'BOOL' in str(field.dtype).upper():
                        dtype = DataType.BOOLEAN
                    elif 'TIMESTAMP' in str(field.dtype).upper():
                        dtype = DataType.TIMESTAMP
                        
                    columns.append(ColumnSchema(
                        name=field.name,
                        dtype=dtype,
                        description=field.tags.get('description') if hasattr(field, 'tags') else None
                    ))
            
            # Extract tags
            tags = getattr(ds, 'tags', {})
            description = tags.get('description')
            frequency = tags.get('frequency')
            
            # Try to parse dates if available in tags
            start_date = None
            end_date = None
            if 'start_date' in tags:
                try:
                    start_date = datetime.fromisoformat(tags['start_date'])
                except:
                    pass
            
            metadata_list.append(DatasetMetadata(
                name=name,
                description=description,
                columns=columns,
                start_date=start_date,
                end_date=end_date,
                frequency=frequency,
                tags=tags
            ))
            
        return metadata_list

    @handle_api_exceptions
    def get_dataset(self, name: str) -> pd.DataFrame:
        """
        Load a full dataset by name.
        """
        self.require_auth()
        return self._manager.get_dataset(name)

    @handle_api_exceptions
    def get_split(self, name: str, config: SplitConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get a dataset split into training and testing sets based on the configuration.
        """
        self.require_auth()
        df = self.get_dataset(name)
        return DatasetSplitter.split(df, config)

    def cleanup(self) -> None:
        self._manager.cleanup()
