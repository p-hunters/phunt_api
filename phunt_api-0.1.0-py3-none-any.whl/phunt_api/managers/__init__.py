"""
Managers module for PHuntAPI.

This module contains manager classes that handle specific responsibilities
previously contained in the monolithic PHuntAPI class.
"""

from .auth_manager import AuthManager
from .dataset_manager import DatasetManager
from .feature_manager import FeatureManager
from .model_manager import ModelManager
from .plugin_manager import PluginManager
from .cache_manager import CacheManager
from .target_manager import TargetManager
from .competition_manager import CompetitionManager
from .nautilus_catalog_manager import NautilusCatalogManager

__all__ = [
    'AuthManager',
    'DatasetManager', 
    'FeatureManager',
    'ModelManager',
    'PluginManager',
    'CacheManager',
    'TargetManager',
    'CompetitionManager',
    'NautilusCatalogManager'
]