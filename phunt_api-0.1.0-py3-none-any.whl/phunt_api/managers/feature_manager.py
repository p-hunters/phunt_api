"""
Feature manager for PHuntAPI.
"""

from typing import Optional, List, Dict, Any, Callable
import pandas as pd
import os
import textwrap
import inspect

from .base import BaseManager
from ..feature import FeatureManager as LegacyFeatureManager
from ..exceptions import FeatureError
from ..misc.decorators import handle_api_exceptions
from ..misc.validation import ValidationUtils


class FeatureManager(BaseManager):
    """Manages feature operations for PHuntAPI.
    
    This manager wraps the legacy FeatureManager to provide:
    - Feast integration for feature storage
    - S3 backend support
    - Feature versioning and lineage
    - Distributed feature computation
    """
    
    def __init__(self, auth_provider: Any, dataset_manager: Any,
                 validation_year: Optional[int] = None, debug: bool = False):
        """Initialize the feature manager.
        
        Args:
            auth_provider: Authentication provider instance
            dataset_manager: Dataset manager instance for Feast integration
            validation_year: Year to use for train/validation split
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.validation_year = validation_year
        self._dataset_manager = dataset_manager
        self._legacy_feature_manager = None
        
    def initialize(self) -> None:
        """Initialize the feature manager."""
        self.logger.debug("Initializing FeatureManager")
        # Initialize the legacy feature manager with dataset manager
        if hasattr(self._dataset_manager, '_legacy_dataset_manager'):
            self._legacy_feature_manager = LegacyFeatureManager(
                self._dataset_manager._legacy_dataset_manager
            )
        
    def set_validation_year(self, year: Optional[int]) -> None:
        """Set the validation year for train/validation split.
        
        Args:
            year: Year to use as validation split point
        """
        self.validation_year = year
        self.logger.debug(f"Validation year set to: {year}")
        
    @handle_api_exceptions
    def list_features(self) -> pd.DataFrame:
        """List all available features from Feast registry.
        
        Returns:
            DataFrame containing feature information
            
        Raises:
            FeatureError: If features cannot be listed
        """
        self.require_auth()
        
        try:
            if self._legacy_feature_manager:
                # Get features from Feast
                feature_views = self._legacy_feature_manager.list_features()
                # Convert to DataFrame for API compatibility
                return pd.DataFrame([
                    {
                        'name': fv.name,
                        'entities': [e.name for e in fv.entities] if hasattr(fv, 'entities') else [],
                        'features': [f.name for f in fv.features] if hasattr(fv, 'features') else [],
                        'online': fv.online if hasattr(fv, 'online') else False,
                        'tags': fv.tags if hasattr(fv, 'tags') else {}
                    }
                    for fv in feature_views
                ])
            else:
                return pd.DataFrame()
        except Exception as e:
            raise FeatureError(f"Failed to list features: {str(e)}")
            
    @handle_api_exceptions
    def get_feature_code_path(self, feature_name: str) -> str:
        """Get the S3 path for a feature's code.
        
        Args:
            feature_name: Name of the feature
            
        Returns:
            Path to the feature code file in S3
            
        Raises:
            FeatureError: If feature code path cannot be retrieved
        """
        self.require_auth()
        
        try:
            if self._legacy_feature_manager:
                try:
                    return self._legacy_feature_manager.get_feature_code_path(feature_name) or ""
                except:
                    # Feature not found, return empty string
                    return ""
            else:
                raise FeatureError("Feature manager not initialized")
        except FeatureError:
            raise
        except Exception as e:
            # For other exceptions, return empty string
            return ""
            
    @handle_api_exceptions
    def get_feature_code(self, feature_name: str) -> str:
        """Get the source code for a feature from S3.
        
        Args:
            feature_name: Name of the feature
            
        Returns:
            Feature source code as string
            
        Raises:
            FeatureError: If feature code cannot be retrieved
        """
        self.require_auth()
        
        try:
            # Get code path from Feast metadata
            code_path = self.get_feature_code_path(feature_name)
            if code_path:
                # Download and read code from S3
                # This would be implemented in the legacy manager
                return f"# Feature code for {feature_name}\n# Path: {code_path}"
            else:
                return ""
        except Exception as e:
            raise FeatureError(f"Failed to get feature code: {str(e)}")
            
    @handle_api_exceptions
    def submit_feature(self, feature_name: str, processing_code: Callable, 
                      feature_type: str = "timeseries",
                      description: str = "", depends_on: List[str] = None,
                      df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """Submit a new feature to Feast.
        
        Args:
            feature_name: Name for the new feature
            processing_code: Function that calculates the feature
            feature_type: Type of feature (e.g., 'timeseries', 'cross_sectional')
            description: Feature description
            depends_on: List of features this feature depends on
            df: Optional pre-computed feature dataframe
            
        Returns:
            Dictionary containing submission result
            
        Raises:
            FeatureError: If feature cannot be submitted
        """
        self.require_auth()
        
        try:
            # Validate the processing code if provided
            if processing_code:
                ValidationUtils._validate_processing_code(processing_code)
            
            if self._legacy_feature_manager:
                # Get the parent API instance for data access
                api_instance = None
                if hasattr(self.auth_provider, 'auth_provider'):
                    # This is another manager, get its auth_provider
                    api_instance = self.auth_provider.auth_provider
                else:
                    # This is the API instance itself
                    api_instance = self.auth_provider
                
                # Use legacy feature manager to submit to Feast
                result = self._legacy_feature_manager.submit_feature(
                    name=feature_name,
                    processing_code=processing_code,
                    df=df,
                    api_instance=api_instance
                )
                
                return {
                    'status': 'success',
                    'feature_name': result,
                    'message': f"Feature '{feature_name}' submitted to Feast successfully"
                }
            else:
                raise FeatureError("Feature manager not initialized")
                
        except Exception as e:
            raise FeatureError(f"Failed to submit feature: {str(e)}")
            
    @handle_api_exceptions
    def get_feature(self, feature_name: str, df: Optional[pd.DataFrame] = None,
                   use_cache: bool = True) -> pd.DataFrame:
        """Get feature from Feast feature store.
        
        Args:
            feature_name: Name of the feature to retrieve
            df: Optional entity dataframe for feature retrieval
            use_cache: Whether to use cached features
            
        Returns:
            DataFrame with feature values
            
        Raises:
            FeatureError: If feature cannot be retrieved
        """
        self.require_auth()
        
        try:
            if self._legacy_feature_manager:
                # Get feature from Feast
                result = self._legacy_feature_manager.get_feature(
                    feature_name, 
                    use_cache=use_cache
                )
                
                # Apply validation year filter if set
                if self.validation_year is not None and 'Date' in result.columns:
                    result = result[result['Date'].dt.year < self.validation_year].copy()
                    self.logger.debug(f"Applied validation year filter: {len(result)} rows remaining")
                    
                return result
            else:
                raise FeatureError("Feature manager not initialized")
                
        except Exception as e:
            raise FeatureError(f"Failed to get feature: {str(e)}")
            
    def cleanup(self) -> None:
        """Cleanup feature manager resources."""
        self.logger.debug("Cleaning up FeatureManager")
        # Add any cleanup logic if needed