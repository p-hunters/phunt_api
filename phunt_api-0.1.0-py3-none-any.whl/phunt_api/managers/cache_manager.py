"""
Cache manager wrapper for PHuntAPI.
"""

from typing import Optional, Any

from .base import BaseManager
from ..misc.cache import CacheManager as CoreCacheManager


class CacheManager(BaseManager):
    """Manages caching operations for PHuntAPI.
    
    This manager provides a unified interface for cache operations,
    wrapping the core CacheManager functionality.
    """
    
    def __init__(self, cache_type: str = "pickle", debug: bool = False):
        """Initialize the cache manager.
        
        Args:
            cache_type: Type of cache to use ('memory', 'file', 'pickle')
            debug: Enable debug mode
        """
        super().__init__(auth_provider=None, debug=debug)
        self.cache_type = cache_type
        self._core_cache = None
        
    def initialize(self) -> None:
        """Initialize the cache manager."""
        self.logger.debug(f"Initializing CacheManager with type: {self.cache_type}")
        self._core_cache = CoreCacheManager(self.cache_type)
        
    def exists(self, key: str) -> bool:
        """Check if a key exists in cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if key exists, False otherwise
        """
        return self._core_cache.exists(key)
        
    def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache.
        
        Args:
            key: Cache key
            default: Default value if key not found
            
        Returns:
            Cached value or default
        """
        return self._core_cache.get(key, default)
        
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds (not supported in all cache types)
        """
        self._core_cache.set(key, value)
        
    def clear(self) -> None:
        """Clear all cache entries."""
        self._core_cache.clear()
        
    # Alias methods for backward compatibility
    def exists_in_cache(self, key: str) -> bool:
        """Alias for exists method."""
        return self.exists(key)
        
    def get_from_cache(self, key: str, default: Any = None) -> Any:
        """Alias for get method."""
        return self.get(key, default)
        
    def set_to_cache(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Alias for set method."""
        return self.set(key, value, ttl)
        
    def cleanup(self) -> None:
        """Cleanup cache manager resources."""
        self.logger.debug("Cleaning up CacheManager")
        # Skip clearing during cleanup to avoid errors