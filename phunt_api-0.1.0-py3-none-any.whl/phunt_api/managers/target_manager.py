"""
Target manager for PHuntAPI.
"""

from typing import Optional, List, Dict, Any, Callable
import pandas as pd
import inspect
import textwrap

from .base import BaseManager
from ..target import TargetManager as LegacyTargetManager
from ..exceptions import TargetError
from ..misc.decorators import handle_api_exceptions
from ..misc.validation import ValidationUtils


class TargetManager(BaseManager):
    """Manages target operations for PHuntAPI.
    
    This manager wraps the legacy TargetManager to provide:
    - Feast integration for target storage
    - S3 backend support
    - Target versioning and lineage
    - Distributed target computation
    """
    
    def __init__(self, auth_provider: Any, dataset_manager: Any,
                 validation_year: Optional[int] = None, core_api: Any = None, debug: bool = False):
        """Initialize the target manager.
        
        Args:
            auth_provider: Authentication provider instance
            dataset_manager: Dataset manager instance for Feast integration
            validation_year: Year to use for train/validation split
            core_api: Reference to PHuntAPI instance
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.validation_year = validation_year
        self._dataset_manager = dataset_manager
        self.core_api = core_api
        self._legacy_target_manager = None
        
    def initialize(self) -> None:
        """Initialize the target manager."""
        self.logger.debug("Initializing TargetManager")
        # Initialize the legacy target manager with dataset manager
        if hasattr(self._dataset_manager, '_legacy_dataset_manager'):
            self._legacy_target_manager = LegacyTargetManager(
                self._dataset_manager._legacy_dataset_manager
            )
        
    def set_validation_year(self, year: Optional[int]) -> None:
        """Set the validation year for train/validation split.
        
        Args:
            year: Year to use as validation split point
        """
        self.validation_year = year
        self.logger.debug(f"Validation year set to: {year}")
        
    @handle_api_exceptions
    def list_targets(self) -> pd.DataFrame:
        """List all available targets from Feast registry.
        
        Returns:
            DataFrame containing target information
            
        Raises:
            TargetError: If targets cannot be listed
        """
        self.require_auth()
        
        try:
            if self._legacy_target_manager:
                # Get targets from Feast
                target_views = self._legacy_target_manager.list_targets()
                # Convert to DataFrame for API compatibility
                return pd.DataFrame([
                    {
                        'name': tv.name,
                        'entities': [e.name for e in tv.entities] if hasattr(tv, 'entities') else [],
                        'features': [f.name for f in tv.features] if hasattr(tv, 'features') else [],
                        'online': tv.online if hasattr(tv, 'online') else False,
                        'tags': tv.tags if hasattr(tv, 'tags') else {}
                    }
                    for tv in target_views
                ])
            else:
                return pd.DataFrame()
        except Exception as e:
            raise TargetError(f"Failed to list targets: {str(e)}")
            
    @handle_api_exceptions
    def submit_target(self, target_name: str, processing_code: Callable,
                      target_type: str = "regression",
                      description: str = "", depends_on: List[str] = None) -> Dict[str, Any]:
        """Submit a new target to Feast.
        
        Args:
            target_name: Name for the new target
            processing_code: Function that calculates the target
            target_type: Type of target (e.g., 'regression', 'classification')
            description: Target description
            depends_on: List of features/targets this target depends on
            
        Returns:
            Dictionary containing submission result
            
        Raises:
            TargetError: If target cannot be submitted
        """
        self.require_auth()
        
        try:
            # Validate the processing code
            ValidationUtils.validate_processing_code(processing_code)
            
            if self._legacy_target_manager:
                # Get the parent API instance for data access
                api_instance = self.core_api
                if not api_instance:
                    # Fallback to auth_provider if it happens to be the API (legacy behavior)
                    if hasattr(self.auth_provider, 'get_dataset'):
                        api_instance = self.auth_provider
                    else:
                        raise TargetError("PHuntAPI instance not available for target processing")
                
                # Use legacy target manager to submit to Feast
                result = self._legacy_target_manager.submit_target(
                    name=target_name,
                    processing_code=processing_code,
                    api_instance=api_instance
                )
                
                return {
                    'status': 'success',
                    'target_name': result,
                    'message': f"Target '{target_name}' submitted to Feast successfully"
                }
            else:
                raise TargetError("Target manager not initialized")
                
        except Exception as e:
            raise TargetError(f"Failed to submit target: {str(e)}")
            
    @handle_api_exceptions
    def get_target(self, target_name: str, df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """Get target from Feast feature store.
        
        Args:
            target_name: Name of the target to retrieve
            df: Optional dataframe (not used, kept for compatibility)
            
        Returns:
            DataFrame with target values
            
        Raises:
            TargetError: If target cannot be retrieved
        """
        self.require_auth()
        
        try:
            if self._legacy_target_manager:
                # Get target from Feast
                result = self._legacy_target_manager.get_target(target_name)
                
                # Apply validation year filter if set
                if self.validation_year is not None and 'Date' in result.columns:
                    result = result[result['Date'].dt.year < self.validation_year].copy()
                    self.logger.debug(f"Applied validation year filter: {len(result)} rows remaining")
                    
                return result
            else:
                raise TargetError("Target manager not initialized")
                
        except Exception as e:
            raise TargetError(f"Failed to get target: {str(e)}")
            
    def get_target_code(self, target_name: str) -> str:
        """Get the source code for a target.
        
        Args:
            target_name: Name of the target
            
        Returns:
            Target source code
            
        Raises:
            TargetError: If code cannot be retrieved
        """
        if self._legacy_target_manager:
            # This would need to be implemented in the legacy manager
            # For now, return placeholder
            return f"# Target code for {target_name}"
        else:
            raise TargetError("Target manager not initialized")
            
    def cleanup(self) -> None:
        """Cleanup target manager resources."""
        self.logger.debug("Cleaning up TargetManager")
        # Add any cleanup logic if needed