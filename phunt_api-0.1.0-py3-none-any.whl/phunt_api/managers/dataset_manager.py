"""
Dataset manager for PHuntAPI.
"""

from typing import Optional, List, Dict, Any
import pandas as pd
import os

from .base import BaseManager
from ..dataset import DatasetManager as LegacyDatasetManager, PublicDatasetManager
from ..exceptions import DatasetError
from ..misc.decorators import handle_api_exceptions


class DatasetManager(BaseManager):
    """Manages dataset operations for PHuntAPI.
    
    This manager wraps the legacy DatasetManager to provide:
    - Feast integration for dataset management
    - S3 backend support
    - Dataset versioning
    - Public dataset access
    """
    
    def __init__(self, auth_provider: Any, repo_path: str = ".", debug: bool = False):
        """Initialize the dataset manager.
        
        Args:
            auth_provider: Authentication provider instance
            repo_path: Repository path for datasets
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.repo_path = repo_path
        self._legacy_dataset_manager = None
        self._public_dataset_manager = None
        
    def initialize(self) -> None:
        """Initialize the dataset manager."""
        self.logger.debug("Initializing DatasetManager")
        self._legacy_dataset_manager = LegacyDatasetManager(self.repo_path)
        self._public_dataset_manager = PublicDatasetManager(self.repo_path)
        
        # Pass credentials if available
        if hasattr(self.auth_provider, 'get_credentials'):
            creds = self.auth_provider.get_credentials()
            if creds:
                self._legacy_dataset_manager.set_creds(creds)
                if hasattr(self._public_dataset_manager, '_dataset_manager'):
                    self._public_dataset_manager._dataset_manager.set_creds(creds)
        
    @handle_api_exceptions
    def list_datasets(self) -> pd.DataFrame:
        """List all available datasets from Feast.
        
        Returns:
            DataFrame containing dataset information
            
        Raises:
            DatasetError: If datasets cannot be listed
        """
        self.require_auth()
        
        try:
            return self._legacy_dataset_manager.list_datasets()
        except Exception as e:
            raise DatasetError(f"Failed to list datasets: {str(e)}")
            
    @handle_api_exceptions
    def get_sample_data(self, dataset_name: str, n: int = 100) -> pd.DataFrame:
        """Get sample data from a dataset.
        
        Args:
            dataset_name: Name of the dataset
            n: Number of samples to retrieve
            
        Returns:
            DataFrame containing sample data
            
        Raises:
            DatasetError: If sample data cannot be retrieved
        """
        self.require_auth()
        
        try:
            # Check if it's a public dataset first
            public_datasets = self._public_dataset_manager.list_datasets()
            public_dataset_names = [ds.name if hasattr(ds, 'name') else str(ds) for ds in public_datasets]
            if dataset_name in public_dataset_names:
                return self._public_dataset_manager.get_sample_data(dataset_name)
            else:
                # Legacy dataset manager doesn't have get_sample_data, use get_dataset_split
                return self._legacy_dataset_manager.get_dataset_split(dataset_name, "sample")
        except Exception as e:
            raise DatasetError(f"Failed to get sample data: {str(e)}")
            
    @handle_api_exceptions
    def get_dataset(self, dataset_name: str, max_rows: Optional[int] = None) -> pd.DataFrame:
        """Get full dataset from Feast.
        
        Args:
            dataset_name: Name of the dataset
            max_rows: Maximum number of rows to retrieve
            
        Returns:
            DataFrame containing dataset
            
        Raises:
            DatasetError: If dataset cannot be retrieved
        """
        self.require_auth()
        
        try:
            # Pass credentials before getting dataset
            if hasattr(self.auth_provider, 'get_credentials'):
                creds = self.auth_provider.get_credentials()
                if creds:
                    # Set credentials on legacy dataset manager
                    self._legacy_dataset_manager.set_creds(creds)
                    # Set credentials on public dataset manager
                    if hasattr(self._public_dataset_manager, '_dataset_manager'):
                        self._public_dataset_manager._dataset_manager.set_creds(creds)
            
            # Check if it's a public dataset first
            public_datasets = self._public_dataset_manager.list_datasets()
            public_dataset_names = [ds.name if hasattr(ds, 'name') else str(ds) for ds in public_datasets]
            if dataset_name in public_dataset_names:
                # PublicDatasetManager.get_dataset doesn't accept max_rows
                df = self._public_dataset_manager.get_dataset(dataset_name)
                if max_rows and len(df) > max_rows:
                    return df.head(max_rows)
                return df
            else:
                # Legacy DatasetManager.get_dataset doesn't accept max_rows either
                df = self._legacy_dataset_manager.get_dataset(dataset_name)
                if max_rows and len(df) > max_rows:
                    return df.head(max_rows)
                return df
        except Exception as e:
            raise DatasetError(f"Failed to get dataset: {str(e)}")
            
    @handle_api_exceptions
    def get_dataset_spec(self, dataset_name: str) -> Dict[str, Any]:
        """Get dataset specification from Feast.
        
        Args:
            dataset_name: Name of the dataset
            
        Returns:
            Dictionary containing dataset specification
            
        Raises:
            DatasetError: If specification cannot be retrieved
        """
        self.require_auth()
        
        try:
            # Check if it's a public dataset first
            public_datasets = self._public_dataset_manager.list_datasets()
            public_dataset_names = [ds.name if hasattr(ds, 'name') else str(ds) for ds in public_datasets]
            if dataset_name in public_dataset_names:
                # PublicDatasetManager doesn't have get_spec, use get_dataset_spec from underlying manager
                return self._public_dataset_manager._dataset_manager.get_dataset_spec(dataset_name)
            else:
                return self._legacy_dataset_manager.get_dataset_spec(dataset_name)
        except Exception as e:
            raise DatasetError(f"Failed to get dataset spec: {str(e)}")
            
    @handle_api_exceptions
    def create_dataset_from_local(self, file_path: str, dataset_name: str,
                                 description: str = "") -> Dict[str, Any]:
        """Create a dataset from a local file and register with Feast.
        
        Args:
            file_path: Path to the local file
            dataset_name: Name for the new dataset
            description: Dataset description
            
        Returns:
            Dictionary containing creation result
            
        Raises:
            DatasetError: If dataset cannot be created
        """
        self.require_auth()
        
        try:
            # Fix the method name and parameter order
            return self._legacy_dataset_manager.create_dataset_from_local(
                dataset_name, file_path
            )
        except Exception as e:
            raise DatasetError(f"Failed to create dataset: {str(e)}")
            
    @handle_api_exceptions
    def get_data_from_source(self, source: str, **kwargs) -> pd.DataFrame:
        """Get data from external data source.
        
        Args:
            source: Data source name (e.g., 'dukascopy', 'mt5', 'oanda')
            **kwargs: Source-specific parameters
            
        Returns:
            DataFrame containing data from source
            
        Raises:
            DatasetError: If data cannot be retrieved from source
        """
        self.require_auth()
        
        try:
            # Create DataSourceManager on demand with required parameters
            if 'symbol' not in kwargs:
                raise DatasetError("Symbol parameter is required")
            if 'granularity' not in kwargs:
                raise DatasetError("Granularity parameter is required")
                
            from ..datasource import DataSourceManager as DSM
            datasource = DSM(
                provider=source,
                symbol=kwargs.pop('symbol'),
                granularity=kwargs.pop('granularity'),
                **kwargs
            )
            return datasource.get_data(**kwargs)
        except Exception as e:
            raise DatasetError(f"Failed to get data from source: {str(e)}")
            
    def cleanup(self) -> None:
        """Cleanup dataset manager resources."""
        self.logger.debug("Cleaning up DatasetManager")
        # Add any cleanup logic if needed