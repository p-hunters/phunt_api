"""
Plugin manager for PHuntAPI.
"""

from typing import Optional, List, Dict, Any, Union
import pandas as pd
from pathlib import Path

from .base import BaseManager
from ..plugin_api import PluginFeatureAPI, PluginTargetAPI, PluginStrategyAPI
from ..exceptions import PHuntAPIException
from ..misc.decorators import handle_api_exceptions


class PluginManager(BaseManager):
    """Manages plugin operations for PHuntAPI.
    
    This manager handles all plugin-related operations including:
    - Installing/uninstalling plugins
    - Managing plugin catalog
    - Executing plugin functions
    - Version conflict resolution
    - Plugin documentation generation
    """
    
    def __init__(self, auth_provider: Any, plugin_cache_dir: Optional[str] = None,
                 core_api: Any = None, debug: bool = False):
        """Initialize the plugin manager.
        
        Args:
            auth_provider: Authentication provider instance
            plugin_cache_dir: Directory for plugin cache
            core_api: Reference to core API instance
            debug: Enable debug mode
        """
        super().__init__(auth_provider=auth_provider, debug=debug)
        self.plugin_cache_dir = plugin_cache_dir
        self.core_api = core_api
        self._plugin_feature_api = None
        self._plugin_target_api = None
        
    def initialize(self) -> None:
        """Initialize the plugin manager."""
        self.logger.debug("Initializing PluginManager")
        self._plugin_feature_api = PluginFeatureAPI(
            plugin_cache_dir=self.plugin_cache_dir,
            core_api=self.core_api
        )
        self._plugin_target_api = PluginTargetAPI(
            plugin_cache_dir=self.plugin_cache_dir,
            core_api=self.core_api
        )
        self._plugin_strategy_api = PluginStrategyAPI(
            plugin_cache_dir=self.plugin_cache_dir,
            core_api=self.core_api
        )
        
    @handle_api_exceptions
    def install_plugin_from_github(self, repo_url: str, branch: str = "main") -> Dict[str, Any]:
        """Install a plugin from GitHub repository.
        
        Args:
            repo_url: GitHub repository URL
            branch: Branch to install from
            
        Returns:
            Dictionary containing installation result
            
        Raises:
            PHuntAPIException: If plugin cannot be installed
        """
        self.require_auth()
        
        try:
            # Try feature plugin first
            result = self._plugin_feature_api.install_plugin_from_github(repo_url, branch)
            if result['status'] == 'success':
                return result
                
            # Try target plugin if feature failed
            result = self._plugin_target_api.install_plugin_from_github(repo_url, branch)
            return result
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to install plugin: {str(e)}")
            
    @handle_api_exceptions
    def list_github_plugins(self) -> List[Dict[str, Any]]:
        """List all installed GitHub plugins.
        
        Returns:
            List of plugin information dictionaries
            
        Raises:
            PHuntAPIException: If plugins cannot be listed
        """
        self.require_auth()
        
        try:
            feature_plugins = self._plugin_feature_api.list_github_plugins()
            target_plugins = self._plugin_target_api.list_github_plugins()
            
            # Combine and mark plugin types
            all_plugins = []
            for plugin in feature_plugins:
                plugin['plugin_type'] = 'feature'
                all_plugins.append(plugin)
            for plugin in target_plugins:
                plugin['plugin_type'] = 'target'
                all_plugins.append(plugin)
                
            return all_plugins
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to list plugins: {str(e)}")
            
    @handle_api_exceptions
    def uninstall_github_plugin(self, repo_url: str) -> Dict[str, Any]:
        """Uninstall a GitHub plugin.
        
        Args:
            repo_url: GitHub repository URL of plugin to uninstall
            
        Returns:
            Dictionary containing uninstallation result
            
        Raises:
            PHuntAPIException: If plugin cannot be uninstalled
        """
        self.require_auth()
        
        try:
            # Try both plugin types
            for api in [self._plugin_feature_api, self._plugin_target_api]:
                try:
                    result = api.uninstall_github_plugin(repo_url)
                    if result['status'] == 'success':
                        return result
                except:
                    continue
                    
            raise PHuntAPIException(f"Plugin not found: {repo_url}")
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to uninstall plugin: {str(e)}")
            
    @handle_api_exceptions
    def update_plugin_catalog(self) -> Dict[str, Any]:
        """Update the plugin catalog.
        
        Returns:
            Dictionary containing update result
            
        Raises:
            PHuntAPIException: If catalog cannot be updated
        """
        self.require_auth()
        
        try:
            feature_result = self._plugin_feature_api.update_catalog()
            target_result = self._plugin_target_api.update_catalog()
            
            return {
                'status': 'success',
                'feature_catalog': feature_result,
                'target_catalog': target_result
            }
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to update catalog: {str(e)}")
            
    @handle_api_exceptions
    def search_plugins(self, query: str, plugin_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for plugins in the catalog.
        
        Args:
            query: Search query
            plugin_type: Type of plugin to search ('feature', 'target', or None for both)
            
        Returns:
            List of matching plugins
            
        Raises:
            PHuntAPIException: If search fails
        """
        self.require_auth()
        
        try:
            results = []
            
            if plugin_type in [None, 'feature']:
                feature_results = self._plugin_feature_api.search_catalog(query)
                for plugin in feature_results:
                    plugin['plugin_type'] = 'feature'
                    results.append(plugin)
                    
            if plugin_type in [None, 'target']:
                target_results = self._plugin_target_api.search_catalog(query)
                for plugin in target_results:
                    plugin['plugin_type'] = 'target'
                    results.append(plugin)
                    
            return results
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to search plugins: {str(e)}")
            
    @handle_api_exceptions
    def install_plugin_from_catalog(self, plugin_name: str, version: Optional[str] = None) -> Dict[str, Any]:
        """Install a plugin from the catalog.
        
        Args:
            plugin_name: Name of the plugin
            version: Version to install (defaults to latest)
            
        Returns:
            Dictionary containing installation result
            
        Raises:
            PHuntAPIException: If plugin cannot be installed
        """
        self.require_auth()
        
        try:
            # Try feature catalog first
            try:
                return self._plugin_feature_api.install_from_catalog(plugin_name, version)
            except:
                # Try target catalog if feature failed
                return self._plugin_target_api.install_from_catalog(plugin_name, version)
                
        except Exception as e:
            raise PHuntAPIException(f"Failed to install plugin: {str(e)}")
            
    @handle_api_exceptions
    def list_plugins(self, plugin_type: Optional[str] = None) -> pd.DataFrame:
        """List all available plugins.
        
        Args:
            plugin_type: Type of plugins to list ('feature', 'target', or None for both)
            
        Returns:
            DataFrame containing plugin information
            
        Raises:
            PHuntAPIException: If plugins cannot be listed
        """
        self.require_auth()
        
        try:
            plugins = []
            
            if plugin_type in [None, 'feature']:
                feature_plugins = self._plugin_feature_api.list_plugins()
                plugins.extend(feature_plugins)
                
            if plugin_type in [None, 'target']:
                target_plugins = self._plugin_target_api.list_plugins()
                plugins.extend(target_plugins)
                
            return pd.DataFrame(plugins)
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to list plugins: {str(e)}")
            
    @handle_api_exceptions
    def get_plugin_functions(self, plugin_name: str) -> List[str]:
        """Get list of functions provided by a plugin.
        
        Args:
            plugin_name: Name of the plugin
            
        Returns:
            List of function names
            
        Raises:
            PHuntAPIException: If functions cannot be retrieved
        """
        self.require_auth()
        
        try:
            # Try both plugin types
            for api in [self._plugin_feature_api, self._plugin_target_api]:
                try:
                    return api.get_plugin_functions(plugin_name)
                except:
                    continue
                    
            raise PHuntAPIException(f"Plugin not found: {plugin_name}")
            
        except Exception as e:
            raise PHuntAPIException(f"Failed to get plugin functions: {str(e)}")
            
    @handle_api_exceptions
    def get_plugin_feature(self, plugin_name: str, function_name: str,
                          df: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """Calculate a feature using a plugin.
        
        Args:
            plugin_name: Name of the plugin
            function_name: Name of the function to call
            df: Input dataframe
            **kwargs: Additional arguments for the function
            
        Returns:
            DataFrame with calculated feature
            
        Raises:
            PHuntAPIException: If feature cannot be calculated
        """
        self.require_auth()
        
        try:
            return self._plugin_feature_api.calculate_feature(
                plugin_name, function_name, df, **kwargs
            )
        except Exception as e:
            raise PHuntAPIException(f"Failed to calculate plugin feature: {str(e)}")
            
    @handle_api_exceptions
    def get_plugin_target(self, plugin_name: str, function_name: str,
                         df: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """Calculate a target using a plugin.
        
        Args:
            plugin_name: Name of the plugin
            function_name: Name of the function to call
            df: Input dataframe
            **kwargs: Additional arguments for the function
            
        Returns:
            DataFrame with calculated target
            
        Raises:
            PHuntAPIException: If target cannot be calculated
        """
        self.require_auth()
        
        try:
            return self._plugin_target_api.calculate_target(
                plugin_name, function_name, df, **kwargs
            )
        except Exception as e:
            raise PHuntAPIException(f"Failed to calculate plugin target: {str(e)}")
            
    def cleanup(self) -> None:
        """Cleanup plugin manager resources."""
        self.logger.debug("Cleaning up PluginManager")
        # Plugin APIs handle their own cleanup
        
    def get_plugin_feature(self, plugin_name: str, feature_name: str, df: pd.DataFrame, **kwargs):
        """Get a specific feature from a plugin."""
        try:
            return self._plugin_feature_api.get_plugin_feature(plugin_name, feature_name, df, **kwargs)
        except Exception as e:
            raise PHuntAPIException(f"Failed to get plugin feature: {str(e)}")
            
    def get_plugin_target(self, plugin_name: str, target_name: str, df: pd.DataFrame, **kwargs):
        """Get a specific target from a plugin."""
        try:
            return self._plugin_target_api.get_plugin_target(plugin_name, target_name, df, **kwargs)
        except Exception as e:
            raise PHuntAPIException(f"Failed to get plugin target: {str(e)}")
            
    def generate_plugin_docs(self, output_dir: Optional[str] = None, plugin_type: Optional[str] = None) -> List[str]:
        """Generate documentation for all plugins."""
        try:
            docs = []
            if plugin_type in [None, 'feature']:
                docs.extend(self._plugin_feature_api.generate_plugin_docs(output_dir))
            if plugin_type in [None, 'target']:
                docs.extend(self._plugin_target_api.generate_plugin_docs(output_dir))
            return docs
        except Exception as e:
            raise PHuntAPIException(f"Failed to generate plugin docs: {str(e)}")
            
    def generate_plugin_doc(self, plugin_name: str, output_dir: Optional[str] = None, plugin_type: Optional[str] = None) -> Optional[str]:
        """Generate documentation for a specific plugin."""
        try:
            # Try to find the plugin in either API
            if plugin_type == 'feature' or plugin_type is None:
                try:
                    return self._plugin_feature_api.generate_plugin_doc(plugin_name, output_dir)
                except:
                    if plugin_type == 'feature':
                        raise
            if plugin_type == 'target' or plugin_type is None:
                try:
                    return self._plugin_target_api.generate_plugin_doc(plugin_name, output_dir)
                except:
                    if plugin_type == 'target':
                        raise
            return None
        except Exception as e:
            raise PHuntAPIException(f"Failed to generate plugin doc: {str(e)}")
            
    def get_plugin_functions(self, plugin_name: str, plugin_type: Optional[str] = None, include_signatures: bool = False):
        """Get available functions from a plugin."""
        try:
            # Try to find the plugin in either API
            if plugin_type == 'feature' or plugin_type is None:
                try:
                    return self._plugin_feature_api.get_plugin_functions(plugin_name, include_signatures)
                except:
                    if plugin_type == 'feature':
                        raise
            if plugin_type == 'target' or plugin_type is None:
                try:
                    return self._plugin_target_api.get_plugin_functions(plugin_name, include_signatures)
                except:
                    if plugin_type == 'target':
                        raise
            return []
        except Exception as e:
            raise PHuntAPIException(f"Failed to get plugin functions: {str(e)}")
            
    def _get_plugin_version(self, plugin_name: str, plugin_type: Optional[str] = None) -> str:
        """Get version of a plugin."""
        try:
            # Try to find the plugin in either API
            if plugin_type == 'feature' or plugin_type is None:
                try:
                    plugins = self._plugin_feature_api.list_installed_plugins()
                    for p in plugins:
                        if p['name'] == plugin_name:
                            return p.get('version', 'unknown')
                except:
                    if plugin_type == 'feature':
                        raise
            if plugin_type == 'target' or plugin_type is None:
                try:
                    plugins = self._plugin_target_api.list_installed_plugins()
                    for p in plugins:
                        if p['name'] == plugin_name:
                            return p.get('version', 'unknown')
                except:
                    if plugin_type == 'target':
                        raise
            return 'unknown'
        except Exception as e:
            raise PHuntAPIException(f"Failed to get plugin version: {str(e)}")