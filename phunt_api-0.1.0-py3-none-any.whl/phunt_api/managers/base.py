"""
Base manager class for all PHuntAPI managers.
"""

from abc import ABC, abstractmethod
from typing import Optional, Any
import logging


class BaseManager(ABC):
    """Base class for all manager classes in PHuntAPI.
    
    This class provides common functionality and interface for all managers,
    including logging, error handling, and authentication checks.
    """
    
    def __init__(self, auth_provider: Optional[Any] = None, debug: bool = False):
        """Initialize the base manager.
        
        Args:
            auth_provider: Authentication provider instance (e.g., PHuntAuth)
            debug: Enable debug mode
        """
        self.auth_provider = auth_provider
        self.debug = debug
        self.logger = logging.getLogger(self.__class__.__name__)
        
        if self.debug:
            self.logger.setLevel(logging.DEBUG)
            
    @property
    def is_authenticated(self) -> bool:
        """Check if the user is authenticated."""
        if self.auth_provider is None:
            return True  # No auth required
        return getattr(self.auth_provider, 'is_logged_in', lambda: False)()
        
    def require_auth(self) -> None:
        """Ensure the user is authenticated.
        
        Raises:
            AuthenticationError: If user is not authenticated
        """
        if not self.is_authenticated:
            from ..exceptions import AuthenticationError
            raise AuthenticationError("Authentication required for this operation")
            
    @abstractmethod
    def initialize(self) -> None:
        """Initialize the manager. Must be implemented by subclasses."""
        pass
        
    def cleanup(self) -> None:
        """Cleanup resources. Can be overridden by subclasses."""
        pass