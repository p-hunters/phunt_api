# -*- coding: utf-8 -*-
"""
Competition repository interface and implementations.
"""

import abc
import json
import os
import fcntl
from typing import List, Optional, Dict
from pathlib import Path

from .models import Competition


class CompetitionRepository(abc.ABC):
    """Abstract base class for competition repository."""

    @abc.abstractmethod
    def save(self, competition: Competition) -> None:
        """Save a competition."""
        pass

    @abc.abstractmethod
    def get(self, competition_id: str) -> Optional[Competition]:
        """Get a competition by ID."""
        pass

    @abc.abstractmethod
    def list_all(self) -> List[Competition]:
        """List all competitions."""
        pass

    @abc.abstractmethod
    def delete(self, competition_id: str) -> None:
        """Delete a competition."""
        pass


class FileCompetitionRepository(CompetitionRepository):
    """File-based implementation of CompetitionRepository."""

    def __init__(self, storage_path: str):
        """Initialize the repository.
        
        Args:
            storage_path: Directory path for storing competition files.
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

    def _get_file_path(self, competition_id: str) -> Path:
        return self.storage_path / f"{competition_id}.json"

    def save(self, competition: Competition) -> None:
        """Save a competition to a JSON file with locking."""
        file_path = self._get_file_path(competition.competition_id)
        
        # Convert to dict using the model's to_dict method which handles serialization
        data = competition.to_dict()
        
        with open(file_path, 'w', encoding='utf-8') as f:
            # Acquire exclusive lock
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                json.dump(data, f, indent=2, ensure_ascii=False)
            finally:
                # Release lock
                fcntl.flock(f, fcntl.LOCK_UN)

    def get(self, competition_id: str) -> Optional[Competition]:
        """Get a competition by ID."""
        file_path = self._get_file_path(competition_id)
        
        if not file_path.exists():
            return None
            
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                # Acquire shared lock
                fcntl.flock(f, fcntl.LOCK_SH)
                try:
                    data = json.load(f)
                    return Competition.from_dict(data)
                finally:
                    fcntl.flock(f, fcntl.LOCK_UN)
        except Exception as e:
            print(f"Error loading competition {competition_id}: {e}")
            return None

    def list_all(self) -> List[Competition]:
        """List all competitions."""
        competitions = []
        for file_path in self.storage_path.glob("*.json"):
            try:
                # We can infer ID from filename, but let's load to be safe and get full object
                # Optimization: Could just read basic info if performance becomes an issue
                comp = self.get(file_path.stem)
                if comp:
                    competitions.append(comp)
            except Exception:
                continue
        return competitions

    def delete(self, competition_id: str) -> None:
        """Delete a competition file."""
        file_path = self._get_file_path(competition_id)
        if file_path.exists():
            file_path.unlink()
