# -*- coding: utf-8 -*-
"""
Competition管理用のStreamlit UI

このモジュールは、Streamlitを使用してCompetitionの参照、編集、登録などができる
管理ページを提供します。
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from typing import List, Dict, Any, Optional
import json

try:
    from ..api import PHuntAPI
    from .models import Competition, CompetitionStatus, LeaderboardEntry, DiscussionPost
    from ..exceptions import CompetitionError
except ImportError:
    # Fallback for direct execution
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from phunt_api.api import PHuntAPI
    from phunt_api.competitions.models import Competition, CompetitionStatus, LeaderboardEntry, DiscussionPost
    from phunt_api.exceptions import CompetitionError


# ページ設定
st.set_page_config(
    page_title="Competition管理",
    page_icon="🏆",
    layout="wide",
    initial_sidebar_state="expanded"
)

# セッション状態の初期化
if 'api' not in st.session_state:
    st.session_state.api = None
if 'initialized' not in st.session_state:
    st.session_state.initialized = False
if 'selected_competition_id' not in st.session_state:
    st.session_state.selected_competition_id = None


def initialize_api():
    """APIを初期化"""
    if not st.session_state.initialized:
        try:
            st.session_state.api = PHuntAPI(debug=True)
            st.session_state.api.login()
            st.session_state.initialized = True
            return True
        except Exception as e:
            st.error(f"API初期化エラー: {str(e)}")
            return False
    return True


def get_competition_manager():
    """CompetitionManagerを取得"""
    if not initialize_api():
        return None
    return st.session_state.api._competition_manager


def format_datetime(dt: Optional[datetime]) -> str:
    """日時をフォーマット"""
    if dt is None:
        return "未設定"
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def status_color(status: CompetitionStatus) -> str:
    """ステータスに応じたカラーコードを返す"""
    colors = {
        CompetitionStatus.DRAFT: "⚪",
        CompetitionStatus.ACTIVE: "🟢",
        CompetitionStatus.CLOSED: "🔴",
        CompetitionStatus.ARCHIVED: "⚫"
    }
    return colors.get(status, "⚪")


# サイドバー
st.sidebar.title("🏆 Competition管理")
page = st.sidebar.radio(
    "ページ選択",
    ["一覧", "作成", "詳細・編集", "リーダーボード", "ルール", "ディスカッション"]
)

# メインコンテンツ
if not initialize_api():
    st.error("APIの初期化に失敗しました。")
    st.stop()

manager = get_competition_manager()
if manager is None:
    st.error("CompetitionManagerを取得できませんでした。")
    st.stop()


# ========== 一覧ページ ==========
if page == "一覧":
    st.title("📋 Competition一覧")
    
    # フィルター
    col1, col2 = st.columns([3, 1])
    with col1:
        search_query = st.text_input("検索", placeholder="Competition名、IDで検索")
    with col2:
        status_filter = st.selectbox(
            "ステータスフィルター",
            ["すべて", "Draft", "Active", "Closed", "Archived"]
        )
    
    try:
        # 全てのコンペティションを取得
        competitions = manager.list_competitions()
        
        # フィルター適用
        if status_filter != "すべて":
            status_map = {
                "Draft": CompetitionStatus.DRAFT,
                "Active": CompetitionStatus.ACTIVE,
                "Closed": CompetitionStatus.CLOSED,
                "Archived": CompetitionStatus.ARCHIVED
            }
            competitions = manager.list_competitions(status=status_map[status_filter])
        
        if search_query:
            competitions = [
                c for c in competitions
                if search_query.lower() in c.name.lower() or search_query.lower() in c.competition_id.lower()
            ]
        
        if not competitions:
            st.info("コンペティションが見つかりませんでした。")
        else:
            # テーブル表示
            data = []
            for comp in competitions:
                data.append({
                    "ID": comp.competition_id,
                    "名前": comp.name,
                    "ステータス": f"{status_color(comp.status)} {comp.status.value}",
                    "問題タイプ": comp.problem_type,
                    "作成日": format_datetime(comp.created_at),
                    "開始日": format_datetime(comp.start_date),
                    "終了日": format_datetime(comp.end_date),
                    "作成者": comp.created_by or "未設定"
                })
            
            df = pd.DataFrame(data)
            st.dataframe(df, use_container_width=True, hide_index=True)
            
            # 選択機能
            st.subheader("詳細表示")
            competition_ids = [c.competition_id for c in competitions]
            selected_id = st.selectbox("表示するCompetitionを選択", [""] + competition_ids)
            if selected_id:
                st.session_state.selected_competition_id = selected_id
                st.success(f"'{selected_id}' を選択しました。詳細ページで確認できます。")
    
    except Exception as e:
        st.error(f"エラーが発生しました: {str(e)}")


# ========== 作成ページ ==========
elif page == "作成":
    st.title("➕ Competition作成")
    
    with st.form("create_competition_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            competition_id = st.text_input("Competition ID *", placeholder="comp_001")
            name = st.text_input("名前 *", placeholder="Forex Prediction Challenge")
            problem_type = st.selectbox(
                "問題タイプ *",
                ["classification", "regression", "time_series"]
            )
            status = st.selectbox(
                "ステータス *",
                ["draft", "active", "closed", "archived"]
            )
        
        with col2:
            created_by = st.text_input("作成者", placeholder="user_123")
            start_date = st.date_input("開始日", value=None)
            end_date = st.date_input("終了日", value=None)
        
        st.markdown("**説明 * (Markdown形式で入力可能)**")
        description = st.text_area(
            "説明 *", 
            placeholder="Competitionの概要を記述（Markdown形式で入力可能）\n\n例:\n# Competition概要\n\nこのCompetitionは...",
            height=150,
            label_visibility="collapsed"
        )
        
        st.markdown("**問題説明 * (Markdown形式で入力可能)**")
        problem_description = st.text_area(
            "問題説明 *",
            placeholder="詳細な問題説明を記述（Markdown形式で入力可能）\n\n例:\n## 問題設定\n\n### 目標\n...",
            height=200,
            label_visibility="collapsed"
        )
        
        # プレビュー表示
        if description or problem_description:
            st.subheader("プレビュー")
            if description:
                st.markdown("**説明:**")
                st.markdown(description)
            if problem_description:
                st.markdown("**問題説明:**")
                st.markdown(problem_description)
        
        # タグ
        tags_input = st.text_input("タグ（カンマ区切り）", placeholder="forex, prediction, challenge")
        tags = [tag.strip() for tag in tags_input.split(",")] if tags_input else []
        
        submitted = st.form_submit_button("作成", type="primary")
        
        if submitted:
            if not competition_id or not name or not description or not problem_description:
                st.error("必須項目（*）をすべて入力してください。")
            else:
                try:
                    competition = manager.create_competition(
                        competition_id=competition_id,
                        name=name,
                        description=description,
                        problem_description=problem_description,
                        problem_type=problem_type,
                        created_by=created_by or "",
                        status=CompetitionStatus(status),
                        start_date=datetime.combine(start_date, datetime.min.time()) if start_date else None,
                        end_date=datetime.combine(end_date, datetime.min.time()) if end_date else None,
                        tags=tags
                    )
                    st.success(f"Competition '{competition_id}' を作成しました！")
                    st.session_state.selected_competition_id = competition_id
                    
                    # 作成されたCompetitionの情報を表示
                    with st.expander("作成されたCompetition情報", expanded=True):
                        st.json(competition.to_dict())
                
                except CompetitionError as e:
                    st.error(f"作成エラー: {str(e)}")
                except Exception as e:
                    st.error(f"予期しないエラーが発生しました: {str(e)}")


# ========== 詳細・編集ページ ==========
elif page == "詳細・編集":
    st.title("📝 Competition詳細・編集")
    
    try:
        competitions = manager.list_competitions()
        competition_ids = [c.competition_id for c in competitions]
        
        if not competition_ids:
            st.info("Competitionが存在しません。まず作成してください。")
        else:
            # Competition選択
            selected_id = st.selectbox(
                "Competitionを選択",
                competition_ids,
                index=competition_ids.index(st.session_state.selected_competition_id) if st.session_state.selected_competition_id in competition_ids else 0
            )
            
            if selected_id:
                competition = manager.get_competition(selected_id)
                st.session_state.selected_competition_id = selected_id
                
                # 基本情報表示
                st.subheader("基本情報")
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("ステータス", f"{status_color(competition.status)} {competition.status.value}")
                with col2:
                    st.metric("問題タイプ", competition.problem_type)
                with col3:
                    st.metric("作成日", format_datetime(competition.created_at))
                
                # 説明と問題説明の表示（マークダウン）
                if competition.description:
                    st.subheader("説明")
                    st.markdown(competition.description)
                
                if competition.problem_description:
                    st.subheader("問題説明")
                    st.markdown(competition.problem_description)
                
                # 編集フォーム
                with st.expander("基本情報を編集", expanded=False):
                    with st.form("edit_basic_info"):
                        new_name = st.text_input("名前", value=competition.name)
                        
                        st.markdown("**説明 (Markdown形式で入力可能)**")
                        new_description = st.text_area(
                            "説明", 
                            value=competition.description,
                            height=150,
                            placeholder="Markdown形式で入力可能",
                            label_visibility="collapsed"
                        )
                        
                        st.markdown("**問題説明 (Markdown形式で入力可能)**")
                        new_problem_description = st.text_area(
                            "問題説明", 
                            value=competition.problem_description,
                            height=200,
                            placeholder="Markdown形式で入力可能",
                            label_visibility="collapsed"
                        )
                        
                        new_problem_type = st.selectbox(
                            "問題タイプ",
                            ["classification", "regression", "time_series"],
                            index=["classification", "regression", "time_series"].index(competition.problem_type)
                        )
                        new_status = st.selectbox(
                            "ステータス",
                            ["draft", "active", "closed", "archived"],
                            index=["draft", "active", "closed", "archived"].index(competition.status.value)
                        )
                        
                        # プレビュー表示
                        if new_description or new_problem_description:
                            st.markdown("---")
                            st.markdown("**プレビュー**")
                            if new_description:
                                st.markdown("**説明:**")
                                st.markdown(new_description)
                            if new_problem_description:
                                st.markdown("**問題説明:**")
                                st.markdown(new_problem_description)
                        
                        if st.form_submit_button("更新"):
                            try:
                                manager.update_competition(
                                    selected_id,
                                    name=new_name,
                                    description=new_description,
                                    problem_description=new_problem_description,
                                    problem_type=new_problem_type,
                                    status=CompetitionStatus(new_status)
                                )
                                st.success("更新しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"更新エラー: {str(e)}")
                
                # リソース管理
                st.subheader("リソース管理")
                
                # Datasets
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write("**Datasets**")
                    datasets = competition.datasets if competition.datasets else []
                    if datasets:
                        for ds in datasets:
                            st.write(f"- {ds}")
                    else:
                        st.write("登録されていません")
                
                with col2:
                    with st.form("add_dataset"):
                        new_dataset = st.text_input("Dataset名", key="dataset_input")
                        if st.form_submit_button("追加"):
                            try:
                                manager.add_dataset(selected_id, new_dataset)
                                st.success("追加しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                    
                    if datasets:
                        with st.form("remove_dataset"):
                            dataset_to_remove = st.selectbox("削除するDataset", datasets, key="dataset_remove")
                            if st.form_submit_button("削除"):
                                try:
                                    manager.remove_dataset(selected_id, dataset_to_remove)
                                    st.success("削除しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
                
                # Models
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write("**Models**")
                    models = competition.models if competition.models else []
                    if models:
                        for m in models:
                            st.write(f"- {m}")
                    else:
                        st.write("登録されていません")
                
                with col2:
                    with st.form("add_model"):
                        new_model = st.text_input("Model名", key="model_input")
                        if st.form_submit_button("追加"):
                            try:
                                manager.add_model(selected_id, new_model)
                                st.success("追加しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                    
                    if models:
                        with st.form("remove_model"):
                            model_to_remove = st.selectbox("削除するModel", models, key="model_remove")
                            if st.form_submit_button("削除"):
                                try:
                                    manager.remove_model(selected_id, model_to_remove)
                                    st.success("削除しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
                
                # Features
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write("**Features**")
                    features = competition.features if competition.features else []
                    if features:
                        for f in features:
                            st.write(f"- {f}")
                    else:
                        st.write("登録されていません")
                
                with col2:
                    with st.form("add_feature"):
                        new_feature = st.text_input("Feature名", key="feature_input")
                        if st.form_submit_button("追加"):
                            try:
                                manager.add_feature(selected_id, new_feature)
                                st.success("追加しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                    
                    if features:
                        with st.form("remove_feature"):
                            feature_to_remove = st.selectbox("削除するFeature", features, key="feature_remove")
                            if st.form_submit_button("削除"):
                                try:
                                    manager.remove_feature(selected_id, feature_to_remove)
                                    st.success("削除しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
                
                # Targets
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write("**Targets**")
                    targets = competition.targets if competition.targets else []
                    if targets:
                        for t in targets:
                            st.write(f"- {t}")
                    else:
                        st.write("登録されていません")
                
                with col2:
                    with st.form("add_target"):
                        new_target = st.text_input("Target名", key="target_input")
                        if st.form_submit_button("追加"):
                            try:
                                manager.add_target(selected_id, new_target)
                                st.success("追加しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                    
                    if targets:
                        with st.form("remove_target"):
                            target_to_remove = st.selectbox("削除するTarget", targets, key="target_remove")
                            if st.form_submit_button("削除"):
                                try:
                                    manager.remove_target(selected_id, target_to_remove)
                                    st.success("削除しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
                
                # タグ管理
                st.subheader("タグ")
                tags = competition.tags if competition.tags else []
                if tags:
                    st.write(" ".join([f"`{tag}`" for tag in tags]))
                
                with st.form("manage_tags"):
                    tags_input = st.text_input("タグ（カンマ区切り）", value=", ".join(tags))
                    if st.form_submit_button("タグを更新"):
                        try:
                            new_tags = [tag.strip() for tag in tags_input.split(",")] if tags_input else []
                            manager.update_competition(selected_id, tags=new_tags)
                            st.success("タグを更新しました！")
                            st.rerun()
                        except Exception as e:
                            st.error(f"エラー: {str(e)}")
                
                # メタデータ
                st.subheader("メタデータ")
                with st.expander("メタデータを表示/編集"):
                    metadata_str = st.text_area(
                        "メタデータ（JSON形式）",
                        value=json.dumps(competition.metadata, indent=2, ensure_ascii=False),
                        height=200
                    )
                    if st.button("メタデータを更新"):
                        try:
                            metadata = json.loads(metadata_str)
                            manager.update_competition(selected_id, metadata=metadata)
                            st.success("メタデータを更新しました！")
                            st.rerun()
                        except json.JSONDecodeError:
                            st.error("JSON形式が不正です。")
                        except Exception as e:
                            st.error(f"エラー: {str(e)}")
                
                # 削除機能
                st.subheader("削除")
                if st.button("このCompetitionを削除", type="secondary"):
                    with st.form("confirm_delete"):
                        st.warning("⚠️ この操作は取り消せません。")
                        confirm = st.text_input("削除を確認するには、Competition IDを入力してください", key="delete_confirm")
                        if st.form_submit_button("削除を実行", type="secondary"):
                            if confirm == selected_id:
                                try:
                                    manager.delete_competition(selected_id)
                                    st.success("Competitionを削除しました。")
                                    st.session_state.selected_competition_id = None
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"削除エラー: {str(e)}")
                            else:
                                st.error("Competition IDが一致しません。")
    
    except Exception as e:
        st.error(f"エラーが発生しました: {str(e)}")


# ========== リーダーボードページ ==========
elif page == "リーダーボード":
    st.title("🏅 リーダーボード管理")
    
    try:
        competitions = manager.list_competitions()
        competition_ids = [c.competition_id for c in competitions]
        
        if not competition_ids:
            st.info("Competitionが存在しません。")
        else:
            selected_id = st.selectbox(
                "Competitionを選択",
                competition_ids,
                index=competition_ids.index(st.session_state.selected_competition_id) if st.session_state.selected_competition_id in competition_ids else 0
            )
            
            if selected_id:
                competition = manager.get_competition(selected_id)
                leaderboard = competition.leaderboard if competition.leaderboard else []
                
                # リーダーボード表示
                st.subheader(f"'{selected_id}' のリーダーボード")
                
                if leaderboard:
                    data = []
                    for entry in leaderboard:
                        data.append({
                            "順位": entry.rank,
                            "参加者ID": entry.participant_id,
                            "参加者名": entry.participant_name,
                            "スコア": entry.score,
                            "モデル名": entry.model_name,
                            "提出日時": format_datetime(entry.submitted_at)
                        })
                    
                    df = pd.DataFrame(data)
                    st.dataframe(df, use_container_width=True, hide_index=True)
                else:
                    st.info("リーダーボードエントリーがありません。")
                
                # エントリー追加
                st.subheader("エントリー追加")
                with st.form("add_leaderboard_entry"):
                    col1, col2 = st.columns(2)
                    with col1:
                        participant_id = st.text_input("参加者ID *")
                        participant_name = st.text_input("参加者名 *")
                    with col2:
                        score = st.number_input("スコア *", value=0.0, step=0.01)
                        model_name = st.text_input("モデル名 *")
                    
                    metadata_input = st.text_area("メタデータ（JSON形式、オプション）", value="{}")
                    
                    if st.form_submit_button("エントリーを追加"):
                        if not participant_id or not participant_name or not model_name:
                            st.error("必須項目を入力してください。")
                        else:
                            try:
                                metadata = json.loads(metadata_input) if metadata_input else {}
                                manager.add_leaderboard_entry(
                                    selected_id,
                                    participant_id=participant_id,
                                    participant_name=participant_name,
                                    score=score,
                                    model_name=model_name,
                                    metadata=metadata
                                )
                                st.success("エントリーを追加しました！")
                                st.rerun()
                            except json.JSONDecodeError:
                                st.error("メタデータのJSON形式が不正です。")
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                
                # エントリー削除
                if leaderboard:
                    st.subheader("エントリー削除")
                    with st.form("remove_leaderboard_entry"):
                        participant_ids = [entry.participant_id for entry in leaderboard]
                        participant_to_remove = st.selectbox("削除する参加者", participant_ids)
                        if st.form_submit_button("エントリーを削除"):
                            try:
                                manager.remove_leaderboard_entry(selected_id, participant_to_remove)
                                st.success("エントリーを削除しました！")
                                st.rerun()
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
    
    except Exception as e:
        st.error(f"エラーが発生しました: {str(e)}")


# ========== ルールページ ==========
elif page == "ルール":
    st.title("📋 ルール管理")
    
    try:
        competitions = manager.list_competitions()
        competition_ids = [c.competition_id for c in competitions]
        
        if not competition_ids:
            st.info("Competitionが存在しません。")
        else:
            selected_id = st.selectbox(
                "Competitionを選択",
                competition_ids,
                index=competition_ids.index(st.session_state.selected_competition_id) if st.session_state.selected_competition_id in competition_ids else 0
            )
            
            if selected_id:
                rules = manager.get_rules(selected_id)
                
                st.subheader(f"'{selected_id}' のルール")
                
                # ルール表示
                if rules:
                    st.json(rules)
                else:
                    st.info("ルールが設定されていません。")
                
                # ルール編集
                st.subheader("ルールを編集")
                rules_str = st.text_area(
                    "ルール（JSON形式）",
                    value=json.dumps(rules, indent=2, ensure_ascii=False),
                    height=300
                )
                
                if st.button("ルールを更新"):
                    try:
                        new_rules = json.loads(rules_str)
                        manager.update_rules(selected_id, new_rules)
                        st.success("ルールを更新しました！")
                        st.rerun()
                    except json.JSONDecodeError:
                        st.error("JSON形式が不正です。")
                    except Exception as e:
                        st.error(f"エラー: {str(e)}")
                
                # ルール例
                with st.expander("ルール例"):
                    example_rules = {
                        "max_submissions_per_day": 5,
                        "allowed_features": ["momentum_1d", "momentum_5d"],
                        "evaluation_metric": "rmse",
                        "min_score_threshold": 0.5,
                        "team_size_limit": 3
                    }
                    st.json(example_rules)
    
    except Exception as e:
        st.error(f"エラーが発生しました: {str(e)}")


# ========== ディスカッションページ ==========
elif page == "ディスカッション":
    st.title("💬 ディスカッション管理")
    
    try:
        competitions = manager.list_competitions()
        competition_ids = [c.competition_id for c in competitions]
        
        if not competition_ids:
            st.info("Competitionが存在しません。")
        else:
            selected_id = st.selectbox(
                "Competitionを選択",
                competition_ids,
                index=competition_ids.index(st.session_state.selected_competition_id) if st.session_state.selected_competition_id in competition_ids else 0
            )
            
            if selected_id:
                discussion = manager.get_discussion(selected_id)
                
                st.subheader(f"'{selected_id}' のディスカッション")
                
                # ディスカッション表示
                if discussion:
                    for post in discussion:
                        with st.container():
                            st.markdown(f"### {post.author_name} ({post.post_id})")
                            st.write(post.content)
                            st.caption(f"投稿日時: {format_datetime(post.created_at)}")
                            
                            # 返信表示
                            if post.replies:
                                with st.container():
                                    st.markdown("**返信:**")
                                    for reply in post.replies:
                                        st.markdown(f"- **{reply.author_name}**: {reply.content}")
                                        st.caption(f"  ({format_datetime(reply.created_at)})")
                            
                            st.divider()
                else:
                    st.info("ディスカッション投稿がありません。")
                
                # 新規投稿
                st.subheader("新規投稿")
                with st.form("add_discussion_post"):
                    col1, col2 = st.columns(2)
                    with col1:
                        post_id = st.text_input("投稿ID *", placeholder="post_001")
                        author_id = st.text_input("作成者ID *", placeholder="user_123")
                    with col2:
                        author_name = st.text_input("作成者名 *", placeholder="Alice")
                    
                    content = st.text_area("内容 *", height=150)
                    metadata_input = st.text_area("メタデータ（JSON形式、オプション）", value="{}")
                    
                    if st.form_submit_button("投稿"):
                        if not post_id or not author_id or not author_name or not content:
                            st.error("必須項目を入力してください。")
                        else:
                            try:
                                metadata = json.loads(metadata_input) if metadata_input else {}
                                manager.add_discussion_post(
                                    selected_id,
                                    post_id=post_id,
                                    author_id=author_id,
                                    author_name=author_name,
                                    content=content,
                                    metadata=metadata
                                )
                                st.success("投稿しました！")
                                st.rerun()
                            except json.JSONDecodeError:
                                st.error("メタデータのJSON形式が不正です。")
                            except Exception as e:
                                st.error(f"エラー: {str(e)}")
                
                # 投稿編集・削除（簡易版）
                if discussion:
                    st.subheader("投稿管理")
                    post_ids = [post.post_id for post in discussion]
                    selected_post_id = st.selectbox("編集・削除する投稿を選択", post_ids)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        with st.form("edit_post"):
                            new_content = st.text_area("新しい内容", key="edit_content")
                            if st.form_submit_button("投稿を編集"):
                                try:
                                    manager.update_discussion_post(selected_id, selected_post_id, new_content)
                                    st.success("投稿を編集しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
                    
                    with col2:
                        with st.form("delete_post"):
                            if st.form_submit_button("投稿を削除", type="secondary"):
                                try:
                                    manager.delete_discussion_post(selected_id, selected_post_id)
                                    st.success("投稿を削除しました！")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"エラー: {str(e)}")
    
    except Exception as e:
        st.error(f"エラーが発生しました: {str(e)}")


# フッター
st.sidebar.markdown("---")
st.sidebar.caption("Competition管理システム v1.0")

