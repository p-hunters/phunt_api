# -*- coding: utf-8 -*-
"""
Competition manager for handling competition operations.
"""

from typing import List, Dict, Optional, Any
from datetime import datetime

from .models import Competition, CompetitionStatus, LeaderboardEntry, DiscussionPost
from .repository import CompetitionRepository, FileCompetitionRepository
from ..exceptions import CompetitionError


class CompetitionManager:
    """Manages competition operations including CRUD and related resources."""
    
    def __init__(self, repository: Optional[CompetitionRepository] = None, storage_path: Optional[str] = None):
        """Initialize the competition manager.
        
        Args:
            repository: CompetitionRepository instance.
            storage_path: Path to directory for storing competition data (used if repository is None).
        """
        if repository:
            self.repository = repository
        elif storage_path:
            self.repository = FileCompetitionRepository(storage_path)
        else:
            # Default to in-memory or error?
            # For backward compatibility with the prototype which allowed None, 
            # we might need a dummy repo or raise error.
            # Let's assume storage_path is required if repo is not provided.
            raise CompetitionError("Either repository or storage_path must be provided")

    def create_competition(
        self,
        competition_id: str,
        name: str,
        description: str,
        problem_description: str,
        problem_type: str = "classification",
        created_by: str = "",
        **kwargs
    ) -> Competition:
        """Create a new competition."""
        if self.repository.get(competition_id):
            raise CompetitionError(f"Competition '{competition_id}' already exists")
        
        competition = Competition(
            competition_id=competition_id,
            name=name,
            description=description,
            problem_description=problem_description,
            problem_type=problem_type,
            created_by=created_by,
            status=CompetitionStatus.DRAFT,
            datasets=kwargs.get('datasets', []),
            models=kwargs.get('models', []),
            features=kwargs.get('features', []),
            targets=kwargs.get('targets', []),
            rules=kwargs.get('rules', {}),
            tags=kwargs.get('tags', []),
            metadata=kwargs.get('metadata', {}),
            start_date=kwargs.get('start_date'),
            end_date=kwargs.get('end_date')
        )
        
        self.repository.save(competition)
        return competition
    
    def get_competition(self, competition_id: str) -> Competition:
        """Get a competition by ID."""
        competition = self.repository.get(competition_id)
        if not competition:
            raise CompetitionError(f"Competition '{competition_id}' not found")
        return competition
    
    def list_competitions(
        self,
        status: Optional[CompetitionStatus] = None,
        tags: Optional[List[str]] = None
    ) -> List[Competition]:
        """List all competitions, optionally filtered."""
        competitions = self.repository.list_all()
        
        if status:
            competitions = [c for c in competitions if c.status == status]
        
        if tags:
            competitions = [
                c for c in competitions
                if all(tag in c.tags for tag in tags)
            ]
        
        return competitions
    
    def update_competition(
        self,
        competition_id: str,
        **kwargs
    ) -> Competition:
        """Update competition attributes."""
        competition = self.get_competition(competition_id)
        
        # Update allowed fields
        allowed_fields = {
            'name', 'description', 'problem_description', 'problem_type',
            'status', 'start_date', 'end_date', 'tags', 'metadata', 'rules'
        }
        
        updated = False
        for key, value in kwargs.items():
            if key in allowed_fields:
                if key == 'status' and isinstance(value, str):
                    value = CompetitionStatus(value)
                
                # Pydantic models are mutable by default
                setattr(competition, key, value)
                updated = True
            else:
                raise CompetitionError(f"Cannot update field '{key}'")
        
        if updated:
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def delete_competition(self, competition_id: str) -> None:
        """Delete a competition."""
        if not self.repository.get(competition_id):
            raise CompetitionError(f"Competition '{competition_id}' not found")
        self.repository.delete(competition_id)
    
    # ========== Resource Management Methods ==========
    
    def add_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Add a dataset to a competition."""
        competition = self.get_competition(competition_id)
        
        if dataset_name not in competition.datasets:
            competition.datasets.append(dataset_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def remove_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Remove a dataset from a competition."""
        competition = self.get_competition(competition_id)
        
        if dataset_name in competition.datasets:
            competition.datasets.remove(dataset_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def add_model(self, competition_id: str, model_name: str) -> Competition:
        """Add a model to a competition."""
        competition = self.get_competition(competition_id)
        
        if model_name not in competition.models:
            competition.models.append(model_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def remove_model(self, competition_id: str, model_name: str) -> Competition:
        """Remove a model from a competition."""
        competition = self.get_competition(competition_id)
        
        if model_name in competition.models:
            competition.models.remove(model_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def add_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Add a feature to a competition."""
        competition = self.get_competition(competition_id)
        
        if feature_name not in competition.features:
            competition.features.append(feature_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def remove_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Remove a feature from a competition."""
        competition = self.get_competition(competition_id)
        
        if feature_name in competition.features:
            competition.features.remove(feature_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition

    def add_target(self, competition_id: str, target_name: str) -> Competition:
        """Add a target to a competition."""
        competition = self.get_competition(competition_id)
        
        if target_name not in competition.targets:
            competition.targets.append(target_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    def remove_target(self, competition_id: str, target_name: str) -> Competition:
        """Remove a target from a competition."""
        competition = self.get_competition(competition_id)
        
        if target_name in competition.targets:
            competition.targets.remove(target_name)
            competition.updated_at = datetime.now()
            self.repository.save(competition)
        
        return competition
    
    # ========== Leaderboard Methods ==========
    
    def add_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str,
        participant_name: str,
        score: float,
        model_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add an entry to the competition leaderboard."""
        competition = self.get_competition(competition_id)
        
        entry = LeaderboardEntry(
            rank=0,  # Will be recalculated
            participant_id=participant_id,
            participant_name=participant_name,
            score=score,
            model_name=model_name,
            submitted_at=datetime.now(),
            metadata=metadata or {}
        )
        
        competition.leaderboard.append(entry)
        self._update_leaderboard_ranks(competition)
        competition.updated_at = datetime.now()
        self.repository.save(competition)
        
        return competition
    
    def _update_leaderboard_ranks(self, competition: Competition) -> None:
        """Update ranks in leaderboard based on scores (descending order)."""
        competition.leaderboard.sort(key=lambda x: x.score, reverse=True)
        for rank, entry in enumerate(competition.leaderboard, start=1):
            entry.rank = rank
    
    def get_leaderboard(self, competition_id: str, top_n: Optional[int] = None) -> List[LeaderboardEntry]:
        """Get leaderboard for a competition."""
        competition = self.get_competition(competition_id)
        leaderboard = competition.leaderboard
        
        if top_n:
            leaderboard = leaderboard[:top_n]
        
        return leaderboard
    
    def remove_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str
    ) -> Competition:
        """Remove an entry from the leaderboard."""
        competition = self.get_competition(competition_id)
        
        competition.leaderboard = [
            entry for entry in competition.leaderboard
            if entry.participant_id != participant_id
        ]
        
        self._update_leaderboard_ranks(competition)
        competition.updated_at = datetime.now()
        self.repository.save(competition)
        
        return competition
    
    # ========== Rules Methods ==========
    
    def update_rules(
        self,
        competition_id: str,
        rules: Dict[str, Any]
    ) -> Competition:
        """Update competition rules."""
        competition = self.get_competition(competition_id)
        competition.rules = rules
        competition.updated_at = datetime.now()
        self.repository.save(competition)
        
        return competition
    
    def get_rules(self, competition_id: str) -> Dict[str, Any]:
        """Get competition rules."""
        competition = self.get_competition(competition_id)
        return competition.rules.copy()
    
    # ========== Discussion Methods ==========
    
    def add_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        author_id: str,
        author_name: str,
        content: str,
        parent_post_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add a discussion post to the competition."""
        competition = self.get_competition(competition_id)
        
        post = DiscussionPost(
            post_id=post_id,
            author_id=author_id,
            author_name=author_name,
            content=content,
            created_at=datetime.now(),
            metadata=metadata or {}
        )
        
        if parent_post_id:
            # Find parent post and add as reply
            parent_post = self._find_post(competition.discussion, parent_post_id)
            if parent_post:
                parent_post.replies.append(post)
            else:
                raise CompetitionError(f"Parent post '{parent_post_id}' not found")
        else:
            # Add as top-level post
            competition.discussion.append(post)
        
        competition.updated_at = datetime.now()
        self.repository.save(competition)
        
        return competition
    
    def _find_post(self, posts: List[DiscussionPost], post_id: str) -> Optional[DiscussionPost]:
        """Find a post by ID, recursively searching replies."""
        for post in posts:
            if post.post_id == post_id:
                return post
            found = self._find_post(post.replies, post_id)
            if found:
                return found
        return None
    
    def get_discussion(self, competition_id: str) -> List[DiscussionPost]:
        """Get all discussion posts for a competition."""
        competition = self.get_competition(competition_id)
        return competition.discussion
    
    def update_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        content: str
    ) -> Competition:
        """Update a discussion post."""
        competition = self.get_competition(competition_id)
        
        post = self._find_post(competition.discussion, post_id)
        if not post:
            raise CompetitionError(f"Post '{post_id}' not found")
        
        post.content = content
        post.updated_at = datetime.now()
        competition.updated_at = datetime.now()
        self.repository.save(competition)
        
        return competition
    
    def delete_discussion_post(
        self,
        competition_id: str,
        post_id: str
    ) -> Competition:
        """Delete a discussion post."""
        competition = self.get_competition(competition_id)
        
        # Try to remove from top-level posts
        for i, post in enumerate(competition.discussion):
            if post.post_id == post_id:
                del competition.discussion[i]
                competition.updated_at = datetime.now()
                self.repository.save(competition)
                return competition
        
        # Try to remove from replies
        # Note: This simple recursion might be expensive for deep trees, but fine for now
        if self._delete_reply(competition.discussion, post_id):
            competition.updated_at = datetime.now()
            self.repository.save(competition)
            return competition
        
        raise CompetitionError(f"Post '{post_id}' not found")

    def _delete_reply(self, posts: List[DiscussionPost], post_id: str) -> bool:
        """Recursively delete a reply."""
        for post in posts:
            for i, reply in enumerate(post.replies):
                if reply.post_id == post_id:
                    del post.replies[i]
                    return True
                if self._delete_reply(post.replies, post_id):
                    return True
        return False
