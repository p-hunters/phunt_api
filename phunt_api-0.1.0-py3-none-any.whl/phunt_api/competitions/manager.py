# -*- coding: utf-8 -*-
"""
Competition manager for handling competition operations.
"""

import os
import json
from typing import List, Dict, Optional, Any
from datetime import datetime
from pathlib import Path

from .models import Competition, CompetitionStatus, LeaderboardEntry, DiscussionPost
from ..exceptions import CompetitionError


class CompetitionManager:
    """Manages competition operations including CRUD and related resources."""
    
    def __init__(self, storage_path: Optional[str] = None):
        """Initialize the competition manager.
        
        Args:
            storage_path: Path to directory for storing competition data.
                         If None, uses in-memory storage.
        """
        self.storage_path = storage_path
        self._competitions: Dict[str, Competition] = {}
        
        if storage_path:
            os.makedirs(storage_path, exist_ok=True)
            self._load_competitions()
    
    def _get_competition_path(self, competition_id: str) -> str:
        """Get file path for a competition."""
        if not self.storage_path:
            raise CompetitionError("Storage path not configured")
        return os.path.join(self.storage_path, f"{competition_id}.json")
    
    def _load_competitions(self) -> None:
        """Load all competitions from storage."""
        if not self.storage_path:
            return
        
        try:
            for file_path in Path(self.storage_path).glob("*.json"):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        competition = Competition.from_dict(data)
                        self._competitions[competition.competition_id] = competition
                except Exception as e:
                    print(f"Warning: Failed to load competition from {file_path}: {str(e)}")
        except Exception as e:
            print(f"Warning: Failed to load competitions: {str(e)}")
    
    def _save_competition(self, competition: Competition) -> None:
        """Save competition to storage."""
        if not self.storage_path:
            return
        
        try:
            file_path = self._get_competition_path(competition.competition_id)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(competition.to_dict(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            raise CompetitionError(f"Failed to save competition: {str(e)}")
    
    def _delete_competition_file(self, competition_id: str) -> None:
        """Delete competition file from storage."""
        if not self.storage_path:
            return
        
        try:
            file_path = self._get_competition_path(competition_id)
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception as e:
            raise CompetitionError(f"Failed to delete competition file: {str(e)}")
    
    def create_competition(
        self,
        competition_id: str,
        name: str,
        description: str,
        problem_description: str,
        problem_type: str = "classification",
        created_by: str = "",
        **kwargs
    ) -> Competition:
        """Create a new competition.
        
        Args:
            competition_id: Unique identifier for the competition
            name: Competition name
            description: Competition description
            problem_description: Detailed problem description
            problem_type: Type of problem (classification/regression/time_series)
            created_by: ID of the user creating the competition
            **kwargs: Additional competition attributes
            
        Returns:
            Created Competition object
            
        Raises:
            CompetitionError: If competition cannot be created
        """
        if competition_id in self._competitions:
            raise CompetitionError(f"Competition '{competition_id}' already exists")
        
        competition = Competition(
            competition_id=competition_id,
            name=name,
            description=description,
            problem_description=problem_description,
            problem_type=problem_type,
            created_by=created_by,
            status=CompetitionStatus.DRAFT,
            datasets=kwargs.get('datasets', []),
            models=kwargs.get('models', []),
            features=kwargs.get('features', []),
            targets=kwargs.get('targets', []),
            rules=kwargs.get('rules', {}),
            tags=kwargs.get('tags', []),
            metadata=kwargs.get('metadata', {}),
            start_date=kwargs.get('start_date'),
            end_date=kwargs.get('end_date')
        )
        
        self._competitions[competition_id] = competition
        self._save_competition(competition)
        
        return competition
    
    def get_competition(self, competition_id: str) -> Competition:
        """Get a competition by ID.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            Competition object
            
        Raises:
            CompetitionError: If competition is not found
        """
        if competition_id not in self._competitions:
            raise CompetitionError(f"Competition '{competition_id}' not found")
        
        return self._competitions[competition_id]
    
    def list_competitions(
        self,
        status: Optional[CompetitionStatus] = None,
        tags: Optional[List[str]] = None
    ) -> List[Competition]:
        """List all competitions, optionally filtered.
        
        Args:
            status: Filter by competition status
            tags: Filter by tags (competition must have all specified tags)
            
        Returns:
            List of Competition objects
        """
        competitions = list(self._competitions.values())
        
        if status:
            competitions = [c for c in competitions if c.status == status]
        
        if tags:
            competitions = [
                c for c in competitions
                if all(tag in c.tags for tag in tags)
            ]
        
        return competitions
    
    def update_competition(
        self,
        competition_id: str,
        **kwargs
    ) -> Competition:
        """Update competition attributes.
        
        Args:
            competition_id: Competition identifier
            **kwargs: Attributes to update (name, description, status, etc.)
            
        Returns:
            Updated Competition object
            
        Raises:
            CompetitionError: If competition is not found or cannot be updated
        """
        competition = self.get_competition(competition_id)
        
        # Update allowed fields
        allowed_fields = {
            'name', 'description', 'problem_description', 'problem_type',
            'status', 'start_date', 'end_date', 'tags', 'metadata', 'rules'
        }
        
        for key, value in kwargs.items():
            if key in allowed_fields:
                if key == 'status' and isinstance(value, str):
                    value = CompetitionStatus(value)
                setattr(competition, key, value)
            else:
                raise CompetitionError(f"Cannot update field '{key}'")
        
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    def delete_competition(self, competition_id: str) -> None:
        """Delete a competition.
        
        Args:
            competition_id: Competition identifier
            
        Raises:
            CompetitionError: If competition is not found or cannot be deleted
        """
        if competition_id not in self._competitions:
            raise CompetitionError(f"Competition '{competition_id}' not found")
        
        del self._competitions[competition_id]
        self._delete_competition_file(competition_id)
    
    # ========== Resource Management Methods ==========
    
    def add_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Add a dataset to a competition.
        
        Args:
            competition_id: Competition identifier
            dataset_name: Name of the dataset to add
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if dataset_name not in competition.datasets:
            competition.datasets.append(dataset_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def remove_dataset(self, competition_id: str, dataset_name: str) -> Competition:
        """Remove a dataset from a competition.
        
        Args:
            competition_id: Competition identifier
            dataset_name: Name of the dataset to remove
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if dataset_name in competition.datasets:
            competition.datasets.remove(dataset_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def add_model(self, competition_id: str, model_name: str) -> Competition:
        """Add a model to a competition.
        
        Args:
            competition_id: Competition identifier
            model_name: Name of the model to add
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if model_name not in competition.models:
            competition.models.append(model_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def remove_model(self, competition_id: str, model_name: str) -> Competition:
        """Remove a model from a competition.
        
        Args:
            competition_id: Competition identifier
            model_name: Name of the model to remove
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if model_name in competition.models:
            competition.models.remove(model_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def add_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Add a feature to a competition.
        
        Args:
            competition_id: Competition identifier
            feature_name: Name of the feature to add
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if feature_name not in competition.features:
            competition.features.append(feature_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def remove_feature(self, competition_id: str, feature_name: str) -> Competition:
        """Remove a feature from a competition.
        
        Args:
            competition_id: Competition identifier
            feature_name: Name of the feature to remove
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if feature_name in competition.features:
            competition.features.remove(feature_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def add_target(self, competition_id: str, target_name: str) -> Competition:
        """Add a target to a competition.
        
        Args:
            competition_id: Competition identifier
            target_name: Name of the target to add
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if target_name not in competition.targets:
            competition.targets.append(target_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    def remove_target(self, competition_id: str, target_name: str) -> Competition:
        """Remove a target from a competition.
        
        Args:
            competition_id: Competition identifier
            target_name: Name of the target to remove
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        if target_name in competition.targets:
            competition.targets.remove(target_name)
            competition.updated_at = datetime.now()
            self._save_competition(competition)
        
        return competition
    
    # ========== Leaderboard Methods ==========
    
    def add_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str,
        participant_name: str,
        score: float,
        model_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add an entry to the competition leaderboard.
        
        Args:
            competition_id: Competition identifier
            participant_id: ID of the participant
            participant_name: Name of the participant
            score: Score achieved
            model_name: Name of the model used
            metadata: Additional metadata
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        entry = LeaderboardEntry(
            rank=0,  # Will be recalculated
            participant_id=participant_id,
            participant_name=participant_name,
            score=score,
            model_name=model_name,
            submitted_at=datetime.now(),
            metadata=metadata or {}
        )
        
        competition.leaderboard.append(entry)
        self._update_leaderboard_ranks(competition)
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    def _update_leaderboard_ranks(self, competition: Competition) -> None:
        """Update ranks in leaderboard based on scores (descending order)."""
        competition.leaderboard.sort(key=lambda x: x.score, reverse=True)
        for rank, entry in enumerate(competition.leaderboard, start=1):
            entry.rank = rank
    
    def get_leaderboard(self, competition_id: str, top_n: Optional[int] = None) -> List[LeaderboardEntry]:
        """Get leaderboard for a competition.
        
        Args:
            competition_id: Competition identifier
            top_n: Return only top N entries (None for all)
            
        Returns:
            List of leaderboard entries
        """
        competition = self.get_competition(competition_id)
        leaderboard = competition.leaderboard.copy()
        
        if top_n:
            leaderboard = leaderboard[:top_n]
        
        return leaderboard
    
    def remove_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str
    ) -> Competition:
        """Remove an entry from the leaderboard.
        
        Args:
            competition_id: Competition identifier
            participant_id: ID of the participant whose entry to remove
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        competition.leaderboard = [
            entry for entry in competition.leaderboard
            if entry.participant_id != participant_id
        ]
        
        self._update_leaderboard_ranks(competition)
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    # ========== Rules Methods ==========
    
    def update_rules(
        self,
        competition_id: str,
        rules: Dict[str, Any]
    ) -> Competition:
        """Update competition rules.
        
        Args:
            competition_id: Competition identifier
            rules: Dictionary of rules
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        competition.rules = rules
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    def get_rules(self, competition_id: str) -> Dict[str, Any]:
        """Get competition rules.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            Dictionary of rules
        """
        competition = self.get_competition(competition_id)
        return competition.rules.copy()
    
    # ========== Discussion Methods ==========
    
    def add_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        author_id: str,
        author_name: str,
        content: str,
        parent_post_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Competition:
        """Add a discussion post to the competition.
        
        Args:
            competition_id: Competition identifier
            post_id: Unique identifier for the post
            author_id: ID of the author
            author_name: Name of the author
            content: Post content
            parent_post_id: ID of parent post (for replies)
            metadata: Additional metadata
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        post = DiscussionPost(
            post_id=post_id,
            author_id=author_id,
            author_name=author_name,
            content=content,
            created_at=datetime.now(),
            metadata=metadata or {}
        )
        
        if parent_post_id:
            # Find parent post and add as reply
            parent_post = self._find_post(competition.discussion, parent_post_id)
            if parent_post:
                parent_post.replies.append(post)
            else:
                raise CompetitionError(f"Parent post '{parent_post_id}' not found")
        else:
            # Add as top-level post
            competition.discussion.append(post)
        
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    def _find_post(self, posts: List[DiscussionPost], post_id: str) -> Optional[DiscussionPost]:
        """Find a post by ID, recursively searching replies."""
        for post in posts:
            if post.post_id == post_id:
                return post
            found = self._find_post(post.replies, post_id)
            if found:
                return found
        return None
    
    def get_discussion(self, competition_id: str) -> List[DiscussionPost]:
        """Get all discussion posts for a competition.
        
        Args:
            competition_id: Competition identifier
            
        Returns:
            List of discussion posts
        """
        competition = self.get_competition(competition_id)
        return competition.discussion.copy()
    
    def update_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        content: str
    ) -> Competition:
        """Update a discussion post.
        
        Args:
            competition_id: Competition identifier
            post_id: ID of the post to update
            content: New content
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        post = self._find_post(competition.discussion, post_id)
        if not post:
            raise CompetitionError(f"Post '{post_id}' not found")
        
        post.content = content
        post.updated_at = datetime.now()
        competition.updated_at = datetime.now()
        self._save_competition(competition)
        
        return competition
    
    def delete_discussion_post(
        self,
        competition_id: str,
        post_id: str
    ) -> Competition:
        """Delete a discussion post.
        
        Args:
            competition_id: Competition identifier
            post_id: ID of the post to delete
            
        Returns:
            Updated Competition object
        """
        competition = self.get_competition(competition_id)
        
        # Try to remove from top-level posts
        for i, post in enumerate(competition.discussion):
            if post.post_id == post_id:
                del competition.discussion[i]
                competition.updated_at = datetime.now()
                self._save_competition(competition)
                return competition
        
        # Try to remove from replies
        for post in competition.discussion:
            for j, reply in enumerate(post.replies):
                if reply.post_id == post_id:
                    del post.replies[j]
                    competition.updated_at = datetime.now()
                    self._save_competition(competition)
                    return competition
        
        raise CompetitionError(f"Post '{post_id}' not found")

