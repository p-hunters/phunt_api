# -*- coding: utf-8 -*-
"""
Competition module for PHuntAPI.

This module provides functionality for managing competitions, which include:
- Problem settings
- Datasets
- Models
- Features
- Leaderboard
- Rules
- Discussion
"""

from .models import Competition
from .manager import CompetitionManager as LegacyCompetitionManager

__all__ = [
    'Competition',
    'LegacyCompetitionManager'
]

