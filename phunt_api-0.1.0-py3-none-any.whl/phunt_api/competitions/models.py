# -*- coding: utf-8 -*-
"""
Competition data models.
"""

from typing import List, Dict, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum


class CompetitionStatus(Enum):
    """Competition status enumeration."""
    DRAFT = "draft"
    ACTIVE = "active"
    CLOSED = "closed"
    ARCHIVED = "archived"


@dataclass
class LeaderboardEntry:
    """Represents a single entry in the competition leaderboard."""
    rank: int
    participant_id: str
    participant_name: str
    score: float
    model_name: str
    submitted_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DiscussionPost:
    """Represents a discussion post in the competition."""
    post_id: str
    author_id: str
    author_name: str
    content: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    replies: List['DiscussionPost'] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Competition:
    """Represents a competition with all its components."""
    
    competition_id: str
    name: str
    description: str
    
    # Problem settings
    problem_description: str
    problem_type: str  # e.g., "classification", "regression", "time_series"
    
    # Associated resources
    datasets: List[str] = field(default_factory=list)
    models: List[str] = field(default_factory=list)
    features: List[str] = field(default_factory=list)
    targets: List[str] = field(default_factory=list)
    
    # Leaderboard
    leaderboard: List[LeaderboardEntry] = field(default_factory=list)
    
    # Rules
    rules: Dict[str, Any] = field(default_factory=dict)
    
    # Discussion
    discussion: List[DiscussionPost] = field(default_factory=list)
    
    # Metadata
    status: CompetitionStatus = CompetitionStatus.DRAFT
    created_by: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert competition to dictionary."""
        data = asdict(self)
        # Convert datetime objects to ISO format strings
        data['created_at'] = self.created_at.isoformat()
        data['updated_at'] = self.updated_at.isoformat()
        if self.start_date:
            data['start_date'] = self.start_date.isoformat()
        if self.end_date:
            data['end_date'] = self.end_date.isoformat()
        data['status'] = self.status.value
        # Convert nested objects
        data['leaderboard'] = [self._entry_to_dict(entry) for entry in self.leaderboard]
        data['discussion'] = [self._post_to_dict(post) for post in self.discussion]
        return data
    
    def _entry_to_dict(self, entry: LeaderboardEntry) -> Dict[str, Any]:
        """Convert leaderboard entry to dictionary."""
        result = asdict(entry)
        result['submitted_at'] = entry.submitted_at.isoformat()
        return result
    
    def _post_to_dict(self, post: DiscussionPost) -> Dict[str, Any]:
        """Convert discussion post to dictionary."""
        result = asdict(post)
        result['created_at'] = post.created_at.isoformat()
        if post.updated_at:
            result['updated_at'] = post.updated_at.isoformat()
        if post.replies:
            result['replies'] = [self._post_to_dict(reply) for reply in post.replies]
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Competition':
        """Create competition from dictionary."""
        # Convert status
        if isinstance(data.get('status'), str):
            data['status'] = CompetitionStatus(data['status'])
        
        # Convert datetime strings
        for date_field in ['created_at', 'updated_at', 'start_date', 'end_date']:
            if date_field in data and data[date_field] and isinstance(data[date_field], str):
                data[date_field] = datetime.fromisoformat(data[date_field])
        
        # Convert leaderboard entries
        if 'leaderboard' in data:
            data['leaderboard'] = [
                LeaderboardEntry(
                    rank=entry['rank'],
                    participant_id=entry['participant_id'],
                    participant_name=entry['participant_name'],
                    score=entry['score'],
                    model_name=entry['model_name'],
                    submitted_at=datetime.fromisoformat(entry['submitted_at']),
                    metadata=entry.get('metadata', {})
                )
                for entry in data['leaderboard']
            ]
        
        # Convert discussion posts
        if 'discussion' in data:
            data['discussion'] = [
                cls._post_from_dict(post) for post in data['discussion']
            ]
        
        return cls(**data)
    
    @staticmethod
    def _post_from_dict(post_data: Dict[str, Any]) -> DiscussionPost:
        """Create discussion post from dictionary."""
        post_data = post_data.copy()
        post_data['created_at'] = datetime.fromisoformat(post_data['created_at'])
        if post_data.get('updated_at'):
            post_data['updated_at'] = datetime.fromisoformat(post_data['updated_at'])
        if post_data.get('replies'):
            post_data['replies'] = [
                Competition._post_from_dict(reply) for reply in post_data['replies']
            ]
        return DiscussionPost(**post_data)

