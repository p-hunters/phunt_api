# -*- coding: utf-8 -*-
"""
Competition data models using Pydantic.
"""

from typing import List, Dict, Optional, Any
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, validator, ConfigDict


class CompetitionStatus(str, Enum):
    """Competition status enumeration."""
    DRAFT = "draft"
    ACTIVE = "active"
    CLOSED = "closed"
    ARCHIVED = "archived"


class LeaderboardEntry(BaseModel):
    """Represents a single entry in the competition leaderboard."""
    rank: int = 0
    participant_id: str
    participant_name: str
    score: float
    model_name: str
    submitted_at: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DiscussionPost(BaseModel):
    """Represents a discussion post in the competition."""
    post_id: str
    author_id: str
    author_name: str
    content: str
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    replies: List['DiscussionPost'] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class Competition(BaseModel):
    """Represents a competition with all its components."""
    
    competition_id: str
    name: str
    description: str
    
    # Problem settings
    problem_description: str
    problem_type: str  # e.g., "classification", "regression", "time_series"
    
    # Associated resources
    datasets: List[str] = Field(default_factory=list)
    models: List[str] = Field(default_factory=list)
    features: List[str] = Field(default_factory=list)
    targets: List[str] = Field(default_factory=list)
    
    # Leaderboard
    leaderboard: List[LeaderboardEntry] = Field(default_factory=list)
    
    # Rules
    rules: Dict[str, Any] = Field(default_factory=dict)
    
    # Discussion
    discussion: List[DiscussionPost] = Field(default_factory=list)
    
    # Metadata
    status: CompetitionStatus = CompetitionStatus.DRAFT
    created_by: str = ""
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert competition to dictionary (alias for model_dump/dict)."""
        # Using json mode to handle datetime serialization automatically if needed,
        # but for compatibility with existing code that expects dicts with ISO strings,
        # we might need custom logic or just rely on Pydantic's dict() and handle dates downstream.
        # However, the previous implementation converted dates to strings manually.
        # Let's provide a compatible output.
        data = self.model_dump()
        
        # Manually convert datetimes to strings to match previous behavior if strictly needed,
        # or rely on the caller to handle datetime objects.
        # The previous `to_dict` returned ISO strings for dates.
        # Let's replicate that for backward compatibility.
        
        def _serialize_dates(obj):
            if isinstance(obj, dict):
                return {k: _serialize_dates(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_serialize_dates(v) for v in obj]
            elif isinstance(obj, datetime):
                return obj.isoformat()
            elif isinstance(obj, Enum):
                return obj.value
            return obj

        return _serialize_dates(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Competition':
        """Create competition from dictionary."""
        # Pydantic handles type conversion automatically for the most part
        return cls(**data)
