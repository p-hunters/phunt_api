import numpy as np
import pandas as pd
from typing import Union, List, Dict

def validate_price_series(prices: pd.Series) -> None:
    """
    Validate price series data quality.
    
    Args:
        prices (pd.Series): Price series to validate
    
    Raises:
        ValueError: If price series fails validation
    """
    if not isinstance(prices, pd.Series):
        raise ValueError("Prices must be a pandas Series")
    
    if not pd.api.types.is_numeric_dtype(prices):
        raise ValueError("Price series must contain numeric values")
    
    if prices.isnull().any():
        raise ValueError("Price series contains missing values")
    
    if (prices <= 0).any():
        raise ValueError("Price series contains zero or negative values")
    
    if not isinstance(prices.index, pd.DatetimeIndex):
        raise ValueError("Price series must have a datetime index")
    
    if prices.index.duplicated().any():
        raise ValueError("Price series contains duplicate timestamps")
    
    if not prices.index.is_monotonic_increasing:
        raise ValueError("Price series timestamps must be strictly increasing")

def validate_horizons(horizons: Union[int, List[int]]) -> None:
    """
    Validate prediction horizons.
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    
    if not all(isinstance(h, int) for h in horizons):
        raise ValueError("All horizons must be integers")
    
    if not all(h > 0 for h in horizons):
        raise ValueError("All horizons must be positive")
    
    if len(set(horizons)) != len(horizons):
        raise ValueError("Duplicate horizons are not allowed")

def validate_windows(windows: Union[int, List[int]], min_window: int = 2) -> None:
    """
    Validate window sizes.
    """
    if isinstance(windows, int):
        windows = [windows]
    
    if not all(isinstance(w, int) for w in windows):
        raise ValueError("All windows must be integers")
    
    if not all(w >= min_window for w in windows):
        raise ValueError(f"All windows must be at least {min_window}")
    
    if len(set(windows)) != len(windows):
        raise ValueError("Duplicate windows are not allowed")

def validate_high_low_data(
    high_prices: pd.Series,
    low_prices: pd.Series,
    prices: pd.Series
) -> None:
    """
    Validate high-low price data.
    """
    if not all(isinstance(x, pd.Series) for x in [high_prices, low_prices]):
        raise ValueError("High and low prices must be pandas Series")
    
    if not all(x.index.equals(prices.index) for x in [high_prices, low_prices]):
        raise ValueError("High and low prices must have same index as close prices")
    
    if (high_prices < low_prices).any():
        raise ValueError("High prices must be greater than or equal to low prices")
    
    if (high_prices < prices).any() or (low_prices > prices).any():
        raise ValueError("Close prices must be between high and low prices")
    
    if high_prices.isnull().any() or low_prices.isnull().any():
        raise ValueError("High-low data contains missing values")
    
    if (high_prices <= 0).any() or (low_prices <= 0).any():
        raise ValueError("High-low data contains zero or negative values")

def validate_benchmarks(benchmarks: Dict[str, pd.Series], prices: pd.Series) -> None:
    """
    Validate benchmark price series.
    """
    if not isinstance(benchmarks, dict):
        raise ValueError("Benchmarks must be a dictionary")
    
    if not benchmarks:
        raise ValueError("Benchmarks dictionary is empty")
    
    for name, benchmark in benchmarks.items():
        if not isinstance(name, str):
            raise ValueError("Benchmark names must be strings")
        
        if not isinstance(benchmark, pd.Series):
            raise ValueError(f"Benchmark {name} must be a pandas Series")
        
        if not benchmark.index.equals(prices.index):
            raise ValueError(f"Benchmark {name} must have same index as main price series")
        
        if benchmark.isnull().any():
            raise ValueError(f"Benchmark {name} contains missing values")
        
        if (benchmark <= 0).any():
            raise ValueError(f"Benchmark {name} contains zero or negative values") 