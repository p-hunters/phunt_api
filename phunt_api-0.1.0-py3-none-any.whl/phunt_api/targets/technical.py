import numpy as np
import pandas as pd
from typing import Union, List, Dict, Tuple
from .validators import validate_price_series, validate_horizons, validate_windows
from .utils import calculate_daily_returns, calculate_future_return, calculate_rolling_volatility

def calculate_momentum_targets(
    prices: pd.Series,
    momentum_windows: Union[int, List[int]] = [5, 10, 20],
    prediction_horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    min_vol_threshold: float = 1e-8
) -> pd.DataFrame:
    """
    Calculate momentum-based targets for prediction.
    
    Args:
        prices (pd.Series): Price series
        momentum_windows (Union[int, List[int]]): Windows for momentum calculation
        prediction_horizons (Union[int, List[int]]): Future horizon(s) to calculate targets for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize momentum by window volatility
        min_vol_threshold (float): Minimum volatility threshold to prevent division by zero
    
    Returns:
        pd.DataFrame: DataFrame containing:
            - momentum_accel_w{window}_h{horizon}: Momentum acceleration
            All values are normalized by volatility if normalize=True
    
    Note:
        - All rolling calculations use only past data to prevent lookahead bias
        - When normalize=True, values are divided by rolling volatility with safeguards
          against zero division
    """
    validate_price_series(prices)
    validate_windows(momentum_windows)
    validate_horizons(prediction_horizons)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if isinstance(momentum_windows, int):
        momentum_windows = [momentum_windows]
    if isinstance(prediction_horizons, int):
        prediction_horizons = [prediction_horizons]
    
    momentum_targets = pd.DataFrame(index=prices.index)
    
    for window in momentum_windows:
        # Past momentum using consistent calculation
        past_momentum = calculate_daily_returns(prices.shift(1), method=method, periods=window)
        
        if normalize:
            # Safe volatility calculation with minimum threshold
            vol = past_momentum.rolling(window=window, min_periods=1).std()
            vol = np.where(vol < min_vol_threshold, np.nan, vol)
            past_momentum = past_momentum / vol
        
        for horizon in prediction_horizons:
            # Future return using the same calculation method
            future_ret = calculate_future_return(prices, horizon, method)
            
            if normalize:
                # Safe future volatility calculation
                future_vol = future_ret.rolling(window=horizon, min_periods=1).std()
                future_vol = np.where(future_vol < min_vol_threshold, np.nan, future_vol)
                future_ret = future_ret / future_vol
            
            # Momentum acceleration (difference between future and past momentum)
            momentum_accel = future_ret - past_momentum
            momentum_targets[f'momentum_accel_w{window}_h{horizon}'] = momentum_accel
            
            # Store raw components if needed for analysis
            momentum_targets[f'past_momentum_w{window}_h{horizon}'] = past_momentum
            momentum_targets[f'future_return_w{window}_h{horizon}'] = future_ret
    
    return momentum_targets

def calculate_range_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_vol_threshold: float = 1e-8
) -> pd.DataFrame:
    """
    Calculate range-based prediction targets (future high-low range).
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate ranges for
        normalize (bool): Whether to normalize ranges by historical volatility
        vol_window (int): Window size for volatility calculation if normalizing
        min_periods (int): Minimum number of observations required for calculations
        min_vol_threshold (float): Minimum volatility threshold to prevent division by zero
    
    Returns:
        pd.DataFrame: DataFrame containing:
            - future_abs_range_{horizon}: Absolute range of future prices
            - future_up_range_{horizon}: Upside range
            - future_down_range_{horizon}: Downside range
            - future_range_zscore_{horizon}: Z-score of the range
            - future_range_crossover_{horizon}: Whether price crosses current range
        All range values are normalized by volatility if normalize=True
    
    Note:
        - All rolling calculations use only past data to prevent lookahead bias
        - Range crossover uses past high/low levels to avoid lookahead
        - When normalize=True, values are divided by rolling volatility with safeguards
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > vol_window:
        raise ValueError("min_periods cannot be greater than vol_window")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    range_targets = pd.DataFrame(index=prices.index)
    
    # Calculate daily returns for volatility using past data only
    returns = calculate_daily_returns(prices.shift(1), method='arithmetic')
    rolling_vol = calculate_rolling_volatility(returns, vol_window, min_periods)
    rolling_vol = np.where(rolling_vol < min_vol_threshold, np.nan, rolling_vol)
    
    for horizon in horizons:
        # Build future price shifts (for range calculation)
        future_prices = pd.concat(
            [prices.shift(-(i+1)) for i in range(horizon)],
            axis=1
        )
        
        # Calculate future ranges
        future_high = future_prices.max(axis=1)
        future_low = future_prices.min(axis=1)
        
        # Calculate range metrics using current price as denominator
        current_price = prices.replace(0, np.nan)  # Protect against zero prices
        abs_range = (future_high - future_low) / current_price
        up_range = (future_high - current_price) / current_price
        down_range = (future_low - current_price) / current_price
        
        if normalize:
            abs_range = abs_range / rolling_vol
            up_range = up_range / rolling_vol
            down_range = down_range / rolling_vol
        
        # Store basic range metrics
        range_targets[f'future_abs_range_{horizon}'] = abs_range
        range_targets[f'future_up_range_{horizon}'] = up_range
        range_targets[f'future_down_range_{horizon}'] = down_range
        
        # Calculate range z-score using past data only
        historical_range = abs_range.shift(horizon)  # Use past ranges
        range_mean = historical_range.rolling(window=vol_window, min_periods=min_periods).mean()
        range_std = historical_range.rolling(window=vol_window, min_periods=min_periods).std()
        range_std = np.where(range_std < min_vol_threshold, np.nan, range_std)
        
        range_z_score = (abs_range - range_mean) / range_std
        range_targets[f'future_range_zscore_{horizon}'] = range_z_score
        
        # Calculate range crossover using past levels only
        past_high = prices.rolling(window=vol_window, min_periods=min_periods).max()
        past_low = prices.rolling(window=vol_window, min_periods=min_periods).min()
        
        range_crossover = (
            (future_high > past_high) |
            (future_low < past_low)
        ).astype(int)
        
        range_targets[f'future_range_crossover_{horizon}'] = range_crossover
    
    return range_targets

def calculate_mean_reversion_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    ma_windows: Union[int, List[int]] = [10, 20, 50, 200],
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    bollinger_std: float = 2.0,
    min_vol_threshold: float = 1e-8
) -> pd.DataFrame:
    """
    Calculate mean reversion based prediction targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate targets for
        ma_windows (Union[int, List[int]]): Moving average windows for mean reversion calculation
        normalize (bool): Whether to normalize distances by volatility
        vol_window (int): Window size for volatility calculation if normalizing
        min_periods (int): Minimum number of observations required for calculations
        bollinger_std (float): Number of standard deviations for Bollinger Bands
        min_vol_threshold (float): Minimum volatility threshold to prevent division by zero
    
    Returns:
        pd.DataFrame: DataFrame containing:
            - ma_dist_{window}_{horizon}: Distance to moving average
            - upper_dist_{window}_{horizon}: Distance to upper Bollinger Band
            - lower_dist_{window}_{horizon}: Distance to lower Bollinger Band
            - ma_cross_{window}_{horizon}: Moving average crossover (binary)
            - bb_position_{window}_{horizon}: Position within Bollinger Bands (0-1)
            - extreme_high/low_{window}_{horizon}: Extreme positions (binary)
            - reversion_intensity_{window}_{horizon}: Strength of mean reversion
        Binary flags are not normalized, continuous values are normalized if normalize=True
    
    Note:
        - All rolling calculations use only past data to prevent lookahead bias
        - Moving averages and Bollinger Bands are calculated using past prices only
        - Binary signals (crosses, extremes) are not normalized regardless of normalize parameter
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows(ma_windows)
    validate_windows([vol_window])
    
    if not isinstance(bollinger_std, (int, float)):
        raise ValueError("bollinger_std must be a number")
    
    if bollinger_std <= 0:
        raise ValueError("bollinger_std must be positive")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    smallest_ma_window = min(ma_windows) if isinstance(ma_windows, list) else ma_windows
    if min_periods > smallest_ma_window:
        raise ValueError("min_periods cannot be greater than smallest window size")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(ma_windows, int):
        ma_windows = [ma_windows]
    
    reversion_targets = pd.DataFrame(index=prices.index)
    
    # Calculate returns and volatility using past data only
    returns = calculate_daily_returns(prices.shift(1), method='arithmetic')
    rolling_vol = calculate_rolling_volatility(returns, vol_window, min_periods)
    rolling_vol = np.where(rolling_vol < min_vol_threshold, np.nan, rolling_vol)
    
    for ma_window in ma_windows:
        # Calculate moving averages and bands using past data only
        shifted_prices = prices.shift(1)  # Use only past prices
        ma = shifted_prices.rolling(window=ma_window, min_periods=min_periods).mean()
        std = shifted_prices.rolling(window=ma_window, min_periods=min_periods).std()
        
        upper_band = ma + bollinger_std * std
        lower_band = ma - bollinger_std * std
        
        # Calculate distances
        current_price = prices.replace(0, np.nan)  # Protect against zero prices
        dist_to_ma = (prices - ma) / current_price
        dist_to_upper = (upper_band - prices) / current_price
        dist_to_lower = (prices - lower_band) / current_price
        
        if normalize:
            dist_to_ma = dist_to_ma / rolling_vol
            dist_to_upper = dist_to_upper / rolling_vol
            dist_to_lower = dist_to_lower / rolling_vol
        
        for horizon in horizons:
            # Calculate future returns using consistent method
            future_ret = calculate_future_return(prices, horizon, 'arithmetic')
            
            if normalize:
                future_ret = future_ret / rolling_vol
            
            # Store distance metrics
            reversion_targets[f'ma_dist_{ma_window}_h{horizon}'] = dist_to_ma
            reversion_targets[f'upper_dist_{ma_window}_h{horizon}'] = dist_to_upper
            reversion_targets[f'lower_dist_{ma_window}_h{horizon}'] = dist_to_lower
            
            # MA cross (binary signal - not normalized)
            ma_cross = ((prices > ma) & (prices.shift(-horizon) < ma)) | \
                      ((prices < ma) & (prices.shift(-horizon) > ma))
            reversion_targets[f'ma_cross_{ma_window}_h{horizon}'] = ma_cross.astype(int)
            
            # Bollinger Band position (0-1 scale)
            bb_position = (prices - lower_band) / (upper_band - lower_band)
            bb_position = bb_position.clip(0, 1)  # Ensure values are between 0 and 1
            reversion_targets[f'bb_position_{ma_window}_h{horizon}'] = bb_position
            
            # Extreme signals (binary - not normalized)
            extreme_high = prices > upper_band
            extreme_low = prices < lower_band
            reversion_targets[f'extreme_high_{ma_window}_h{horizon}'] = extreme_high.astype(int)
            reversion_targets[f'extreme_low_{ma_window}_h{horizon}'] = extreme_low.astype(int)
            
            # Mean reversion intensity
            reversion_intensity = -np.sign(dist_to_ma) * future_ret
            reversion_targets[f'reversion_intensity_{ma_window}_h{horizon}'] = reversion_intensity
            
            # Store raw components for analysis
            reversion_targets[f'ma_{ma_window}_h{horizon}'] = ma
            reversion_targets[f'upper_band_{ma_window}_h{horizon}'] = upper_band
            reversion_targets[f'lower_band_{ma_window}_h{horizon}'] = lower_band
    
    return reversion_targets

def calculate_price_patterns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    pattern_windows: Union[int, List[int]] = [20, 50],
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_pattern_size: int = 10,
    min_vol_threshold: float = 1e-8,
    pattern_thresholds: Dict[str, float] = {
        'head_shoulders': 0.02,  # Minimum head-shoulder height difference
        'double': 0.015,         # Minimum double top/bottom height
        'triangle': 0.01         # Minimum triangle height
    }
) -> pd.DataFrame:
    """
    Calculate price pattern based prediction targets with improved pattern detection.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate patterns for
        pattern_windows (Union[int, List[int]]): Windows for pattern detection
        normalize (bool): Whether to normalize continuous values by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        min_pattern_size (int): Minimum size for pattern detection
        min_vol_threshold (float): Minimum volatility threshold to prevent division by zero
        pattern_thresholds (Dict[str, float]): Thresholds for pattern detection
    
    Returns:
        pd.DataFrame: DataFrame containing:
            Binary pattern signals (not normalized):
            - head_shoulders_{window}_{horizon}: Head and shoulders pattern
            - inv_head_shoulders_{window}_{horizon}: Inverse head and shoulders
            - double_top/bottom_{window}_{horizon}: Double top/bottom patterns
            - asc/desc/sym_triangle_{window}_{horizon}: Triangle patterns
            
            Continuous measures (normalized if normalize=True):
            - pattern_similarity_{type}_{window}_{horizon}: Pattern similarity scores
            - pattern_strength_{type}_{window}_{horizon}: Pattern strength measures
            
    Note:
        - All pattern detection uses only past data to prevent lookahead bias
        - Binary pattern signals are not normalized regardless of normalize parameter
        - Continuous measures (similarities, strengths) are normalized if normalize=True
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows(pattern_windows)
    validate_windows([vol_window])
    
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(pattern_windows, int):
        pattern_windows = [pattern_windows]
    
    pattern_targets = pd.DataFrame(index=prices.index)
    
    # Calculate returns and volatility using past data only
    returns = calculate_daily_returns(prices.shift(1), method='arithmetic')
    rolling_vol = calculate_rolling_volatility(returns, vol_window, min_periods)
    rolling_vol = np.where(rolling_vol < min_vol_threshold, np.nan, rolling_vol)
    
    def detect_head_and_shoulders(window_prices: pd.Series) -> Tuple[bool, bool, float, float]:
        """Detect head and shoulders pattern with improved criteria."""
        if len(window_prices) < min_pattern_size:
            return False, False, 0.0, 0.0
        
        # Find local extrema
        size = len(window_prices)
        third = size // 3
        
        left = window_prices.iloc[:third]
        middle = window_prices.iloc[third:2*third]
        right = window_prices.iloc[2*third:]
        
        left_max = left.max()
        head = middle.max()
        right_max = right.max()
        
        left_min = window_prices.iloc[third:2*third].min()
        right_min = window_prices.iloc[2*third:].min()
        
        # Check regular H&S
        is_hs = (
            (head > left_max) and (head > right_max) and
            (abs(left_max - right_max) / left_max < pattern_thresholds['head_shoulders']) and
            (left_min < left_max) and (right_min < right_max)
        )
        
        # Check inverse H&S
        left_min_inv = left.min()
        head_inv = middle.min()
        right_min_inv = right.min()
        
        is_ihs = (
            (head_inv < left_min_inv) and (head_inv < right_min_inv) and
            (abs(left_min_inv - right_min_inv) / left_min_inv < pattern_thresholds['head_shoulders']) and
            (window_prices.iloc[third:2*third].max() > left_min_inv) and
            (window_prices.iloc[2*third:].max() > right_min_inv)
        )
        
        # Calculate pattern strength
        hs_strength = (head - (left_max + right_max) / 2) / window_prices.mean() if is_hs else 0
        ihs_strength = ((left_min_inv + right_min_inv) / 2 - head_inv) / window_prices.mean() if is_ihs else 0
        
        return is_hs, is_ihs, hs_strength, ihs_strength
    
    def detect_double_pattern(window_prices: pd.Series) -> Tuple[bool, bool, float, float]:
        """Detect double top and bottom patterns with improved criteria."""
        if len(window_prices) < min_pattern_size:
            return False, False, 0.0, 0.0
        
        # Split window into two parts
        half = len(window_prices) // 2
        first_half = window_prices.iloc[:half]
        second_half = window_prices.iloc[half:]
        
        # Find peaks and troughs
        first_max = first_half.max()
        second_max = second_half.max()
        middle_min = window_prices.iloc[half//2:3*half//2].min()
        
        first_min = first_half.min()
        second_min = second_half.min()
        middle_max = window_prices.iloc[half//2:3*half//2].max()
        
        # Check double top
        is_double_top = (
            (abs(first_max - second_max) / first_max < pattern_thresholds['double']) and
            (middle_min < min(first_max, second_max) * (1 - pattern_thresholds['double']))
        )
        
        # Check double bottom
        is_double_bottom = (
            (abs(first_min - second_min) / first_min < pattern_thresholds['double']) and
            (middle_max > max(first_min, second_min) * (1 + pattern_thresholds['double']))
        )
        
        # Calculate pattern strength
        dt_strength = (max(first_max, second_max) - middle_min) / window_prices.mean() if is_double_top else 0
        db_strength = (middle_max - min(first_min, second_min)) / window_prices.mean() if is_double_bottom else 0
        
        return is_double_top, is_double_bottom, dt_strength, db_strength
    
    def detect_triangle_pattern(window_prices: pd.Series) -> Tuple[bool, bool, bool, float]:
        """Detect triangle patterns with improved criteria."""
        if len(window_prices) < min_pattern_size:
            return False, False, False, 0.0
        
        # Calculate trend lines
        x = np.arange(len(window_prices))
        highs = window_prices.rolling(window=min_pattern_size//2, min_periods=2).max()
        lows = window_prices.rolling(window=min_pattern_size//2, min_periods=2).min()
        
        # Fit lines to highs and lows
        high_slope, high_intercept = np.polyfit(x[~highs.isna()], highs.dropna(), 1)
        low_slope, low_intercept = np.polyfit(x[~lows.isna()], lows.dropna(), 1)
        
        # Calculate convergence point
        if abs(high_slope - low_slope) > 1e-10:  # Avoid division by zero
            x_intersect = (low_intercept - high_intercept) / (high_slope - low_slope)
            y_intersect = high_slope * x_intersect + high_intercept
        else:
            x_intersect = np.inf
            y_intersect = np.nan
        
        # Pattern height at start
        start_height = abs(high_intercept - low_intercept)
        
        # Check triangle types
        is_ascending = (
            low_slope > pattern_thresholds['triangle'] and
            abs(high_slope) < pattern_thresholds['triangle'] and
            start_height > window_prices.mean() * pattern_thresholds['triangle']
        )
        
        is_descending = (
            high_slope < -pattern_thresholds['triangle'] and
            abs(low_slope) < pattern_thresholds['triangle'] and
            start_height > window_prices.mean() * pattern_thresholds['triangle']
        )
        
        is_symmetric = (
            abs(high_slope + low_slope) < pattern_thresholds['triangle'] and
            start_height > window_prices.mean() * pattern_thresholds['triangle']
        )
        
        # Calculate pattern strength
        triangle_strength = start_height / window_prices.mean()
        
        return is_ascending, is_descending, is_symmetric, triangle_strength
    
    for window in pattern_windows:
        for horizon in horizons:
            # Rolling window analysis
            for i in range(window, len(prices)):
                window_prices = prices.iloc[i-window:i]
                
                # Detect patterns
                is_hs, is_ihs, hs_strength, ihs_strength = detect_head_and_shoulders(window_prices)
                is_dt, is_db, dt_strength, db_strength = detect_double_pattern(window_prices)
                is_asc, is_desc, is_sym, triangle_strength = detect_triangle_pattern(window_prices)
                
                # Store binary pattern signals (not normalized)
                pattern_targets.loc[prices.index[i], f'head_shoulders_{window}_{horizon}'] = int(is_hs)
                pattern_targets.loc[prices.index[i], f'inv_head_shoulders_{window}_{horizon}'] = int(is_ihs)
                pattern_targets.loc[prices.index[i], f'double_top_{window}_{horizon}'] = int(is_dt)
                pattern_targets.loc[prices.index[i], f'double_bottom_{window}_{horizon}'] = int(is_db)
                pattern_targets.loc[prices.index[i], f'asc_triangle_{window}_{horizon}'] = int(is_asc)
                pattern_targets.loc[prices.index[i], f'desc_triangle_{window}_{horizon}'] = int(is_desc)
                pattern_targets.loc[prices.index[i], f'sym_triangle_{window}_{horizon}'] = int(is_sym)
                
                # Store pattern strengths (will be normalized if requested)
                pattern_targets.loc[prices.index[i], f'hs_strength_{window}_{horizon}'] = hs_strength
                pattern_targets.loc[prices.index[i], f'ihs_strength_{window}_{horizon}'] = ihs_strength
                pattern_targets.loc[prices.index[i], f'dt_strength_{window}_{horizon}'] = dt_strength
                pattern_targets.loc[prices.index[i], f'db_strength_{window}_{horizon}'] = db_strength
                pattern_targets.loc[prices.index[i], f'triangle_strength_{window}_{horizon}'] = triangle_strength
            
            # Calculate pattern completion probabilities
            future_returns = calculate_future_return(prices, horizon, 'arithmetic')
            if normalize:
                future_returns = future_returns / rolling_vol
            
            for pattern in ['head_shoulders', 'inv_head_shoulders', 'double_top', 'double_bottom',
                          'asc_triangle', 'desc_triangle', 'sym_triangle']:
                pattern_series = pattern_targets[f'{pattern}_{window}_{horizon}']
                
                # Calculate success rate (pattern followed by expected move)
                if pattern in ['head_shoulders', 'double_top', 'desc_triangle']:
                    success = (pattern_series == 1) & (future_returns < 0)
                elif pattern in ['inv_head_shoulders', 'double_bottom', 'asc_triangle']:
                    success = (pattern_series == 1) & (future_returns > 0)
                else:  # Symmetric triangle
                    success = (pattern_series == 1) & (abs(future_returns) > rolling_vol)
                
                success_rate = success.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                pattern_targets[f'{pattern}_success_{window}_{horizon}'] = success_rate
                
                # Calculate pattern frequency
                pattern_freq = pattern_series.rolling(
                    window=vol_window, 
                    min_periods=min_periods
                ).mean()
                pattern_targets[f'{pattern}_freq_{window}_{horizon}'] = pattern_freq
            
            # Normalize continuous measures if requested
            if normalize:
                for col in pattern_targets.columns:
                    if any(x in col for x in ['strength', 'success', 'freq']):
                        pattern_targets[col] = pattern_targets[col] / rolling_vol
    
    return pattern_targets 