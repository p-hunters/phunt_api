"""
BigQueryアダプタのテスト用スクリプト
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

# ロギングの設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# BigQueryアダプタのインポート
from phunt_api.targets.return_targets._adapters.bigquery_adapter import (
    BigQueryReturnTargetService,
    calculate_future_returns_bigquery,
    calculate_risk_adjusted_returns_bigquery,
    construct_query
)

def test_construct_query():
    """
    construct_query関数のテスト
    """
    # テストケース1: 単一のWITH句
    sql_parts1 = [
        "WITH data AS (SELECT * FROM table)",
        "SELECT * FROM data"
    ]
    result1 = construct_query(sql_parts1)
    logger.info(f"テストケース1結果:\n{result1}")
    
    # テストケース2: 複数のCTE
    sql_parts2 = [
        "WITH data AS (SELECT * FROM table)",
        "cte1 AS (SELECT * FROM data)",
        "cte2 AS (SELECT * FROM cte1)",
        "SELECT * FROM cte2"
    ]
    result2 = construct_query(sql_parts2)
    logger.info(f"テストケース2結果:\n{result2}")
    
    return "construct_query関数のテスト完了"

def test_with_sample_data():
    """
    サンプルデータを使用したBigQueryアダプタのテスト
    """
    # サンプルデータの作成
    dates = pd.date_range(start='2024-01-01', periods=100, freq='D')
    prices = np.random.normal(100, 5, 100).cumsum() + 1000
    df = pd.DataFrame({
        'ts': dates,
        'close': prices
    })
    
    # BigQueryサービスの初期化
    service = BigQueryReturnTargetService(project_id="phunt-api")
    
    try:
        # リスク調整済みリターンの計算
        result = service.calculate_risk_adjusted_returns(
            prices=df,
            horizons=[5, 10],
            risk_window=20,
            date_column='ts',
            price_column='close'
        )
        logger.info(f"リスク調整済みリターン計算結果: {result.head() if result is not None else 'None'}")
        return "サンプルデータテスト完了"
    except Exception as e:
        logger.error(f"テスト中にエラーが発生: {e}")
        return f"エラー: {e}"

if __name__ == "__main__":
    logger.info("BigQueryアダプタのテストを開始")
    
    # construct_query関数のテスト
    logger.info(test_construct_query())
    
    # サンプルデータを使用したテスト
    logger.info(test_with_sample_data())
    
    logger.info("テスト完了") 