from typing import Union, List, Optional, Dict, Tuple
import pandas as pd

from .validators import (
    validate_price_series,
    validate_horizons,
    validate_windows,
    validate_high_low_data,
    validate_benchmarks
)

from .returns import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns
)

from .technical import (
    calculate_momentum_targets,
    calculate_range_targets,
    calculate_mean_reversion_targets
)

from .volatility import calculate_volatility_targets
from .relative import calculate_relative_returns

from .classification import (
    calculate_multiclass_direction,
    calculate_sr_breakout
)

def calculate_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    min_return: float = -0.1,
    max_return: float = 0.1,
    direction_threshold: float = 0.0,
    vol_window: int = 20,
    include_direction: bool = True,
    include_vol_adjusted: bool = True,
    include_momentum: bool = True,
    include_risk_adjusted: bool = True,
    include_range: bool = True,
    include_mean_reversion: bool = True,
    include_relative: bool = True,
    include_multiclass: bool = True,
    include_sr_breakout: bool = True,
    include_volatility: bool = True,
    momentum_windows: Union[int, List[int]] = [5, 10, 20],
    normalize_momentum: bool = True,
    risk_window: int = 60,
    risk_free_rate: float = 0.0,
    min_periods: int = 5,
    normalize_range: bool = True,
    ma_windows: Union[int, List[int]] = [10, 20, 50, 200],
    normalize_reversion: bool = True,
    bollinger_std: float = 2.0,
    benchmarks: Optional[Dict[str, pd.Series]] = None,
    normalize_relative: bool = True,
    correlation_window: int = 60,
    direction_thresholds: Union[Tuple[float, float], List[Tuple[float, float]]] = [
        (-0.02, -0.005),
        (0.005, 0.02)
    ],
    normalize_direction: bool = True,
    sr_windows: Union[int, List[int]] = [20, 50, 100],
    pivot_threshold: float = 0.01,
    breakout_threshold: float = 0.003,
    min_pivot_distance: int = 5,
    vol_windows: Union[int, List[int]] = [20, 50, 100],
    vol_method: str = 'standard',
    vol_of_vol_window: int = 50,
    high_low_data: Optional[Tuple[pd.Series, pd.Series]] = None,
    jump_threshold: float = 3.0,
    regime_thresholds: Union[Tuple[float, float], List[Tuple[float, float]]] = [
        (0.5, 1.5)
    ]
) -> pd.DataFrame:
    """
    Calculate various target variables for machine learning.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate targets for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        min_return (float): Minimum return threshold for outlier handling
        max_return (float): Maximum return threshold for outlier handling
        direction_threshold (float): Return threshold to determine direction
        vol_window (int): Window size for volatility calculation
        include_direction (bool): Whether to include direction labels
        include_vol_adjusted (bool): Whether to include volatility-adjusted returns
        include_momentum (bool): Whether to include momentum-based targets
        include_risk_adjusted (bool): Whether to include risk-adjusted return targets
        include_range (bool): Whether to include range-based prediction targets
        include_mean_reversion (bool): Whether to include mean reversion targets
        include_relative (bool): Whether to include relative return targets
        include_multiclass (bool): Whether to include multi-class direction prediction
        include_sr_breakout (bool): Whether to include support/resistance breakout prediction
        include_volatility (bool): Whether to include volatility prediction targets
        momentum_windows (Union[int, List[int]]): Windows for momentum calculation
        normalize_momentum (bool): Whether to normalize momentum by volatility
        risk_window (int): Window size for risk calculations
        risk_free_rate (float): Annual risk-free rate
        min_periods (int): Minimum periods for rolling calculations
        normalize_range (bool): Whether to normalize ranges by volatility
        ma_windows (Union[int, List[int]]): Moving average windows for mean reversion
        normalize_reversion (bool): Whether to normalize mean reversion measures
        bollinger_std (float): Number of standard deviations for Bollinger Bands
        benchmarks (Optional[Dict[str, pd.Series]]): Dictionary of benchmark price series
        normalize_relative (bool): Whether to normalize relative returns
        correlation_window (int): Window for correlation calculations
        direction_thresholds (Union[Tuple[float, float], List[Tuple[float, float]]]): 
            Thresholds for multi-class direction prediction
        normalize_direction (bool): Whether to normalize direction prediction returns
        sr_windows (Union[int, List[int]]): Windows for support/resistance calculation
        pivot_threshold (float): Minimum price change to identify pivot points
        breakout_threshold (float): Minimum move to confirm breakout
        min_pivot_distance (int): Minimum distance between pivot points
        vol_windows (Union[int, List[int]]): Windows for volatility calculation
        vol_method (str): Method for volatility calculation ('standard', 'parkinson', 'garman_klass')
        vol_of_vol_window (int): Window for volatility of volatility calculation
        high_low_data (Optional[Tuple[pd.Series, pd.Series]]): High and low price series
        jump_threshold (float): Threshold for jump detection
        regime_thresholds (Union[Tuple[float, float], List[Tuple[float, float]]]): 
            Thresholds for volatility regime boundaries
    
    Returns:
        pd.DataFrame: DataFrame with all calculated target variables
    """
    # Calculate future returns
    targets = calculate_future_returns(
        prices=prices,
        horizons=horizons,
        method=method,
        min_return=min_return,
        max_return=max_return
    )
    
    # Add direction labels if requested
    if include_direction:
        direction_df = calculate_direction_labels(
            prices=prices,
            horizons=horizons,
            threshold=direction_threshold
        )
        targets = pd.concat([targets, direction_df], axis=1)
    
    # Add volatility-adjusted returns if requested
    if include_vol_adjusted:
        vol_adj_df = calculate_volatility_adjusted_returns(
            prices=prices,
            horizons=horizons,
            vol_window=vol_window,
            method=method
        )
        targets = pd.concat([targets, vol_adj_df], axis=1)
    
    # Add momentum targets if requested
    if include_momentum:
        momentum_df = calculate_momentum_targets(
            prices=prices,
            momentum_windows=momentum_windows,
            prediction_horizons=horizons,
            method=method,
            normalize=normalize_momentum
        )
        targets = pd.concat([targets, momentum_df], axis=1)
    
    # Add risk-adjusted return targets if requested
    if include_risk_adjusted:
        risk_adj_df = calculate_risk_adjusted_returns(
            prices=prices,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods
        )
        targets = pd.concat([targets, risk_adj_df], axis=1)
    
    # Add range-based prediction targets if requested
    if include_range:
        range_df = calculate_range_targets(
            prices=prices,
            horizons=horizons,
            normalize=normalize_range,
            vol_window=vol_window,
            min_periods=min_periods
        )
        targets = pd.concat([targets, range_df], axis=1)
    
    # Add mean reversion targets if requested
    if include_mean_reversion:
        reversion_df = calculate_mean_reversion_targets(
            prices=prices,
            horizons=horizons,
            ma_windows=ma_windows,
            normalize=normalize_reversion,
            vol_window=vol_window,
            min_periods=min_periods,
            bollinger_std=bollinger_std
        )
        targets = pd.concat([targets, reversion_df], axis=1)
    
    # Add relative return targets if requested and benchmarks are provided
    if include_relative and benchmarks is not None:
        relative_df = calculate_relative_returns(
            prices=prices,
            benchmarks=benchmarks,
            horizons=horizons,
            method=method,
            normalize=normalize_relative,
            vol_window=vol_window,
            min_periods=min_periods,
            correlation_window=correlation_window
        )
        targets = pd.concat([targets, relative_df], axis=1)
    
    # Add multi-class direction prediction if requested
    if include_multiclass:
        multiclass_df = calculate_multiclass_direction(
            prices=prices,
            horizons=horizons,
            thresholds=direction_thresholds,
            vol_normalize=normalize_direction,
            vol_window=vol_window,
            min_periods=min_periods
        )
        targets = pd.concat([targets, multiclass_df], axis=1)
    
    # Add support/resistance breakout prediction if requested
    if include_sr_breakout:
        breakout_df = calculate_sr_breakout(
            prices=prices,
            horizons=horizons,
            sr_windows=sr_windows,
            pivot_threshold=pivot_threshold,
            breakout_threshold=breakout_threshold,
            vol_normalize=normalize_direction,
            vol_window=vol_window,
            min_periods=min_periods,
            min_pivot_distance=min_pivot_distance
        )
        targets = pd.concat([targets, breakout_df], axis=1)
    
    # Add volatility prediction targets if requested
    if include_volatility:
        volatility_df = calculate_volatility_targets(
            prices=prices,
            horizons=horizons,
            vol_windows=vol_windows,
            method=vol_method,
            vol_of_vol_window=vol_of_vol_window,
            min_periods=min_periods,
            high_low_data=high_low_data,
            jump_threshold=jump_threshold,
            regime_thresholds=regime_thresholds
        )
        targets = pd.concat([targets, volatility_df], axis=1)
    
    return targets
