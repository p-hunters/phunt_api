import numpy as np
import pandas as pd
from typing import Union, List
from .validators import validate_price_series, validate_horizons, validate_windows
from .utils import calculate_daily_returns, calculate_future_return, calculate_rolling_volatility

def calculate_future_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: float = None,
    max_return: float = None
) -> pd.DataFrame:
    """
    Calculate future returns for multiple horizons.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize returns by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        min_return (float, optional): Minimum return threshold for outlier handling
        max_return (float, optional): Maximum return threshold for outlier handling
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    future_returns = pd.DataFrame(index=prices.index)
    
    # Calculate volatility if normalizing
    if normalize:
        daily_returns = calculate_daily_returns(prices, method)
        vol = calculate_rolling_volatility(daily_returns, vol_window, min_periods)
    
    # Calculate returns for each horizon
    for horizon in horizons:
        future_ret = calculate_future_return(prices, horizon, method)
        
        # Apply return thresholds if specified
        if min_return is not None:
            future_ret = future_ret.clip(lower=min_return)
        if max_return is not None:
            future_ret = future_ret.clip(upper=max_return)
        
        if normalize:
            # Ensure alignment of future_ret and vol
            aligned_vol = vol.reindex(future_ret.index)
            future_ret = future_ret / aligned_vol
        
        future_returns[f'future_return_{horizon}'] = future_ret
    
    return future_returns

def calculate_direction_labels(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0
) -> pd.DataFrame:
    """
    Calculate binary direction labels for future price movements.
    Labels: 1 = price moves up more than `threshold`, 0 = otherwise.
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    direction_labels = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        # Calculate future returns (positive when price goes up)
        future_return = (prices.shift(-horizon) / prices - 1)
        direction = (future_return > threshold).astype(int)
        direction_labels[f'direction_{horizon}'] = direction
    
    return direction_labels

def calculate_volatility_adjusted_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic'
) -> pd.DataFrame:
    """Calculate volatility-adjusted future returns."""
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("method must be either 'arithmetic' or 'log'")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Calculate daily returns for volatility
    daily_returns = prices.pct_change()
    volatility = daily_returns.rolling(window=vol_window, min_periods=1).std()
    
    vol_adj_returns = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        # Calculate future returns (positive when price goes up)
        future_ret = -(prices.shift(-horizon) / prices - 1)
        
        # Ensure proper alignment of volatility with returns
        aligned_vol = volatility.copy()
        vol_adj_ret = future_ret / aligned_vol
        
        vol_adj_returns[f'vol_adj_return_{horizon}'] = vol_adj_ret
    
    return vol_adj_returns

def calculate_risk_adjusted_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20
) -> pd.DataFrame:
    """Calculate risk-adjusted return targets (Sharpe and Sortino ratios, etc.)."""
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([risk_window])
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if not isinstance(risk_free_rate, (int, float)):
        raise ValueError("risk_free_rate must be a number")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > risk_window:
        raise ValueError("min_periods cannot be greater than risk_window")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    risk_adj_returns = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        future_ret = calculate_future_return(prices, horizon, method)
        
        # Convert annual risk-free rate to match horizon days (assuming 252 trading days)
        period_rf_rate = (1 + risk_free_rate) ** (horizon / 252) - 1
        
        # Rolling stats
        rolling_mean = future_ret.rolling(window=risk_window, min_periods=min_periods).mean()
        rolling_std = future_ret.rolling(window=risk_window, min_periods=min_periods).std()
        
        # Downside returns for Sortino ratio
        downside_returns = future_ret.copy()
        downside_returns[downside_returns > period_rf_rate] = 0
        rolling_downside_std = np.sqrt(
            (downside_returns ** 2).rolling(window=risk_window, min_periods=min_periods).mean()
        )
        
        # Sharpe ratio
        sharpe = (rolling_mean - period_rf_rate) / rolling_std
        risk_adj_returns[f'future_sharpe_{horizon}'] = sharpe
        
        # Sortino ratio
        sortino = (rolling_mean - period_rf_rate) / rolling_downside_std
        risk_adj_returns[f'future_sortino_{horizon}'] = sortino
        
        # Calmar ratio (naive version based on rolling returns)
        rolling_max = future_ret.rolling(window=risk_window, min_periods=min_periods).max()
        rolling_drawdown = (future_ret - rolling_max) / rolling_max
        max_drawdown = rolling_drawdown.rolling(window=risk_window, min_periods=min_periods).min()
        calmar = (rolling_mean - period_rf_rate) / abs(max_drawdown)
        risk_adj_returns[f'future_calmar_{horizon}'] = calmar
    
    return risk_adj_returns

# ... 他のリターン関連関数も同様に移動 