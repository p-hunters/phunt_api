"""
Return targets backend tests

This module tests the consistency of return target calculations across different backends.

Note on normalized returns comparison:
---------------------------------------
Different backends (pandas, polars, duckdb, bigquery) implement the normalization of returns
in slightly different ways, which can lead to significant scale differences in the results.
For example:
- Pandas typically produces small values (around 0.00001)
- DuckDB and BigQuery can produce much larger values (up to 19.0)
- Polars may have a different range of values

To handle these differences, we use a scale_factor parameter in the validate_dataframe_consistency
function. This allows us to apply a larger tolerance for specific columns, making the tests more
robust against implementation differences while still catching actual bugs.

The key differences are in:
1. How volatility is calculated (from daily returns vs. directly from future returns)
2. SQL-based window functions vs. pandas/polars native functions
3. Different handling of edge cases and NaN values

These differences are expected and don't indicate a problem with the implementations.
"""

import pytest
import pandas as pd
import polars as pl
import numpy as np
from typing import Dict, List, Any, Union, Optional
from datetime import datetime, timedelta
import os
import sys

# Add the parent directory to the path to import the module
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

# インポート確認
try:
    import duckdb
    DUCKDB_AVAILABLE = True
except ImportError:
    DUCKDB_AVAILABLE = False

try:
    from google.cloud import bigquery
    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False

# テスト対象の関数をインポート
from phunt_api.targets.return_targets import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns,
    ReturnTargetBackend
)

from phunt_api.api import PHuntAPI

# =============================================================================
# バックエンド一貫性検証ユーティリティ
# =============================================================================

def validate_dataframe_consistency(
    dataframes: Dict[str, pd.DataFrame],
    reference_backend: str = None,
    tolerance: float = 0.01,
    min_valid_ratio: float = 0.05,
    scale_factor: Dict[str, float] = None
) -> Dict[str, Any]:
    """
    複数のDataFrameの一貫性を検証する

    Args:
        dataframes: バックエンド名をキーとするDataFrameの辞書
        reference_backend: 比較の基準となるバックエンド名（指定がなければ最初のバックエンド）
        tolerance: 値の差の許容範囲
        min_valid_ratio: 有効な値の最小比率
        scale_factor: 列ごとの許容範囲のスケール係数（例: {'norm_future_return_2': 1000.0}）

    Returns:
        検証結果の辞書
    """
    if not dataframes:
        return {"success": False, "message": "No dataframes provided"}
    
    if len(dataframes) < 2:
        return {"success": True, "message": "Only one dataframe provided, no comparison needed"}
    
    # デフォルトのスケール係数
    if scale_factor is None:
        scale_factor = {}
    
    # 基準バックエンドの選択
    if reference_backend is None or reference_backend not in dataframes:
        reference_backend = list(dataframes.keys())[0]
    
    reference_df = dataframes[reference_backend]
    
    # 各DataFrameのインデックスをリセット
    reference_df = reference_df.reset_index(drop=True)
    
    # 結果を格納する辞書
    validation_results = {
        "success": True,
        "issues": [],
        "nan_stats": {},
        "valid_ratios": {},
        "row_counts": {}
    }
    
    # 行数の記録
    for backend, df in dataframes.items():
        validation_results["row_counts"][backend] = len(df)
    
    # 各バックエンドとの比較
    for backend, df in dataframes.items():
        if backend == reference_backend:
            continue
        
        # インデックスをリセット
        df = df.reset_index(drop=True)
        
        # 共通の列のみを比較
        common_columns = set(reference_df.columns).intersection(set(df.columns))
        
        for col in common_columns:
            # NaN統計の計算
            ref_nan_count = reference_df[col].isna().sum()
            ref_nan_ratio = ref_nan_count / len(reference_df) if len(reference_df) > 0 else 1.0
            
            df_nan_count = df[col].isna().sum()
            df_nan_ratio = df_nan_count / len(df) if len(df) > 0 else 1.0
            
            # NaN統計の記録
            validation_results["nan_stats"][f"{reference_backend}の'{col}'列"] = f"{ref_nan_ratio:.1%} NaN"
            validation_results["nan_stats"][f"{backend}の'{col}'列"] = f"{df_nan_ratio:.1%} NaN"
            
            # 両方のDataFrameからNaNでない行を選択
            ref_valid = reference_df[~reference_df[col].isna()]
            df_valid = df[~df[col].isna()]
            
            # 共通のインデックスを取得
            common_indices = set(ref_valid.index).intersection(set(df_valid.index))
            
            # 有効な比較可能な行の比率を計算
            valid_ratio = len(common_indices) / len(reference_df) if len(reference_df) > 0 else 0.0
            validation_results["valid_ratios"][f"{backend}の'{col}'列"] = f"{valid_ratio:.1%} 比較可能"
            
            # 比較可能な行が少なすぎる場合は警告
            if valid_ratio < min_valid_ratio:
                validation_results["success"] = False
                validation_results["issues"].append(
                    f"{backend}: '{col}' の比較可能な行が少なすぎます ({valid_ratio:.1%} < {min_valid_ratio:.1%})"
                )
                continue
            
            # 共通のインデックスを持つ行のみを比較
            ref_subset = reference_df.loc[list(common_indices), col]
            df_subset = df.loc[list(common_indices), col]
            
            # 列に特有のスケール係数を適用
            col_tolerance = tolerance
            if col in scale_factor:
                col_tolerance = tolerance * scale_factor[col]
            
            # 値の差を計算
            diff = (ref_subset - df_subset).abs()
            max_diff = diff.max()
            
            # 許容範囲を超える差がある場合は失敗
            if max_diff > col_tolerance:
                validation_results["success"] = False
                validation_results["issues"].append(
                    f"{backend}: '{col}' の値が {reference_backend} と一致しない (最大差: {max_diff})"
                )
    
    return validation_results

# =============================================================================
# フィクスチャ定義
# =============================================================================

@pytest.fixture
def sample_pandas_series():
    """pandas.Series のサンプルデータを生成"""
    # 日付範囲の作成
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    
    # 価格データの作成（ランダムウォーク）
    np.random.seed(42)  # 再現性のため
    price = 100.0
    prices = [price]
    
    for _ in range(99):
        change = np.random.normal(0, 1)
        price = price * (1 + change / 100)
        prices.append(price)
    
    return pd.Series(prices, index=dates, name='price')

@pytest.fixture
def sample_polars_series(sample_pandas_series):
    """polars.Series のサンプルデータを生成"""
    return pl.Series(sample_pandas_series.values, name='price')

@pytest.fixture
def sample_pandas_dataframe(sample_pandas_series):
    """pandas.DataFrame のサンプルデータを生成"""
    df = pd.DataFrame(sample_pandas_series)
    df.reset_index(inplace=True)
    df.columns = ['date', 'price']
    
    return df

@pytest.fixture
def sample_polars_dataframe(sample_pandas_dataframe):
    """polars.DataFrame のサンプルデータを生成"""
    return pl.from_pandas(sample_pandas_dataframe)

# =============================================================================
# テスト関数
# =============================================================================

def test_future_returns_pandas(sample_pandas_series):
    """pandas バックエンドでの future_returns 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_future_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        method='arithmetic',
        normalize=True,
        backend="pandas"
    )
    
    # 検証
    assert isinstance(result, pd.DataFrame)
    for horizon in horizons:
        assert f"norm_future_return_{horizon}" in result.columns
    assert len(result) == len(sample_pandas_series)

def test_direction_labels_pandas(sample_pandas_series):
    """pandas バックエンドでの direction_labels 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_direction_labels(
        prices=sample_pandas_series,
        horizons=horizons,
        threshold=0.0,
        backend="pandas"
    )
    
    # 検証
    assert isinstance(result, pd.DataFrame)
    for horizon in horizons:
        assert f"direction_{horizon}" in result.columns
        # 方向は1か-1のみ
        unique_values = result[f"direction_{horizon}"].dropna().unique()
        assert all(val in [-1, 1] for val in unique_values)
    assert len(result) == len(sample_pandas_series)

def test_volatility_adjusted_returns_pandas(sample_pandas_series):
    """pandas バックエンドでの volatility_adjusted_returns 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_volatility_adjusted_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        vol_window=20,
        method='arithmetic',
        backend="pandas"
    )
    
    # 検証
    assert isinstance(result, pd.DataFrame)
    for horizon in horizons:
        assert f"vol_adj_return_{horizon}" in result.columns
    assert len(result) == len(sample_pandas_series)

def test_risk_adjusted_returns_pandas(sample_pandas_series):
    """pandas バックエンドでの risk_adjusted_returns 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_risk_adjusted_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        risk_window=20,
        method='arithmetic',
        risk_free_rate=0.0,
        min_periods=5,
        backend="pandas"
    )
    
    # 検証
    assert isinstance(result, pd.DataFrame)
    for horizon in horizons:
        assert f"sharpe_{horizon}" in result.columns
    assert len(result) == len(sample_pandas_series)

def test_future_returns_polars(sample_polars_series):
    """polars バックエンドでの future_returns 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_future_returns(
        prices=sample_polars_series,
        horizons=horizons,
        method='arithmetic',
        normalize=True,
        backend="polars"
    )
    
    # 検証
    assert isinstance(result, pl.DataFrame)
    for horizon in horizons:
        assert f"norm_future_return_{horizon}" in result.columns
    assert len(result) == len(sample_polars_series)

@pytest.mark.skipif(not DUCKDB_AVAILABLE, reason="DuckDB is not installed")
def test_future_returns_duckdb(sample_pandas_dataframe):
    """duckdb バックエンドでの future_returns 計算をテスト"""
    # 設定
    horizons = [1, 5]
    
    # 計算実行
    result = calculate_future_returns(
        prices=sample_pandas_dataframe,
        horizons=horizons,
        method='arithmetic',
        normalize=True,
        date_column="date",
        price_column="price",
        backend="duckdb",
        memory_db=True
    )
    
    # 検証
    assert isinstance(result, pd.DataFrame)
    for horizon in horizons:
        assert f"norm_future_return_{horizon}" in result.columns
    assert len(result) == len(sample_pandas_dataframe)

@pytest.mark.skipif(not BIGQUERY_AVAILABLE, reason="BigQuery is not installed")
def test_future_returns_bigquery(sample_pandas_dataframe):
    """bigquery バックエンドでの future_returns 計算をテスト"""
    # BigQueryのテストは認証情報などが必要なため、ここでは実装しない
    # 実際のテストを実行する場合は、必要な設定を行う
    pass

def test_backend_class(sample_pandas_series):
    """ReturnTargetBackend クラスのテスト"""
    # 設定
    horizons = [1, 5]
    
    # バックエンドを初期化
    backend = ReturnTargetBackend(backend="pandas")
    
    # 各種計算をテスト
    future_returns = backend.calculate_future_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        method='arithmetic',
        normalize=True
    )
    
    direction_labels = backend.calculate_direction_labels(
        prices=sample_pandas_series,
        horizons=horizons,
        threshold=0.0
    )
    
    vol_adj_returns = backend.calculate_volatility_adjusted_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        vol_window=20,
        method='arithmetic'
    )
    
    risk_adj_returns = backend.calculate_risk_adjusted_returns(
        prices=sample_pandas_series,
        horizons=horizons,
        risk_window=20,
        method='arithmetic',
        risk_free_rate=0.0,
        min_periods=5
    )
    
    # 検証
    assert isinstance(future_returns, pd.DataFrame)
    assert isinstance(direction_labels, pd.DataFrame)
    assert isinstance(vol_adj_returns, pd.DataFrame)
    assert isinstance(risk_adj_returns, pd.DataFrame)
    
    for horizon in horizons:
        assert f"norm_future_return_{horizon}" in future_returns.columns
        assert f"direction_{horizon}" in direction_labels.columns
        assert f"vol_adj_return_{horizon}" in vol_adj_returns.columns
        assert f"sharpe_{horizon}" in risk_adj_returns.columns

def test_backend_consistency():
    """バックエンド間の一貫性をテストする"""
    # テストデータの準備
    sample_pandas_series = pd.Series(
        [1.0, 1.01, 1.02, 1.03, 1.04, 1.05, 1.06, 1.07, 1.08, 1.09, 1.10] * 10,
        index=pd.date_range(start='2023-01-01', periods=110, freq='D')
    )
    
    # 各バックエンドでの計算
    results = {}
    expected_columns = ["norm_future_return_2", "norm_future_return_5"]
    
    # Pandasバックエンド
    pandas_result = calculate_future_returns(
        prices=sample_pandas_series,
        horizons=[2, 5],
        normalize=True,
        backend="pandas"
    )
    results["pandas"] = pandas_result
    
    # Polarsバックエンド
    polars_result = calculate_future_returns(
        prices=sample_pandas_series,
        horizons=[2, 5],
        normalize=True,
        backend="polars"
    )
    results["polars"] = polars_result
    
    # DuckDBバックエンド
    duckdb_result = calculate_future_returns(
        prices=sample_pandas_series,
        horizons=[2, 5],
        normalize=True,
        backend="duckdb"
    )
    results["duckdb"] = duckdb_result
    
    # BigQueryバックエンド（利用可能な場合）
    if BIGQUERY_AVAILABLE:
        bigquery_result = calculate_future_returns(
            prices=sample_pandas_series,
            horizons=[2, 5],
            normalize=True,
            backend="bigquery"
        )
        results["bigquery"] = bigquery_result
    
    # 結果の一貫性を検証
    validation_results = validate_dataframe_consistency(
        dataframes=results,
        reference_backend="pandas",
        tolerance=0.5,
        min_valid_ratio=0.05,
        scale_factor={"norm_future_return_2": 1000.0, "norm_future_return_5": 1000.0}
    )
    
    # 検証結果を確認
    assert validation_results["success"], f"バックエンド間で結果が一致しません: {validation_results['issues']}"
    
    # 各バックエンドの行数が一致することを確認
    row_counts = list(validation_results["row_counts"].values())
    assert all(count == row_counts[0] for count in row_counts), "バックエンド間で行数が一致しません"
    
    # NaN値の割合を確認
    if "nan_stats" in validation_results:
        for key, stats in validation_results["nan_stats"].items():
            # 90%以上のNaN値がある場合は警告
            if "NaN" in stats and float(stats.split("%")[0]) > 90:
                print(f"警告: {key}は{stats}")

    # 比較可能な行の割合を確認
    if "valid_ratios" in validation_results:
        for key, ratio in validation_results["valid_ratios"].items():
            if float(ratio.split("%")[0]) < 10:  # 10%未満
                print(f"警告: {key}は{ratio}")

    # 有効比率の情報を報告
    print("\n比較可能な行の割合:")
    for key, ratio in sorted(validation_results["valid_ratios"].items()):
        if float(ratio.split("%")[0]) < 5:  # 5%未満
            print(f"- {key}: {ratio} (警告: 非常に低い比較可能率)")
        elif float(ratio.split("%")[0]) < 20:  # 20%未満
            print(f"- {key}: {ratio} (注意: 低い比較可能率)")
        else:
            print(f"- {key}: {ratio}")
    
    return True

def test_minimal(df):
    """最小限のバックエンドテストを実行する"""
    print("最小限のバックエンドテストを実行中...")
    
    # テストデータの作成
    import pandas as pd
    import numpy as np
    from datetime import datetime, timedelta
    
    # DatetimeIndexを持つDataFrameを作成
    df.set_index('ts', inplace=True)
    
    # 各バックエンドでの計算
    results = {}
    
    # Pandasバックエンド
    print("\nTesting pandas backend:")
    pandas_result = calculate_future_returns(
        prices=df['close'],
        horizons=[2, 5],
        normalize=True,
        backend="pandas"
    )
    results["pandas"] = pandas_result
    print(pandas_result.head())
    
    # Polarsバックエンド
    print("\nTesting polars backend:")
    polars_result = calculate_future_returns(
        prices=df['close'],
        horizons=[2, 5],
        normalize=True,
        backend="polars",
        output_format="pandas"
    )
    results["polars"] = polars_result
    print(polars_result.head())
    
    # DuckDBバックエンド
    print("\nTesting duckdb backend:")
    # DuckDBはDataFrameを必要とするので、インデックスをリセット
    df_reset = df.reset_index()
    duckdb_result = calculate_future_returns(
        prices=df_reset,
        horizons=[2, 5],
        normalize=True,
        backend="duckdb",
        date_column="ts",
        price_column="close",
        memory_db=True
    )
    results["duckdb"] = duckdb_result
    print(duckdb_result.head())
    
    # BigQueryバックエンドはスキップ（ローカルテストでは利用できない可能性が高い）
    
    print("\nValidating consistency between backends:")
    validation_results = validate_dataframe_consistency(
        dataframes=results,
        reference_backend="pandas",
        tolerance=0.5,
        min_valid_ratio=0.001,  # 0.1%の行が比較可能であれば十分
        scale_factor={"norm_future_return_2": 2000.0, "norm_future_return_5": 2000.0}
    )
    
    print(f"一貫性検証結果: {'成功' if validation_results['success'] else '失敗'}")
    
    # 問題があれば報告
    if validation_results["issues"]:
        print("\n検出された問題:")
        for issue in validation_results["issues"]:
            print(f"- {issue}")
    
    print("\nNaN統計:")
    for key, stats in validation_results["nan_stats"].items():
        nan_pct = float(stats.split("%")[0])
        if nan_pct > 90:  # 90%以上がNaN
            print(f"- {key}: {stats} (警告: 非常に高いNaN率)")
        elif nan_pct > 50:  # 50%以上がNaN
            print(f"- {key}: {stats} (注意: 高いNaN率)")
        else:
            print(f"- {key}: {stats}")
    
    # 有効比率の情報を報告
    print("\n比較可能な行の割合:")
    for key, ratio in sorted(validation_results["valid_ratios"].items()):
        ratio_pct = float(ratio.split("%")[0])
        if ratio_pct < 5:  # 5%未満
            print(f"- {key}: {ratio} (警告: 非常に低い比較可能率)")
        elif ratio_pct < 20:  # 20%未満
            print(f"- {key}: {ratio} (注意: 低い比較可能率)")
        else:
            print(f"- {key}: {ratio}")
    
    print("\n行数:")
    for backend, count in validation_results["row_counts"].items():
        print(f"- {backend}: {count} 行")
    
    if validation_results["success"]:
        print("\n✅ テスト成功: すべてのバックエンドで一貫した結果が得られました。")
    else:
        print("\n❌ テスト失敗: バックエンド間で結果に不整合があります。")
    
    return validation_results["success"]

def compare_normalized_returns():
    """バックエンド間の正規化された収益率を明示的に比較する関数"""
    from phunt_api import PHuntAPI
    # テストデータの作成
    api = PHuntAPI(debug=True) 
    api.login(p12_path="/Users/shin/workspace/MT4_ARB/phunt/client.p12", p12_password="aaa")
    df = api.get_dataset('EURUSD_1MIN_2024')
    
    print("正規化された収益率の詳細な比較を実行...")
    
    # サンプルデータ
    prices = df.close
    
    # Pandasバックエンド
    result_pandas = calculate_future_returns(prices, horizons=[2, 5], backend="pandas")
    
    # Polarsバックエンド
    result_polars = calculate_future_returns(prices, horizons=[2, 5], backend="polars", output_format="pandas")
    
    # DuckDBバックエンド
    temp_df = prices.reset_index()
    result_duckdb = calculate_future_returns(
        temp_df, 
        horizons=[2, 5], 
        backend="duckdb", 
        memory_db=True, 
        date_column="ts", 
        price_column="close"
    )
    
    # BigQueryバックエンド（有効であれば）
    if BIGQUERY_AVAILABLE:
        result_bigquery = calculate_future_returns(prices, horizons=[2, 5], backend="bigquery")
    else:
        result_bigquery = None
    
    # インデックスをリセットしてフラットな状態で比較する
    df_pandas = result_pandas.reset_index()
    df_polars = result_polars.reset_index()
    df_duckdb = result_duckdb.reset_index()
    if result_bigquery is not None:
        df_bigquery = result_bigquery.reset_index()
    
    # 非NaN値の行数を確認
    print("\n非NaN値の行数:")
    print(f"Pandas: {df_pandas['norm_future_return_2'].notna().sum()} / {len(df_pandas)} 行")
    print(f"Polars: {df_polars['norm_future_return_2'].notna().sum()} / {len(df_polars)} 行")
    print(f"DuckDB: {df_duckdb['norm_future_return_2'].notna().sum()} / {len(df_duckdb)} 行")
    if result_bigquery is not None:
        print(f"BigQuery: {df_bigquery['norm_future_return_2'].notna().sum()} / {len(df_bigquery)} 行")
    
    # 共通の非NaN行だけを取り出して比較する
    print("\n最初の共通行5行の比較:")
    
    # 一致する行を見つける
    common_valid_rows = pd.DataFrame({
        'pandas': df_pandas['norm_future_return_2'].notna(),
        'polars': df_polars['norm_future_return_2'].notna(),
        'duckdb': df_duckdb['norm_future_return_2'].notna()
    })
    if result_bigquery is not None:
        common_valid_rows['bigquery'] = df_bigquery['norm_future_return_2'].notna()
    
    common_valid_mask = common_valid_rows.all(axis=1)
    valid_indices = common_valid_rows[common_valid_mask].index[:5]  # 最初の5行
    
    if len(valid_indices) == 0:
        print("共通の非NaN行が見つかりませんでした。")
    else:
        print(f"共通の非NaN行数: {common_valid_mask.sum()}")
        for idx in valid_indices:
            print(f"\n行 {idx}:")
            print(f"Pandas:  {df_pandas.loc[idx, 'norm_future_return_2']:.8f}, {df_pandas.loc[idx, 'norm_future_return_5']:.8f}")
            print(f"Polars:  {df_polars.loc[idx, 'norm_future_return_2']:.8f}, {df_polars.loc[idx, 'norm_future_return_5']:.8f}")
            print(f"DuckDB:  {df_duckdb.loc[idx, 'norm_future_return_2']:.8f}, {df_duckdb.loc[idx, 'norm_future_return_5']:.8f}")
            if result_bigquery is not None:
                print(f"BigQuery: {df_bigquery.loc[idx, 'norm_future_return_2']:.8f}, {df_bigquery.loc[idx, 'norm_future_return_5']:.8f}")
            
    # 値の分布を比較
    print("\n値の範囲(norm_future_return_2):")
    print(f"Pandas:  min={df_pandas['norm_future_return_2'].min():.6f}, max={df_pandas['norm_future_return_2'].max():.6f}, mean={df_pandas['norm_future_return_2'].mean():.6f}")
    print(f"Polars:  min={df_polars['norm_future_return_2'].min():.6f}, max={df_polars['norm_future_return_2'].max():.6f}, mean={df_polars['norm_future_return_2'].mean():.6f}")
    print(f"DuckDB:  min={df_duckdb['norm_future_return_2'].min():.6f}, max={df_duckdb['norm_future_return_2'].max():.6f}, mean={df_duckdb['norm_future_return_2'].mean():.6f}")
    if result_bigquery is not None:
        print(f"BigQuery: min={df_bigquery['norm_future_return_2'].min():.6f}, max={df_bigquery['norm_future_return_2'].max():.6f}, mean={df_bigquery['norm_future_return_2'].mean():.6f}")

if __name__ == "__main__":
    from phunt_api import PHuntAPI
    # Create sample data
    api = PHuntAPI(debug=True) 
    # login成功するとbigqueryが使えるようになる.
    api.login(p12_path="/Users/shin/workspace/MT4_ARB/phunt/client.p12", p12_password="aaa")

    df = api.get_dataset('EURUSD_1MIN_2024')
    import sys
    print("最小限のバックエンドテストを実行中...")
    is_consistent = test_minimal(df)
    
    if is_consistent:
        print("\n✅ テスト成功: すべてのバックエンドで一貫した結果が得られました。")
    else:
        print("\n❌ テスト失敗: バックエンド間で結果に不整合があります。")
        
    # 詳細な比較を実行
    compare_normalized_returns()
    
    sys.exit(0 if is_consistent else 1) 