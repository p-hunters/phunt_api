"""
Pandas adapter for return target calculations

This module provides pandas-based implementations for return target calculations.
It reuses the original implementations from phunt_api.targets.returns with minimal modifications.
"""

from typing import Union, List, Optional
import pandas as pd
import numpy as np

# Import the original pandas-based functions
from phunt_api.targets.returns import (
    calculate_future_returns as pandas_calculate_future_returns,
    calculate_direction_labels as pandas_calculate_direction_labels,
    calculate_volatility_adjusted_returns as pandas_calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns as pandas_calculate_risk_adjusted_returns,
)

def calculate_future_returns_pandas(
    prices: Union[pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: Optional[float] = None,
    max_return: Optional[float] = None,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating future returns using pandas backend
    
    Args:
        prices: Price data
        horizons: Horizons for future return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value (for winsorizing)
        max_return: Maximum return value (for winsorizing)
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated future returns
    """
    # Ensure prices is a pandas Series
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices = prices['close']
        else:
            prices = prices.iloc[:, 0]
    
    # Call the original implementation
    return pandas_calculate_future_returns(
        prices=prices,
        horizons=horizons,
        method=method,
        normalize=normalize,
        vol_window=vol_window,
        min_periods=min_periods,
        min_return=min_return,
        max_return=max_return
    )

def calculate_direction_labels_pandas(
    prices: Union[pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating direction labels using pandas backend
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction (e.g., 0.0 for any movement)
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated direction labels
    """
    # Ensure prices is a pandas Series
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices = prices['close']
        else:
            prices = prices.iloc[:, 0]
    
    # Call the original implementation
    return pandas_calculate_direction_labels(
        prices=prices,
        horizons=horizons,
        threshold=threshold
    )

def calculate_volatility_adjusted_returns_pandas(
    prices: Union[pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic',
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating volatility-adjusted returns using pandas backend
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns
    """
    # Ensure prices is a pandas Series
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices = prices['close']
        else:
            prices = prices.iloc[:, 0]
    
    # Call the original implementation
    return pandas_calculate_volatility_adjusted_returns(
        prices=prices,
        horizons=horizons,
        vol_window=vol_window,
        method=method
    )

def calculate_risk_adjusted_returns_pandas(
    prices: Union[pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating risk-adjusted returns using pandas backend
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated risk-adjusted returns
    """
    # Ensure prices is a pandas Series
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices = prices['close']
        else:
            prices = prices.iloc[:, 0]
    
    # Call the original implementation
    return pandas_calculate_risk_adjusted_returns(
        prices=prices,
        horizons=horizons,
        risk_window=risk_window,
        method=method,
        risk_free_rate=risk_free_rate,
        min_periods=min_periods
    ) 