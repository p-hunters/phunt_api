"""
Adapter modules for return target calculations with different backends
"""

# Re-export adapter factory functions
from .adapter_factory import (
    calculate_future_returns_adapter,
    calculate_direction_labels_adapter,
    calculate_volatility_adjusted_returns_adapter,
    calculate_risk_adjusted_returns_adapter
) 