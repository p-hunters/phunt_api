"""
BigQuery adapter for return target calculations

This module provides BigQuery-based implementations for return target calculations.
It leverages SQL-based processing for efficient calculations on large datasets.
"""

from typing import Union, List, Optional
import pandas as pd
import polars as pl
import numpy as np
import logging
import os
# Import necessary BigQuery services and utilities
from phunt_api.misc.bq import (
    BIGQUERY_AVAILABLE,
    BigQueryConfig,
    BigQueryTableManager,
    BigQueryDataFetcher
)

# Set up logger
logger = logging.getLogger(__name__)

class BigQueryReturnTargetService:
    """
    Service for calculating return targets using BigQuery
    """
    
    def __init__(
        self,
        project_id: Optional[str] = None,
        dataset_id: str = "phunt_api",
        location: str = "asia-northeast1",
        **kwargs
    ):
        """
        Initialize the BigQuery service
        
        Args:
            project_id: Google Cloud project ID
            dataset_id: BigQuery dataset ID
            location: BigQuery dataset location
            **kwargs: Additional options
        """
        if project_id is None:
            project_id = os.environ.get('gcp_project_id')
        # Initialize BigQuery config
        self.config = BigQueryConfig(
            project_id=project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        # Create BigQuery components
        self.table_manager = BigQueryTableManager(config=self.config)
        self.data_fetcher = BigQueryDataFetcher(config=self.config)
    
    def _prepare_data(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> tuple:
        """
        Prepare data for BigQuery processing
        
        Args:
            prices: Price data
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            Tuple of (prepared DataFrame, date column name, price column name)
        """
        # Standardize column names
        standard_date_col = 'ts'
        standard_price_col = 'price'
        
        # Handle pandas DataFrame
        if isinstance(prices, pd.DataFrame):
            df = prices
            
            # Determine column names
            date_col = date_column or df.columns[0]
            price_col = price_column or ('close' if 'close' in df.columns else df.columns[1])
            
            # Rename columns to ensure consistency
            if date_col != standard_date_col or price_col != standard_price_col:
                df = df.copy()
                column_mapping = {date_col: standard_date_col, price_col: standard_price_col}
                df.rename(columns=column_mapping, inplace=True)
                date_col = standard_date_col
                price_col = standard_price_col
            
        # Handle pandas Series
        elif isinstance(prices, pd.Series):
            # Create DataFrame with proper index
            df = pd.DataFrame({price_column or standard_price_col: prices})
            df.index.name = date_column or standard_date_col
            df = df.reset_index()
            
            # Set column names
            date_col = date_column or standard_date_col
            price_col = price_column or standard_price_col
            
        # Handle polars Series
        elif isinstance(prices, pl.Series):
            # Create DataFrame with proper index
            df = pl.DataFrame({price_column or standard_price_col: prices})
            # Add index column
            df = df.with_row_index(date_column or standard_date_col)
            
            # Set column names
            date_col = date_column or standard_date_col
            price_col = price_column or standard_price_col
            
            # Convert to pandas for BigQuery
            df = df.to_pandas()
            
        # Handle polars DataFrame
        else:  # pl.DataFrame
            # Convert to pandas for BigQuery
            df = prices.to_pandas()
            
            # Determine column names
            date_col = date_column or df.columns[0]
            price_col = price_column or ('close' if 'close' in df.columns else df.columns[1])
            
            # Rename columns to ensure consistency
            if date_col != standard_date_col or price_col != standard_price_col:
                df = df.copy()
                column_mapping = {date_col: standard_date_col, price_col: standard_price_col}
                df.rename(columns=column_mapping, inplace=True)
                date_col = standard_date_col
                price_col = standard_price_col
        
        return df, date_col, price_col
    
    def calculate_future_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        method: str = 'arithmetic',
        normalize: bool = True,
        vol_window: int = 20,
        min_periods: int = 5,
        min_return: Optional[float] = None,
        max_return: Optional[float] = None,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate future returns using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for future return calculation
            method: Return calculation method ('arithmetic' or 'log')
            normalize: Whether to normalize returns by volatility
            vol_window: Window size for volatility calculation
            min_periods: Minimum number of observations for volatility calculation
            min_return: Minimum return value (for winsorizing)
            max_return: Maximum return value (for winsorizing)
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated future returns
        """
        # Prepare data for BigQuery
        df, date_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL query for future returns
        sql_parts = []
        
        # Create CTE for future returns calculations
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTEs for each horizon's future returns
        for horizon in horizons:
            # Future return calculation SQL
            if method == 'arithmetic':
                return_expr = f"(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) - {price_col}) / {price_col}"
            else:  # log
                return_expr = f"LN(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) / {price_col})"
            
            # Apply winsorizing if specified
            if min_return is not None and max_return is not None:
                return_expr = f"LEAST(GREATEST({return_expr}, {min_return}), {max_return})"
            elif min_return is not None:
                return_expr = f"GREATEST({return_expr}, {min_return})"
            elif max_return is not None:
                return_expr = f"LEAST({return_expr}, {max_return})"
            
            # Add CTE for this horizon
            sql_parts.append(f"future_return_{horizon} AS (SELECT {date_col}, {return_expr} AS return_{horizon} FROM price_data)")
        
        # Join all return CTEs
        select_parts = [f"p.{date_col}"]
        join_parts = []
        
        for horizon in horizons:
            select_parts.append(f"fr{horizon}.return_{horizon}")
            join_parts.append(f"LEFT JOIN future_return_{horizon} fr{horizon} ON p.{date_col} = fr{horizon}.{date_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{date_col}
        """)
        
        # Complete SQL
        with_clauses = sql_parts[1:-1]  # Get all CTEs except the first 'WITH' and the last SELECT
        select_clause = sql_parts[-1]   # Get the final SELECT part
        if with_clauses:
            sql = f"{sql_parts[0]}\n, {', '.join(with_clauses)}\n{select_clause}"
        else:
            sql = f"{sql_parts[0]}\n{select_clause}"
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("future_returns")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
                
                # Set the date column as index for consistent return format
                if result is not None and not result.empty and 'ts' in result.columns:
                    result = result.set_index('ts')
                
                # Calculate normalized returns if requested
                if normalize and result is not None:
                    # Create volatility SQL query - Pandasと同様の実装
                    vol_sql = f"""
                    WITH price_data AS (SELECT * FROM `{table_id}`),
                    -- 日次リターンの計算（前日比）
                    daily_returns AS (
                        SELECT 
                            {date_col}, 
                            CASE 
                                WHEN {method == 'arithmetic'} 
                                THEN ({price_col} - LAG({price_col}) OVER (ORDER BY {date_col})) / LAG({price_col}) OVER (ORDER BY {date_col})
                                ELSE LN({price_col} / LAG({price_col}) OVER (ORDER BY {date_col}))
                            END AS daily_return_value
                        FROM price_data
                    ),
                    -- ローリングウィンドウによるボラティリティ計算
                    vol AS (
                        SELECT 
                            {date_col},
                            -- min_periodsパラメータを考慮した実装
                            CASE 
                                WHEN COUNT(daily_return_value) OVER (
                                    ORDER BY {date_col} 
                                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                                ) >= {min_periods}
                                THEN STDDEV(daily_return_value) OVER (
                                    ORDER BY {date_col} 
                                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                                )
                                ELSE NULL
                            END AS rolling_std
                        FROM daily_returns
                        WHERE daily_return_value IS NOT NULL
                    )
                    
                    SELECT {date_col}, rolling_std
                    FROM vol
                    ORDER BY {date_col}
                    """
                    
                    # Execute volatility query
                    vol_df = self.data_fetcher.execute_query(vol_sql)
                    
                    # Join volatility with returns and calculate normalized returns
                    if vol_df is not None and not vol_df.empty:
                        # Pandasの実装と同様のインデックス処理と結合ロジック
                        # 日付列がインデックスでなければインデックスに設定
                        if not isinstance(result.index, pd.DatetimeIndex) and date_col in result.columns:
                            result = result.set_index(date_col)
                        
                        if date_col in vol_df.columns:
                            vol_df = vol_df.set_index(date_col)
                        
                        # Pandasの実装と同様に、ボラティリティをリターンのインデックスに合わせる
                        result_with_vol = result.copy()
                        result_with_vol['rolling_std'] = vol_df['rolling_std']
                        
                        # Calculate normalized returns
                        for horizon in horizons:
                            col_name = f"return_{horizon}"
                            if col_name in result_with_vol.columns:
                                # Avoid division by zero - Pandasと同じロジック
                                rolling_std = result_with_vol['rolling_std'].fillna(1.0)
                                rolling_std = rolling_std.replace(0, 1.0)
                                
                                # Calculate normalized returns
                                result_with_vol[f"norm_future_return_{horizon}"] = result_with_vol[col_name] / rolling_std
                        
                        # Remove rolling_std column
                        if 'rolling_std' in result_with_vol.columns:
                            result_with_vol = result_with_vol.drop('rolling_std', axis=1)
                        
                        result = result_with_vol
        
            return result
            
        except Exception as e:
            logger.error(f"Error calculating future returns with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_future_returns_pandas
            return calculate_future_returns_pandas(
                prices=prices,
                horizons=horizons,
                method=method,
                normalize=normalize,
                vol_window=vol_window,
                min_periods=min_periods,
                min_return=min_return,
                max_return=max_return
            )
    
    def calculate_direction_labels(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        threshold: float = 0.0,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate direction labels using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for direction label calculation
            threshold: Threshold for determining direction
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated direction labels
        """
        # Prepare data for BigQuery
        df, date_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL for direction labels
        sql_parts = []
        
        # Create CTE for price data
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTEs for each horizon's direction
        for horizon in horizons:
            # Direction calculation SQL
            direction_expr = f"""
            CASE 
                WHEN (LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) - {price_col}) / {price_col} > {threshold} THEN 1
                ELSE -1
            END
            """
            
            # Add CTE for this horizon
            sql_parts.append(f"direction_{horizon} AS (SELECT {date_col}, {direction_expr} AS direction_{horizon} FROM price_data)")
        
        # Join all direction CTEs
        select_parts = [f"p.{date_col}"]
        join_parts = []
        
        for horizon in horizons:
            select_parts.append(f"d{horizon}.direction_{horizon}")
            join_parts.append(f"LEFT JOIN direction_{horizon} d{horizon} ON p.{date_col} = d{horizon}.{date_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{date_col}
        """)
        
        # Complete SQL
        with_clauses = sql_parts[1:-1]  # Get all CTEs except the first 'WITH' and the last SELECT
        select_clause = sql_parts[-1]   # Get the final SELECT part
        if with_clauses:
            sql = f"{sql_parts[0]}\n, {', '.join(with_clauses)}\n{select_clause}"
        else:
            sql = f"{sql_parts[0]}\n{select_clause}"
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("direction_labels")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
            
            return result
            
        except Exception as e:
            logger.error(f"Error calculating direction labels with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_direction_labels_pandas
            return calculate_direction_labels_pandas(
                prices=prices,
                horizons=horizons,
                threshold=threshold
            )
    
    def calculate_volatility_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        vol_window: int = 20,
        method: str = 'arithmetic',
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate volatility-adjusted returns using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for return calculation
            vol_window: Window size for volatility calculation
            method: Return calculation method ('arithmetic' or 'log')
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated volatility-adjusted returns
        """
        # Prepare data for BigQuery
        df, date_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL for volatility-adjusted returns
        sql_parts = []
        
        # Create CTE for price data
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTE for past returns
        if method == 'arithmetic':
            return_expr = f"({price_col} - LAG({price_col}) OVER (ORDER BY {date_col})) / LAG({price_col}) OVER (ORDER BY {date_col})"
        else:  # log
            return_expr = f"LN({price_col} / LAG({price_col}) OVER (ORDER BY {date_col}))"
        
        sql_parts.append(f"past_returns AS (SELECT {date_col}, {return_expr} AS return_value FROM price_data)")
        
        # Create CTE for volatility
        sql_parts.append(f"""
        volatility AS (
            SELECT 
                {date_col},
                STDDEV(return_value) OVER (
                    ORDER BY {date_col} 
                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                ) AS rolling_std
            FROM past_returns
            WHERE return_value IS NOT NULL
        )
        """)
        
        # Create CTEs for each horizon's future returns
        for horizon in horizons:
            # Future return calculation SQL
            if method == 'arithmetic':
                future_return_expr = f"(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) - {price_col}) / {price_col}"
            else:  # log
                future_return_expr = f"LN(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) / {price_col})"
            
            # Add CTE for this horizon
            sql_parts.append(f"future_return_{horizon} AS (SELECT {date_col}, {future_return_expr} AS return_{horizon} FROM price_data)")
        
        # Join all CTEs for volatility-adjusted returns
        select_parts = [f"p.{date_col}"]
        join_parts = [f"LEFT JOIN volatility v ON p.{date_col} = v.{date_col}"]
        
        for horizon in horizons:
            select_parts.append(f"""
            CASE 
                WHEN v.rolling_std IS NULL OR v.rolling_std = 0 THEN NULL
                ELSE fr{horizon}.return_{horizon} / v.rolling_std 
            END AS vol_adj_return_{horizon}
            """)
            join_parts.append(f"LEFT JOIN future_return_{horizon} fr{horizon} ON p.{date_col} = fr{horizon}.{date_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{date_col}
        """)
        
        # Complete SQL
        with_clauses = sql_parts[1:-1]  # Get all CTEs except the first 'WITH' and the last SELECT
        select_clause = sql_parts[-1]   # Get the final SELECT part
        if with_clauses:
            sql = f"{sql_parts[0]}\n, {', '.join(with_clauses)}\n{select_clause}"
        else:
            sql = f"{sql_parts[0]}\n{select_clause}"
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("volatility_adjusted_returns")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
                
                # Set the date column as index for consistent return format
                if result is not None and not result.empty and 'ts' in result.columns:
                    result = result.set_index('ts')
            
            return result
            
        except Exception as e:
            logger.error(f"Error calculating volatility-adjusted returns with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_volatility_adjusted_returns_pandas
            return calculate_volatility_adjusted_returns_pandas(
                prices=prices,
                horizons=horizons,
                vol_window=vol_window,
                method=method
            )
    
    def calculate_risk_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        risk_window: int = 60,
        method: str = 'arithmetic',
        risk_free_rate: float = 0.0,
        min_periods: int = 20,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate risk-adjusted returns (Sharpe ratio) using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for return calculation
            risk_window: Window size for risk calculation
            method: Return calculation method ('arithmetic' or 'log')
            risk_free_rate: Risk-free rate for Sharpe ratio calculation
            min_periods: Minimum number of observations for risk calculation
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated risk-adjusted returns
        """
        # For Sharpe ratio calculation, first calculate future returns
        future_returns = self.calculate_future_returns(
            prices=prices,
            horizons=horizons,
            method=method,
            normalize=False,
            date_column=date_column,
            price_column=price_column
        )
        
        # Convert future returns to BigQuery for Sharpe ratio calculation
        if future_returns is not None and not future_returns.empty:
            try:
                # Load future returns to BigQuery
                with self.table_manager as manager:
                    table_id = manager.create_temp_table_id("risk_adjusted_returns")
                    manager.load_dataframe(future_returns, table_id)
                
                # Convert horizons to list if needed
                if isinstance(horizons, int):
                    horizons = [horizons]
                
                # Create SQL for Sharpe ratio calculation
                sql_parts = []
                
                # Create CTE for returns data
                sql_parts.append(f"WITH returns_data AS (SELECT * FROM `{table_id}`)")
                
                # Create CTEs for each horizon's Sharpe ratio
                for horizon in horizons:
                    return_col = f"return_{horizon}"
                    
                    # Skip if return column doesn't exist
                    if return_col not in future_returns.columns:
                        continue
                    
                    # Create CTE for rolling stats
                    sql_parts.append(f"""
                    sharpe_{horizon} AS (
                        SELECT 
                            *,
                            AVG({return_col}) OVER (
                                ORDER BY {future_returns.columns[0]} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS rolling_mean_{horizon},
                            STDDEV({return_col}) OVER (
                                ORDER BY {future_returns.columns[0]} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS rolling_std_{horizon},
                            COUNT({return_col}) OVER (
                                ORDER BY {future_returns.columns[0]} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS rolling_count_{horizon}
                        FROM returns_data
                    )
                    """)
                
                # Join all Sharpe ratio CTEs
                select_parts = [f"s1.{future_returns.columns[0]}"]
                
                for horizon in horizons:
                    return_col = f"return_{horizon}"
                    
                    # Skip if return column doesn't exist
                    if return_col not in future_returns.columns:
                        continue
                    
                    select_parts.append(f"""
                    CASE 
                        WHEN s{horizon}.rolling_count_{horizon} < {min_periods} THEN NULL
                        WHEN s{horizon}.rolling_std_{horizon} IS NULL OR s{horizon}.rolling_std_{horizon} = 0 THEN NULL
                        ELSE (s{horizon}.rolling_mean_{horizon} - {risk_free_rate}) / s{horizon}.rolling_std_{horizon}
                    END AS sharpe_{horizon}
                    """)
                
                if len(horizons) > 1:
                    join_parts = []
                    for i, horizon in enumerate(horizons[1:], 2):
                        return_col = f"return_{horizon}"
                        
                        # Skip if return column doesn't exist
                        if return_col not in future_returns.columns:
                            continue
                        
                        join_parts.append(f"LEFT JOIN sharpe_{horizon} s{i} ON s1.{future_returns.columns[0]} = s{i}.{future_returns.columns[0]}")
                    
                    # Create the main query for multiple horizons
                    sql_parts.append(f"""
                    SELECT 
                        {', '.join(select_parts)}
                    FROM sharpe_{horizons[0]} s1
                    {' '.join(join_parts)}
                    ORDER BY s1.{future_returns.columns[0]}
                    """)
                else:
                    # Create the main query for single horizon
                    sql_parts.append(f"""
                    SELECT 
                        {', '.join(select_parts)}
                    FROM sharpe_{horizons[0]} s1
                    ORDER BY s1.{future_returns.columns[0]}
                    """)
                
                # Complete SQL
                sql = '\n, '.join(sql_parts)
                
                # Execute query
                result = self.data_fetcher.execute_query(sql)
                
                # Set the date column as index for consistent return format
                if result is not None and not result.empty and 'ts' in result.columns:
                    result = result.set_index('ts')
                
                return result
                
            except Exception as e:
                logger.error(f"Error calculating risk-adjusted returns with BigQuery: {e}")
        
        # Fallback to pandas implementation
        from .pandas_adapter import calculate_risk_adjusted_returns_pandas
        return calculate_risk_adjusted_returns_pandas(
            prices=prices,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods
        )

# Export adapter functions that use the service
def calculate_future_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: Optional[float] = None,
    max_return: Optional[float] = None,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate future returns using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for future return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value (for winsorizing)
        max_return: Maximum return value (for winsorizing)
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated future returns
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_future_returns_pandas
        return calculate_future_returns_pandas(
            prices=prices,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return
        )
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_future_returns(
        prices=prices,
        horizons=horizons,
        method=method,
        normalize=normalize,
        vol_window=vol_window,
        min_periods=min_periods,
        min_return=min_return,
        max_return=max_return,
        date_column=date_column,
        price_column=price_column
    )

def calculate_direction_labels_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate direction labels using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated direction labels
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_direction_labels_pandas
        return calculate_direction_labels_pandas(prices, horizons, threshold)
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_direction_labels(
        prices=prices,
        horizons=horizons,
        threshold=threshold,
        date_column=date_column,
        price_column=price_column
    )

def calculate_volatility_adjusted_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate volatility-adjusted returns using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_volatility_adjusted_returns_pandas
        return calculate_volatility_adjusted_returns_pandas(prices, horizons, vol_window, method)
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_volatility_adjusted_returns(
        prices=prices,
        horizons=horizons,
        vol_window=vol_window,
        method=method,
        date_column=date_column,
        price_column=price_column
    )

def calculate_risk_adjusted_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate risk-adjusted returns (Sharpe ratio) using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated risk-adjusted returns
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_risk_adjusted_returns_pandas
        return calculate_risk_adjusted_returns_pandas(
            prices=prices,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods
        )
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_risk_adjusted_returns(
        prices=prices,
        horizons=horizons,
        risk_window=risk_window,
        method=method,
        risk_free_rate=risk_free_rate,
        min_periods=min_periods,
        date_column=date_column,
        price_column=price_column
    ) 