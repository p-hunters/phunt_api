"""
BigQuery adapter for return target calculations

This module provides BigQuery-based implementations for return target calculations.
It leverages SQL-based processing for efficient calculations on large datasets.
"""

from typing import Union, List, Optional
import pandas as pd
import polars as pl
import numpy as np
import logging
import os
# Import necessary BigQuery services and utilities
from phunt_api.misc.bq import (
    BIGQUERY_AVAILABLE,
    BigQueryConfig,
    BigQueryTableManager,
    BigQueryDataFetcher
)

# Set up logger
logger = logging.getLogger(__name__)

class BigQueryReturnTargetService:
    """
    Service for calculating return targets using BigQuery
    """
    
    def __init__(
        self,
        project_id: Optional[str] = None,
        dataset_id: str = "phunt_api",
        location: str = "asia-northeast1",
        **kwargs
    ):
        """
        Initialize the BigQuery service
        
        Args:
            project_id: Google Cloud project ID
            dataset_id: BigQuery dataset ID
            location: BigQuery dataset location
            **kwargs: Additional options
        """
        if project_id is None:
            project_id = os.environ.get('gcp_project_id')
        # Initialize BigQuery config
        self.config = BigQueryConfig(
            project_id=project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        # Create BigQuery components
        self.table_manager = BigQueryTableManager(config=self.config)
        self.data_fetcher = BigQueryDataFetcher(config=self.config)
    
    @staticmethod
    def _prepare_data_static(
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> tuple:
        """
        静的メソッド: データの準備とカラムの特定
        
        Args:
            prices: 価格データ
            date_column: 日付カラム名
            price_column: 価格カラム名
            
        Returns:
            (データフレーム, 日付カラム名, 価格カラム名)のタプル
        """
        logger = logging.getLogger(__name__)
        logger.debug("データ準備（静的メソッド）: 入力データの型を確認")
        
        # Convert to pandas DataFrame
        if isinstance(prices, pl.Series):
            df = prices.to_pandas().to_frame()
        elif isinstance(prices, pl.DataFrame):
            df = prices.to_pandas()
        elif isinstance(prices, pd.Series):
            df = prices.to_frame()
        elif isinstance(prices, pd.DataFrame):
            df = prices.copy()
        else:
            logger.error(f"データ準備（静的メソッド）: サポートされていない入力型: {type(prices)}")
            raise ValueError(f"サポートされていない入力型: {type(prices)}")
            
        # 日付カラムの特定
        ts_col = None
        if date_column is not None and date_column in df.columns:
            ts_col = date_column
            logger.debug(f"データ準備（静的メソッド）: 指定された日付カラム '{ts_col}' を使用")
        else:
            # 一般的な日付カラム名を確認
            common_date_cols = ['ts', 'date', 'timestamp', 'time', 'datetime', 'dt']
            for col in common_date_cols:
                if col in df.columns:
                    ts_col = col
                    logger.debug(f"データ準備（静的メソッド）: 日付カラム '{ts_col}' を自動検出")
                    break
            
            # 見つからなかった場合、日付型のカラムを探す
            if ts_col is None:
                for col in df.columns:
                    if pd.api.types.is_datetime64_any_dtype(df[col]):
                        ts_col = col
                        logger.debug(f"データ準備（静的メソッド）: データ型による日付カラム '{ts_col}' を検出")
                        break
            
            # それでも見つからない場合、最初のカラムを使用
            if ts_col is None and len(df.columns) > 0:
                ts_col = df.columns[0]
                logger.warning(f"データ準備（静的メソッド）: 日付カラムが見つからないため、最初のカラム '{ts_col}' を使用")
        
        # 価格カラムの特定
        price_col = None
        if price_column is not None and price_column in df.columns:
            price_col = price_column
            logger.debug(f"データ準備（静的メソッド）: 指定された価格カラム '{price_col}' を使用")
        else:
            # 一般的な価格カラム名を確認
            common_price_cols = ['close', 'price', 'value', 'adj_close', 'adjusted_close']
            for col in common_price_cols:
                if col in df.columns:
                    price_col = col
                    logger.debug(f"データ準備（静的メソッド）: 価格カラム '{price_col}' を自動検出")
                    break
            
            # 見つからなかった場合、数値型の最初のカラムを使用（日付カラム以外）
            if price_col is None:
                for col in df.columns:
                    if col != ts_col and pd.api.types.is_numeric_dtype(df[col]):
                        price_col = col
                        logger.debug(f"データ準備（静的メソッド）: データ型による価格カラム '{price_col}' を検出")
                        break
            
            # それでも見つからない場合、日付カラム以外の最初のカラムを使用
            if price_col is None:
                for col in df.columns:
                    if col != ts_col:
                        price_col = col
                        logger.warning(f"データ準備（静的メソッド）: 価格カラムが見つからないため、カラム '{price_col}' を使用")
                        break
        
        logger.info(f"データ準備（静的メソッド）: 日付カラム='{ts_col}', 価格カラム='{price_col}', データシェイプ={df.shape}")
        
        if ts_col == price_col:
            logger.error(f"データ準備（静的メソッド）: 日付カラムと価格カラムが同じです。日付カラムを使用します。")
            raise ValueError(f"日付カラムと価格カラムが同じです。設定を見直してください。")
        
        return df, ts_col, price_col
    
    def _prepare_data(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> tuple:
        """
        Prepare data and identify columns
        
        Args:
            prices: Price data
            date_column: Date column name
            price_column: Price column name
            
        Returns:
            Tuple of (dataframe, date_column, price_column)
        """
        logger = logging.getLogger(__name__)
        logger.debug("データ準備: 入力データの型を確認")
        
        # Handle pandas Series
        if isinstance(prices, pd.Series):
            # Create DataFrame with proper index
            df = pd.DataFrame({price_column or 'price': prices})
            if prices.index.name:
                df.index.name = prices.index.name
            else:
                df.index.name = date_column or 'ts'
            df = df.reset_index()
            
            # Set column names
            date_col = df.columns[0]  # インデックスから変換された列
            price_col = price_column or 'price'
            
        # Handle pandas DataFrame
        elif isinstance(prices, pd.DataFrame):
            # インデックスが日付型で名前がある場合、それを列に変換
            if isinstance(prices.index, pd.DatetimeIndex) and prices.index.name:
                df = prices.reset_index()
                date_col = prices.index.name
            else:
                df = prices.copy()
                # インデックスが日付型だが名前がない場合
                if isinstance(prices.index, pd.DatetimeIndex):
                    df = prices.reset_index()
                    date_col = date_column or 'ts'
                    df.rename(columns={'index': date_col}, inplace=True)
                else:
                    # 通常のDataFrame
                    date_col = date_column or ('ts' if 'ts' in df.columns else df.columns[0])
            
            price_col = price_column or ('close' if 'close' in df.columns else 
                                       (df.columns[1] if len(df.columns) > 1 else df.columns[0]))
            
        # Handle polars Series
        elif isinstance(prices, pl.Series):
            # Create DataFrame with proper index
            df = pl.DataFrame({price_column or 'price': prices})
            # Add index column
            df = df.with_row_index(date_column or 'ts')
            
            # Set column names
            date_col = date_column or 'ts'
            price_col = price_column or 'price'
            
            # Convert to pandas for BigQuery
            df = df.to_pandas()
            
        # Handle polars DataFrame
        else:  # pl.DataFrame
            # Convert to pandas for BigQuery
            df = prices.to_pandas()
            
            # Determine column names
            date_col = date_column or ('ts' if 'ts' in df.columns else df.columns[0])
            price_col = price_column or ('close' if 'close' in df.columns else 
                                       (df.columns[1] if len(df.columns) > 1 else df.columns[0]))
        
        logger.info(f"データ準備: 日付カラム='{date_col}', 価格カラム='{price_col}', データシェイプ={df.shape}")
        
        # 日付カラムと価格カラムが同じ場合はエラー
        if date_col == price_col and len(df.columns) > 1:
            logger.warning(f"データ準備: 日付カラム '{date_col}' と価格カラム '{price_col}' が同じです。別のカラムを選択します。")
            for col in df.columns:
                if col != date_col:
                    price_col = col
                    logger.info(f"データ準備: 新しい価格カラム '{price_col}' を選択しました")
                    break
        
        return df, date_col, price_col
    
    def calculate_future_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        method: str = 'arithmetic',
        normalize: bool = True,
        vol_window: int = 20,
        min_periods: int = 5,
        min_return: Optional[float] = None,
        max_return: Optional[float] = None,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate future returns using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for future return calculation
            method: Return calculation method ('arithmetic' or 'log')
            normalize: Whether to normalize returns by volatility
            vol_window: Window size for volatility calculation
            min_periods: Minimum number of observations for volatility calculation
            min_return: Minimum return value (for winsorizing)
            max_return: Maximum return value (for winsorizing)
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated future returns
        """
        # Prepare data for BigQuery
        df, ts_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL query for future returns
        sql_parts = []
        
        # Create CTE for future returns calculations
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTEs for each horizon's future returns
        for horizon in horizons:
            # Future return calculation SQL
            if method == 'arithmetic':
                return_expr = f"(LEAD({price_col}, {horizon}) OVER (ORDER BY {ts_col}) - {price_col}) / {price_col}"
            else:  # log
                return_expr = f"LN(LEAD({price_col}, {horizon}) OVER (ORDER BY {ts_col}) / {price_col})"
            
            # Apply winsorizing if specified
            if min_return is not None and max_return is not None:
                return_expr = f"LEAST(GREATEST({return_expr}, {min_return}), {max_return})"
            elif min_return is not None:
                return_expr = f"GREATEST({return_expr}, {min_return})"
            elif max_return is not None:
                return_expr = f"LEAST({return_expr}, {max_return})"
            
            # Add CTE for this horizon
            sql_parts.append(f"future_return_{horizon} AS (SELECT {ts_col}, {return_expr} AS return_{horizon} FROM price_data)")
        
        # Join all return CTEs
        select_parts = [f"p.{ts_col}"]
        join_parts = []
        
        for horizon in horizons:
            select_parts.append(f"fr{horizon}.return_{horizon}")
            join_parts.append(f"LEFT JOIN future_return_{horizon} fr{horizon} ON p.{ts_col} = fr{horizon}.{ts_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{ts_col}
        """)
        
        # Complete SQL
        sql = construct_query(sql_parts)
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("future_returns")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
                
                # Set the date column as index for consistent return format
                if result is not None and not result.empty and 'ts' in result.columns:
                    result = result.set_index('ts')
                
                # Calculate normalized returns if requested
                if normalize and result is not None:
                    # Create volatility SQL query - Pandasと同様の実装
                    vol_sql = f"""
                    WITH price_data AS (SELECT * FROM `{table_id}`),
                    -- 日次リターンの計算（前日比）
                    daily_returns AS (
                        SELECT 
                            {ts_col}, 
                            CASE 
                                WHEN {method == 'arithmetic'} 
                                THEN ({price_col} - LAG({price_col}) OVER (ORDER BY {ts_col})) / LAG({price_col}) OVER (ORDER BY {ts_col})
                                ELSE LN({price_col} / LAG({price_col}) OVER (ORDER BY {ts_col}))
                            END AS daily_return_value
                        FROM price_data
                    ),
                    -- ローリングウィンドウによるボラティリティ計算
                    vol AS (
                        SELECT 
                            {ts_col},
                            -- min_periodsパラメータを考慮した実装
                            CASE 
                                WHEN COUNT(daily_return_value) OVER (
                                    ORDER BY {ts_col} 
                                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                                ) >= {min_periods}
                                THEN STDDEV(daily_return_value) OVER (
                                    ORDER BY {ts_col} 
                                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                                )
                                ELSE NULL
                            END AS rolling_std
                        FROM daily_returns
                        WHERE daily_return_value IS NOT NULL
                    )
                    
                    SELECT {ts_col}, rolling_std
                    FROM vol
                    ORDER BY {ts_col}
                    """
                    
                    # Execute volatility query
                    vol_df = self.data_fetcher.execute_query(vol_sql)
                    
                    # Join volatility with returns and calculate normalized returns
                    if vol_df is not None and not vol_df.empty:
                        # Pandasの実装と同様のインデックス処理と結合ロジック
                        # 日付列がインデックスでなければインデックスに設定
                        if not isinstance(result.index, pd.DatetimeIndex) and ts_col in result.columns:
                            result = result.set_index(ts_col)
                        
                        if ts_col in vol_df.columns:
                            vol_df = vol_df.set_index(ts_col)
                        
                        # Pandasの実装と同様に、ボラティリティをリターンのインデックスに合わせる
                        result_with_vol = result.copy()
                        result_with_vol['rolling_std'] = vol_df['rolling_std']
                        
                        # Calculate normalized returns
                        for horizon in horizons:
                            col_name = f"return_{horizon}"
                            if col_name in result_with_vol.columns:
                                # Avoid division by zero - Pandasと同じロジック
                                rolling_std = result_with_vol['rolling_std'].fillna(1.0)
                                rolling_std = rolling_std.replace(0, 1.0)
                                
                                # Calculate normalized returns
                                result_with_vol[f"norm_future_return_{horizon}"] = result_with_vol[col_name] / rolling_std
                        
                        # Remove rolling_std column
                        if 'rolling_std' in result_with_vol.columns:
                            result_with_vol = result_with_vol.drop('rolling_std', axis=1)
                        
                        result = result_with_vol
        
            return result
            
        except Exception as e:
            logger.error(f"Error calculating future returns with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_future_returns_pandas
            return calculate_future_returns_pandas(
                prices=prices,
                horizons=horizons,
                method=method,
                normalize=normalize,
                vol_window=vol_window,
                min_periods=min_periods,
                min_return=min_return,
                max_return=max_return
            )
    
    def calculate_direction_labels(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        threshold: float = 0.0,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate direction labels using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for direction label calculation
            threshold: Threshold for determining direction
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated direction labels
        """
        # Prepare data for BigQuery
        df, date_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL for direction labels
        sql_parts = []
        
        # Create CTE for price data
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTEs for each horizon's direction
        for horizon in horizons:
            # Direction calculation SQL
            direction_expr = f"""
            CASE 
                WHEN (LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) - {price_col}) / {price_col} > {threshold} THEN 1
                ELSE -1
            END
            """
            
            # Add CTE for this horizon
            sql_parts.append(f"direction_{horizon} AS (SELECT {date_col}, {direction_expr} AS direction_{horizon} FROM price_data)")
        
        # Join all direction CTEs
        select_parts = [f"p.{date_col}"]
        join_parts = []
        
        for horizon in horizons:
            select_parts.append(f"d{horizon}.direction_{horizon}")
            join_parts.append(f"LEFT JOIN direction_{horizon} d{horizon} ON p.{date_col} = d{horizon}.{date_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{date_col}
        """)
        
        # Complete SQL
        sql = construct_query(sql_parts)
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("direction_labels")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
            
            return result
            
        except Exception as e:
            logger.error(f"Error calculating direction labels with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_direction_labels_pandas
            return calculate_direction_labels_pandas(
                prices=prices,
                horizons=horizons,
                threshold=threshold
            )
    
    def calculate_volatility_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        vol_window: int = 20,
        method: str = 'arithmetic',
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate volatility-adjusted returns using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for return calculation
            vol_window: Window size for volatility calculation
            method: Return calculation method ('arithmetic' or 'log')
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated volatility-adjusted returns
        """
        # Prepare data for BigQuery
        df, date_col, price_col = self._prepare_data(prices, date_column, price_column)
        
        # Convert horizons to list if needed
        if isinstance(horizons, int):
            horizons = [horizons]
        
        # Create SQL for volatility-adjusted returns
        sql_parts = []
        
        # Create CTE for price data
        sql_parts.append(f"WITH price_data AS (SELECT * FROM `{{table_id}}`)")
        
        # Create CTE for past returns
        if method == 'arithmetic':
            return_expr = f"({price_col} - LAG({price_col}) OVER (ORDER BY {date_col})) / LAG({price_col}) OVER (ORDER BY {date_col})"
        else:  # log
            return_expr = f"LN({price_col} / LAG({price_col}) OVER (ORDER BY {date_col}))"
        
        sql_parts.append(f"past_returns AS (SELECT {date_col}, {return_expr} AS return_value FROM price_data)")
        
        # Create CTE for volatility
        sql_parts.append(f"""
        volatility AS (
            SELECT 
                {date_col},
                STDDEV(return_value) OVER (
                    ORDER BY {date_col} 
                    ROWS BETWEEN {vol_window-1} PRECEDING AND CURRENT ROW
                ) AS rolling_std
            FROM past_returns
            WHERE return_value IS NOT NULL
        )
        """)
        
        # Create CTEs for each horizon's future returns
        for horizon in horizons:
            # Future return calculation SQL
            if method == 'arithmetic':
                future_return_expr = f"(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) - {price_col}) / {price_col}"
            else:  # log
                future_return_expr = f"LN(LEAD({price_col}, {horizon}) OVER (ORDER BY {date_col}) / {price_col})"
            
            # Add CTE for this horizon
            sql_parts.append(f"future_return_{horizon} AS (SELECT {date_col}, {future_return_expr} AS return_{horizon} FROM price_data)")
        
        # Join all CTEs for volatility-adjusted returns
        select_parts = [f"p.{date_col}"]
        join_parts = [f"LEFT JOIN volatility v ON p.{date_col} = v.{date_col}"]
        
        for horizon in horizons:
            select_parts.append(f"""
            CASE 
                WHEN v.rolling_std IS NULL OR v.rolling_std = 0 THEN NULL
                ELSE fr{horizon}.return_{horizon} / v.rolling_std 
            END AS vol_adj_return_{horizon}
            """)
            join_parts.append(f"LEFT JOIN future_return_{horizon} fr{horizon} ON p.{date_col} = fr{horizon}.{date_col}")
        
        # Create the main query
        sql_parts.append(f"""
        SELECT 
            {', '.join(select_parts)}
        FROM price_data p
        {' '.join(join_parts)}
        ORDER BY p.{date_col}
        """)
        
        # Complete SQL
        sql = construct_query(sql_parts)
        
        try:
            # Use BigQuery to process data
            with self.table_manager as manager:
                # Create temp table ID and load data into BigQuery
                table_id = manager.create_temp_table_id("volatility_adjusted_returns")
                manager.load_dataframe(df, table_id)
                
                # Execute query with table ID placeholder
                formatted_sql = sql.format(table_id=table_id)
                result = self.data_fetcher.execute_query(formatted_sql)
                
                # Set the date column as index for consistent return format
                if result is not None and not result.empty and 'ts' in result.columns:
                    result = result.set_index('ts')
            
            return result
            
        except Exception as e:
            logger.error(f"Error calculating volatility-adjusted returns with BigQuery: {e}")
            # Fallback to pandas implementation
            from .pandas_adapter import calculate_volatility_adjusted_returns_pandas
            return calculate_volatility_adjusted_returns_pandas(
                prices=prices,
                horizons=horizons,
                vol_window=vol_window,
                method=method
            )
    
    def calculate_risk_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        risk_window: int = 60,
        method: str = 'arithmetic',
        risk_free_rate: float = 0.0,
        min_periods: int = 20,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate risk-adjusted returns (Sharpe ratio) using BigQuery
        
        Args:
            prices: Price data
            horizons: Horizons for return calculation
            risk_window: Window size for risk calculation
            method: Return calculation method ('arithmetic' or 'log')
            risk_free_rate: Risk-free rate for Sharpe ratio calculation
            min_periods: Minimum number of observations for risk calculation
            date_column: Column name for date
            price_column: Column name for price
            
        Returns:
            DataFrame with calculated risk-adjusted returns
        """
        # ロガーの初期化
        logger = logging.getLogger(__name__)
        logger.info("リスク調整済みリターン計算（独立関数）: BigQueryを使用して計算を開始")
        
        # データの準備とタイムスタンプカラムの特定
        try:
            # BigQueryサービスの初期化
            service = BigQueryReturnTargetService(
                project_id=self.config.project_id,
                dataset_id=self.config.dataset_id,
                location=self.config.location,
                **self.config.kwargs
            )
            
            # データの準備：常にインスタンスメソッドを使用
            prices_df, ts_col, price_col = service._prepare_data(prices, date_column, price_column)
            logger.info(f"リスク調整済みリターン計算（独立関数）: サービスでデータを準備 ({len(prices_df)}行)")
            
            # タイムスタンプカラムが存在することを確認
            if ts_col not in prices_df.columns:
                logger.error(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム '{ts_col}' が入力データに存在しません")
                logger.error(f"リスク調整済みリターン計算（独立関数）: 入力データの列: {list(prices_df.columns)}")
                return pd.DataFrame()
            
            # タイムスタンプをバックアップ
            original_timestamps = prices_df[ts_col].copy()
            logger.debug(f"リスク調整済みリターン計算（独立関数）: タイムスタンプをバックアップ（{len(original_timestamps)}行）")
            
            # まず未来リターンを計算（修正版）
            future_returns = calculate_future_returns_bigquery(
                prices=prices_df,
                horizons=horizons,
                method=method,
                normalize=False,  # リスク調整済みリターンにはノーマライズしない未加工のリターンが必要
                date_column=ts_col,
                price_column=price_col,
                project_id=self.config.project_id,
                dataset_id=self.config.dataset_id,
                location=self.config.location,
                **self.config.kwargs
            )
            
            if future_returns is None or future_returns.empty:
                logger.warning("リスク調整済みリターン計算（独立関数）: 未来リターンの計算に失敗しました")
                return pd.DataFrame()
            
            # タイムスタンプカラムが結果に含まれているか確認
            # 含まれていない場合は追加
            if ts_col not in future_returns.columns:
                logger.info(f"リスク調整済みリターン計算（独立関数）: 未来リターンにタイムスタンプカラムを追加 ({ts_col})")
                if len(original_timestamps) == len(future_returns):
                    future_returns[ts_col] = original_timestamps.values
                    # タイムスタンプカラムを最初の列に移動
                    cols = [ts_col] + [col for col in future_returns.columns if col != ts_col]
                    future_returns = future_returns[cols]
                else:
                    logger.warning(f"リスク調整済みリターン計算（独立関数）: 行数が一致しません（元={len(original_timestamps)}、リターン={len(future_returns)}）")
            
            # BigQueryサービスの初期化
            service = BigQueryReturnTargetService(
                project_id=self.config.project_id,
                dataset_id=self.config.dataset_id,
                location=self.config.location,
                **self.config.kwargs
            )
            
            # データセット存在確認
            dataset_id_full = f"{service.config.project_id}.{service.config.dataset_id}"
            try:
                service.data_fetcher.client.get_dataset(dataset_id_full)
                logger.info(f"リスク調整済みリターン計算（独立関数）: データセット '{dataset_id_full}' が存在することを確認")
            except Exception as e:
                logger.warning(f"リスク調整済みリターン計算（独立関数）: データセット '{dataset_id_full}' が見つかりません: {e}")
                return pd.DataFrame()
            
            # 一時テーブルの作成とデータのロード
            try:
                # タイムスタンプベースの一時テーブル名
                table_id = service.table_manager.create_temp_table_id("risk_adjusted_returns")
                logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を作成")
                
                # タイムスタンプカラムに関する情報をログ
                logger.info(f"リスク調整済みリターン計算（独立関数）: future_returns の列: {future_returns.columns.tolist()}")
                logger.info(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム: {ts_col}")
                
                # 一時テーブルにデータをロード
                service.table_manager.load_dataframe(future_returns, table_id)
                logger.info(f"リスク調整済みリターン計算（独立関数）: データを一時テーブル '{table_id}' にロード (行数: {len(future_returns)})")
                
                # horizonsを確実にリストに変換
                horizons_list = horizons if isinstance(horizons, list) else [horizons]
                
                # CTEパーツの初期化
                cte_parts = []
                
                # タイムスタンプカラムの特定 - 名前で明示的に確認
                if ts_col not in future_returns.columns:
                    # タイムスタンプカラムが見つからない場合はエラー
                    logger.error(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム '{ts_col}' が未来リターンに存在しません")
                    logger.error(f"リスク調整済みリターン計算（独立関数）: 未来リターンの列: {future_returns.columns.tolist()}")
                    
                    # 代替手段：カラム名を探す
                    if 'ts' in future_returns.columns:
                        ts_col = 'ts'
                        logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'ts' を使用")
                    elif 'date' in future_returns.columns:
                        ts_col = 'date'
                        logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'date' を使用")
                    elif 'timestamp' in future_returns.columns:
                        ts_col = 'timestamp'
                        logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'timestamp' を使用")
                    else:
                        # カラムのデータ型を確認して、日付型の列を探す
                        for col in future_returns.columns:
                            if pd.api.types.is_datetime64_any_dtype(future_returns[col]):
                                ts_col = col
                                logger.info(f"リスク調整済みリターン計算（独立関数）: 日付型カラム '{col}' を使用")
                                break
                        
                        if ts_col is None:
                            # 日付型のカラムが見つからなかった場合、最初のカラムをタイムスタンプとして使用（緊急措置）
                            ts_col = future_returns.columns[0]
                            logger.warning(f"リスク調整済みリターン計算（独立関数）: 日付型カラムが見つからないため、最初のカラム '{ts_col}' を使用")
                
                logger.info(f"リスク調整済みリターン計算（独立関数）: 時系列カラム = {ts_col}")
                
                # ソースデータのCTE - テーブル参照の形式を修正
                # table_id に既にデータセット名が含まれている場合は調整
                if '.' in table_id:
                    # table_id が 'dataset.table' 形式の場合
                    table_ref = f"{service.config.project_id}.{table_id}"
                else:
                    # table_id が単なるテーブル名の場合
                    table_ref = f"{service.config.project_id}.{service.config.dataset_id}.{table_id}"
                
                # データセット名が重複していないことを確認
                if f"{service.config.project_id}.{service.config.dataset_id}.{service.config.dataset_id}" in table_ref:
                    table_ref = table_ref.replace(
                        f"{service.config.project_id}.{service.config.dataset_id}.{service.config.dataset_id}",
                        f"{service.config.project_id}.{service.config.dataset_id}"
                    )
                    logger.warning(f"リスク調整済みリターン計算（独立関数）: テーブル参照の重複を修正")
                
                # 最終的なテーブル参照をログ出力
                logger.info(f"リスク調整済みリターン計算（独立関数）: テーブル参照 = {table_ref}")
                
                cte_parts.append(f"""
                source_data AS (
                  SELECT * FROM `{table_ref}`
                )""")
                
                # 各horizonごとにCTEを作成
                valid_horizons = []
                for horizon in horizons_list:
                    return_col = f"return_{horizon}"
                    
                    # リターンカラムが存在しなければスキップ
                    if return_col not in future_returns.columns:
                        logger.warning(f"リスク調整済みリターン計算（独立関数）: カラム '{return_col}' が見つかりません")
                        continue
                    
                    valid_horizons.append(horizon)
                    logger.info(f"リスク調整済みリターン計算（独立関数）: horizon={horizon}, return_col={return_col}, ts_col={ts_col}")
                    
                    # 各horizonのSharpe比計算用CTE - 必ず時系列カラムでソート
                    cte_parts.append(f"""
                    horizon_{horizon} AS (
                        SELECT 
                            *,
                            AVG({return_col}) OVER (
                                ORDER BY {ts_col} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS mean_{horizon},
                            STDDEV({return_col}) OVER (
                                ORDER BY {ts_col} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS std_{horizon},
                            COUNT({return_col}) OVER (
                                ORDER BY {ts_col} 
                                ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                            ) AS count_{horizon}
                        FROM source_data
                    )""")
                
                # 有効なhorizonがなければ終了
                if not valid_horizons:
                    logger.warning("リスク調整済みリターン計算（独立関数）: 有効なhorizonが見つかりません")
                    return pd.DataFrame()
                
                # 最初のhorizonを基準にする
                first_horizon = valid_horizons[0]
                
                # SELECTステートメントの構築 - 最初のカラムは必ず時系列カラム
                select_parts = [f"h{first_horizon}.{ts_col}"]
                
                # 各horizonのSharpe比を計算
                for horizon in valid_horizons:
                    select_parts.append(f"""
                    CASE 
                        WHEN h{horizon}.count_{horizon} < {min_periods} THEN NULL
                        WHEN h{horizon}.std_{horizon} IS NULL OR h{horizon}.std_{horizon} = 0 THEN NULL
                        ELSE (h{horizon}.mean_{horizon} - {risk_free_rate}) / h{horizon}.std_{horizon}
                    END AS sharpe_{horizon}""")
                
                # JOINステートメントの構築 - 必ず時系列カラムでJOIN
                join_parts = []
                for horizon in valid_horizons[1:]:
                    join_parts.append(f"LEFT JOIN horizon_{horizon} h{horizon} ON h{first_horizon}.{ts_col} = h{horizon}.{ts_col}")
                
                # 最終的なSQL文の構築 - 時系列カラムでORDER BY
                sql = "WITH " + ",\n".join(cte_parts) + f"""

SELECT 
    {', '.join(select_parts)}
FROM horizon_{first_horizon} h{first_horizon}
{' '.join(join_parts)}
ORDER BY h{first_horizon}.{ts_col}
"""
                
                # SQLクエリのログ出力
                logger.info(f"リスク調整済みリターン計算（独立関数）: 生成されたSQLクエリ:\n{sql}")
                
                # クエリ実行
                logger.info(f"リスク調整済みリターン計算（独立関数）: SQLクエリを実行します（テーブル '{table_id}'）")
                result = service.data_fetcher.execute_query(sql)
                
                # テーブルの削除
                try:
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を削除します")
                    service.table_manager.client.delete_table(table_id, not_found_ok=True)
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を正常に削除しました")
                except Exception as delete_error:
                    logger.warning(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' の削除中にエラー: {delete_error}")
                
                # 結果を返す
                if result is not None and not result.empty and ts_col in result.columns:
                    # 時系列カラムをインデックスに設定
                    result = result.set_index(ts_col)
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 計算完了 (結果の行数: {len(result)})")
                    return result
                else:
                    logger.warning("リスク調整済みリターン計算（独立関数）: 結果が空または無効です")
                    return pd.DataFrame()
                
            except Exception as e:
                logger.error(f"リスク調整済みリターン計算（独立関数）: エラーが発生しました: {e}")
                import traceback
                logger.error(traceback.format_exc())
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"リスク調整済みリターン計算（独立関数）: 初期化エラー: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return pd.DataFrame()

# Export adapter functions that use the service
def calculate_future_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: Optional[float] = None,
    max_return: Optional[float] = None,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate future returns using BigQuery

    Args:
        prices: Price data
        horizons: Horizons for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value
        max_return: Maximum return value
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: Google Cloud location
        **kwargs: Additional arguments for BigQuery service

    Returns:
        DataFrame with calculated future returns
    """
    # ロガーの初期化
    logger = logging.getLogger(__name__)
    logger.info("未来リターン計算（独立関数）: BigQueryを使用して計算を開始")
    
    # BigQueryサービスの初期化
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    # データの準備とタイムスタンプカラムの特定
    try:
        prices_df, ts_col, price_col = service._prepare_data(prices, date_column, price_column)
        
        # タイムスタンプカラムが存在することを確認
        if ts_col not in prices_df.columns:
            logger.error(f"未来リターン計算（独立関数）: タイムスタンプカラム '{ts_col}' が入力データに存在しません")
            # デバッグ用に列名を出力
            logger.error(f"未来リターン計算（独立関数）: 入力データの列: {list(prices_df.columns)}")
            return pd.DataFrame()
        
        # タイムスタンプカラムをインデックスとして明示的に保存
        timestamp_series = prices_df[ts_col].copy()
        logger.debug(f"未来リターン計算（独立関数）: タイムスタンプカラムを保存: {ts_col}, 先頭5行: {timestamp_series.head()}")
        
        # 結果を返す
        result = service.calculate_future_returns(
            prices=prices_df,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return,
            date_column=ts_col,
            price_column=price_col
        )
        
        # 結果がNoneでなく、空でない場合
        if result is not None and not result.empty:
            # タイムスタンプカラムが結果に含まれているか確認
            # インデックスがタイムスタンプの場合、リセットしてカラムとして追加
            if result.index.name == ts_col:
                result = result.reset_index()
            # タイムスタンプカラムが結果に含まれていない場合は追加
            elif ts_col not in result.columns:
                logger.info(f"未来リターン計算（独立関数）: 結果にタイムスタンプカラムを追加: {ts_col}")
                result[ts_col] = timestamp_series.reset_index(drop=True)
                # タイムスタンプカラムを最初の列に移動
                cols = [ts_col] + [col for col in result.columns if col != ts_col]
                result = result[cols]
            
            logger.info(f"未来リターン計算（独立関数）: 計算完了 - 出力は {list(result.columns)} 列を含む")
            return result
        else:
            logger.warning("未来リターン計算（独立関数）: 計算結果が空または無効")
            return pd.DataFrame()
        
    except Exception as e:
        logger.error(f"未来リターン計算（独立関数）: エラーが発生しました: {e}")
        return pd.DataFrame()

def calculate_direction_labels_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate direction labels using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated direction labels
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_direction_labels_pandas
        return calculate_direction_labels_pandas(prices, horizons, threshold)
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_direction_labels(
        prices=prices,
        horizons=horizons,
        threshold=threshold,
        date_column=date_column,
        price_column=price_column
    )

def calculate_volatility_adjusted_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate volatility-adjusted returns using BigQuery backend
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: BigQuery dataset location
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns
    """
    if not BIGQUERY_AVAILABLE:
        logger.warning("BigQuery not available, falling back to pandas implementation")
        from .pandas_adapter import calculate_volatility_adjusted_returns_pandas
        return calculate_volatility_adjusted_returns_pandas(prices, horizons, vol_window, method)
    
    # Create service and calculate
    service = BigQueryReturnTargetService(
        project_id=project_id,
        dataset_id=dataset_id,
        location=location,
        **kwargs
    )
    
    return service.calculate_volatility_adjusted_returns(
        prices=prices,
        horizons=horizons,
        vol_window=vol_window,
        method=method,
        date_column=date_column,
        price_column=price_column
    )

def calculate_risk_adjusted_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: str = "phunt_api",
    location: str = "asia-northeast1",
    **kwargs
) -> pd.DataFrame:
    """
    Calculate risk-adjusted returns (Sharpe ratio) using BigQuery

    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        date_column: Column name for date
        price_column: Column name for price
        project_id: Google Cloud project ID
        dataset_id: BigQuery dataset ID
        location: Google Cloud location
        **kwargs: Additional arguments for BigQuery service

    Returns:
        DataFrame with calculated risk-adjusted returns
    """
    # ロガーの初期化
    logger = logging.getLogger(__name__)
    logger.info("リスク調整済みリターン計算（独立関数）: BigQueryを使用して計算を開始")
    
    # データの準備とタイムスタンプカラムの特定
    try:
        # BigQueryサービスの初期化
        service = BigQueryReturnTargetService(
            project_id=project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        # データの準備：常にインスタンスメソッドを使用
        prices_df, ts_col, price_col = service._prepare_data(prices, date_column, price_column)
        logger.info(f"リスク調整済みリターン計算（独立関数）: サービスでデータを準備 ({len(prices_df)}行)")
        
        # タイムスタンプカラムが存在することを確認
        if ts_col not in prices_df.columns:
            logger.error(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム '{ts_col}' が入力データに存在しません")
            logger.error(f"リスク調整済みリターン計算（独立関数）: 入力データの列: {list(prices_df.columns)}")
            return pd.DataFrame()
        
        # タイムスタンプをバックアップ
        original_timestamps = prices_df[ts_col].copy()
        logger.debug(f"リスク調整済みリターン計算（独立関数）: タイムスタンプをバックアップ（{len(original_timestamps)}行）")
    
        # まず未来リターンを計算（修正版）
        future_returns = calculate_future_returns_bigquery(
            prices=prices_df,
            horizons=horizons,
            method=method,
            normalize=False,  # リスク調整済みリターンにはノーマライズしない未加工のリターンが必要
            date_column=ts_col,
            price_column=price_col,
            project_id=project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        if future_returns is None or future_returns.empty:
            logger.warning("リスク調整済みリターン計算（独立関数）: 未来リターンの計算に失敗しました")
            return pd.DataFrame()
        
        # タイムスタンプカラムが結果に含まれているか確認
        # 含まれていない場合は追加
        if ts_col not in future_returns.columns:
            logger.info(f"リスク調整済みリターン計算（独立関数）: 未来リターンにタイムスタンプカラムを追加 ({ts_col})")
            if len(original_timestamps) == len(future_returns):
                future_returns[ts_col] = original_timestamps.values
                # タイムスタンプカラムを最初の列に移動
                cols = [ts_col] + [col for col in future_returns.columns if col != ts_col]
                future_returns = future_returns[cols]
            else:
                logger.warning(f"リスク調整済みリターン計算（独立関数）: 行数が一致しません（元={len(original_timestamps)}、リターン={len(future_returns)}）")
        
        # BigQueryサービスの初期化
        service = BigQueryReturnTargetService(
            project_id=project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        # データセット存在確認
        dataset_id_full = f"{service.config.project_id}.{service.config.dataset_id}"
        try:
            service.data_fetcher.client.get_dataset(dataset_id_full)
            logger.info(f"リスク調整済みリターン計算（独立関数）: データセット '{dataset_id_full}' が存在することを確認")
        except Exception as e:
            logger.warning(f"リスク調整済みリターン計算（独立関数）: データセット '{dataset_id_full}' が見つかりません: {e}")
            return pd.DataFrame()
        
        # 一時テーブルの作成とデータのロード
        try:
            # タイムスタンプベースの一時テーブル名
            table_id = service.table_manager.create_temp_table_id("risk_adjusted_returns")
            logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を作成")
            
            # タイムスタンプカラムに関する情報をログ
            logger.info(f"リスク調整済みリターン計算（独立関数）: future_returns の列: {future_returns.columns.tolist()}")
            logger.info(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム: {ts_col}")
            
            # 一時テーブルにデータをロード
            service.table_manager.load_dataframe(future_returns, table_id)
            logger.info(f"リスク調整済みリターン計算（独立関数）: データを一時テーブル '{table_id}' にロード (行数: {len(future_returns)})")
            
            # horizonsを確実にリストに変換
            horizons_list = horizons if isinstance(horizons, list) else [horizons]
            
            # CTEパーツの初期化
            cte_parts = []
            
            # タイムスタンプカラムの特定 - 名前で明示的に確認
            if ts_col not in future_returns.columns:
                # タイムスタンプカラムが見つからない場合はエラー
                logger.error(f"リスク調整済みリターン計算（独立関数）: タイムスタンプカラム '{ts_col}' が未来リターンに存在しません")
                logger.error(f"リスク調整済みリターン計算（独立関数）: 未来リターンの列: {future_returns.columns.tolist()}")
                
                # 代替手段：カラム名を探す
                if 'ts' in future_returns.columns:
                    ts_col = 'ts'
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'ts' を使用")
                elif 'date' in future_returns.columns:
                    ts_col = 'date'
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'date' を使用")
                elif 'timestamp' in future_returns.columns:
                    ts_col = 'timestamp'
                    logger.info(f"リスク調整済みリターン計算（独立関数）: 代替タイムスタンプカラム 'timestamp' を使用")
                else:
                    # カラムのデータ型を確認して、日付型の列を探す
                    for col in future_returns.columns:
                        if pd.api.types.is_datetime64_any_dtype(future_returns[col]):
                            ts_col = col
                            logger.info(f"リスク調整済みリターン計算（独立関数）: 日付型カラム '{col}' を使用")
                            break
                    
                    if ts_col is None:
                        # 日付型のカラムが見つからなかった場合、最初のカラムをタイムスタンプとして使用（緊急措置）
                        ts_col = future_returns.columns[0]
                        logger.warning(f"リスク調整済みリターン計算（独立関数）: 日付型カラムが見つからないため、最初のカラム '{ts_col}' を使用")
            
            logger.info(f"リスク調整済みリターン計算（独立関数）: 時系列カラム = {ts_col}")
            
            # ソースデータのCTE - テーブル参照の形式を修正
            # table_id に既にデータセット名が含まれている場合は調整
            if '.' in table_id:
                # table_id が 'dataset.table' 形式の場合
                table_ref = f"{service.config.project_id}.{table_id}"
            else:
                # table_id が単なるテーブル名の場合
                table_ref = f"{service.config.project_id}.{service.config.dataset_id}.{table_id}"
            
            # データセット名が重複していないことを確認
            if f"{service.config.project_id}.{service.config.dataset_id}.{service.config.dataset_id}" in table_ref:
                table_ref = table_ref.replace(
                    f"{service.config.project_id}.{service.config.dataset_id}.{service.config.dataset_id}",
                    f"{service.config.project_id}.{service.config.dataset_id}"
                )
                logger.warning(f"リスク調整済みリターン計算（独立関数）: テーブル参照の重複を修正")
            
            # 最終的なテーブル参照をログ出力
            logger.info(f"リスク調整済みリターン計算（独立関数）: テーブル参照 = {table_ref}")
            
            cte_parts.append(f"""
            source_data AS (
              SELECT * FROM `{table_ref}`
            )""")
            
            # 各horizonごとにCTEを作成
            valid_horizons = []
            for horizon in horizons_list:
                return_col = f"return_{horizon}"
                
                # リターンカラムが存在しなければスキップ
                if return_col not in future_returns.columns:
                    logger.warning(f"リスク調整済みリターン計算（独立関数）: カラム '{return_col}' が見つかりません")
                    continue
                
                valid_horizons.append(horizon)
                logger.info(f"リスク調整済みリターン計算（独立関数）: horizon={horizon}, return_col={return_col}, ts_col={ts_col}")
                
                # 各horizonのSharpe比計算用CTE - 必ず時系列カラムでソート
                cte_parts.append(f"""
                horizon_{horizon} AS (
                    SELECT 
                        *,
                        AVG({return_col}) OVER (
                            ORDER BY {ts_col} 
                            ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                        ) AS mean_{horizon},
                        STDDEV({return_col}) OVER (
                            ORDER BY {ts_col} 
                            ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                        ) AS std_{horizon},
                        COUNT({return_col}) OVER (
                            ORDER BY {ts_col} 
                            ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                        ) AS count_{horizon}
                    FROM source_data
                )""")
            
            # 有効なhorizonがなければ終了
            if not valid_horizons:
                logger.warning("リスク調整済みリターン計算（独立関数）: 有効なhorizonが見つかりません")
                return pd.DataFrame()
            
            # 最初のhorizonを基準にする
            first_horizon = valid_horizons[0]
            
            # SELECTステートメントの構築 - 最初のカラムは必ず時系列カラム
            select_parts = [f"h{first_horizon}.{ts_col}"]
            
            # 各horizonのSharpe比を計算
            for horizon in valid_horizons:
                select_parts.append(f"""
                CASE 
                    WHEN h{horizon}.count_{horizon} < {min_periods} THEN NULL
                    WHEN h{horizon}.std_{horizon} IS NULL OR h{horizon}.std_{horizon} = 0 THEN NULL
                    ELSE (h{horizon}.mean_{horizon} - {risk_free_rate}) / h{horizon}.std_{horizon}
                END AS sharpe_{horizon}""")
            
            # JOINステートメントの構築 - 必ず時系列カラムでJOIN
            join_parts = []
            for horizon in valid_horizons[1:]:
                join_parts.append(f"LEFT JOIN horizon_{horizon} h{horizon} ON h{first_horizon}.{ts_col} = h{horizon}.{ts_col}")
            
            # 最終的なSQL文の構築 - 時系列カラムでORDER BY
            sql = "WITH " + ",\n".join(cte_parts) + f"""

SELECT 
    {', '.join(select_parts)}
FROM horizon_{first_horizon} h{first_horizon}
{' '.join(join_parts)}
ORDER BY h{first_horizon}.{ts_col}
"""
            
            # SQLクエリのログ出力
            logger.info(f"リスク調整済みリターン計算（独立関数）: 生成されたSQLクエリ:\n{sql}")
            
            # クエリ実行
            logger.info(f"リスク調整済みリターン計算（独立関数）: SQLクエリを実行します（テーブル '{table_id}'）")
            result = service.data_fetcher.execute_query(sql)
            
            # テーブルの削除
            try:
                logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を削除します")
                service.table_manager.client.delete_table(table_id, not_found_ok=True)
                logger.info(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' を正常に削除しました")
            except Exception as delete_error:
                logger.warning(f"リスク調整済みリターン計算（独立関数）: 一時テーブル '{table_id}' の削除中にエラー: {delete_error}")
            
            # 結果を返す
            if result is not None and not result.empty and ts_col in result.columns:
                # 時系列カラムをインデックスに設定
                result = result.set_index(ts_col)
                logger.info(f"リスク調整済みリターン計算（独立関数）: 計算完了 (結果の行数: {len(result)})")
                return result
            else:
                logger.warning("リスク調整済みリターン計算（独立関数）: 結果が空または無効です")
                return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"リスク調整済みリターン計算（独立関数）: エラーが発生しました: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return pd.DataFrame()
            
    except Exception as e:
        logger.error(f"リスク調整済みリターン計算（独立関数）: 初期化エラー: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return pd.DataFrame()

def construct_query(sql_parts):
    """
    CTEを含むSQLクエリを正しく構築する補助関数
    BigQueryのCTE構文に準拠した形式にする
    """
    if len(sql_parts) <= 1:
        return ''.join(sql_parts)
    
    # sql_partsの内容を確認
    logger.debug(f"construct_query: sql_parts[0]の先頭20文字 = {sql_parts[0][:20]}")
    if len(sql_parts) > 1:
        logger.debug(f"construct_query: sql_parts[1]の先頭20文字 = {sql_parts[1][:20]}")
    
    # WITH句を含む最初のCTEを抽出
    with_clause = sql_parts[0].strip()
    
    # WITH句から "WITH" キーワードを抽出
    if "WITH" in with_clause:
        # WITHを含むCTEを分解
        parts = with_clause.split("WITH", 1)
        prefix = parts[0]  # WITHの前の部分（通常は空か改行）
        
        # 最初のCTEの内容
        first_cte = parts[1].strip()
        
        # 複数のCTEに分解する準備
        cte_parts = [first_cte]
    else:
        # WITHが見つからない場合（通常はエラー）
        logger.warning("construct_query: WITH句が見つかりません")
        prefix = ""
        cte_parts = [with_clause]
    
    # 中間のCTE定義を追加（カンマを前につけた形式になっているはず）
    for cte in sql_parts[1:-1]:
        # カンマで始まる場合はカンマを削除
        if cte.strip().startswith(','):
            cte_parts.append(cte.strip()[1:].strip())
        else:
            cte_parts.append(cte.strip())
    
    # 最後のSELECTクエリ
    select_query = sql_parts[-1].strip()
    
    # BigQueryに適した形式でCTEを構築
    # WITH cte1 AS (...), cte2 AS (...), ... SELECT ...
    result = f"{prefix}WITH " + ",\n".join(cte_parts) + "\n" + select_query
    
    # 結果のデバッグログ
    logger.debug(f"construct_query: 生成されたSQLの先頭50文字 = {result[:50]}...")
    
    return result 