"""
Polars adapter for return target calculations

This module provides polars-based implementations for return target calculations.
"""

from typing import Union, List, Optional
import pandas as pd
import polars as pl
import numpy as np

def calculate_future_returns_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: Optional[float] = None,
    max_return: Optional[float] = None,
    **kwargs
) -> pl.DataFrame:
    """
    Calculate future returns using polars
    
    Args:
        prices: Price data
        horizons: Horizons for future return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value (for winsorizing)
        max_return: Maximum return value (for winsorizing)
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated future returns
    """
    # インデックス情報を保持するために pandas を経由する
    if isinstance(prices, pd.Series):
        # Pandasと同じ処理を行うために一度Pandasに変換
        from phunt_api.targets.returns import calculate_future_returns as pandas_calculate_future_returns
        
        # Pandasの実装を直接呼び出し
        pandas_result = pandas_calculate_future_returns(
            prices=prices,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return
        )
        
        # Polarsに変換して返す
        return pl.from_pandas(pandas_result)
    
    # DataFrame の場合も Series に変換してから処理
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices_series = prices['close']
        else:
            prices_series = prices.iloc[:, 0]
        
        return calculate_future_returns_polars(
            prices=prices_series,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return,
            **kwargs
        )
    
    # Polars オブジェクトの場合は pandas に変換してから処理
    if isinstance(prices, pl.Series) or isinstance(prices, pl.DataFrame):
        if isinstance(prices, pl.DataFrame):
            if 'close' in prices.columns:
                prices_pl = prices['close']
            else:
                prices_pl = prices[prices.columns[0]]
        else:
            prices_pl = prices
        
        # Pandasに変換
        prices_pd = prices_pl.to_pandas()
        
        # 再帰的に Pandas Series を処理
        return calculate_future_returns_polars(
            prices=prices_pd,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return,
            **kwargs
        )
    
    # ここには到達しないはず
    raise ValueError("Unsupported price data type")

def calculate_direction_labels_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0,
    **kwargs
) -> pl.DataFrame:
    """
    Calculate direction labels using polars
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated direction labels
    """
    # Pandasの実装を使用
    if isinstance(prices, pd.Series):
        from phunt_api.targets.returns import calculate_direction_labels as pandas_calculate_direction_labels
        
        # Pandasの実装を直接呼び出し
        pandas_result = pandas_calculate_direction_labels(
            prices=prices,
            horizons=horizons,
            threshold=threshold
        )
        
        # Polarsに変換して返す
        return pl.from_pandas(pandas_result)
    
    # DataFrame の場合も Series に変換してから処理
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices_series = prices['close']
        else:
            prices_series = prices.iloc[:, 0]
        
        return calculate_direction_labels_polars(
            prices=prices_series,
            horizons=horizons,
            threshold=threshold,
            **kwargs
        )
    
    # Polars オブジェクトの場合は pandas に変換してから処理
    if isinstance(prices, pl.Series) or isinstance(prices, pl.DataFrame):
        if isinstance(prices, pl.DataFrame):
            if 'close' in prices.columns:
                prices_pl = prices['close']
            else:
                prices_pl = prices[prices.columns[0]]
        else:
            prices_pl = prices
        
        # Pandasに変換
        prices_pd = prices_pl.to_pandas()
        
        # 再帰的に Pandas Series を処理
        return calculate_direction_labels_polars(
            prices=prices_pd,
            horizons=horizons,
            threshold=threshold,
            **kwargs
        )
    
    # ここには到達しないはず
    raise ValueError("Unsupported price data type")

def calculate_volatility_adjusted_returns_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic',
    **kwargs
) -> pl.DataFrame:
    """
    Calculate volatility-adjusted returns using polars
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns
    """
    # Pandasの実装を使用
    if isinstance(prices, pd.Series):
        from phunt_api.targets.returns import calculate_volatility_adjusted_returns as pandas_calculate_volatility_adjusted_returns
        
        # Pandasの実装を直接呼び出し
        pandas_result = pandas_calculate_volatility_adjusted_returns(
            prices=prices,
            horizons=horizons,
            vol_window=vol_window,
            method=method
        )
        
        # Polarsに変換して返す
        return pl.from_pandas(pandas_result)
    
    # DataFrame の場合も Series に変換してから処理
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices_series = prices['close']
        else:
            prices_series = prices.iloc[:, 0]
        
        return calculate_volatility_adjusted_returns_polars(
            prices=prices_series,
            horizons=horizons,
            vol_window=vol_window,
            method=method,
            **kwargs
        )
    
    # Polars オブジェクトの場合は pandas に変換してから処理
    if isinstance(prices, pl.Series) or isinstance(prices, pl.DataFrame):
        if isinstance(prices, pl.DataFrame):
            if 'close' in prices.columns:
                prices_pl = prices['close']
            else:
                prices_pl = prices[prices.columns[0]]
        else:
            prices_pl = prices
        
        # Pandasに変換
        prices_pd = prices_pl.to_pandas()
        
        # 再帰的に Pandas Series を処理
        return calculate_volatility_adjusted_returns_polars(
            prices=prices_pd,
            horizons=horizons,
            vol_window=vol_window,
            method=method,
            **kwargs
        )
    
    # ここには到達しないはず
    raise ValueError("Unsupported price data type")

def calculate_risk_adjusted_returns_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20,
    **kwargs
) -> pl.DataFrame:
    """
    Calculate risk-adjusted returns using polars
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        **kwargs: Additional options
        
    Returns:
        DataFrame with calculated risk-adjusted returns
    """
    # Pandasの実装を使用
    if isinstance(prices, pd.Series):
        from phunt_api.targets.returns import calculate_risk_adjusted_returns as pandas_calculate_risk_adjusted_returns
        
        # Pandasの実装を直接呼び出し
        pandas_result = pandas_calculate_risk_adjusted_returns(
            prices=prices,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods
        )
        
        # Polarsに変換して返す
        return pl.from_pandas(pandas_result)
    
    # DataFrame の場合も Series に変換してから処理
    if isinstance(prices, pd.DataFrame):
        if 'close' in prices.columns:
            prices_series = prices['close']
        else:
            prices_series = prices.iloc[:, 0]
        
        return calculate_risk_adjusted_returns_polars(
            prices=prices_series,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods,
            **kwargs
        )
    
    # Polars オブジェクトの場合は pandas に変換してから処理
    if isinstance(prices, pl.Series) or isinstance(prices, pl.DataFrame):
        if isinstance(prices, pl.DataFrame):
            if 'close' in prices.columns:
                prices_pl = prices['close']
            else:
                prices_pl = prices[prices.columns[0]]
        else:
            prices_pl = prices
        
        # Pandasに変換
        prices_pd = prices_pl.to_pandas()
        
        # 再帰的に Pandas Series を処理
        return calculate_risk_adjusted_returns_polars(
            prices=prices_pd,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods,
            **kwargs
        )
    
    # ここには到達しないはず
    raise ValueError("Unsupported price data type") 