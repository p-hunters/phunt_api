"""
Adapter factory for return target calculations

This module provides factory functions that select the appropriate adapter based on the requested backend.
"""

from typing import Callable, Any, Dict, Union, List, Optional
import pandas as pd
import polars as pl

from .pandas_adapter import (
    calculate_future_returns_pandas,
    calculate_direction_labels_pandas,
    calculate_volatility_adjusted_returns_pandas,
    calculate_risk_adjusted_returns_pandas,
)

from .polars_adapter import (
    calculate_future_returns_polars,
    calculate_direction_labels_polars,
    calculate_volatility_adjusted_returns_polars,
    calculate_risk_adjusted_returns_polars,
)

from .duckdb_adapter import (
    calculate_future_returns_duckdb,
    calculate_direction_labels_duckdb,
    calculate_volatility_adjusted_returns_duckdb,
    calculate_risk_adjusted_returns_duckdb,
)

from .bigquery_adapter import (
    calculate_future_returns_bigquery,
    calculate_direction_labels_bigquery,
    calculate_volatility_adjusted_returns_bigquery,
    calculate_risk_adjusted_returns_bigquery,
)

def calculate_future_returns_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]],
    method: str,
    normalize: bool,
    vol_window: int,
    min_periods: int,
    min_return: Optional[float],
    max_return: Optional[float],
    date_column: Optional[str],
    price_column: Optional[str],
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate future returns calculation adapter based on the backend.
    
    Args:
        prices: Price data
        horizons: Horizons for future return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value (for winsorizing)
        max_return: Maximum return value (for winsorizing)
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated future returns using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_future_returns_pandas(
            prices, horizons, method, normalize, vol_window, min_periods, min_return, max_return, **backend_options
        )
    elif backend == "polars":
        return calculate_future_returns_polars(
            prices, horizons, method, normalize, vol_window, min_periods, min_return, max_return, **backend_options
        )
    elif backend == "duckdb":
        return calculate_future_returns_duckdb(
            prices, horizons, method, normalize, vol_window, min_periods, min_return, max_return, 
            date_column, price_column, **backend_options
        )
    elif backend == "bigquery":
        return calculate_future_returns_bigquery(
            prices, horizons, method, normalize, vol_window, min_periods, min_return, max_return, 
            date_column, price_column, **backend_options
        )
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, duckdb, bigquery")

def calculate_direction_labels_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]],
    threshold: float,
    date_column: Optional[str],
    price_column: Optional[str],
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate direction labels calculation adapter based on the backend.
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction (e.g., 0.0 for any movement)
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated direction labels using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_direction_labels_pandas(prices, horizons, threshold, **backend_options)
    elif backend == "polars":
        return calculate_direction_labels_polars(prices, horizons, threshold, **backend_options)
    elif backend == "duckdb":
        return calculate_direction_labels_duckdb(
            prices, horizons, threshold, date_column, price_column, **backend_options
        )
    elif backend == "bigquery":
        return calculate_direction_labels_bigquery(
            prices, horizons, threshold, date_column, price_column, **backend_options
        )
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, duckdb, bigquery")

def calculate_volatility_adjusted_returns_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]],
    vol_window: int,
    method: str,
    date_column: Optional[str],
    price_column: Optional[str],
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate volatility-adjusted returns calculation adapter based on the backend.
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_volatility_adjusted_returns_pandas(prices, horizons, vol_window, method, **backend_options)
    elif backend == "polars":
        return calculate_volatility_adjusted_returns_polars(prices, horizons, vol_window, method, **backend_options)
    elif backend == "duckdb":
        return calculate_volatility_adjusted_returns_duckdb(
            prices, horizons, vol_window, method, date_column, price_column, **backend_options
        )
    elif backend == "bigquery":
        return calculate_volatility_adjusted_returns_bigquery(
            prices, horizons, vol_window, method, date_column, price_column, **backend_options
        )
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, duckdb, bigquery")

def calculate_risk_adjusted_returns_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]],
    risk_window: int,
    method: str,
    risk_free_rate: float,
    min_periods: int,
    date_column: Optional[str],
    price_column: Optional[str],
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate risk-adjusted returns calculation adapter based on the backend.
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated risk-adjusted returns using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_risk_adjusted_returns_pandas(
            prices, horizons, risk_window, method, risk_free_rate, min_periods, **backend_options
        )
    elif backend == "polars":
        return calculate_risk_adjusted_returns_polars(
            prices, horizons, risk_window, method, risk_free_rate, min_periods, **backend_options
        )
    elif backend == "duckdb":
        return calculate_risk_adjusted_returns_duckdb(
            prices, horizons, risk_window, method, risk_free_rate, min_periods, 
            date_column, price_column, **backend_options
        )
    elif backend == "bigquery":
        return calculate_risk_adjusted_returns_bigquery(
            prices, horizons, risk_window, method, risk_free_rate, min_periods, 
            date_column, price_column, **backend_options
        )
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, duckdb, bigquery") 