"""
Unified API for return target calculations with multiple backends

This module provides a unified interface for calculating return targets (future returns, direction labels, etc.)
using different backends (pandas, polars, duckdb, bigquery).
"""

from typing import Union, List, Dict, Any, Optional, TypeVar
import pandas as pd
import polars as pl
from enum import Enum

# Default backend
DEFAULT_BACKEND = "pandas"

DataFrameType = TypeVar('DataFrameType', pd.DataFrame, pl.DataFrame)

# Import adapter functions once they're created
# For now, these are placeholders that will be implemented in adapter modules
from ._adapters.adapter_factory import (
    calculate_future_returns_adapter,
    calculate_direction_labels_adapter,
    calculate_volatility_adjusted_returns_adapter,
    calculate_risk_adjusted_returns_adapter,
)

def _determine_output_format(
    input_data: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    output_format: Optional[str]
) -> str:
    """
    Determine the output format based on input data and requested format
    
    Args:
        input_data: Input data
        output_format: Requested output format ('pandas', 'polars', or None)
        
    Returns:
        Determined output format ('pandas' or 'polars')
    """
    if output_format is not None:
        if output_format not in ["pandas", "polars"]:
            raise ValueError(f"Invalid output_format: {output_format}. Must be 'pandas', 'polars', or None")
        return output_format
    
    # If no format specified, match input format
    if isinstance(input_data, (pl.Series, pl.DataFrame)):
        return "polars"
    else:
        return "pandas"

def _convert_output(
    result: Union[pd.DataFrame, pl.DataFrame],
    output_format: str
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Convert the result to the desired output format
    
    Args:
        result: Result DataFrame
        output_format: Desired output format ('pandas' or 'polars')
        
    Returns:
        DataFrame in the desired format
    """
    if output_format == "pandas" and isinstance(result, pl.DataFrame):
        return result.to_pandas()
    elif output_format == "polars" and isinstance(result, pd.DataFrame):
        return pl.from_pandas(result)
    return result

def _standardize_output(
    result: Union[pd.DataFrame, pl.DataFrame],
    required_columns: List[str] = None,
    index_name: str = None
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    標準化された結果を返す
    
    Args:
        result: 結果のDataFrame
        required_columns: 必要なカラムのリスト（指定された場合はこれらのカラムのみを返す）
        index_name: インデックスにする列名
        
    Returns:
        標準化されたDataFrame
    """
    # 不要なカラムを削除
    if required_columns is not None:
        existing_columns = [col for col in required_columns if col in result.columns]
        missing_columns = [col for col in required_columns if col not in result.columns]
        
        # 既存の列のみを選択
        if isinstance(result, pd.DataFrame):
            if existing_columns:
                result = result[existing_columns]
            # 欠けている列を追加（NaN値で）
            for col in missing_columns:
                result[col] = None
        else:  # Polars DataFrame
            if existing_columns:
                result = result.select(existing_columns)
            # 欠けている列を追加（null値で）
            for col in missing_columns:
                result = result.with_columns(pl.lit(None).alias(col))
    
    # インデックス設定（Pandas DataFrame のみ）
    if index_name is not None and isinstance(result, pd.DataFrame) and index_name in result.columns:
        result = result.set_index(index_name)
    
    return result

def calculate_future_returns(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: float = None,
    max_return: float = None,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate future returns for price data with the selected backend
    
    Args:
        prices: Price data
        horizons: Horizons for future return calculation
        method: Return calculation method ('arithmetic' or 'log')
        normalize: Whether to normalize returns by volatility
        vol_window: Window size for volatility calculation
        min_periods: Minimum number of observations for volatility calculation
        min_return: Minimum return value (for winsorizing)
        max_return: Maximum return value (for winsorizing)
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated future returns in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_future_returns_adapter(
        prices=prices,
        horizons=horizons,
        method=method,
        normalize=normalize,
        vol_window=vol_window,
        min_periods=min_periods,
        min_return=min_return,
        max_return=max_return,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected return columns
    if isinstance(horizons, int):
        horizons = [horizons]
    if normalize:
        required_columns = [f"norm_future_return_{h}" for h in horizons]
    else:
        required_columns = [f"future_return_{h}" for h in horizons]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

def calculate_direction_labels(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate direction labels (1 for up, -1 for down) based on future returns
    
    Args:
        prices: Price data
        horizons: Horizons for direction label calculation
        threshold: Threshold for determining direction (e.g., 0.0 for any movement)
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated direction labels in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_direction_labels_adapter(
        prices=prices,
        horizons=horizons,
        threshold=threshold,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected label columns
    if isinstance(horizons, int):
        horizons = [horizons]
    required_columns = [f"direction_{h}" for h in horizons]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

def calculate_volatility_adjusted_returns(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate volatility-adjusted future returns
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        vol_window: Window size for volatility calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated volatility-adjusted returns in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_volatility_adjusted_returns_adapter(
        prices=prices,
        horizons=horizons,
        vol_window=vol_window,
        method=method,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected return columns
    if isinstance(horizons, int):
        horizons = [horizons]
    required_columns = [f"vol_adj_return_{h}" for h in horizons]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

def calculate_risk_adjusted_returns(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20,
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate risk-adjusted returns (Sharpe ratio) for future returns
    
    Args:
        prices: Price data
        horizons: Horizons for return calculation
        risk_window: Window size for risk calculation
        method: Return calculation method ('arithmetic' or 'log')
        risk_free_rate: Risk-free rate for Sharpe ratio calculation
        min_periods: Minimum number of observations for risk calculation
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated risk-adjusted returns in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_risk_adjusted_returns_adapter(
        prices=prices,
        horizons=horizons,
        risk_window=risk_window,
        method=method,
        risk_free_rate=risk_free_rate,
        min_periods=min_periods,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected return columns
    if isinstance(horizons, int):
        horizons = [horizons]
    required_columns = [f"sharpe_{h}" for h in horizons]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

# Convenience class for using a consistent backend across all target calculations
class ReturnTargetBackend:
    """
    A class that provides a unified interface for all return target calculations
    using a consistent backend.
    """
    
    def __init__(
        self,
        backend: str = DEFAULT_BACKEND,
        output_format: Optional[str] = None,
        **backend_options
    ):
        """
        Initialize the backend interface
        
        Args:
            backend: Backend to use ('pandas', 'polars', 'duckdb', 'bigquery')
            output_format: Force output format ('pandas' or 'polars'), if None matches input
            **backend_options: Additional backend-specific options
        """
        self.backend = backend
        self.output_format = output_format
        self.backend_options = backend_options
    
    def calculate_future_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        method: str = 'arithmetic',
        normalize: bool = True,
        vol_window: int = 20,
        min_periods: int = 5,
        min_return: float = None,
        max_return: float = None,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate future returns using the configured backend
        """
        return calculate_future_returns(
            prices=prices,
            horizons=horizons,
            method=method,
            normalize=normalize,
            vol_window=vol_window,
            min_periods=min_periods,
            min_return=min_return,
            max_return=max_return,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        )
    
    def calculate_direction_labels(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        threshold: float = 0.0,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate direction labels using the configured backend
        """
        return calculate_direction_labels(
            prices=prices,
            horizons=horizons,
            threshold=threshold,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        )
    
    def calculate_volatility_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        vol_window: int = 20,
        method: str = 'arithmetic',
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate volatility-adjusted returns using the configured backend
        """
        return calculate_volatility_adjusted_returns(
            prices=prices,
            horizons=horizons,
            vol_window=vol_window,
            method=method,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        )
    
    def calculate_risk_adjusted_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        horizons: Union[int, List[int]] = [1, 5, 10, 20],
        risk_window: int = 60,
        method: str = 'arithmetic',
        risk_free_rate: float = 0.0,
        min_periods: int = 20,
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate risk-adjusted returns using the configured backend
        """
        return calculate_risk_adjusted_returns(
            prices=prices,
            horizons=horizons,
            risk_window=risk_window,
            method=method,
            risk_free_rate=risk_free_rate,
            min_periods=min_periods,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        ) 