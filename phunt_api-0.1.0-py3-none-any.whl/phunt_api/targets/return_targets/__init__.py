"""
Return target calculations with multiple backends

This package provides functions for calculating return targets (future returns, 
direction labels, etc.) with support for multiple backends (pandas, polars, 
duckdb, bigquery).
"""

# Re-export the main functions and class from the unified API
from .unified_api import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns,
    ReturnTargetBackend
)

# Re-export the adapter functions for direct access if needed
from ._adapters.pandas_adapter import (
    calculate_future_returns_pandas,
    calculate_direction_labels_pandas,
    calculate_volatility_adjusted_returns_pandas,
    calculate_risk_adjusted_returns_pandas,
)

from ._adapters.polars_adapter import (
    calculate_future_returns_polars,
    calculate_direction_labels_polars,
    calculate_volatility_adjusted_returns_polars,
    calculate_risk_adjusted_returns_polars,
)

# Only re-export these if the backends are available
try:
    from ._adapters.duckdb_adapter import (
        calculate_future_returns_duckdb,
        calculate_direction_labels_duckdb,
        calculate_volatility_adjusted_returns_duckdb,
        calculate_risk_adjusted_returns_duckdb,
    )
except ImportError:
    pass

try:
    from ._adapters.bigquery_adapter import (
        calculate_future_returns_bigquery,
        calculate_direction_labels_bigquery,
        calculate_volatility_adjusted_returns_bigquery,
        calculate_risk_adjusted_returns_bigquery,
    )
except ImportError:
    pass

# Set default backend to pandas
DEFAULT_BACKEND = "pandas" 