"""
BigQueryのリスク調整済みリターン計算のテスト - PHuntAPI認証を使用
"""
import pandas as pd
import numpy as np
import logging
import os
from datetime import datetime, timedelta

# ロギングの設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# PHuntAPIのインポート
from phunt_api import PHuntAPI

# BigQuery関連のインポート
from phunt_api.misc.bq import BigQueryDataFetcher, BigQueryConfig, BigQueryTableManager

def login_phunt_api():
    """
    PHuntAPIにログインしてBigQuery認証情報を取得
    """
    # P12ファイルのパスを確認
    p12_path = "/Users/shin/workspace/MT4_ARB/phunt/client.p12"
    if not os.path.exists(p12_path):
        logger.error(f"P12ファイルが見つかりません: {p12_path}")
        return False
    
    try:
        # PHuntAPIの初期化とログイン
        api = PHuntAPI(debug=True)
        api.login(p12_path=p12_path, p12_password="aaa")
        logger.info("PHuntAPIログイン成功: BigQuery認証情報が利用可能です")
        return True
    except Exception as e:
        logger.error(f"PHuntAPIログイン失敗: {e}")
        return False

def create_test_data(rows=100):
    """
    テスト用のデータフレームを作成
    """
    dates = pd.date_range(start='2025-01-01', periods=rows, freq='D')
    prices = np.random.normal(100, 5, rows).cumsum() + 1000
    
    # リターン計算
    returns_2 = np.random.normal(0.001, 0.02, rows)
    returns_5 = np.random.normal(0.002, 0.03, rows)
    returns_10 = np.random.normal(0.003, 0.04, rows)
    
    df = pd.DataFrame({
        'ts': dates,
        'close': prices,
        'return_2': returns_2,
        'return_5': returns_5,
        'return_10': returns_10
    })
    
    return df

def test_simple_cte():
    """
    シンプルなCTEクエリのテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーの初期化
    fetcher = BigQueryDataFetcher(config)
    
    # シンプルなCTEクエリ
    query = """
    WITH data AS (
        SELECT 1 AS id, 'test' AS name
    ),
    data2 AS (
        SELECT id, CONCAT(name, '_suffix') AS full_name
        FROM data
    )
    SELECT * FROM data2
    """
    
    try:
        result = fetcher.execute_query(query)
        logger.info(f"シンプルCTEクエリの結果: {result}")
        return "シンプルCTEクエリのテスト成功"
    except Exception as e:
        logger.error(f"シンプルCTEクエリのテスト失敗: {e}")
        return f"エラー: {e}"

def test_risk_adjusted_returns():
    """
    リスク調整済みリターン計算のSQLクエリテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーとテーブルマネージャーの初期化
    fetcher = BigQueryDataFetcher(config)
    table_manager = BigQueryTableManager(config)
    
    # テスト用データの作成
    df = create_test_data(100)
    
    try:
        # データをBigQueryテーブルにロード
        temp_table_id = table_manager.create_temp_table_id("risk_test")
        logger.info(f"テーブルID: {temp_table_id}")
        
        # データのロード
        table_manager.load_dataframe(df, temp_table_id)
        logger.info(f"テストデータをテーブル '{temp_table_id}' にロードしました (行数: {len(df)})")
        
        # リスク調整済みリターン計算用のSQLクエリ
        # ここで修正後のSQL文法を使用
        horizons = [2, 5, 10]
        risk_window = 20
        min_periods = 5
        risk_free_rate = 0.0
        
        # 完全修飾テーブル参照
        fully_qualified_table_ref = f"{config.project_id}.{temp_table_id}"
        
        # CTEパーツの構築
        cte_parts = []
        
        # ソースデータのCTE
        cte_parts.append(f"""
        source_data AS (
          SELECT * FROM `{fully_qualified_table_ref}`
        )""")
        
        # 各horizonごとにCTEを作成
        for h_idx, horizon in enumerate(horizons, 1):
            # 各horizonのSharpe比計算用CTE
            # 正しいカラム名を使用（'return_h'ではなく'return_{horizon}'）
            cte_parts.append(f"""
            horizon_{horizon} AS (
                SELECT 
                    ts,
                    return_{horizon},
                    AVG(return_{horizon}) OVER (
                        ORDER BY ts 
                        ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                    ) AS mean_{horizon},
                    STDDEV(return_{horizon}) OVER (
                        ORDER BY ts 
                        ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                    ) AS std_{horizon},
                    COUNT(return_{horizon}) OVER (
                        ORDER BY ts 
                        ROWS BETWEEN {risk_window-1} PRECEDING AND CURRENT ROW
                    ) AS count_{horizon}
                FROM source_data
            )""")
        
        # WITH句とすべてのCTEを結合
        sql = "WITH " + ",\n".join(cte_parts)
        
        # SELECTステートメントの構築
        # 各テーブルからの列参照を修正（テーブル名は一貫してhorizon_Xを使用）
        select_clause = ["h2.ts"]
        
        # 各horizonのSharpe比計算
        for horizon in horizons:
            select_clause.append(f"""
            CASE 
                WHEN h{horizon}.count_{horizon} < {min_periods} THEN NULL
                WHEN h{horizon}.std_{horizon} IS NULL OR h{horizon}.std_{horizon} = 0 THEN NULL
                ELSE (h{horizon}.mean_{horizon} - {risk_free_rate}) / h{horizon}.std_{horizon}
            END AS sharpe_{horizon}""")
        
        # JOINステートメントの構築
        join_clause = []
        for horizon in horizons[1:]:
            # 最初のhorizonはFROM句で指定するので、2つ目以降をJOIN
            join_clause.append(f"LEFT JOIN horizon_{horizon} h{horizon} ON h2.ts = h{horizon}.ts")
        
        # 最終的なSELECTステートメント
        # 最初のhorizonは2なので、FROM句でhorizon_2を指定
        sql += f"""

SELECT 
    {', '.join(select_clause)}
FROM horizon_2 h2
{' '.join(join_clause)}
ORDER BY h2.ts
"""
        
        # SQLクエリのロギング
        logger.info(f"実行するSQLクエリ:\n{sql}")
        
        # クエリ実行
        result = fetcher.execute_query(sql)
        logger.info(f"リスク調整済みリターン計算の結果（先頭5行）:\n{result.head()}")
        
        # テーブルの削除
        table_manager.client.delete_table(temp_table_id, not_found_ok=True)
        logger.info(f"テストテーブル '{temp_table_id}' を削除しました")
        
        return "リスク調整済みリターン計算のテスト成功"
    except Exception as e:
        logger.error(f"リスク調整済みリターン計算のテスト失敗: {e}")
        return f"エラー: {e}"

if __name__ == "__main__":
    logger.info("BigQueryリスク調整済みリターン計算のテストを開始")
    
    # シンプルなCTEのテスト
    logger.info(test_simple_cte())
    
    # リスク調整済みリターン計算のテスト
    logger.info(test_risk_adjusted_returns())
    
    logger.info("テスト完了") 