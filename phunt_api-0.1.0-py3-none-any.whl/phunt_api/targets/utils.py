import numpy as np
import pandas as pd

def calculate_daily_returns(prices: pd.Series, method: str = 'arithmetic') -> pd.Series:
    """Calculate daily returns using specified method."""
    if method == 'arithmetic':
        return prices.pct_change()
    elif method == 'log':
        return np.log(prices / prices.shift(1))
    else:
        raise ValueError("Method must be 'arithmetic' or 'log'")

def calculate_future_return(
    prices: pd.Series,
    horizon: int,
    method: str = 'arithmetic'
) -> pd.Series:
    """Calculate future return for a given horizon."""
    if method == 'arithmetic':
        return prices.shift(-horizon) / prices - 1
    else:
        return np.log(prices.shift(-horizon) / prices)

def calculate_rolling_volatility(
    returns: pd.Series,
    window: int,
    min_periods: int = None
) -> pd.Series:
    """Calculate rolling volatility."""
    return returns.rolling(window=window, min_periods=min_periods).std() 