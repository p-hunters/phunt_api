import numpy as np
import pandas as pd
from typing import Union, List, Dict
from .validators import validate_price_series, validate_horizons, validate_windows, validate_benchmarks
from .utils import calculate_daily_returns, calculate_rolling_volatility

def calculate_relative_returns(
    prices: pd.Series,
    benchmarks: Dict[str, pd.Series],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    correlation_window: int = 60
) -> pd.DataFrame:
    """
    Calculate relative returns against benchmarks.
    
    Args:
        prices (pd.Series): Price series
        benchmarks (Dict[str, pd.Series]): Dictionary of benchmark price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        correlation_window (int): Window for rolling correlation calculation
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window, correlation_window])
    validate_benchmarks(benchmarks, prices)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > min(vol_window, correlation_window):
        raise ValueError("min_periods cannot be greater than smallest window size")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    relative_returns = pd.DataFrame(index=prices.index)
    
    # Price returns
    price_returns = calculate_daily_returns(prices, method)
    
    # Benchmark returns
    benchmark_returns = {}
    for name, benchmark in benchmarks.items():
        benchmark_returns[name] = calculate_daily_returns(benchmark, method)
    
    # Rolling volatilities
    price_vol = calculate_rolling_volatility(price_returns, vol_window, min_periods)
    benchmark_vols = {
        name: calculate_rolling_volatility(ret, vol_window, min_periods)
        for name, ret in benchmark_returns.items()
    }
    
    for horizon in horizons:
        # Future returns for the main price
        future_ret = (prices.shift(-horizon) / prices - 1) if method == 'arithmetic' else \
                    np.log(prices.shift(-horizon) / prices)
        
        for name, bench_ret in benchmark_returns.items():
            # Future returns for the benchmark
            future_benchmark_ret = (benchmarks[name].shift(-horizon) / benchmarks[name] - 1) \
                if method == 'arithmetic' else np.log(benchmarks[name].shift(-horizon) / benchmarks[name])
            
            # Relative performance
            relative_ret = future_ret - future_benchmark_ret
            if normalize:
                relative_ret = relative_ret / price_vol
            
            relative_returns[f'relative_return_{name}_{horizon}'] = relative_ret
            
            # Rolling correlation
            rolling_corr = price_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).corr(bench_ret)
            relative_returns[f'correlation_{name}_{horizon}'] = rolling_corr
            
            # Strength ratio (past horizon performance ratio)
            rolling_ratio = (
                (prices / prices.shift(horizon)) /
                (benchmarks[name] / benchmarks[name].shift(horizon))
            )
            relative_returns[f'strength_ratio_{name}_{horizon}'] = rolling_ratio
            
            # Beta
            rolling_cov = price_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).cov(bench_ret)
            rolling_var = bench_ret.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).var()
            beta = rolling_cov / rolling_var
            relative_returns[f'beta_{name}_{horizon}'] = beta
            
            # Relative volatility
            rel_vol = price_vol / benchmark_vols[name]
            relative_returns[f'relative_vol_{name}_{horizon}'] = rel_vol
            
            # Information ratio
            excess_returns = price_returns - bench_ret
            tracking_error = excess_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).std()
            info_ratio = (
                excess_returns.rolling(
                    window=correlation_window,
                    min_periods=min_periods
                ).mean()
                / tracking_error
            )
            relative_returns[f'info_ratio_{name}_{horizon}'] = info_ratio
            
            # Cross-asset momentum
            momentum_diff = (
                (prices / prices.shift(horizon) - 1) -
                (benchmarks[name] / benchmarks[name].shift(horizon) - 1)
            )
            if normalize:
                momentum_diff = momentum_diff / price_vol
            relative_returns[f'momentum_diff_{name}_{horizon}'] = momentum_diff
            
            # Relative strength index (RSI) difference
            def calculate_rsi(data: pd.Series, window: int = 14) -> pd.Series:
                delta = data.diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
                rs = gain / loss
                return 100 - (100 / (1 + rs))
            
            price_rsi = calculate_rsi(prices, horizon)
            bench_rsi = calculate_rsi(benchmarks[name], horizon)
            rsi_diff = price_rsi - bench_rsi
            relative_returns[f'rsi_diff_{name}_{horizon}'] = rsi_diff
    
    return relative_returns 