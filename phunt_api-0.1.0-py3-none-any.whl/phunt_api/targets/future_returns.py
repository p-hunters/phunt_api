import numpy as np
import pandas as pd
from typing import Union, List, Optional, Dict, Tuple

def validate_price_series(prices: pd.Series) -> None:
    """
    Validate price series data quality.
    
    Args:
        prices (pd.Series): Price series to validate
    
    Raises:
        ValueError: If price series fails validation
    """
    if not isinstance(prices, pd.Series):
        raise ValueError("Prices must be a pandas Series")
    
    if not pd.api.types.is_numeric_dtype(prices):
        raise ValueError("Price series must contain numeric values")
    
    if prices.isnull().any():
        raise ValueError("Price series contains missing values")
    
    if (prices <= 0).any():
        raise ValueError("Price series contains zero or negative values")
    
    if not isinstance(prices.index, pd.DatetimeIndex):
        raise ValueError("Price series must have a datetime index")
    
    if prices.index.duplicated().any():
        raise ValueError("Price series contains duplicate timestamps")
    
    if not prices.index.is_monotonic_increasing:
        raise ValueError("Price series timestamps must be strictly increasing")

def validate_horizons(horizons: Union[int, List[int]]) -> None:
    """
    Validate prediction horizons.
    
    Args:
        horizons (Union[int, List[int]]): Horizons to validate
    
    Raises:
        ValueError: If horizons fail validation
    """
    if isinstance(horizons, int):
        horizons = [horizons]
    
    if not all(isinstance(h, int) for h in horizons):
        raise ValueError("All horizons must be integers")
    
    if not all(h > 0 for h in horizons):
        raise ValueError("All horizons must be positive")
    
    if len(set(horizons)) != len(horizons):
        raise ValueError("Duplicate horizons are not allowed")

def validate_windows(windows: Union[int, List[int]], min_window: int = 2) -> None:
    """
    Validate window sizes.
    
    Args:
        windows (Union[int, List[int]]): Windows to validate
        min_window (int): Minimum allowed window size
    
    Raises:
        ValueError: If windows fail validation
    """
    if isinstance(windows, int):
        windows = [windows]
    
    if not all(isinstance(w, int) for w in windows):
        raise ValueError("All windows must be integers")
    
    if not all(w >= min_window for w in windows):
        raise ValueError(f"All windows must be at least {min_window}")
    
    if len(set(windows)) != len(windows):
        raise ValueError("Duplicate windows are not allowed")

def validate_high_low_data(
    high_prices: pd.Series,
    low_prices: pd.Series,
    prices: pd.Series
) -> None:
    """
    Validate high-low price data.
    
    Args:
        high_prices (pd.Series): High price series
        low_prices (pd.Series): Low price series
        prices (pd.Series): Close price series
    
    Raises:
        ValueError: If high-low data fails validation
    """
    # Validate types and structure
    if not all(isinstance(x, pd.Series) for x in [high_prices, low_prices]):
        raise ValueError("High and low prices must be pandas Series")
    
    if not all(x.index.equals(prices.index) for x in [high_prices, low_prices]):
        raise ValueError("High and low prices must have same index as close prices")
    
    # Validate high-low relationship
    if (high_prices < low_prices).any():
        raise ValueError("High prices must be greater than or equal to low prices")
    
    if (high_prices < prices).any() or (low_prices > prices).any():
        raise ValueError("Close prices must be between high and low prices")
    
    # Validate data quality
    if high_prices.isnull().any() or low_prices.isnull().any():
        raise ValueError("High-low data contains missing values")
    
    if (high_prices <= 0).any() or (low_prices <= 0).any():
        raise ValueError("High-low data contains zero or negative values")

def validate_benchmarks(benchmarks: Dict[str, pd.Series], prices: pd.Series) -> None:
    """
    Validate benchmark price series.
    
    Args:
        benchmarks (Dict[str, pd.Series]): Dictionary of benchmark price series
        prices (pd.Series): Main price series
    
    Raises:
        ValueError: If benchmarks fail validation
    """
    if not isinstance(benchmarks, dict):
        raise ValueError("Benchmarks must be a dictionary")
    
    if not benchmarks:
        raise ValueError("Benchmarks dictionary is empty")
    
    for name, benchmark in benchmarks.items():
        if not isinstance(name, str):
            raise ValueError("Benchmark names must be strings")
        
        if not isinstance(benchmark, pd.Series):
            raise ValueError(f"Benchmark {name} must be a pandas Series")
        
        if not benchmark.index.equals(prices.index):
            raise ValueError(f"Benchmark {name} must have same index as main price series")
        
        if benchmark.isnull().any():
            raise ValueError(f"Benchmark {name} contains missing values")
        
        if (benchmark <= 0).any():
            raise ValueError(f"Benchmark {name} contains zero or negative values")

def calculate_future_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5
) -> pd.DataFrame:
    """
    Calculate future returns for multiple horizons.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize returns by volatility
        vol_window (int): Window size for volatility calculation if normalizing
        min_periods (int): Minimum number of observations required for calculations
    
    Returns:
        pd.DataFrame: DataFrame with future returns for each horizon
    """
    # Validate inputs
    validate_price_series(prices)
    validate_horizons(horizons)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if vol_window < 2:
        raise ValueError("vol_window must be at least 2")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    future_returns = pd.DataFrame(index=prices.index)
    
    # Precompute daily returns for volatility
    if method == 'arithmetic':
        daily_returns = prices.pct_change()
    else:
        daily_returns = np.log(prices / prices.shift(1))
    
    vol = daily_returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    # Calculate returns for each horizon
    for horizon in horizons:
        if method == 'arithmetic':
            # (p[t+h] / p[t] - 1)
            future_ret = prices.shift(-horizon) / prices - 1
        else:  # log returns: log(p[t+h]/p[t])
            future_ret = np.log(prices.shift(-horizon) / prices)
        
        if normalize:
            future_ret = future_ret / vol
        
        future_returns[f'future_return_{horizon}'] = future_ret
    
    return future_returns

def calculate_direction_labels(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0
) -> pd.DataFrame:
    """
    Calculate binary direction labels for future price movements.
    Labels: 1 = price moves up more than `threshold`, 0 = otherwise.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate direction for
        threshold (float): Return threshold to determine direction (helps avoid noise)
    
    Returns:
        pd.DataFrame: DataFrame with binary direction labels (1: up, 0: down)
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    direction_labels = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        # Arithmetic future return by default
        future_return = prices.shift(-horizon) / prices - 1
        
        direction = (future_return > threshold).astype(int)
        direction_labels[f'direction_{horizon}'] = direction
    
    return direction_labels

def calculate_volatility_adjusted_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic'
) -> pd.DataFrame:
    """
    Calculate volatility-adjusted future returns.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        vol_window (int): Window size for volatility calculation
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
    
    Returns:
        pd.DataFrame: DataFrame with volatility-adjusted future returns
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows(vol_window)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("method must be either 'arithmetic' or 'log'")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Calculate daily returns for volatility
    if method == 'arithmetic':
        daily_returns = prices.pct_change()
    else:
        daily_returns = np.log(prices / prices.shift(1))
    
    volatility = daily_returns.rolling(window=vol_window).std()
    vol_adj_returns = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        # Calculate future returns
        if method == 'arithmetic':
            future_ret = prices.shift(-horizon) / prices - 1
        else:
            future_ret = np.log(prices.shift(-horizon) / prices)
        
        # Volatility-adjusted returns
        vol_adj_ret = future_ret / volatility
        vol_adj_returns[f'vol_adj_return_{horizon}'] = vol_adj_ret
    
    return vol_adj_returns

def calculate_momentum_targets(
    prices: pd.Series,
    momentum_windows: Union[int, List[int]] = [5, 10, 20],
    prediction_horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True
) -> pd.DataFrame:
    """
    Calculate momentum-based targets for prediction.
    
    Args:
        prices (pd.Series): Price series
        momentum_windows (Union[int, List[int]]): Windows for momentum calculation
        prediction_horizons (Union[int, List[int]]): Future horizon(s) to calculate targets for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize momentum by window volatility
    
    Returns:
        pd.DataFrame: DataFrame with momentum acceleration targets
    """
    validate_price_series(prices)
    validate_windows(momentum_windows)
    validate_horizons(prediction_horizons)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if isinstance(momentum_windows, int):
        momentum_windows = [momentum_windows]
    if isinstance(prediction_horizons, int):
        prediction_horizons = [prediction_horizons]
    
    momentum_targets = pd.DataFrame(index=prices.index)
    
    for window in momentum_windows:
        # Past momentum
        if method == 'arithmetic':
            past_momentum = prices.pct_change(window)
        else:
            past_momentum = np.log(prices / prices.shift(window))
        
        if normalize:
            vol = past_momentum.rolling(window=window).std()
            past_momentum = past_momentum / vol
        
        for horizon in prediction_horizons:
            # Future momentum
            if method == 'arithmetic':
                future_momentum = prices.shift(-horizon) / prices - 1
            else:
                future_momentum = np.log(prices.shift(-horizon) / prices)
            
            if normalize:
                future_vol = future_momentum.rolling(window=horizon).std()
                future_momentum = future_momentum / future_vol
            
            # Momentum acceleration
            momentum_accel = future_momentum - past_momentum
            momentum_targets[f'momentum_accel_w{window}_h{horizon}'] = momentum_accel
    
    return momentum_targets

def calculate_risk_adjusted_returns(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20
) -> pd.DataFrame:
    """
    Calculate risk-adjusted return targets (Sharpe and Sortino ratios, etc.).
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        risk_window (int): Window size for rolling risk calculation
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        risk_free_rate (float): Annual risk-free rate (converted to match horizon)
        min_periods (int): Minimum number of observations required for rolling calculations
    
    Returns:
        pd.DataFrame: DataFrame with risk-adjusted return targets
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([risk_window])
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if not isinstance(risk_free_rate, (int, float)):
        raise ValueError("risk_free_rate must be a number")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > risk_window:
        raise ValueError("min_periods cannot be greater than risk_window")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    risk_adj_returns = pd.DataFrame(index=prices.index)
    
    for horizon in horizons:
        # Future returns
        if method == 'arithmetic':
            future_ret = prices.shift(-horizon) / prices - 1
        else:
            future_ret = np.log(prices.shift(-horizon) / prices)
        
        # Convert annual risk-free rate to match 'horizon' days
        # Assuming 252 trading days per year
        period_rf_rate = (1 + risk_free_rate) ** (horizon / 252) - 1
        
        # Rolling stats
        rolling_mean = future_ret.rolling(window=risk_window, min_periods=min_periods).mean()
        rolling_std = future_ret.rolling(window=risk_window, min_periods=min_periods).std()
        
        # Downside returns for Sortino ratio
        downside_returns = future_ret.copy()
        downside_returns[downside_returns > period_rf_rate] = 0
        rolling_downside_std = np.sqrt(
            (downside_returns ** 2).rolling(window=risk_window, min_periods=min_periods).mean()
        )
        
        # Sharpe ratio
        sharpe = (rolling_mean - period_rf_rate) / rolling_std
        risk_adj_returns[f'future_sharpe_{horizon}'] = sharpe
        
        # Sortino ratio
        sortino = (rolling_mean - period_rf_rate) / rolling_downside_std
        risk_adj_returns[f'future_sortino_{horizon}'] = sortino
        
        # Calmar ratio (naive version based on rolling returns)
        rolling_max = future_ret.rolling(window=risk_window, min_periods=min_periods).max()
        rolling_drawdown = (future_ret - rolling_max) / rolling_max
        max_drawdown = rolling_drawdown.rolling(window=risk_window, min_periods=min_periods).min()
        calmar = (rolling_mean - period_rf_rate) / abs(max_drawdown)
        risk_adj_returns[f'future_calmar_{horizon}'] = calmar
    
    return risk_adj_returns

def calculate_range_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5
) -> pd.DataFrame:
    """
    Calculate range-based prediction targets (future high-low range).
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate ranges for
        normalize (bool): Whether to normalize ranges by historical volatility
        vol_window (int): Window size for volatility calculation if normalizing
        min_periods (int): Minimum number of observations required for calculations
    
    Returns:
        pd.DataFrame: DataFrame with range-based prediction targets
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > vol_window:
        raise ValueError("min_periods cannot be greater than vol_window")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    range_targets = pd.DataFrame(index=prices.index)
    
    # Calculate daily returns for volatility
    returns = prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    for horizon in horizons:
        # Build future price shifts
        price_windows = []
        for i in range(horizon):
            price_windows.append(prices.shift(-(i+1)))
        
        future_prices_all = pd.concat(
            [prices.to_frame('current_price')] + 
            [pd.DataFrame({f'price_{i+1}': p}) for i, p in enumerate(price_windows)], 
            axis=1
        )
        
        # Calculate future high/low over the next horizon days
        future_high = future_prices_all.max(axis=1)
        future_low = future_prices_all.min(axis=1)
        
        # Range-based metrics
        abs_range = (future_high - future_low) / prices
        up_range = (future_high - prices) / prices
        down_range = (future_low - prices) / prices
        
        if normalize:
            abs_range = abs_range / rolling_vol
            up_range = up_range / rolling_vol
            down_range = down_range / rolling_vol
        
        range_targets[f'future_abs_range_{horizon}'] = abs_range
        range_targets[f'future_up_range_{horizon}'] = up_range
        range_targets[f'future_down_range_{horizon}'] = down_range
        
        # Range z-score
        current_range = abs_range.rolling(window=vol_window, min_periods=min_periods)
        range_mean = current_range.mean()
        range_std = current_range.std()
        
        range_z_score = (abs_range - range_mean) / range_std
        range_targets[f'future_range_zscore_{horizon}'] = range_z_score
        
        # Range crossover
        range_targets[f'future_range_crossover_{horizon}'] = (
            (future_high > prices.rolling(window=vol_window).max()) |
            (future_low < prices.rolling(window=vol_window).min())
        ).astype(int)
    
    return range_targets

def calculate_mean_reversion_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    ma_windows: Union[int, List[int]] = [10, 20, 50, 200],
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    bollinger_std: float = 2.0
) -> pd.DataFrame:
    """
    Calculate mean reversion based prediction targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate targets for
        ma_windows (Union[int, List[int]]): Moving average windows for mean reversion calculation
        normalize (bool): Whether to normalize distances by volatility
        vol_window (int): Window size for volatility calculation if normalizing
        min_periods (int): Minimum number of observations required for calculations
        bollinger_std (float): Number of standard deviations for Bollinger Bands
    
    Returns:
        pd.DataFrame: DataFrame with mean reversion targets
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows(ma_windows)
    validate_windows([vol_window])
    
    if not isinstance(bollinger_std, (int, float)):
        raise ValueError("bollinger_std must be a number")
    
    if bollinger_std <= 0:
        raise ValueError("bollinger_std must be positive")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    # smallest_ma_window
    smallest_ma_window = min(ma_windows) if isinstance(ma_windows, list) else ma_windows
    if min_periods > smallest_ma_window:
        raise ValueError("min_periods cannot be greater than smallest window size")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    if isinstance(ma_windows, int):
        ma_windows = [ma_windows]
    
    reversion_targets = pd.DataFrame(index=prices.index)
    
    # For normalization
    returns = prices.pct_change()
    rolling_vol = returns.rolling(window=vol_window, min_periods=min_periods).std()
    
    for ma_window in ma_windows:
        ma = prices.rolling(window=ma_window, min_periods=min_periods).mean()
        std = prices.rolling(window=ma_window, min_periods=min_periods).std()
        
        upper_band = ma + bollinger_std * std
        lower_band = ma - bollinger_std * std
        
        dist_to_ma = (prices - ma) / prices
        dist_to_upper = (upper_band - prices) / prices
        dist_to_lower = (prices - lower_band) / prices
        
        if normalize:
            dist_to_ma = dist_to_ma / rolling_vol
            dist_to_upper = dist_to_upper / rolling_vol
            dist_to_lower = dist_to_lower / rolling_vol
        
        for horizon in horizons:
            future_price = prices.shift(-horizon)
            future_return = (future_price - prices) / prices
            
            if normalize:
                future_return = future_return / rolling_vol
            
            # Record distances
            reversion_targets[f'ma_dist_{ma_window}_h{horizon}'] = dist_to_ma
            reversion_targets[f'upper_dist_{ma_window}_h{horizon}'] = dist_to_upper
            reversion_targets[f'lower_dist_{ma_window}_h{horizon}'] = dist_to_lower
            
            # MA cross
            ma_cross = ((prices > ma) & (future_price < ma)) | ((prices < ma) & (future_price > ma))
            reversion_targets[f'ma_cross_{ma_window}_h{horizon}'] = ma_cross.astype(int)
            
            # Bollinger Band position
            bb_position = (prices - lower_band) / (upper_band - lower_band)
            reversion_targets[f'bb_position_{ma_window}_h{horizon}'] = bb_position
            
            # Extreme signals
            extreme_high = prices > upper_band
            extreme_low = prices < lower_band
            reversion_targets[f'extreme_high_{ma_window}_h{horizon}'] = extreme_high.astype(int)
            reversion_targets[f'extreme_low_{ma_window}_h{horizon}'] = extreme_low.astype(int)
            
            # Mean reversion intensity: how strongly price reverts towards MA
            reversion_intensity = -np.sign(dist_to_ma) * future_return
            reversion_targets[f'reversion_intensity_{ma_window}_h{horizon}'] = reversion_intensity
    
    return reversion_targets

def calculate_relative_returns(
    prices: pd.Series,
    benchmarks: Dict[str, pd.Series],
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    correlation_window: int = 60
) -> pd.DataFrame:
    """
    Calculate relative returns against benchmarks.
    
    Args:
        prices (pd.Series): Price series
        benchmarks (Dict[str, pd.Series]): Dictionary of benchmark price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        correlation_window (int): Window for rolling correlation calculation
    
    Returns:
        pd.DataFrame: DataFrame with relative return targets
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window, correlation_window])
    validate_benchmarks(benchmarks, prices)
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > min(vol_window, correlation_window):
        raise ValueError("min_periods cannot be greater than smallest window size")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    relative_returns = pd.DataFrame(index=prices.index)
    
    # Price returns
    if method == 'arithmetic':
        price_returns = prices.pct_change()
    else:
        price_returns = np.log(prices / prices.shift(1))
    
    # Benchmark returns
    benchmark_returns = {}
    for name, benchmark in benchmarks.items():
        if method == 'arithmetic':
            benchmark_returns[name] = benchmark.pct_change()
        else:
            benchmark_returns[name] = np.log(benchmark / benchmark.shift(1))
    
    # Rolling volatilities
    price_vol = price_returns.rolling(window=vol_window, min_periods=min_periods).std()
    benchmark_vols = {
        name: ret.rolling(window=vol_window, min_periods=min_periods).std()
        for name, ret in benchmark_returns.items()
    }
    
    for horizon in horizons:
        # Future returns for the main price
        if method == 'arithmetic':
            future_ret = prices.shift(-horizon) / prices - 1
        else:
            future_ret = np.log(prices.shift(-horizon) / prices)
        
        for name, bench_ret in benchmark_returns.items():
            # Future returns for the benchmark
            if method == 'arithmetic':
                future_benchmark_ret = benchmarks[name].shift(-horizon) / benchmarks[name] - 1
            else:
                future_benchmark_ret = np.log(benchmarks[name].shift(-horizon) / benchmarks[name])
            
            # Relative performance
            relative_ret = future_ret - future_benchmark_ret
            if normalize:
                relative_ret = relative_ret / price_vol
            
            relative_returns[f'relative_return_{name}_{horizon}'] = relative_ret
            
            # Rolling correlation
            rolling_corr = price_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).corr(bench_ret)
            relative_returns[f'correlation_{name}_{horizon}'] = rolling_corr
            
            # Strength ratio (past horizon performance ratio; not strictly "future")
            rolling_ratio = (
                (prices / prices.shift(horizon)) /
                (benchmarks[name] / benchmarks[name].shift(horizon))
            )
            relative_returns[f'strength_ratio_{name}_{horizon}'] = rolling_ratio
            
            # Beta
            rolling_cov = price_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).cov(bench_ret)
            rolling_var = bench_ret.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).var()
            beta = rolling_cov / rolling_var
            relative_returns[f'beta_{name}_{horizon}'] = beta
            
            # Relative volatility
            rel_vol = price_vol / benchmark_vols[name]
            relative_returns[f'relative_vol_{name}_{horizon}'] = rel_vol
            
            # Information ratio
            excess_returns = price_returns - bench_ret
            tracking_error = excess_returns.rolling(
                window=correlation_window,
                min_periods=min_periods
            ).std()
            info_ratio = (
                excess_returns.rolling(window=correlation_window, min_periods=min_periods).mean()
                / tracking_error
            )
            relative_returns[f'info_ratio_{name}_{horizon}'] = info_ratio
    
    return relative_returns

def calculate_volatility_targets(
    prices: pd.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_windows: Union[int, List[int]] = [20, 50, 100],
    method: str = 'standard',  # 'standard', 'parkinson', 'garman_klass'
    vol_of_vol_window: int = 50,
    min_periods: int = 5,
    high_low_data: Optional[Tuple[pd.Series, pd.Series]] = None,
    jump_threshold: float = 3.0,  # Number of standard deviations for jump detection
    regime_thresholds: Union[Tuple[float, float], List[Tuple[float, float]]] = [
        (0.5, 1.5)  # (low_to_medium, medium_to_high) in terms of historical std
    ]
) -> pd.DataFrame:
    """
    Calculate forward-looking volatility prediction targets.
    
    Args:
        prices (pd.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate volatility for
        vol_windows (Union[int, List[int]]): Windows for historical volatility calculation
        method (str): Volatility calculation method
            - 'standard': Close-to-close volatility
            - 'parkinson': High-low based (Parkinson) volatility
            - 'garman_klass': Open-high-low-close based volatility
        vol_of_vol_window (int): Window for calculating volatility of volatility
        min_periods (int): Minimum number of observations required
        high_low_data (Optional[Tuple[pd.Series, pd.Series]]): High and low price series
        jump_threshold (float): Threshold for jump detection in std deviations
        regime_thresholds (Union[Tuple[float, float], List[Tuple[float, float]]]): 
            Thresholds for regime boundaries in terms of historical standard deviations
    
    Returns:
        pd.DataFrame: DataFrame with volatility prediction targets
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    if isinstance(vol_windows, int):
        vol_windows = [vol_windows]
    validate_windows(vol_windows)
    
    if isinstance(regime_thresholds[0], float):
        # Ensure it's a list of tuples
        regime_thresholds = [regime_thresholds]
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > min(vol_windows + [vol_of_vol_window]):
        raise ValueError("min_periods cannot be greater than smallest window size")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    vol_targets = pd.DataFrame(index=prices.index)
    
    # Daily returns
    returns = prices.pct_change()
    log_returns = np.log(prices / prices.shift(1))
    
    # Determine daily volatility measure
    if high_low_data is not None and method in ['parkinson', 'garman_klass']:
        high_prices, low_prices = high_low_data
        validate_high_low_data(high_prices, low_prices, prices)
        
        log_high_low = np.log(high_prices / low_prices)
        
        if method == 'parkinson':
            # Parkinson estimator
            daily_vol = np.sqrt(
                (1 / (4 * np.log(2))) * (log_high_low ** 2)
            )
        else:
            # Garman-Klass (close-to-open not fully used if no 'open' provided, 
            # but we'll keep the structure as is)
            log_co = np.log(prices / prices.shift(1))  # approximate close-to-open
            # high_to_open
            log_ho = np.log(high_prices / prices.shift(1))
            # low_to_open
            log_lo = np.log(low_prices / prices.shift(1))
            
            daily_vol = np.sqrt(
                0.5 * (log_high_low ** 2)
                - (2 * np.log(2) - 1) * (log_co ** 2)
            )
    else:
        # Standard close-to-close volatility measure as absolute returns
        daily_vol = returns.abs()
    
    for window in vol_windows:
        hist_vol = daily_vol.rolling(window=window, min_periods=min_periods).std()
        
        # EWMA volatility as an example (with lambda=0.94)
        lambda_param = 0.94
        ewma_vol = np.sqrt((1 - lambda_param) * (returns ** 2).ewm(alpha=(1 - lambda_param)).mean())
        
        # Vol of vol
        vol_of_vol = hist_vol.rolling(window=vol_of_vol_window, min_periods=min_periods).std()
        
        # Jump detection
        returns_std = returns.rolling(window=window, min_periods=min_periods).std()
        jumps = (returns.abs() > (jump_threshold * returns_std)).astype(int)
        jump_intensity = jumps.rolling(window=window, min_periods=min_periods).mean()
        
        for horizon in horizons:
            # Future realized volatility
            future_vol = daily_vol.rolling(window=horizon).std().shift(-horizon)
            vol_targets[f'future_vol_{window}_{horizon}'] = future_vol
            
            # Store current historical measures
            vol_targets[f'hist_vol_{window}_{horizon}'] = hist_vol
            vol_targets[f'ewma_vol_{window}_{horizon}'] = ewma_vol
            vol_targets[f'vol_of_vol_{window}_{horizon}'] = vol_of_vol
            
            # Volatility regimes
            vol_zscore = (hist_vol - hist_vol.mean()) / hist_vol.std()
            future_vol_zscore = (future_vol - future_vol.mean()) / future_vol.std()
            
            for low_thresh, high_thresh in regime_thresholds:
                current_regime = pd.Series(1, index=prices.index)
                current_regime[vol_zscore <= -low_thresh] = 0
                current_regime[vol_zscore >= high_thresh] = 2
                
                future_regime = pd.Series(1, index=prices.index)
                future_regime[future_vol_zscore <= -low_thresh] = 0
                future_regime[future_vol_zscore >= high_thresh] = 2
                
                vol_targets[f'current_vol_regime_{window}_{horizon}'] = current_regime
                vol_targets[f'future_vol_regime_{window}_{horizon}'] = future_regime
            
            # Jump measures
            vol_targets[f'jump_intensity_{window}_{horizon}'] = jump_intensity
            future_jumps = jumps.rolling(window=horizon).sum().shift(-horizon)
            vol_targets[f'future_jumps_{window}_{horizon}'] = future_jumps
            
            # Volatility term structure (if window > horizon)
            if window > horizon:
                vol_term_structure = future_vol / hist_vol - 1
                vol_targets[f'vol_term_structure_{window}_{horizon}'] = vol_term_structure
            
            # Intraday volatility pattern (if high-low data is given)
            if high_low_data is not None:
                high_prices, low_prices = high_low_data
                high_low_range = (high_prices - low_prices) / prices
                future_range = high_low_range.rolling(window=horizon).mean().shift(-horizon)
                vol_targets[f'future_range_{window}_{horizon}'] = future_range
            
            # Volatility acceleration
            vol_change = hist_vol.pct_change()
            future_vol_change = future_vol.pct_change()
            vol_targets[f'vol_change_{window}_{horizon}'] = vol_change
            vol_targets[f'future_vol_change_{window}_{horizon}'] = future_vol_change
            
            # Regime transition probabilities
            current_regime = vol_targets[f'current_vol_regime_{window}_{horizon}']
            future_regime = vol_targets[f'future_vol_regime_{window}_{horizon}']
            
            for i in range(3):
                for j in range(3):
                    current_state = (current_regime == i)
                    next_state = (future_regime == j)
                    # Probability of transitioning from i to j over 'window'
                    trans_prob = (
                        (current_state & next_state)
                        .rolling(window=window, min_periods=min_periods)
                        .mean()
                        / (current_state.rolling(window=window, min_periods=min_periods).mean() + 1e-10)
                    )
                    vol_targets[f'vol_regime_trans_{i}to{j}_{window}_{horizon}'] = trans_prob
    
    return vol_targets
