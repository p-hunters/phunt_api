import numpy as np
import polars as pl
from typing import Union, List, Optional

# =================
#    Validators
# =================

def validate_price_series(prices: pl.Series) -> None:
    """
    Validate price series data quality.
    
    Args:
        prices (pl.Series): Price series to validate
    
    Raises:
        ValueError: If price series fails validation
    """
    if not isinstance(prices, pl.Series):
        raise ValueError("Prices must be a polars Series")
    
    if not pl.datatypes.is_numeric(prices.dtype):
        raise ValueError("Price series must contain numeric values")
    
    if prices.null_count() > 0:
        raise ValueError("Price series contains missing values")
    
    if (prices <= 0).any():
        raise ValueError("Price series contains zero or negative values")


def validate_horizons(horizons: Union[int, List[int]]) -> None:
    """
    Validate prediction horizons.
    
    Args:
        horizons (Union[int, List[int]]): Prediction horizon(s) to validate
    
    Raises:
        ValueError: If horizons fail validation
    """
    if isinstance(horizons, int):
        horizons = [horizons]
        
    if not all(isinstance(h, int) for h in horizons):
        raise ValueError("All horizons must be integers")
        
    if any(h <= 0 for h in horizons):
        raise ValueError("All horizons must be positive")


def validate_windows(windows: Union[int, List[int]], min_window: int = 2) -> None:
    """
    Validate window sizes.
    
    Args:
        windows (Union[int, List[int]]): Window size(s) to validate
        min_window (int): Minimum allowed window size
    
    Raises:
        ValueError: If windows fail validation
    """
    if isinstance(windows, int):
        windows = [windows]
    
    if not all(isinstance(w, int) for w in windows):
        raise ValueError("All windows must be integers")
    
    if any(w < min_window for w in windows):
        raise ValueError(f"All windows must be at least {min_window}")

# =================
#    Utilities
# =================

def calculate_daily_returns(prices: pl.Series, method: str = 'arithmetic') -> pl.Series:
    """Calculate daily returns using specified method."""
    if method == 'arithmetic':
        return (prices / prices.shift(1) - 1)
    elif method == 'log':
        return (prices / prices.shift(1)).log()
    else:
        raise ValueError("Method must be 'arithmetic' or 'log'")


def calculate_future_return(
    prices: pl.Series,
    horizon: int,
    method: str = 'arithmetic'
) -> pl.Series:
    """Calculate future return for a given horizon."""
    if method == 'arithmetic':
        return (prices.shift(-horizon) / prices - 1)
    else:
        return (prices.shift(-horizon) / prices).log()


def calculate_rolling_volatility(
    returns: pl.Series,
    window: int,
    min_periods: Optional[int] = None
) -> pl.Series:
    """Calculate rolling volatility."""
    # If min_periods not specified, use the full window
    if min_periods is None:
        min_periods = window
        
    return returns.rolling_std(window_size=window, min_periods=min_periods)

# =================
#  Target Functions
# =================

def calculate_future_returns(
    prices: pl.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    method: str = 'arithmetic',
    normalize: bool = True,
    vol_window: int = 20,
    min_periods: int = 5,
    min_return: Optional[float] = None,
    max_return: Optional[float] = None
) -> pl.DataFrame:
    """
    Calculate future returns for multiple horizons.
    
    Args:
        prices (pl.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        normalize (bool): Whether to normalize returns by volatility
        vol_window (int): Window size for volatility calculation
        min_periods (int): Minimum number of observations required
        min_return (float, optional): Minimum return threshold for outlier handling
        max_return (float, optional): Maximum return threshold for outlier handling
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Initialize with the price series to keep the row indices
    df = pl.DataFrame({prices.name or "price": prices})
    
    # Calculate volatility if normalizing
    if normalize:
        # Calculate daily returns
        daily_returns = calculate_daily_returns(prices, method)
        # Calculate rolling volatility
        vol = calculate_rolling_volatility(daily_returns, vol_window, min_periods)
    
    # Calculate returns for each horizon
    exprs = []
    
    for horizon in horizons:
        future_ret = calculate_future_return(prices, horizon, method)
        future_ret_name = f'future_return_{horizon}'
        
        # Apply return thresholds if specified
        if min_return is not None:
            future_ret = future_ret.clip_min(min_return)
        if max_return is not None:
            future_ret = future_ret.clip_max(max_return)
        
        if normalize:
            # Add volatility to the dataframe for calculation
            vol_name = f"vol_{vol_window}"
            df = df.with_column(pl.Series(vol_name, vol))
            
            # Create normalized return expression
            ret_expr = pl.col(future_ret_name) / pl.col(vol_name)
            exprs.append(ret_expr.alias(future_ret_name))
            
            # Add the future return column first
            df = df.with_column(pl.Series(future_ret_name, future_ret))
        else:
            # Just add the future return column
            df = df.with_column(pl.Series(future_ret_name, future_ret))
            exprs.append(pl.col(future_ret_name))
    
    # If we need to normalize, apply the expressions
    if normalize and exprs:
        df = df.select([col for col in df.columns if not col.startswith("vol_")] + exprs)
    
    # Drop the price column if it exists
    if prices.name or "price" in df.columns:
        df = df.drop([prices.name or "price"])
    
    return df


def calculate_direction_labels(
    prices: pl.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    threshold: float = 0.0
) -> pl.DataFrame:
    """
    Calculate binary direction labels for future price movements.
    Labels: 1 = price moves up more than `threshold`, 0 = otherwise.
    
    Args:
        prices (pl.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate labels for
        threshold (float): Return threshold to consider as positive
    
    Returns:
        pl.DataFrame: DataFrame with binary direction labels
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Initialize with the price series to keep the row indices
    df = pl.DataFrame({prices.name or "price": prices})
    
    # Calculate direction labels for each horizon
    for horizon in horizons:
        # Calculate future returns (positive when price goes up)
        future_return = (prices.shift(-horizon) / prices - 1)
        
        # Create binary labels
        direction = (future_return > threshold).cast(pl.Int8)
        
        # Add to DataFrame
        df = df.with_column(pl.Series(f'direction_{horizon}', direction))
    
    # Drop the price column if it exists
    if prices.name or "price" in df.columns:
        df = df.drop([prices.name or "price"])
    
    return df


def calculate_volatility_adjusted_returns(
    prices: pl.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    vol_window: int = 20,
    method: str = 'arithmetic'
) -> pl.DataFrame:
    """
    Calculate volatility-adjusted future returns.
    
    Args:
        prices (pl.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        vol_window (int): Window size for volatility calculation
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
    
    Returns:
        pl.DataFrame: DataFrame with volatility-adjusted returns
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([vol_window])
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("method must be either 'arithmetic' or 'log'")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Initialize with the price series to keep the row indices
    df = pl.DataFrame({prices.name or "price": prices})
    
    # Calculate daily returns for volatility using our helper function
    daily_returns = calculate_daily_returns(prices, 'arithmetic')
    
    # Calculate rolling volatility
    volatility = daily_returns.rolling_std(window_size=vol_window, min_periods=1)
    
    for horizon in horizons:
        # Calculate future returns (positive when price goes up)
        if method == 'arithmetic':
            future_ret = -(prices.shift(-horizon) / prices - 1)
        else:
            future_ret = -(prices.shift(-horizon) / prices).log()
        
        # Calculate volatility-adjusted returns
        vol_adj_ret = future_ret / volatility
        
        # Add to DataFrame
        df = df.with_column(pl.Series(f'vol_adj_return_{horizon}', vol_adj_ret))
    
    # Drop the price column if it exists
    if prices.name or "price" in df.columns:
        df = df.drop([prices.name or "price"])
    
    return df


def rolling_window_apply(series: pl.Series, window: int, func, min_periods: int = None) -> pl.Series:
    """
    Apply a custom function to a rolling window over a series.
    
    Args:
        series (pl.Series): Input series
        window (int): Window size
        func: Function to apply
        min_periods (int, optional): Minimum periods required
    
    Returns:
        pl.Series: Result of applying function to rolling windows
    """
    if min_periods is None:
        min_periods = window
        
    values = series.to_list()
    result = [None] * len(values)
    
    # Apply function to each window
    if len(values) >= min_periods:
        for i in range(window - 1, len(values)):
            window_vals = values[i - window + 1:i + 1]
            if window_vals.count(None) > (window - min_periods):
                result[i] = None
            else:
                filtered_vals = [x for x in window_vals if x is not None]
                if filtered_vals:
                    try:
                        result[i] = func(filtered_vals)
                    except:
                        result[i] = None
    
    return pl.Series(name=series.name, values=result)


def calculate_risk_adjusted_returns(
    prices: pl.Series,
    horizons: Union[int, List[int]] = [1, 5, 10, 20],
    risk_window: int = 60,
    method: str = 'arithmetic',
    risk_free_rate: float = 0.0,
    min_periods: int = 20
) -> pl.DataFrame:
    """
    Calculate risk-adjusted return targets (Sharpe and Sortino ratios, etc.).
    
    Args:
        prices (pl.Series): Price series
        horizons (Union[int, List[int]]): Future horizon(s) to calculate returns for
        risk_window (int): Window size for risk calculation
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
        risk_free_rate (float): Annual risk-free rate
        min_periods (int): Minimum number of observations required
    
    Returns:
        pl.DataFrame: DataFrame with risk-adjusted return metrics
    """
    validate_price_series(prices)
    validate_horizons(horizons)
    validate_windows([risk_window])
    
    if method not in ['arithmetic', 'log']:
        raise ValueError("Method must be either 'arithmetic' or 'log'")
    
    if not isinstance(risk_free_rate, (int, float)):
        raise ValueError("risk_free_rate must be a number")
    
    if min_periods < 1:
        raise ValueError("min_periods must be at least 1")
    
    if min_periods > risk_window:
        raise ValueError("min_periods cannot be greater than risk_window")
    
    if isinstance(horizons, int):
        horizons = [horizons]
    
    # Initialize with the price series to keep the row indices
    df = pl.DataFrame({prices.name or "price": prices})
    
    for horizon in horizons:
        # Calculate future returns
        future_ret = calculate_future_return(prices, horizon, method)
        
        # Convert annual risk-free rate to match horizon days (assuming 252 trading days)
        period_rf_rate = (1 + risk_free_rate) ** (horizon / 252) - 1
        
        # Calculate rolling statistics using custom window function
        def calc_mean(x):
            return np.mean(x)
        
        def calc_std(x):
            return np.std(x, ddof=1) if len(x) > 1 else np.nan
        
        def calc_downside_std(x, rf=period_rf_rate):
            downside = [max(0, rf - r) for r in x]
            return np.sqrt(np.mean(np.array(downside) ** 2)) if downside else np.nan
        
        def calc_max_drawdown(x):
            if not x or len(x) < 2:
                return np.nan
            
            cumulative = np.cumprod(np.array(x) + 1)
            running_max = np.maximum.accumulate(cumulative)
            drawdown = cumulative / running_max - 1
            return np.min(drawdown)
        
        # Apply rolling calculations
        rolling_mean = rolling_window_apply(future_ret, risk_window, calc_mean, min_periods)
        rolling_std = rolling_window_apply(future_ret, risk_window, calc_std, min_periods)
        rolling_downside_std = rolling_window_apply(future_ret, risk_window, 
                                                 lambda x: calc_downside_std(x, period_rf_rate), 
                                                 min_periods)
        max_drawdown = rolling_window_apply(future_ret, risk_window, calc_max_drawdown, min_periods)
        
        # Calculate risk-adjusted metrics
        excess_return = rolling_mean - period_rf_rate
        
        # Sharpe ratio
        sharpe = excess_return / rolling_std
        
        # Sortino ratio
        sortino = excess_return / rolling_downside_std
        
        # Calmar ratio 
        calmar = excess_return / abs(max_drawdown)
        
        # Add to DataFrame
        df = df.with_columns([
            pl.Series(f'future_sharpe_{horizon}', sharpe),
            pl.Series(f'future_sortino_{horizon}', sortino),
            pl.Series(f'future_calmar_{horizon}', calmar)
        ])
    
    # Drop the price column if it exists
    if prices.name or "price" in df.columns:
        df = df.drop([prices.name or "price"])
    
    return df 