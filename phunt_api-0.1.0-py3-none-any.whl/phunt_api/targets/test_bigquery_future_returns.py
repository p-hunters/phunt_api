"""
BigQueryの未来リターン計算のテスト - PHuntAPI認証を使用
"""
import pandas as pd
import numpy as np
import logging
import os
from datetime import datetime, timedelta

# ロギングの設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# PHuntAPIのインポート
from phunt_api import PHuntAPI

# BigQuery関連のインポート
from phunt_api.misc.bq import BigQueryDataFetcher, BigQueryConfig, BigQueryTableManager
from phunt_api.targets.return_targets._adapters.bigquery_adapter import BigQueryReturnTargetService

def login_phunt_api():
    """
    PHuntAPIにログインしてBigQuery認証情報を取得
    """
    # P12ファイルのパスを確認
    p12_path = "/Users/shin/workspace/MT4_ARB/phunt/client.p12"
    if not os.path.exists(p12_path):
        logger.error(f"P12ファイルが見つかりません: {p12_path}")
        return False
    
    try:
        # PHuntAPIの初期化とログイン
        api = PHuntAPI(debug=True)
        api.login(p12_path=p12_path, p12_password="aaa")
        logger.info("PHuntAPIログイン成功: BigQuery認証情報が利用可能です")
        return True
    except Exception as e:
        logger.error(f"PHuntAPIログイン失敗: {e}")
        return False

def create_test_data(rows=100):
    """
    テスト用のデータフレームを作成
    """
    # 連続した日付の生成
    dates = pd.date_range(start='2025-01-01', periods=rows, freq='D')
    
    # 人工的な価格データを生成（ランダムウォーク）
    np.random.seed(42)  # 再現性のために乱数シードを固定
    random_changes = np.random.normal(0.001, 0.02, rows)  # 小さな平均上昇と適度なボラティリティ
    prices = 100.0 * (1 + np.cumsum(random_changes))  # 初期値100から累積変化
    
    # データフレーム作成
    df = pd.DataFrame({
        'ts': dates,
        'close': prices
    })
    
    return df

def test_lead_function():
    """
    BigQueryのLEAD関数を使った単純なテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーの初期化
    fetcher = BigQueryDataFetcher(config)
    
    # シンプルなLEAD関数のテスト
    query = """
    WITH sample_data AS (
        SELECT 1 as id, DATE '2025-01-01' as date, 100.0 as price UNION ALL
        SELECT 2 as id, DATE '2025-01-02' as date, 101.0 as price UNION ALL
        SELECT 3 as id, DATE '2025-01-03' as date, 99.0 as price UNION ALL
        SELECT 4 as id, DATE '2025-01-04' as date, 102.0 as price UNION ALL
        SELECT 5 as id, DATE '2025-01-05' as date, 103.0 as price
    )
    SELECT 
        date,
        price,
        LEAD(price, 1) OVER (ORDER BY date) as next_price,
        LEAD(price, 2) OVER (ORDER BY date) as next_2_price,
        CASE 
            WHEN LEAD(price, 1) OVER (ORDER BY date) IS NULL THEN NULL
            ELSE (LEAD(price, 1) OVER (ORDER BY date) - price) / price
        END as return_1
    FROM sample_data
    ORDER BY date
    """
    
    try:
        result = fetcher.execute_query(query)
        logger.info(f"LEAD関数テストの結果:\n{result}")
        return "LEAD関数テスト成功"
    except Exception as e:
        logger.error(f"LEAD関数テスト失敗: {e}")
        return f"エラー: {e}"

def test_future_returns():
    """
    未来リターン計算のSQLテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーとテーブルマネージャーの初期化
    fetcher = BigQueryDataFetcher(config)
    table_manager = BigQueryTableManager(config)
    
    # テスト用データの作成
    df = create_test_data(100)
    
    try:
        # データをBigQueryテーブルにロード
        temp_table_id = table_manager.create_temp_table_id("future_returns_test")
        logger.info(f"テーブルID: {temp_table_id}")
        
        # データのロード
        table_manager.load_dataframe(df, temp_table_id)
        logger.info(f"テストデータをテーブル '{temp_table_id}' にロードしました (行数: {len(df)})")
        
        # 完全修飾テーブル参照
        fully_qualified_table_ref = f"{config.project_id}.{config.dataset_id}.{temp_table_id}"
        
        # 未来リターン計算用のSQLクエリ
        horizons = [2, 5, 10]
        method = 'arithmetic'  # または 'log'
        
        sql = f"""
        WITH price_data AS (SELECT * FROM `{fully_qualified_table_ref.replace('.phunt_api.phunt_api.', '.phunt_api.')}`)
        
        -- 日付順に並べて単一のSELECTで未来リターンを計算
        SELECT 
            pd.ts as ts,
            pd.close as close,
        """
        
        # 各horizonのリターン計算部分を追加
        for horizon in horizons:
            if method == 'arithmetic':
                # 算術リターン: (未来価格 - 現在価格) / 現在価格
                sql += f"""
            CASE 
                WHEN LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) IS NULL THEN NULL
                WHEN pd.close = 0 THEN NULL
                ELSE (LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) - pd.close) / pd.close
            END AS return_{horizon},
        """
            else:  # method == 'log'
                # 対数リターン: ln(未来価格 / 現在価格)
                sql += f"""
            CASE 
                WHEN LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) IS NULL THEN NULL
                WHEN pd.close <= 0 OR LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) <= 0 THEN NULL
                ELSE LN(LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) / pd.close)
            END AS return_{horizon},
        """
        
        # 最後のカンマを削除
        sql = sql.rstrip(",\n") + "\n"
        
        # FROM句とORDER BY句を追加
        sql += f"""
        FROM price_data pd
        ORDER BY pd.ts
        """
        
        # SQLクエリのロギング
        logger.info(f"実行するSQLクエリ:\n{sql}")
        
        # クエリ実行
        result = fetcher.execute_query(sql)
        logger.info(f"未来リターン計算の結果（先頭5行）:\n{result.head()}")
        
        # Pandasでの計算結果と比較
        pandas_result = pd.DataFrame({'ts': df['ts'], 'close': df['close']})
        
        for horizon in horizons:
            if method == 'arithmetic':
                pandas_result[f'return_{horizon}'] = df['close'].shift(-horizon).sub(df['close']).div(df['close'])
            else:  # method == 'log'
                pandas_result[f'return_{horizon}'] = np.log(df['close'].shift(-horizon).div(df['close']))
        
        logger.info(f"Pandas計算の結果（先頭5行）:\n{pandas_result.head()}")
        
        # 結果の比較（先頭10行の平均絶対誤差）
        comparison_rows = min(10, len(result), len(pandas_result))
        
        for horizon in horizons:
            bq_values = result[f'return_{horizon}'].iloc[:comparison_rows].dropna()
            pd_values = pandas_result[f'return_{horizon}'].iloc[:comparison_rows].dropna()
            
            # 共通のインデックスを持つ値のみを比較
            common_indices = set(bq_values.index).intersection(set(pd_values.index))
            if common_indices:
                bq_common = bq_values.loc[list(common_indices)]
                pd_common = pd_values.loc[list(common_indices)]
                
                # 平均絶対誤差（MAE）
                mae = (bq_common - pd_common).abs().mean()
                logger.info(f"Horizon {horizon}の平均絶対誤差: {mae}")
                
                # 誤差が小さいことを確認（浮動小数点の誤差を考慮）
                assert mae < 1e-10, f"Horizon {horizon}のBigQueryとPandasの結果が一致しません（MAE={mae}）"
        
        # テスト終了後にテーブルを削除
        try:
            # 正規表現で重複するphunt_api部分を削除
            corrected_table_ref = fully_qualified_table_ref.replace('.phunt_api.phunt_api.', '.phunt_api.')
            table_manager.client.delete_table(corrected_table_ref, not_found_ok=True)
            logger.info(f"テーブル '{fully_qualified_table_ref}' は正常に削除されました")
        except Exception as e:
            logger.error(f"テーブル削除エラー: {str(e)}")
        
        return "未来リターン計算のテスト成功"
    except Exception as e:
        logger.error(f"未来リターン計算のテスト失敗: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return f"エラー: {e}"

def test_bigquery_service_methods():
    """
    BigQueryReturnTargetServiceの内部メソッドをテストする
    """
    print("\n===== BigQueryReturnTargetService内部メソッドのテスト =====")
    
    try:
        # テスト用のDataFrameを作成
        df = pd.DataFrame({
            'ts': pd.date_range(start='2025-01-01', periods=100),
            'close': np.random.normal(100, 5, 100).cumsum() + 1000
        })
        
        # モックサービスの設定
        from unittest.mock import MagicMock
        
        # サービスのクラスをインポートしなおして使用する
        from phunt_api.targets.return_targets._adapters.bigquery_adapter import BigQueryReturnTargetService
        
        # プロジェクトIDを実際の存在するものに設定
        service = BigQueryReturnTargetService(project_id="phunt-api")
        
        # データフェッチャーとテーブルマネージャーをモックに置き換え
        service.data_fetcher = MagicMock()
        service.table_manager = MagicMock()
        
        # _prepare_dataメソッドのテスト
        df_prep, ts_col, price_col = service._prepare_data(df)
        print(f"_prepare_data結果: ts_col={ts_col}, price_col={price_col}")
        assert ts_col == 'ts', f"日付カラムが正しく認識されていません: {ts_col}"
        assert price_col == 'close', f"価格カラムが正しく認識されていません: {price_col}"
        
        # _calculate_daily_volatilityメソッドの存在チェック
        assert hasattr(service, '_calculate_daily_volatility'), "サービスに_calculate_daily_volatilityメソッドがありません"
        
        # メソッドのシグネチャをチェック
        import inspect
        sig = inspect.signature(service._calculate_daily_volatility)
        assert len(sig.parameters) >= 6, f"_calculate_daily_volatilityメソッドのパラメータが不足しています: {len(sig.parameters)}"
        
        print("BigQueryReturnTargetServiceの内部メソッドのテストに成功しました！")
        
    except Exception as e:
        import traceback
        print(f"エラー: {str(e)}")
        print(traceback.format_exc())

if __name__ == "__main__":
    logger.info("BigQuery未来リターン計算のテストを開始")
    
    # LEAD関数の基本テスト
"""
BigQueryの未来リターン計算のテスト - PHuntAPI認証を使用
"""
import pandas as pd
import numpy as np
import logging
import os
from datetime import datetime, timedelta

# ロギングの設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# PHuntAPIのインポート
from phunt_api import PHuntAPI

# BigQuery関連のインポート
from phunt_api.misc.bq import BigQueryDataFetcher, BigQueryConfig, BigQueryTableManager
from phunt_api.targets.return_targets._adapters.bigquery_adapter import BigQueryReturnTargetService

def login_phunt_api():
    """
    PHuntAPIにログインしてBigQuery認証情報を取得
    """
    # P12ファイルのパスを確認
    p12_path = "/Users/shin/workspace/MT4_ARB/phunt/client.p12"
    if not os.path.exists(p12_path):
        logger.error(f"P12ファイルが見つかりません: {p12_path}")
        return False
    
    try:
        # PHuntAPIの初期化とログイン
        api = PHuntAPI(debug=True)
        api.login(p12_path=p12_path, p12_password="aaa")
        logger.info("PHuntAPIログイン成功: BigQuery認証情報が利用可能です")
        return True
    except Exception as e:
        logger.error(f"PHuntAPIログイン失敗: {e}")
        return False

def create_test_data(rows=100):
    """
    テスト用のデータフレームを作成
    """
    # 連続した日付の生成
    dates = pd.date_range(start='2025-01-01', periods=rows, freq='D')
    
    # 人工的な価格データを生成（ランダムウォーク）
    np.random.seed(42)  # 再現性のために乱数シードを固定
    random_changes = np.random.normal(0.001, 0.02, rows)  # 小さな平均上昇と適度なボラティリティ
    prices = 100.0 * (1 + np.cumsum(random_changes))  # 初期値100から累積変化
    
    # データフレーム作成
    df = pd.DataFrame({
        'ts': dates,
        'close': prices
    })
    
    return df

def test_lead_function():
    """
    BigQueryのLEAD関数を使った単純なテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーの初期化
    fetcher = BigQueryDataFetcher(config)
    
    # シンプルなLEAD関数のテスト
    query = """
    WITH sample_data AS (
        SELECT 1 as id, DATE '2025-01-01' as date, 100.0 as price UNION ALL
        SELECT 2 as id, DATE '2025-01-02' as date, 101.0 as price UNION ALL
        SELECT 3 as id, DATE '2025-01-03' as date, 99.0 as price UNION ALL
        SELECT 4 as id, DATE '2025-01-04' as date, 102.0 as price UNION ALL
        SELECT 5 as id, DATE '2025-01-05' as date, 103.0 as price
    )
    SELECT 
        date,
        price,
        LEAD(price, 1) OVER (ORDER BY date) as next_price,
        LEAD(price, 2) OVER (ORDER BY date) as next_2_price,
        CASE 
            WHEN LEAD(price, 1) OVER (ORDER BY date) IS NULL THEN NULL
            ELSE (LEAD(price, 1) OVER (ORDER BY date) - price) / price
        END as return_1
    FROM sample_data
    ORDER BY date
    """
    
    try:
        result = fetcher.execute_query(query)
        logger.info(f"LEAD関数テストの結果:\n{result}")
        return "LEAD関数テスト成功"
    except Exception as e:
        logger.error(f"LEAD関数テスト失敗: {e}")
        return f"エラー: {e}"

def test_future_returns():
    """
    未来リターン計算のSQLテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーとテーブルマネージャーの初期化
    fetcher = BigQueryDataFetcher(config)
    table_manager = BigQueryTableManager(config)
    
    # テスト用データの作成
    df = create_test_data(100)
    
    try:
        # データをBigQueryテーブルにロード
        temp_table_id = table_manager.create_temp_table_id("future_returns_test")
        logger.info(f"テーブルID: {temp_table_id}")
        
        # データのロード
        table_manager.load_dataframe(df, temp_table_id)
        logger.info(f"テストデータをテーブル '{temp_table_id}' にロードしました (行数: {len(df)})")
        
        # 完全修飾テーブル参照
        fully_qualified_table_ref = f"{config.project_id}.{config.dataset_id}.{temp_table_id}"
        
        # 未来リターン計算用のSQLクエリ
        horizons = [2, 5, 10]
        method = 'arithmetic'  # または 'log'
        
        sql = f"""
        WITH price_data AS (SELECT * FROM `{fully_qualified_table_ref.replace('.phunt_api.phunt_api.', '.phunt_api.')}`)
        
        -- 日付順に並べて単一のSELECTで未来リターンを計算
        SELECT 
            pd.ts as ts,
            pd.close as close,
        """
        
        # 各horizonのリターン計算部分を追加
        for horizon in horizons:
            if method == 'arithmetic':
                # 算術リターン: (未来価格 - 現在価格) / 現在価格
                sql += f"""
            CASE 
                WHEN LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) IS NULL THEN NULL
                WHEN pd.close = 0 THEN NULL
                ELSE (LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) - pd.close) / pd.close
            END AS return_{horizon},
        """
            else:  # method == 'log'
                # 対数リターン: ln(未来価格 / 現在価格)
                sql += f"""
            CASE 
                WHEN LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) IS NULL THEN NULL
                WHEN pd.close <= 0 OR LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) <= 0 THEN NULL
                ELSE LN(LEAD(pd.close, {horizon}) OVER (ORDER BY pd.ts) / pd.close)
            END AS return_{horizon},
        """
        
        # 最後のカンマを削除
        sql = sql.rstrip(",\n") + "\n"
        
        # FROM句とORDER BY句を追加
        sql += f"""
        FROM price_data pd
        ORDER BY pd.ts
        """
        
        # SQLクエリのロギング
        logger.info(f"実行するSQLクエリ:\n{sql}")
        
        # クエリ実行
        result = fetcher.execute_query(sql)
        logger.info(f"未来リターン計算の結果（先頭5行）:\n{result.head()}")
        
        # Pandasでの計算結果と比較
        pandas_result = pd.DataFrame({'ts': df['ts'], 'close': df['close']})
        
        for horizon in horizons:
            if method == 'arithmetic':
                pandas_result[f'return_{horizon}'] = df['close'].shift(-horizon).sub(df['close']).div(df['close'])
            else:  # method == 'log'
                pandas_result[f'return_{horizon}'] = np.log(df['close'].shift(-horizon).div(df['close']))
        
        logger.info(f"Pandas計算の結果（先頭5行）:\n{pandas_result.head()}")
        
        # 結果の比較（先頭10行の平均絶対誤差）
        comparison_rows = min(10, len(result), len(pandas_result))
        
        for horizon in horizons:
            bq_values = result[f'return_{horizon}'].iloc[:comparison_rows].dropna()
            pd_values = pandas_result[f'return_{horizon}'].iloc[:comparison_rows].dropna()
            
            # 共通のインデックスを持つ値のみを比較
            common_indices = set(bq_values.index).intersection(set(pd_values.index))
            if common_indices:
                bq_common = bq_values.loc[list(common_indices)]
                pd_common = pd_values.loc[list(common_indices)]
                
                # 平均絶対誤差（MAE）
                mae = (bq_common - pd_common).abs().mean()
                logger.info(f"Horizon {horizon}の平均絶対誤差: {mae}")
                
                # 誤差が小さいことを確認（浮動小数点の誤差を考慮）
                assert mae < 1e-10, f"Horizon {horizon}のBigQueryとPandasの結果が一致しません（MAE={mae}）"
        
        # テーブルの削除
        table_manager.client.delete_table(fully_qualified_table_ref, not_found_ok=True)
        logger.info(f"テストテーブル '{temp_table_id}' を削除しました")
        
        return "未来リターン計算のテスト成功"
    except Exception as e:
        logger.error(f"未来リターン計算のテスト失敗: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return f"エラー: {e}"

def test_bigquery_service_methods():
    """
    BigQueryReturnTargetServiceの内部メソッドをテスト
    """
    print("\n===== BigQueryReturnTargetService内部メソッドのテスト =====")
    
    try:
        # テストデータ
        df = pd.DataFrame({
            'ts': pd.date_range(start='2025-01-01', periods=100),
            'close': np.random.normal(100, 5, 100).cumsum() + 1000
        })
        
        # サービスインスタンスの作成（PHuntAPI認証を使わずにモックする）
        from unittest.mock import MagicMock
        
        # モックオブジェクトとサービスの設定
        service = BigQueryReturnTargetService(project_id="dummy-project")
        service.data_fetcher = MagicMock()
        service.table_manager = MagicMock()
        
        # _prepare_dataメソッドのテスト
        df_prep, ts_col, price_col = service._prepare_data(df)
        print(f"_prepare_data結果: ts_col={ts_col}, price_col={price_col}")
        assert ts_col == 'ts', f"日付カラムが正しく認識されていません: {ts_col}"
        assert price_col == 'close', f"価格カラムが正しく認識されていません: {price_col}"
        
        # _calculate_daily_volatilityメソッドの存在チェック
        assert hasattr(service, '_calculate_daily_volatility'), "サービスに_calculate_daily_volatilityメソッドがありません"
        print("_calculate_daily_volatilityメソッドの存在確認: OK")
        
        # メソッドの引数チェック
        import inspect
        sig = inspect.signature(service._calculate_daily_volatility)
        assert len(sig.parameters) >= 6, f"_calculate_daily_volatilityメソッドは少なくとも6つの引数を受け取る必要があります: {sig}"
        print(f"_calculate_daily_volatilityメソッドのシグネチャ: {sig}")
        
        print("BigQueryReturnTargetServiceの内部メソッドテスト成功")
    except Exception as e:
        print(f"エラー: {e}")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    logger.info("BigQuery未来リターン計算のテストを開始")
    
    # LEAD関数の基本テスト
    logger.info(test_lead_function())
    
    # 未来リターン計算のテスト
    logger.info(test_future_returns())
    
    # BigQueryReturnTargetServiceの内部メソッドテスト
    test_bigquery_service_methods()
    
    logger.info("テスト完了") 