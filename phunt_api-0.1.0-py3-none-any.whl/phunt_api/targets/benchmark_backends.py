#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
各バックエンド（pandas、polars、duckdb、bigquery）の処理時間を計測するベンチマークスクリプト
"""

import os
import time
import pandas as pd
import numpy as np
import polars as pl
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from typing import Dict, List, Optional, Union, Any, Tuple
import warnings

# 警告を抑制
warnings.filterwarnings('ignore')

# 自作モジュールのインポート
from phunt_api.targets.return_targets import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns
)

# BigQueryが利用可能かチェック
try:
    from google.cloud import bigquery
    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False

# DuckDBが利用可能かチェック
try:
    import duckdb
    DUCKDB_AVAILABLE = True
except ImportError:
    DUCKDB_AVAILABLE = False

def create_synthetic_data(size: int = 100000) -> pd.DataFrame:
    """ベンチマーク用の合成データを作成する"""
    # 日付の作成
    start_date = datetime(2020, 1, 1)
    dates = [start_date + timedelta(hours=i) for i in range(size)]
    
    # ランダム価格の生成（ランダムウォーク）
    np.random.seed(42)  # 再現性のために乱数シードを固定
    random_changes = np.random.normal(0, 1, size) * 0.01
    prices = 100 * np.exp(np.cumsum(random_changes))
    
    # データフレーム作成
    df = pd.DataFrame({
        'ts': dates,
        'close': prices,
        'open': prices * np.random.uniform(0.99, 1.01, size),
        'high': prices * np.random.uniform(1.0, 1.02, size),
        'low': prices * np.random.uniform(0.98, 1.0, size),
        'volume': np.random.randint(1000, 100000, size)
    })
    
    return df

def load_real_data() -> pd.DataFrame:
    from phunt_api import PHuntAPI
    api = PHuntAPI(debug=True)
    api.login(p12_path="/Users/shin/workspace/MT4_ARB/phunt/client.p12", p12_password="aaa")
    df = api.get_dataset('EURUSD_1MIN_2024')
    return df


def run_benchmark(df: pd.DataFrame, horizons: List[int] = [2, 5, 10, 20], 
                 run_count: int = 3, backends: List[str] = None) -> Dict[str, Any]:
    """
    各バックエンドの処理時間を計測する
    
    Parameters:
    -----------
    df : pd.DataFrame
        入力データフレーム
    horizons : List[int]
        将来リターン計算の期間
    run_count : int
        各測定の実行回数（平均を取るため）
    backends : List[str]
        テストするバックエンドのリスト。None の場合はすべてのバックエンドをテスト
        
    Returns:
    --------
    Dict[str, Any]
        各バックエンドの処理時間と結果
    """
    if backends is None:
        backends = ["pandas", "polars"]
        if DUCKDB_AVAILABLE:
            backends.append("duckdb")
        if BIGQUERY_AVAILABLE:
            backends.append("bigquery")
    
    # 結果を保存する辞書
    results = {
        "data_size": len(df),
        "horizons": horizons,
        "run_count": run_count,
        "backends": {},
        "functions": [
            # "calculate_future_returns", 
            # "calculate_direction_labels", 
            # "calculate_volatility_adjusted_returns", 
            "calculate_risk_adjusted_returns"
        ]
    }
    
    # 前処理
    df_copy = df.copy()
    if 'ts' in df_copy.columns:
        df_copy.set_index('ts', inplace=True)
    
    # 各バックエンドでベンチマークを実行
    for backend in backends:
        print(f"\n===== {backend.upper()} バックエンドのベンチマーク =====")
        backend_results = {
            "calculate_future_returns": [],
            "calculate_direction_labels": [],
            "calculate_volatility_adjusted_returns": [],
            "calculate_risk_adjusted_returns": []
        }
        
        # # 各関数でベンチマークを実行
        # # 1. calculate_future_returns
        # for i in range(run_count):
        #     start_time = time.time()
        #     try:
        #         result = calculate_future_returns(
        #             prices=df_copy['close'],
        #             horizons=horizons,
        #             normalize=True,
        #             backend=backend
        #         )
        #         duration = time.time() - start_time
        #         print(f"calculate_future_returns (実行 {i+1}/{run_count}): {duration:.4f}秒")
        #         backend_results["calculate_future_returns"].append(duration)
        #         # 最初の実行の結果サンプルを保存（JSONシリアライズ可能な形式で）
        #         if i == 0 and isinstance(result, pd.DataFrame):
        #             # Timestampなどのシリアライズ問題を避けるため、単純な値だけ保存
        #             try:
        #                 sample_dict = {}
        #                 for col in result.columns:
        #                     sample_dict[str(col)] = [float(x) if pd.notna(x) else None for x in result[col].head(5)]
        #                 backend_results["future_returns_sample"] = sample_dict
        #             except Exception as e:
        #                 print(f"サンプル保存エラー: {e}")
        #                 backend_results["future_returns_sample"] = {"error": str(e)}
        #     except Exception as e:
        #         print(f"エラー (calculate_future_returns): {e}")
        #         backend_results["calculate_future_returns"].append(None)
        
        # # 2. calculate_direction_labels
        # for i in range(run_count):
        #     start_time = time.time()
        #     try:
        #         result = calculate_direction_labels(
        #             prices=df_copy['close'],
        #             horizons=horizons,
        #             backend=backend
        #         )
        #         duration = time.time() - start_time
        #         print(f"calculate_direction_labels (実行 {i+1}/{run_count}): {duration:.4f}秒")
        #         backend_results["calculate_direction_labels"].append(duration)
        #         if i == 0 and isinstance(result, pd.DataFrame):
        #             # Timestampなどのシリアライズ問題を避けるため、単純な値だけ保存
        #             try:
        #                 sample_dict = {}
        #                 for col in result.columns:
        #                     sample_dict[str(col)] = [float(x) if pd.notna(x) else None for x in result[col].head(5)]
        #                 backend_results["direction_labels_sample"] = sample_dict
        #             except Exception as e:
        #                 print(f"サンプル保存エラー: {e}")
        #                 backend_results["direction_labels_sample"] = {"error": str(e)}
        #     except Exception as e:
        #         print(f"エラー (calculate_direction_labels): {e}")
        #         backend_results["calculate_direction_labels"].append(None)
        
        # # 3. calculate_volatility_adjusted_returns
        # for i in range(run_count):
        #     start_time = time.time()
        #     try:
        #         result = calculate_volatility_adjusted_returns(
        #             prices=df_copy['close'],
        #             horizons=horizons,
        #             backend=backend
        #         )
        #         duration = time.time() - start_time
        #         print(f"calculate_volatility_adjusted_returns (実行 {i+1}/{run_count}): {duration:.4f}秒")
        #         backend_results["calculate_volatility_adjusted_returns"].append(duration)
        #         if i == 0 and isinstance(result, pd.DataFrame):
        #             # Timestampなどのシリアライズ問題を避けるため、単純な値だけ保存
        #             try:
        #                 sample_dict = {}
        #                 for col in result.columns:
        #                     sample_dict[str(col)] = [float(x) if pd.notna(x) else None for x in result[col].head(5)]
        #                 backend_results["vol_adj_returns_sample"] = sample_dict
        #             except Exception as e:
        #                 print(f"サンプル保存エラー: {e}")
        #                 backend_results["vol_adj_returns_sample"] = {"error": str(e)}
        #     except Exception as e:
        #         print(f"エラー (calculate_volatility_adjusted_returns): {e}")
        #         backend_results["calculate_volatility_adjusted_returns"].append(None)
        
        # 4. calculate_risk_adjusted_returns
        for i in range(run_count):
            start_time = time.time()
            try:
                result = calculate_risk_adjusted_returns(
                    prices=df_copy['close'],
                    horizons=horizons,
                    backend=backend
                )
                duration = time.time() - start_time
                print(f"calculate_risk_adjusted_returns (実行 {i+1}/{run_count}): {duration:.4f}秒")
                backend_results["calculate_risk_adjusted_returns"].append(duration)
                if i == 0 and isinstance(result, pd.DataFrame):
                    # Timestampなどのシリアライズ問題を避けるため、単純な値だけ保存
                    try:
                        sample_dict = {}
                        for col in result.columns:
                            sample_dict[str(col)] = [float(x) if pd.notna(x) else None for x in result[col].head(5)]
                        backend_results["risk_adj_returns_sample"] = sample_dict
                    except Exception as e:
                        print(f"サンプル保存エラー: {e}")
                        backend_results["risk_adj_returns_sample"] = {"error": str(e)}
            except Exception as e:
                print(f"エラー (calculate_risk_adjusted_returns): {e}")
                backend_results["calculate_risk_adjusted_returns"].append(None)
        
        # 平均処理時間を計算
        # イテレーション中に辞書を変更しないようにリストで関数名を取得
        function_names = [func for func in backend_results.keys() if not func.endswith("_sample")]
        for func in function_names:
            times = [t for t in backend_results[func] if t is not None]
            if times:
                backend_results[f"{func}_avg"] = sum(times) / len(times)
                backend_results[f"{func}_min"] = min(times)
                backend_results[f"{func}_max"] = max(times)
            else:
                backend_results[f"{func}_avg"] = None
                backend_results[f"{func}_min"] = None
                backend_results[f"{func}_max"] = None
        
        results["backends"][backend] = backend_results
    
    return results

def generate_visualization(results: Dict[str, Any], output_dir: str = "benchmark_results"):
    """
    ベンチマーク結果の可視化を生成する
    
    Parameters:
    -----------
    results : Dict[str, Any]
        ベンチマーク結果
    output_dir : str
        出力ディレクトリ
    """
    # 出力ディレクトリの作成
    Path(output_dir).mkdir(exist_ok=True, parents=True)
    
    # 各関数ごとに棒グラフを作成
    for func in results["functions"]:
        # データ収集
        backends = []
        avg_times = []
        min_times = []
        max_times = []
        
        for backend, data in results["backends"].items():
            if f"{func}_avg" in data and data[f"{func}_avg"] is not None:
                backends.append(backend)
                avg_times.append(data[f"{func}_avg"])
                min_times.append(data[f"{func}_min"])
                max_times.append(data[f"{func}_max"])
        
        if not backends:
            continue
        
        # プロット作成
        plt.figure(figsize=(10, 6))
        bar_width = 0.5
        index = np.arange(len(backends))
        
        bars = plt.bar(index, avg_times, bar_width, label='平均時間', alpha=0.8)
        
        # エラーバーの追加 (min/max)
        yerr = [
            [avg - min_val for avg, min_val in zip(avg_times, min_times)],  # 下側エラー
            [max_val - avg for avg, max_val in zip(avg_times, max_times)]   # 上側エラー
        ]
        plt.errorbar(index, avg_times, yerr=yerr, fmt='none', color='black', capsize=5)
        
        # バーの上に値を表示
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.02,
                     f'{avg_times[i]:.4f}s',
                     ha='center', va='bottom', rotation=0)
        
        plt.xlabel('バックエンド')
        plt.ylabel('処理時間 (秒)')
        plt.title(f'{func} の処理時間比較')
        plt.xticks(index, backends)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存
        plt.savefig(f"{output_dir}/{func}_comparison.png")
        plt.close()
    
    # 総合比較グラフ
    plt.figure(figsize=(12, 8))
    bar_width = 0.2
    functions = results["functions"]
    backends = list(results["backends"].keys())
    
    # 各関数ごとのデータを収集
    data = {}
    for func in functions:
        data[func] = []
        for backend in backends:
            if backend in results["backends"] and f"{func}_avg" in results["backends"][backend]:
                data[func].append(results["backends"][backend][f"{func}_avg"] or 0)
            else:
                data[func].append(0)
    
    # プロットの作成
    index = np.arange(len(backends))
    for i, func in enumerate(functions):
        plt.bar(index + i * bar_width, data[func], bar_width, 
                label=func.replace('calculate_', '').replace('_', ' '))
    
    plt.xlabel('バックエンド')
    plt.ylabel('平均処理時間 (秒)')
    plt.title('各バックエンドの関数ごとの処理時間比較')
    plt.xticks(index + bar_width * (len(functions) - 1) / 2, backends)
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # 保存
    plt.savefig(f"{output_dir}/overall_comparison.png")
    plt.close()
    
    # 各バックエンドの総合時間を計算
    total_times = {}
    for backend in backends:
        if backend in results["backends"]:
            total = 0
            count = 0
            for func in functions:
                if f"{func}_avg" in results["backends"][backend] and results["backends"][backend][f"{func}_avg"]:
                    total += results["backends"][backend][f"{func}_avg"]
                    count += 1
            if count > 0:
                total_times[backend] = total / count
    
    # 総合時間の棒グラフ
    if total_times:
        plt.figure(figsize=(10, 6))
        backends_sorted = sorted(total_times.keys(), key=lambda x: total_times[x])
        times_sorted = [total_times[b] for b in backends_sorted]
        
        bars = plt.bar(backends_sorted, times_sorted, alpha=0.8)
        
        # バーの上に値を表示
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.02,
                     f'{times_sorted[i]:.4f}s',
                     ha='center', va='bottom', rotation=0)
        
        plt.xlabel('バックエンド')
        plt.ylabel('平均処理時間 (秒)')
        plt.title('各バックエンドの総合パフォーマンス比較')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存
        plt.savefig(f"{output_dir}/total_performance.png")
        plt.close()

def save_results(results: Dict[str, Any], output_dir: str = "benchmark_results"):
    """ベンチマーク結果をJSONファイルに保存する"""
    Path(output_dir).mkdir(exist_ok=True, parents=True)
    
    # シリアライズ可能なデータに変換
    def json_serializable(obj):
        if hasattr(obj, 'to_dict'):
            # DataFrameなどto_dictメソッドを持つオブジェクト
            return obj.to_dict()
        elif hasattr(obj, 'isoformat'):
            # datetime, timestamp系のオブジェクト
            return obj.isoformat()
        else:
            # その他の型
            return str(obj)
    
    with open(f"{output_dir}/benchmark_results.json", 'w') as f:
        json.dump(results, f, indent=2, default=json_serializable)
    print(f"結果を {output_dir}/benchmark_results.json に保存しました")

def generate_markdown_report(results: Dict[str, Any], output_dir: str = "benchmark_results"):
    """ベンチマーク結果からMarkdownレポートを生成する"""
    Path(output_dir).mkdir(exist_ok=True, parents=True)
    
    # 関数名をきれいに表示するための辞書
    function_display_names = {
        "calculate_future_returns": "将来リターン計算",
        "calculate_direction_labels": "方向ラベル計算",
        "calculate_volatility_adjusted_returns": "ボラティリティ調整済みリターン計算",
        "calculate_risk_adjusted_returns": "リスク調整済みリターン計算"
    }
    
    # バックエンドの説明
    backend_descriptions = {
        "pandas": "Python データ分析の標準ライブラリ。使いやすさと柔軟性が特徴。",
        "polars": "Rust で書かれた高速な DataFrame ライブラリ。並列処理とメモリ効率が特徴。",
        "duckdb": "分析向けの組み込みSQLデータベースエンジン。大規模データセットに効率的。",
        "bigquery": "Google Cloud のサーバーレスデータウェアハウス。膨大なデータ処理に適している。"
    }
    
    with open(f"{output_dir}/benchmark_report.md", 'w') as f:
        # ヘッダー
        f.write("# バックエンドパフォーマンス比較レポート\n\n")
        f.write(f"**作成日時**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**データサイズ**: {results['data_size']} 行\n")
        f.write(f"**計算期間**: {', '.join(map(str, results['horizons']))}\n")
        f.write(f"**実行回数**: {results['run_count']} 回 (平均値を報告)\n\n")
        
        # 各バックエンドの説明
        f.write("## バックエンドの概要\n\n")
        for backend in results["backends"]:
            if backend in backend_descriptions:
                f.write(f"### {backend.capitalize()}\n")
                f.write(f"{backend_descriptions[backend]}\n\n")
        
        # 総合パフォーマンス
        f.write("## 総合パフォーマンス\n\n")
        f.write("![総合パフォーマンス](total_performance.png)\n\n")
        f.write("各バックエンドの全関数の平均処理時間を比較しています。低いほど高速です。\n\n")
        
        # 関数ごとの詳細比較
        f.write("## 関数ごとの詳細比較\n\n")
        f.write("![全体比較](overall_comparison.png)\n\n")
        
        # テーブル形式でのデータ表示
        f.write("### 処理時間の詳細 (秒)\n\n")
        
        # テーブルのヘッダー
        f.write("| 関数 | " + " | ".join([b.capitalize() for b in results["backends"].keys()]) + " |\n")
        f.write("| --- | " + " | ".join(["---" for _ in results["backends"]]) + " |\n")
        
        # 各関数の結果
        for func in results["functions"]:
            display_name = function_display_names.get(func, func)
            row = [f"**{display_name}**"]
            
            for backend in results["backends"].keys():
                key = f"{func}_avg"
                if key in results["backends"][backend] and results["backends"][backend][key] is not None:
                    row.append(f"{results['backends'][backend][key]:.4f}")
                else:
                    row.append("N/A")
            
            f.write("| " + " | ".join(row) + " |\n")
        
        # 最速バックエンドの特定
        f.write("\n## 最速バックエンド分析\n\n")
        
        fastest_backends = {}
        for func in results["functions"]:
            fastest = None
            fastest_time = float('inf')
            
            for backend, data in results["backends"].items():
                key = f"{func}_avg"
                if key in data and data[key] is not None and data[key] < fastest_time:
                    fastest = backend
                    fastest_time = data[key]
            
            if fastest:
                fastest_backends[func] = (fastest, fastest_time)
        
        if fastest_backends:
            f.write("各関数で最速のバックエンド:\n\n")
            for func, (backend, time) in fastest_backends.items():
                display_name = function_display_names.get(func, func)
                f.write(f"- **{display_name}**: {backend.capitalize()} ({time:.4f}秒)\n")
        
        # 個別の関数ごとの詳細
        f.write("\n## 個別関数の詳細\n\n")
        for func in results["functions"]:
            display_name = function_display_names.get(func, func)
            f.write(f"### {display_name}\n\n")
            f.write(f"![{display_name}]({func}_comparison.png)\n\n")
            
            # 最小、平均、最大実行時間のテーブル
            f.write("| バックエンド | 最小 (秒) | 平均 (秒) | 最大 (秒) |\n")
            f.write("| --- | --- | --- | --- |\n")
            
            for backend in results["backends"].keys():
                min_key = f"{func}_min"
                avg_key = f"{func}_avg"
                max_key = f"{func}_max"
                
                if (avg_key in results["backends"][backend] and 
                    results["backends"][backend][avg_key] is not None):
                    min_val = results["backends"][backend][min_key]
                    avg_val = results["backends"][backend][avg_key]
                    max_val = results["backends"][backend][max_key]
                    f.write(f"| {backend.capitalize()} | {min_val:.4f} | {avg_val:.4f} | {max_val:.4f} |\n")
            
            f.write("\n")
        
        # 推奨事項
        f.write("## 推奨事項\n\n")
        
        # 各ユースケースに最適なバックエンドの推奨
        f.write("### ユースケース別推奨バックエンド\n\n")
        
        f.write("| ユースケース | 推奨バックエンド | 理由 |\n")
        f.write("| --- | --- | --- |\n")
        f.write("| 小〜中規模データセット (メモリ内処理) | ")
        
        # 小〜中規模データ向けの推奨バックエンド
        small_medium_backends = ["pandas", "polars"]
        small_medium_backends = [b for b in small_medium_backends if b in results["backends"]]
        if small_medium_backends:
            fastest = min(small_medium_backends, 
                           key=lambda b: sum(results["backends"][b].get(f"{f}_avg", float('inf')) 
                                            for f in results["functions"] 
                                            if f"{f}_avg" in results["backends"][b]))
            f.write(f"{fastest.capitalize()} | ")
            if fastest == "polars":
                f.write("並列処理と最適化されたメモリ使用により、メモリ内計算で高速 |\n")
            else:
                f.write("使いやすさと十分な速度のバランスが良い |\n")
        else:
            f.write("データなし | データなし |\n")
        
        # 大規模データ向けの推奨バックエンド
        f.write("| 大規模データセット | ")
        large_backends = ["duckdb", "bigquery"]
        large_backends = [b for b in large_backends if b in results["backends"]]
        if large_backends:
            fastest = min(large_backends, 
                          key=lambda b: sum(results["backends"][b].get(f"{f}_avg", float('inf')) 
                                           for f in results["functions"] 
                                           if f"{f}_avg" in results["backends"][b]))
            f.write(f"{fastest.capitalize()} | ")
            if fastest == "duckdb":
                f.write("ローカル環境で大規模データセットでも効率的に処理可能 |\n")
            else:
                f.write("クラウドベースで膨大なデータ処理に適している |\n")
        else:
            f.write("テスト実行なし | 大規模データセットについては別途テストが必要 |\n")
        
        # リアルタイム計算向けの推奨バックエンド
        f.write("| リアルタイム計算 | ")
        realtime_backends = ["polars", "pandas"]
        realtime_backends = [b for b in realtime_backends if b in results["backends"]]
        if realtime_backends:
            fastest = min(realtime_backends, 
                          key=lambda b: min(results["backends"][b].get(f"{f}_min", float('inf')) 
                                           for f in results["functions"] 
                                           if f"{f}_min" in results["backends"][b]))
            f.write(f"{fastest.capitalize()} | ")
            if fastest == "polars":
                f.write("低レイテンシと予測可能なパフォーマンスが特徴 |\n")
            else:
                f.write("使い慣れた API と十分な速度 |\n")
        else:
            f.write("データなし | データなし |\n")
        
        # バッチ処理向けの推奨バックエンド
        f.write("| バッチ処理 | ")
        batch_backends = ["duckdb", "bigquery"]
        batch_backends = [b for b in batch_backends if b in results["backends"]]
        if batch_backends:
            fastest = min(batch_backends, 
                          key=lambda b: sum(results["backends"][b].get(f"{f}_avg", float('inf')) 
                                           for f in results["functions"] 
                                           if f"{f}_avg" in results["backends"][b]))
            f.write(f"{fastest.capitalize()} | ")
            if fastest == "duckdb":
                f.write("効率的なクエリ最適化とディスクベースの処理により大量データでも安定したパフォーマンス |\n")
            else:
                f.write("スケーラブルなクラウドインフラストラクチャを活用した大規模バッチ処理に適している |\n")
        else:
            f.write("テスト実行なし | バッチ処理については別途テストが必要 |\n")
        
        # 全体的な結論
        f.write("\n### 総合評価\n\n")
        
        # 総合時間に基づいて順位付け
        total_times = {}
        for backend in results["backends"]:
            total = 0
            count = 0
            for func in results["functions"]:
                key = f"{func}_avg"
                if key in results["backends"][backend] and results["backends"][backend][key] is not None:
                    total += results["backends"][backend][key]
                    count += 1
            if count > 0:
                total_times[backend] = total / count
        
        if total_times:
            sorted_backends = sorted(total_times.keys(), key=lambda x: total_times[x])
            
            f.write("総合パフォーマンス順位（処理時間が短い順）:\n\n")
            for i, backend in enumerate(sorted_backends):
                f.write(f"{i+1}. **{backend.capitalize()}** - 平均処理時間: {total_times[backend]:.4f}秒\n")
            
            f.write("\n")
            
            if sorted_backends:
                best = sorted_backends[0]
                f.write(f"**総合評価**: このベンチマークの結果では、全体的に **{best.capitalize()}** が最良のパフォーマンスを示しました。\n\n")
                
                f.write("ただし、実際の選択は以下の要素も考慮する必要があります：\n\n")
                f.write("- **データサイズ**: 大規模データセットでは DuckDB や BigQuery が優れる可能性があります\n")
                f.write("- **開発の容易さ**: Pandas は API が使いやすく、幅広いサポートがあります\n")
                f.write("- **メモリ制約**: Polars や DuckDB はメモリ効率が高いため、リソースが制限された環境に適しています\n")
                f.write("- **バッチ vs リアルタイム**: リアルタイム処理には低レイテンシの Polars が、バッチ処理には DuckDB が適している場合があります\n")
        
        print(f"レポートを {output_dir}/benchmark_report.md に保存しました")

def main():
    """メイン関数"""
    print("バックエンドベンチマークを開始します...")
    
    # データの読み込み（実データまたは合成データ）
    df = load_real_data()
    print(f"データサイズ: {len(df)}行")
    
    # ベンチマークの実行（すべてのバックエンド）
    print("すべての利用可能なバックエンドでテストを実行します")
    backends = ["pandas", "polars"]
    if DUCKDB_AVAILABLE:
        backends.append("duckdb")
        print("DuckDBバックエンドが利用可能です")
    else:
        print("DuckDBバックエンドは利用できません")
    
    # BigQueryも追加
    if BIGQUERY_AVAILABLE:
        backends.append("bigquery")
        print("BigQueryバックエンドが利用可能です")
    else:
        print("BigQueryバックエンドは利用できません")
    
    print(f"テスト対象バックエンド: {backends}")
    results = run_benchmark(df, run_count=1, backends=backends)
    
    # 結果の保存
    output_dir = "api/benchmark_results"
    save_results(results, output_dir)
    
    # 可視化の生成
    generate_visualization(results, output_dir)
    
    # マークダウンレポートの生成
    generate_markdown_report(results, output_dir)
    
    print("ベンチマーク完了")

if __name__ == "__main__":
    main() 