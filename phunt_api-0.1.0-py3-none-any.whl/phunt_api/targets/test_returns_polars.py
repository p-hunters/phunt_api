import numpy as np
import pandas as pd
import polars as pl
import pytest
from datetime import datetime, timedelta

from phunt_api.targets.returns_polars import (
    calculate_future_returns,
    calculate_direction_labels,
    calculate_volatility_adjusted_returns,
    calculate_risk_adjusted_returns,
    rolling_window_apply
)

# Helper functions for tests
def create_test_series():
    """Create a test price series in both Pandas and Polars formats."""
    # Create date range
    dates = [datetime(2023, 1, 1) + timedelta(days=i) for i in range(100)]
    
    # Create price data (simple upward trend with small random component)
    prices = [100.0 + i * 0.5 + np.random.normal(0, 0.5) for i in range(100)]
    
    # Create Pandas Series
    pd_series = pd.Series(prices, index=dates, name="price")
    
    # Convert to Polars Series
    pl_series = pl.Series("price", prices)
    
    return pd_series, pl_series

def create_constant_series():
    """Create a constant price series in both Pandas and Polars formats."""
    # Create date range
    dates = [datetime(2023, 1, 1) + timedelta(days=i) for i in range(100)]
    
    # Create constant price data
    prices = [100.0] * 100
    
    # Create Pandas Series
    pd_series = pd.Series(prices, index=dates, name="price")
    
    # Convert to Polars Series
    pl_series = pl.Series("price", prices)
    
    return pd_series, pl_series

def assert_dataframes_equal(pd_df, pl_df, rtol=1e-5, atol=1e-8):
    """Compare pandas and polars DataFrames with tolerance."""
    # Convert polars DataFrame to pandas for comparison
    pl_pd_df = pl_df.to_pandas()
    
    # Ensure same column order for comparison
    if set(pd_df.columns) == set(pl_pd_df.columns):
        pl_pd_df = pl_pd_df[pd_df.columns]
    
    # Compare values with tolerance
    for col in pd_df.columns:
        if col in pl_pd_df.columns:
            np.testing.assert_allclose(
                pd_df[col].dropna().values,
                pl_pd_df[col].dropna().values,
                rtol=rtol,
                atol=atol,
                equal_nan=True
            )

# Test functions
def test_calculate_future_returns():
    """Test the calculate_future_returns function."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test basic future returns calculation
    horizons = [1, 5, 10, 20]
    future_returns = calculate_future_returns(pl_prices, horizons=horizons, normalize=False)
    
    # Check output columns
    expected_cols = [f'future_return_{h}' for h in horizons]
    assert all(col in future_returns.columns for col in expected_cols)

def test_calculate_future_returns_normalize():
    """Test the calculate_future_returns function with normalization."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test with normalization
    horizons = [1, 5, 10]
    future_returns = calculate_future_returns(pl_prices, horizons=horizons, normalize=True)
    
    # Check output columns
    expected_cols = [f'future_return_{h}' for h in horizons]
    assert all(col in future_returns.columns for col in expected_cols)

def test_calculate_direction_labels():
    """Test the calculate_direction_labels function."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test binary direction labels
    horizons = [1, 5, 10]
    direction_labels = calculate_direction_labels(pl_prices, horizons=horizons, threshold=0.0)
    
    # Check output columns
    expected_cols = [f'direction_{h}' for h in horizons]
    assert all(col in direction_labels.columns for col in expected_cols)
    
    # Check all values are binary (0 or 1)
    for col in expected_cols:
        unique_vals = direction_labels[col].unique().to_list()
        assert all(val in [0, 1, None] for val in unique_vals)

def test_calculate_volatility_adjusted_returns():
    """Test the calculate_volatility_adjusted_returns function."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test volatility adjusted returns
    horizons = [1, 5, 10]
    vol_adj_returns = calculate_volatility_adjusted_returns(
        pl_prices, horizons=horizons, vol_window=10
    )
    
    # Check output columns
    expected_cols = [f'vol_adj_return_{h}' for h in horizons]
    assert all(col in vol_adj_returns.columns for col in expected_cols)

def test_rolling_window_apply():
    """Test the rolling_window_apply function."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test simple mean function
    def mean_func(x):
        return np.mean(x)
    
    # Apply rolling window function
    window_size = 10
    result = rolling_window_apply(pl_prices, window=window_size, func=mean_func)
    
    # Check length
    assert len(result) == len(pl_prices)
    
    # Check first values are None (not enough data)
    assert all(v is None for v in result[:window_size-1])
    
    # Check remaining values are not None
    assert all(v is not None for v in result[window_size-1:])

def test_calculate_risk_adjusted_returns():
    """Test the calculate_risk_adjusted_returns function."""
    # Create test data
    _, pl_prices = create_test_series()
    
    # Test risk adjusted returns
    horizons = [5, 10]
    risk_adj_returns = calculate_risk_adjusted_returns(
        pl_prices, horizons=horizons, risk_window=20, min_periods=5
    )
    
    # Check output columns
    expected_prefixes = ['future_sharpe_', 'future_sortino_', 'future_calmar_']
    expected_cols = [f'{prefix}{h}' for prefix in expected_prefixes for h in horizons]
    assert all(col in risk_adj_returns.columns for col in expected_cols)

def test_constant_price_series():
    """Test all functions with constant price series."""
    # Create constant test data
    _, pl_constant = create_constant_series()
    
    # Test functions with constant data
    horizons = [1, 5]
    
    # Future returns
    future_returns = calculate_future_returns(pl_constant, horizons=horizons, normalize=False)
    
    # Direction labels
    direction_labels = calculate_direction_labels(pl_constant, horizons=horizons)
    
    # Check all direction labels for constant series should be 0
    for col in direction_labels.columns:
        # First few may be None due to shifting, so check non-null values
        non_null = direction_labels[col].drop_nulls()
        assert (non_null == 0).all()

    # Volatility adjusted returns may contain NaN/inf due to zero volatility
    # This is expected behavior
    vol_adj_returns = calculate_volatility_adjusted_returns(
        pl_constant, horizons=horizons, vol_window=10
    )
    
    # For the risk-adjusted returns, we should get reasonable values or NaN
    risk_adj_returns = calculate_risk_adjusted_returns(
        pl_constant, horizons=horizons, risk_window=20, min_periods=5
    )

# Run tests when script is executed directly
if __name__ == "__main__":
    test_calculate_future_returns()
    test_calculate_future_returns_normalize()
    test_calculate_direction_labels()
    test_calculate_volatility_adjusted_returns()
    test_rolling_window_apply()
    test_calculate_risk_adjusted_returns()
    test_constant_price_series()
    print("All tests passed!") 