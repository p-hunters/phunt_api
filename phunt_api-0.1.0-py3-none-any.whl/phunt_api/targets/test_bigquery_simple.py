"""
シンプルなBigQueryテスト - PHuntAPI認証を使用
"""
import pandas as pd
import numpy as np
import logging
import time
import os
from datetime import datetime, timedelta

# ロギングの設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# PHuntAPIのインポート
from phunt_api import PHuntAPI

# BigQuery関連のインポート
from phunt_api.misc.bq import BigQueryDataFetcher, BigQueryConfig

def login_phunt_api():
    """
    PHuntAPIにログインしてBigQuery認証情報を取得
    """
    # P12ファイルのパスを確認
    p12_path = "/Users/shin/workspace/MT4_ARB/phunt/client.p12"
    if not os.path.exists(p12_path):
        logger.error(f"P12ファイルが見つかりません: {p12_path}")
        return False
    
    try:
        # PHuntAPIの初期化とログイン
        api = PHuntAPI(debug=True)
        api.login(p12_path=p12_path, p12_password="aaa")
        logger.info("PHuntAPIログイン成功: BigQuery認証情報が利用可能です")
        return True
    except Exception as e:
        logger.error(f"PHuntAPIログイン失敗: {e}")
        return False

def test_simple_query():
    """
    シンプルなBigQueryクエリのテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーの初期化
    fetcher = BigQueryDataFetcher(config)
    
    # シンプルなクエリ（CTEなし、JOINなし）
    query = """
    SELECT 
        1 AS test_value,
        CURRENT_TIMESTAMP() AS current_time
    """
    
    try:
        result = fetcher.execute_query(query)
        logger.info(f"クエリ実行結果: {result}")
        return "シンプルクエリのテスト成功"
    except Exception as e:
        logger.error(f"シンプルクエリのテスト失敗: {e}")
        return f"エラー: {e}"

def create_and_query_temp_table():
    """
    一時テーブルの作成と基本的なクエリのテスト
    """
    # PHuntAPIにログインして認証情報を取得
    if not login_phunt_api():
        return "PHuntAPIログインに失敗したためテストをスキップします"
    
    # テスト用設定
    config = BigQueryConfig(
        project_id="phunt-api",
        dataset_id="phunt_api"
    )
    
    # データフェッチャーの初期化
    fetcher = BigQueryDataFetcher(config)
    
    # テスト用データの作成
    data = pd.DataFrame({
        'id': range(1, 6),
        'value': [10, 20, 30, 40, 50],
        'timestamp': pd.date_range(start='2025-01-01', periods=5)
    })
    
    # テーブル名
    table_id = f"phunt_api.test_table_{int(time.time())}"
    
    try:
        # テーブル作成クエリ
        create_query = f"""
        CREATE OR REPLACE TABLE `{table_id}` AS
        SELECT * FROM UNNEST([
            STRUCT(1 AS id, 10 AS value, TIMESTAMP '2025-01-01' AS timestamp),
            STRUCT(2 AS id, 20 AS value, TIMESTAMP '2025-01-02' AS timestamp),
            STRUCT(3 AS id, 30 AS value, TIMESTAMP '2025-01-03' AS timestamp),
            STRUCT(4 AS id, 40 AS value, TIMESTAMP '2025-01-04' AS timestamp),
            STRUCT(5 AS id, 50 AS value, TIMESTAMP '2025-01-05' AS timestamp)
        ])
        """
        fetcher.execute_query(create_query)
        logger.info(f"テストテーブル '{table_id}' を作成しました")
        
        # シンプルなSELECTクエリ
        select_query = f"""
        SELECT * FROM `{table_id}`
        ORDER BY id
        """
        result = fetcher.execute_query(select_query)
        logger.info(f"テーブルクエリ結果: {result}")
        
        # テーブル削除
        drop_query = f"DROP TABLE IF EXISTS `{table_id}`"
        fetcher.execute_query(drop_query)
        logger.info(f"テストテーブル '{table_id}' を削除しました")
        
        return "一時テーブルのテスト成功"
    except Exception as e:
        logger.error(f"一時テーブルのテスト失敗: {e}")
        return f"エラー: {e}"

if __name__ == "__main__":
    logger.info("BigQueryの簡易テストを開始")
    
    # シンプルなクエリのテスト
    logger.info(test_simple_query())
    
    # 一時テーブルのテスト
    logger.info(create_and_query_temp_table())
    
    logger.info("テスト完了") 