import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple


def calculate_basic_orderbook_features(
    orderbook_data: Dict[str, pd.DataFrame],
    depth_levels: int = 5
) -> pd.DataFrame:
    """
    Calculate basic orderbook features like spread, mid price, and imbalance.
    
    Args:
        orderbook_data: Dictionary containing bid and ask DataFrames with price and volume
        depth_levels: Number of price levels to consider
    
    Returns:
        DataFrame with basic orderbook features
    """
    features = pd.DataFrame(index=orderbook_data['bid'].index)
    
    # Best bid/ask prices and volumes
    best_bid = orderbook_data['bid'].iloc[:, 0]  # Assuming first column is best bid
    best_ask = orderbook_data['ask'].iloc[:, 0]  # Assuming first column is best ask
    best_bid_vol = orderbook_data['bid_volume'].iloc[:, 0]
    best_ask_vol = orderbook_data['ask_volume'].iloc[:, 0]
    
    # Calculate basic features
    features['spread'] = best_ask - best_bid
    features['mid_price'] = (best_ask + best_bid) / 2
    features['relative_spread'] = features['spread'] / features['mid_price']
    
    # Volume imbalance at best prices
    features['best_bid_ask_imbalance'] = (best_bid_vol - best_ask_vol) / (best_bid_vol + best_ask_vol)
    
    # Calculate features for each depth level
    for level in range(depth_levels):
        bid_price = orderbook_data['bid'].iloc[:, level]
        ask_price = orderbook_data['ask'].iloc[:, level]
        bid_vol = orderbook_data['bid_volume'].iloc[:, level]
        ask_vol = orderbook_data['ask_volume'].iloc[:, level]
        
        # Price and volume features at each level
        features[f'bid_price_level_{level+1}'] = bid_price
        features[f'ask_price_level_{level+1}'] = ask_price
        features[f'bid_volume_level_{level+1}'] = bid_vol
        features[f'ask_volume_level_{level+1}'] = ask_vol
        
        # Price gaps between levels
        if level > 0:
            prev_bid = orderbook_data['bid'].iloc[:, level-1]
            prev_ask = orderbook_data['ask'].iloc[:, level-1]
            features[f'bid_gap_level_{level}'] = prev_bid - bid_price
            features[f'ask_gap_level_{level}'] = ask_price - prev_ask
    
    return features


def calculate_orderbook_liquidity_features(
    orderbook_data: Dict[str, pd.DataFrame],
    price_levels: List[float] = [0.0001, 0.0002, 0.0005]  # Price distances from mid
) -> pd.DataFrame:
    """
    Calculate liquidity-related features from the orderbook.
    
    Args:
        orderbook_data: Dictionary containing bid and ask DataFrames with price and volume
        price_levels: List of price distances from mid price to calculate liquidity at
    
    Returns:
        DataFrame with liquidity features
    """
    features = pd.DataFrame(index=orderbook_data['bid'].index)
    
    mid_price = (orderbook_data['ask'].iloc[:, 0] + orderbook_data['bid'].iloc[:, 0]) / 2
    
    for price_level in price_levels:
        # Calculate cumulative volume available within price_level distance from mid
        bid_mask = (mid_price - orderbook_data['bid']) <= price_level
        ask_mask = (orderbook_data['ask'] - mid_price) <= price_level
        
        bid_liquidity = (orderbook_data['bid_volume'] * bid_mask).sum(axis=1)
        ask_liquidity = (orderbook_data['ask_volume'] * ask_mask).sum(axis=1)
        
        features[f'bid_liquidity_{price_level}'] = bid_liquidity
        features[f'ask_liquidity_{price_level}'] = ask_liquidity
        features[f'liquidity_imbalance_{price_level}'] = (bid_liquidity - ask_liquidity) / (bid_liquidity + ask_liquidity)
    
    return features


def calculate_orderbook_pressure_features(
    orderbook_data: Dict[str, pd.DataFrame],
    windows: List[int] = [5, 10, 20]
) -> pd.DataFrame:
    """
    Calculate order book pressure features including price impact and order flow imbalance.
    
    Args:
        orderbook_data: Dictionary containing bid and ask DataFrames with price and volume
        windows: List of window sizes for rolling calculations
    
    Returns:
        DataFrame with pressure-related features
    """
    features = pd.DataFrame(index=orderbook_data['bid'].index)
    
    # Calculate total volume at each side
    total_bid_volume = orderbook_data['bid_volume'].sum(axis=1)
    total_ask_volume = orderbook_data['ask_volume'].sum(axis=1)
    
    # Order flow imbalance
    features['order_flow_imbalance'] = (total_bid_volume - total_ask_volume) / (total_bid_volume + total_ask_volume)
    
    # Calculate rolling statistics
    for window in windows:
        # Rolling mean of order flow imbalance
        features[f'order_flow_imbalance_ma_{window}'] = features['order_flow_imbalance'].rolling(window=window).mean()
        
        # Rolling volatility of order flow imbalance
        features[f'order_flow_imbalance_std_{window}'] = features['order_flow_imbalance'].rolling(window=window).std()
        
        # Rolling correlation between order flow imbalance and price changes
        mid_price = (orderbook_data['ask'].iloc[:, 0] + orderbook_data['bid'].iloc[:, 0]) / 2
        price_changes = mid_price.pct_change()
        features[f'flow_price_corr_{window}'] = (
            features['order_flow_imbalance'].rolling(window=window)
            .corr(price_changes)
        )
    
    return features


def calculate_trade_flow_features(
    trade_data: pd.DataFrame,
    windows: List[int] = [5, 10, 20]
) -> pd.DataFrame:
    """
    Calculate features from trade flow data.
    
    Args:
        trade_data: DataFrame with trade data (price, volume, direction)
        windows: List of window sizes for rolling calculations
    
    Returns:
        DataFrame with trade flow features
    """
    features = pd.DataFrame(index=trade_data.index)
    
    # Assuming trade_data has columns: price, volume, direction (1 for buy, -1 for sell)
    
    # Calculate basic trade flow metrics
    features['trade_flow'] = trade_data['volume'] * trade_data['direction']
    features['trade_flow_imbalance'] = features['trade_flow'].rolling(window=1).sum()
    
    for window in windows:
        # Volume-weighted average price (VWAP)
        features[f'vwap_{window}'] = (
            (trade_data['price'] * trade_data['volume']).rolling(window=window).sum() /
            trade_data['volume'].rolling(window=window).sum()
        )
        
        # Rolling trade flow metrics
        features[f'trade_flow_ma_{window}'] = features['trade_flow'].rolling(window=window).mean()
        features[f'trade_flow_std_{window}'] = features['trade_flow'].rolling(window=window).std()
        
        # Buy/Sell ratio
        buy_volume = (trade_data['volume'] * (trade_data['direction'] == 1)).rolling(window=window).sum()
        sell_volume = (trade_data['volume'] * (trade_data['direction'] == -1)).rolling(window=window).sum()
        features[f'buy_sell_ratio_{window}'] = buy_volume / sell_volume
    
    return features


def calculate_all_orderbook_features(
    orderbook_data: Dict[str, pd.DataFrame],
    trade_data: Optional[pd.DataFrame] = None,
    depth_levels: int = 5,
    price_levels: List[float] = [0.0001, 0.0002, 0.0005],
    windows: List[int] = [5, 10, 20]
) -> pd.DataFrame:
    """
    Calculate all orderbook-related features.
    
    Args:
        orderbook_data: Dictionary containing bid and ask DataFrames with price and volume
        trade_data: Optional DataFrame with trade data
        depth_levels: Number of price levels to consider
        price_levels: List of price distances from mid for liquidity calculation
        windows: List of window sizes for rolling calculations
    
    Returns:
        DataFrame with all orderbook features
    """
    # Calculate basic orderbook features
    basic_features = calculate_basic_orderbook_features(orderbook_data, depth_levels)
    
    # Calculate liquidity features
    liquidity_features = calculate_orderbook_liquidity_features(orderbook_data, price_levels)
    
    # Calculate pressure features
    pressure_features = calculate_orderbook_pressure_features(orderbook_data, windows)
    
    # Combine all features
    features = pd.concat([
        basic_features,
        liquidity_features,
        pressure_features
    ], axis=1)
    
    # Add trade flow features if trade data is available
    if trade_data is not None:
        trade_features = calculate_trade_flow_features(trade_data, windows)
        features = pd.concat([features, trade_features], axis=1)
    
    return features 