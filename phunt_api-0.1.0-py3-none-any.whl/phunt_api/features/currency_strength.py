import pandas as pd
import numpy as np
import os

data_dir = os.environ.get('DATA_DIR', '../data')

def get_1min_bar(symbol, year):
    df = pd.read_parquet(f'{data_dir}/{symbol}_1MIN_{year}.parquet')
    df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('datetime', inplace=True)
    pip_factor = 1/10**(max(df.close.astype(str).apply(lambda x: len(x.split('.')[1])).values)-1)
    df['spread'] = df['spread'] * pip_factor
    df['close'] = df['close'] - df['spread'] / 2
    print(f'{symbol} spread_max: {df.spread.max()}, spread_min: {df.spread.min()}, pip_factor: {pip_factor}')
    return df

def get_log_changes(symbols, year):
    dfs = []
    for symbol in symbols:
        df = get_1min_bar(symbol, year)
        df[symbol] = np.log(df['close'] / df['close'].iloc[0])
        df = df[[symbol]]
        dfs.append(df)
    df = pd.concat(dfs, axis=1)
    df.dropna(inplace=True)
    return df

def calc_strength(symbols, currency, year):
    def strength_sign(symbol, currencty):
        return -1 if symbol.endswith(currencty) else 1
    
    log_changes = get_log_changes(symbols, year)
    strength = None
    for symbol in symbols:
        if not currency in symbol:
            continue
        if strength is None:
            strength = strength_sign(symbol, currency) * log_changes[symbol]
        else:
            strength += strength_sign(symbol, currency) * log_changes[symbol]
    return strength.fillna(method='ffill')

def extract_currencies(symbols):
    currencies = set()
    for symbol in symbols:
        currencies.add(symbol[:3])
        currencies.add(symbol[-3:])
    return currencies   

def calc_all_currency_strength(symbols, year):
    currencies = extract_currencies(symbols)
    strengths = {}
    for currency in currencies:
        strengths[currency] = calc_strength(symbols, currency, year)
    return pd.DataFrame(strengths)

def get_currency_strength(symbols, year=2024):
    os.makedirs(f'{data_dir}/strengths', exist_ok=True)
    if os.path.exists(f'{data_dir}/strengths/{year}.parquet'):
        print(f'{year}.parquet exists')
        strengths = pd.read_parquet(f'{data_dir}/strengths/{year}.parquet')
    else:
        print(f'{year}.parquet not exists')
        strengths = calc_all_currency_strength(symbols, year)
        strengths.to_parquet(f'{data_dir}/strengths/{year}.parquet')
    return strengths

def strength_selected(_strengths):
    strengths = _strengths.copy()
    strengths['METALS'] = (strengths['XAU'] + strengths['XAG']) / 2 
    strengths['OCEANIA'] = (strengths['AUD'] + strengths['NZD']) / 2  
    strengths['RISK_OFF'] = (strengths['JPY'] + strengths['CHF']) / 2 
    strengths['EUROPE'] = (strengths['EUR'] + strengths['GBP']) / 2 
    strengths['AMERICA'] = (strengths['USD'] + strengths['CAD']) / 2 
    strengths_selected = strengths[['METALS', 'OCEANIA', 'RISK_OFF', 'EUROPE', 'AMERICA']]
    return strengths_selected


def create_strength_target(_strengths, target_currency='JPY', MIN_PERIOD=7):
    # 分足ベースの MIN_PERIOD 分 のリスク調整済みリターンがターゲット
    # 推論に1分かかる想定で、1分後からMIN_PERIOD1分の値幅を計算している
    strengths = _strengths.copy()
    target = strengths[target_currency].diff(1).rolling(window=MIN_PERIOD).mean().shift(-1*MIN_PERIOD-1) / strengths[target_currency].diff(1).rolling(window=MIN_PERIOD).std().shift(-1*MIN_PERIOD-1)
    target = target.dropna()
    outliers_plus = target < target.quantile(0.999)
    outliers_minus = target > target.quantile(0.001)
    target = target[(outliers_plus & outliers_minus)]

    # target.plot()
    target.hist(bins=10000)

    # 3値分類
    thr = 0.5
    target_3 = target.apply(lambda x: 1 if x > thr else -1 if x < -thr else 0)
    print(target_3.value_counts())
    return target_3

