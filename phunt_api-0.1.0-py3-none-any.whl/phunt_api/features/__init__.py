# Temporarily import only market_features for testing
from .market_features import (
    calculate_returns as market_calculate_returns,
    calculate_cross_currency_features,
    calculate_futures_features,
    calculate_market_turbulence,
    calculate_currency_strength_features,
    calculate_all_market_features,
)
from .price_features import calculate_price_features
from .price_features_polars import calculate_price_features as calculate_price_features_polars
from .price_features_bq import calculate_statistical_moments_bq

# 統一APIのインポート
try:
    from .price_features.unified_api import (
        calculate_returns,
        calculate_moving_averages,
        calculate_statistical_moments,
        PriceFeatureBackend,
    )
    UNIFIED_API_AVAILABLE = True
except ImportError:
    # 統一APIが利用できない場合のフォールバック
    UNIFIED_API_AVAILABLE = False

__all__ = [
    # 既存のAPI
    'market_calculate_returns',  # 名前衝突を避けるためにリネーム
    'calculate_cross_currency_features',
    'calculate_futures_features',
    'calculate_market_turbulence',
    'calculate_currency_strength_features',
    'calculate_all_market_features',
    'calculate_price_features',
    'calculate_price_features_polars',
    'calculate_statistical_moments_bq',
]

# 統一APIが利用可能なら、それらをエクスポートリストに追加
if UNIFIED_API_AVAILABLE:
    __all__.extend([
        'calculate_returns',
        'calculate_moving_averages',
        'calculate_statistical_moments',
        'PriceFeatureBackend',
    ])
