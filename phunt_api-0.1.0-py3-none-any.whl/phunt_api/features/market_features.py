import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union
from concurrent.futures import ThreadPoolExecutor

# ==============================================================================
# 1. Utility Function for Returns
# ==============================================================================
def calculate_returns(
    price_series: pd.Series,
    return_periods: List[int] = [1, 5, 10, 15]
) -> pd.DataFrame:
    """
    Calculate rolling returns for a given price series over specified periods.

    Args:
        price_series (pd.Series): The price series.
        return_periods (List[int]): A list of periods for which to calculate returns.

    Returns:
        pd.DataFrame: A DataFrame where each column represents the returns over a given period.
                      Column names follow the pattern 'ret_{period}'.
    """
    returns_df = pd.DataFrame(index=price_series.index)
    for period in return_periods:
        returns_df[f"ret_{period}"] = price_series.pct_change(periods=period)
    return returns_df


# ==============================================================================
# 2. Cross-Currency Features
# ==============================================================================
def calculate_cross_currency_features(
    currency_data: Dict[str, pd.Series],
    base_currency: str = "EURUSD",
    return_periods: List[int] = [1, 5, 10, 15],
    correlation_window: int = 20
) -> pd.DataFrame:
    """
    Calculate cross-currency features such as rolling returns and rolling correlations
    against a specified base currency.

    Args:
        currency_data (Dict[str, pd.Series]): A dictionary where keys are currency pair symbols
            (e.g., 'EURUSD') and values are price series.
        base_currency (str): The currency pair used as reference to calculate correlation.
        return_periods (List[int]): A list of periods for which to calculate returns.
        correlation_window (int): Lookback window size for calculating rolling correlation.

    Returns:
        pd.DataFrame: A DataFrame with:
            - Rolling returns for all currency pairs, each prefixed with <pair>_ret_<period>.
            - Rolling correlation of each pair with the base_currency price returns.
    """
    if base_currency not in currency_data:
        raise ValueError(f"Base currency '{base_currency}' not found in currency_data keys.")

    # Sort index of base currency for consistency
    base_prices = currency_data[base_currency].sort_index()
    features = pd.DataFrame(index=base_prices.index)

    # Calculate rolling returns for each currency pair
    for pair, price_series in currency_data.items():
        price_series = price_series.sort_index()
        pair_returns = calculate_returns(price_series, return_periods)
        pair_returns = pair_returns.add_prefix(f"{pair}_")
        features = features.join(pair_returns, how="outer")

    # Calculate rolling correlations with the base currency
    base_ret = base_prices.pct_change()
    for pair, price_series in currency_data.items():
        if pair == base_currency:
            continue
        pair_ret = price_series.sort_index().pct_change()
        corr_series = (
            base_ret.rolling(window=correlation_window, min_periods=correlation_window)
                   .corr(pair_ret)
        )
        features[f"{pair}_corr_{base_currency}_{correlation_window}"] = corr_series

    return features


# ==============================================================================
# 3. Futures-Related Features
# ==============================================================================
def calculate_futures_features(
    futures_data: Dict[str, Dict[str, pd.Series]],
    return_periods: List[int] = [1, 5, 10, 15],
    volume_ma_windows: List[int] = [5, 20],
    volatility_windows: List[int] = [5, 20]
) -> pd.DataFrame:
    """
    Calculate features for futures instruments (e.g. E6, SR3, VIX). Includes returns,
    volume/open-interest moving averages, ratios, and historical volatility.

    Args:
        futures_data (Dict[str, Dict[str, pd.Series]]): Nested dictionary containing
            price/volume/open interest time series by future symbol.
        return_periods (List[int]): Periods for rolling returns calculation.
        volume_ma_windows (List[int]): Windows for calculating volume/open-interest MAs.
        volatility_windows (List[int]): Windows for volatility calculations.

    Returns:
        pd.DataFrame: A DataFrame with features for each future symbol and date index.
    """
    all_futures_features = pd.DataFrame()

    for future_symbol, data_dict in futures_data.items():
        if "price" not in data_dict:
            raise ValueError(f"No 'price' series found for {future_symbol} in futures_data.")

        price_series = data_dict["price"].sort_index()
        symbol_features = pd.DataFrame(index=price_series.index)

        # (1) Returns
        returns_df = calculate_returns(price_series, return_periods)
        returns_df = returns_df.add_prefix(f"{future_symbol}_")
        symbol_features = symbol_features.join(returns_df, how="outer")

        # (2) Volume-based features
        if "volume" in data_dict:
            volume_series = data_dict["volume"].sort_index()
            for window in volume_ma_windows:
                vol_ma = volume_series.rolling(window=window, min_periods=1).mean()
                symbol_features[f"{future_symbol}_volume_ma_{window}"] = vol_ma
                symbol_features[f"{future_symbol}_volume_ratio_{window}"] = (
                    volume_series / vol_ma
                )

        # (3) Open-interest-based features
        if "open_interest" in data_dict:
            oi_series = data_dict["open_interest"].sort_index()
            for window in volume_ma_windows:
                oi_ma = oi_series.rolling(window=window, min_periods=1).mean()
                symbol_features[f"{future_symbol}_oi_ma_{window}"] = oi_ma
                symbol_features[f"{future_symbol}_oi_ratio_{window}"] = (
                    oi_series / oi_ma
                )

        # (4) Volatility features (annualized approximation)
        for window in volatility_windows:
            vol = (
                price_series.pct_change()
                .rolling(window=window, min_periods=1)
                .std()
                * np.sqrt(252)
            )
            symbol_features[f"{future_symbol}_volatility_{window}"] = vol

        all_futures_features = pd.concat([all_futures_features, symbol_features], axis=1)

    return all_futures_features


# ==============================================================================
# 4. Market Turbulence with Mahalanobis Distance (Chunk + Overlap)
# ==============================================================================
def calculate_market_turbulence(
    currency_data: Dict[str, pd.Series],
    window: int = 20,
    chunk_size: int = 1000,
    max_retries_for_inv: int = 5
) -> pd.Series:
    """
    Calculate a market turbulence index using the Mahalanobis distance on rolling
    windows of currency returns. Implements chunk processing with overlap so that
    rolling windows across chunk boundaries are computed correctly.

    Args:
        currency_data (Dict[str, pd.Series]): Dictionary of currency pairs and their
            price series.
        window (int): Lookback window size for mean/covariance computation.
        chunk_size (int): Size of chunks for processing large datasets (with overlap).
        max_retries_for_inv (int): Maximum retries for inverting near-singular matrices.

    Returns:
        pd.Series: A Series with the same index as the merged currency returns,
                   containing the turbulence index (Mahalanobis distance).
    """
    # Build returns DataFrame
    returns_df = pd.DataFrame()
    first_series = next(iter(currency_data.values()))
    index = first_series.index
    
    for pair, price_series in currency_data.items():
        sorted_series = price_series.sort_index()
        returns_df[pair] = sorted_series.pct_change()

    returns_df = returns_df.dropna(how="all")  # Drop rows that are all NaNs

    # Prepare output Series with the same index as input
    turbulence = pd.Series(index=index, dtype=float)
    turbulence[:] = np.nan  # Initialize all values as NaN

    # Mahalanobis distance helper
    def mahalanobis_distance(
        x: Union[pd.Series, np.ndarray],
        mean_vec: Union[pd.Series, np.ndarray],
        cov_mat: pd.DataFrame
    ) -> float:
        diff = x - mean_vec
        return float(diff @ np.linalg.inv(cov_mat) @ diff.T)

    # Process by chunks with overlap
    n = len(returns_df)
    start_idx = 0

    while start_idx < n:
        # end_idx は overlap 分（= window）を足す
        end_idx = min(start_idx + chunk_size + window, n)
        chunk = returns_df.iloc[start_idx:end_idx]

        # 計算はchunk先頭からだが、最初のwindow番目までは計算できないので window から開始
        for i in range(window, len(chunk)):
            idx = chunk.index[i]
            current_returns = chunk.iloc[i]
            hist_slice = chunk.iloc[i - window : i]

            # 平均と共分散
            mean_vec = hist_slice.mean()
            cov_mat = hist_slice.cov()

            # near-singular対策
            retry = 0
            while retry < max_retries_for_inv:
                try:
                    _ = np.linalg.inv(cov_mat)
                    break
                except np.linalg.LinAlgError:
                    cov_mat = cov_mat + np.eye(cov_mat.shape[0]) * 1e-6
                    retry += 1

            # Mahalanobis distance
            try:
                val = mahalanobis_distance(current_returns, mean_vec, cov_mat)
                turbulence.loc[idx] = val
            except np.linalg.LinAlgError:
                turbulence.loc[idx] = np.nan

        # 次の chunk へ
        start_idx += chunk_size

    return turbulence


# ==============================================================================
# 5. Currency Strength Features (with Parallel Calculation)
# ==============================================================================

def calculate_single_currency_strength(
    currency: str,
    log_changes: Dict[str, pd.Series]
) -> pd.Series:
    """
    Calculate strength for a single currency by summing/subtracting the log changes
    of all currency pairs that involve that currency.

    Args:
        currency (str): The currency code (e.g. 'USD', 'EUR').
        log_changes (Dict[str, pd.Series]): A dict mapping 'pair' -> log prices,
                                            e.g. 'EURUSD' -> pd.Series of log(prices).

    Returns:
        pd.Series: Series of currency strength (index aligned with the log_changes data).
    """
    currency_strength_series = pd.Series(0.0, index=next(iter(log_changes.values())).index)
    for pair, series in log_changes.items():
        base, quote = pair[:3], pair[3:]
        if base == currency:
            currency_strength_series += series
        elif quote == currency:
            currency_strength_series -= series
    return currency_strength_series


def calculate_currency_strength_features(
    currency_data: Dict[str, pd.Series],
    base_value_index: int = 0,
    fill_method: str = "ffill",
    combine_groups: bool = True,
    n_jobs: int = -1
) -> pd.DataFrame:
    """
    Calculate individual currency strength features based on log price changes.
    This simplistic approach sums (or subtracts) the log changes of pairs that
    involve each currency. Parallel processing is used via ThreadPoolExecutor.

    Args:
        currency_data (Dict[str, pd.Series]): Dictionary of currency pairs and
            their price series.
        base_value_index (int): The index used as a "base" for log returns
            (commonly 0 for the first available data point).
        fill_method (str): Method for filling missing values (e.g., 'ffill', 'bfill', or None).
        combine_groups (bool): If True, will create combined strength indices like
            METALS_strength, OCEANIA_strength, etc.
        n_jobs (int): Number of threads for parallel processing (-1 means "use all cores").

    Returns:
        pd.DataFrame: DataFrame indexed by date/time with columns for each currency strength,
                      and optionally combined groups.
    """
    # 1. すべての通貨コードを抽出
    unique_currencies = set()
    for pair in currency_data.keys():
        base, quote = pair[:3], pair[3:]
        unique_currencies.update([base, quote])

    # 2. インデックス基準を作成
    first_series = next(iter(currency_data.values()))
    features = pd.DataFrame(index=first_series.sort_index().index)

    # 3. 各ペアの対数価格(log_changes)を作成
    log_changes = {}
    for pair, price_series in currency_data.items():
        price_series = price_series.sort_index()
        if base_value_index < len(price_series):
            ref_value = price_series.iloc[base_value_index]
        else:
            ref_value = price_series.iloc[0]
        log_price = np.log(price_series / ref_value).fillna(0.0)
        log_changes[pair] = log_price

    # 4. 並列処理で各通貨のstrengthを計算
    results_map = {}
    with ThreadPoolExecutor(max_workers=n_jobs if n_jobs > 0 else None) as executor:
        future_to_currency = {
            executor.submit(calculate_single_currency_strength, cur, log_changes): cur
            for cur in unique_currencies
        }
        for future in future_to_currency:
            currency = future_to_currency[future]
            currency_strength_series = future.result()
            results_map[currency] = currency_strength_series

    # 5. features DataFrame に書き込み
    for currency, series in results_map.items():
        features[f"{currency}_strength"] = series

    # 6. 欠損値埋め (fill_method に応じて)
    if fill_method == "ffill":
        features = features.ffill()
    elif fill_method == "bfill":
        features = features.bfill()
    elif fill_method is not None:
        features = features.fillna(0.0)

    # 7. グループ通貨（METALS, OCEANIAなど）の強度を合成
    if combine_groups:
        group_defs = {
            "METALS_strength": ["XAU", "XAG"],
            "OCEANIA_strength": ["AUD", "NZD"],
            "RISK_OFF_strength": ["JPY", "CHF"],
            "EUROPE_strength": ["EUR", "GBP"],
            "AMERICA_strength": ["USD", "CAD"],
        }
        for group_name, group_currencies in group_defs.items():
            available_currencies = [c for c in group_currencies if f"{c}_strength" in features.columns]
            if len(available_currencies) > 0:  # 1つ以上の通貨が利用可能な場合
                features[group_name] = features[[f"{c}_strength" for c in available_currencies]].mean(axis=1)

    return features


# ==============================================================================
# 6. Master Function to Calculate All Market Features
# ==============================================================================
def calculate_all_market_features(
    currency_data: Dict[str, pd.Series],
    futures_data: Dict[str, Dict[str, pd.Series]],
    base_currency: str = "EURUSD",
    return_periods: List[int] = [1, 5, 10, 15],
    correlation_window: int = 20,
    volume_ma_windows: List[int] = [5, 20],
    volatility_windows: List[int] = [5, 20],
    turbulence_window: int = 20,
    turbulence_chunk_size: int = 1000,
    currency_strength_kwargs: Optional[Dict] = None
) -> pd.DataFrame:
    """
    Calculate a comprehensive set of market features, including:

    1. Cross-currency features (returns and correlations)
    2. Currency strength features (log-based, possibly parallel)
    3. Futures features (returns, volume, open-interest, volatility)
    4. Market turbulence index (Mahalanobis distance with chunked processing)

    Args:
        currency_data (Dict[str, pd.Series]): Dictionary of currency pairs and price series.
        futures_data (Dict[str, Dict[str, pd.Series]]): Dictionary of futures data,
            each key is a future symbol mapping to a dict with 'price', 'volume', 'open_interest'.
        base_currency (str): Reference currency pair for correlation calculations.
        return_periods (List[int]): Return intervals for currency/futures.
        correlation_window (int): Window size for currency correlation calculations.
        volume_ma_windows (List[int]): Window sizes for volume/open-interest MAs.
        volatility_windows (List[int]): Window sizes for volatility calculations.
        turbulence_window (int): Window size for turbulence calculation.
        turbulence_chunk_size (int): Chunk size for turbulence processing (with overlap).
        currency_strength_kwargs (Optional[Dict]): Additional arguments for currency
            strength calculation. e.g. {'base_value_index': 0, 'fill_method': 'ffill', 'n_jobs': 4}.

    Returns:
        pd.DataFrame: Combined DataFrame of all features, indexed by date/time.
    """
    # (0) チェック: すべての通貨ペアが pd.Series か
    if not all(isinstance(v, pd.Series) for v in currency_data.values()):
        raise ValueError("All currency_data values must be pandas Series.")

    # (0) 全通貨ペアでインデックスを揃える(必須ならreindexするなど)
    indices = [series.index for series in currency_data.values()]
    if not all(indices[0].equals(idx) for idx in indices[1:]):
        raise ValueError("All currency pairs must have the same index for consistent calculations.")

    if currency_strength_kwargs is None:
        currency_strength_kwargs = {}

    # (1) Cross-currency features
    cross_ccy = calculate_cross_currency_features(
        currency_data=currency_data,
        base_currency=base_currency,
        return_periods=return_periods,
        correlation_window=correlation_window
    )

    # (2) Currency strength features
    ccy_strength = calculate_currency_strength_features(currency_data, **currency_strength_kwargs)

    # (3) Futures features
    futures_feats = calculate_futures_features(
        futures_data=futures_data,
        return_periods=return_periods,
        volume_ma_windows=volume_ma_windows,
        volatility_windows=volatility_windows
    )

    # (4) Market turbulence
    turbulence_series = calculate_market_turbulence(
        currency_data=currency_data,
        window=turbulence_window,
        chunk_size=turbulence_chunk_size
    ).rename("market_turbulence")

    # 結合
    all_features = pd.concat([cross_ccy, ccy_strength, futures_feats, turbulence_series], axis=1)

    return all_features
