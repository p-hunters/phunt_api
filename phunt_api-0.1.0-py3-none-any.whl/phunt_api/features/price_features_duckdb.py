"""
DuckDBを使用した価格データからの特徴量計算モジュール

このモジュールは、価格データから統計的モーメント（平均、分散、歪度、尖度、JB統計量）などの
時系列特徴量をDuckDBを用いて計算します。
"""

import polars as pl
import pandas as pd
import asyncio
from typing import Union, List, Dict, Optional, Any, Tuple, TypeVar
import os
import duckdb
import pathlib
import logging
# 共通DuckDBコンポーネントのインポート
from phunt_api.misc.duckdb import (
    DUCKDB_AVAILABLE,
    DuckDBConfig,
    DuckDBTableManager,
    DuckDBDataFetcher,
    DuckDBResourceError,
    QueryExecutionError,
    ValidationError,
    check_duckdb_requirements,
    DuckDBService,
    is_duckdb_available
)

# バックエンド利用可能性フラグ
DUCKDB_AVAILABLE = is_duckdb_available()

# ロガー設定
logger = logging.getLogger(__name__)

# =============================================================================
# 特徴量SQL生成クラス
# =============================================================================

class DuckDBFeatureGenerator:
    """
    DuckDBでの特徴量計算用SQLクエリを生成するクラス
    
    主な責務:
    - 各種特徴量計算のためのSQL生成
    - クエリの最適化と標準化
    - 複雑なウィンドウ関数とSQL式の構築
    """
    
    @staticmethod
    def get_moments_query(
        table_id: str,
        date_column: str,
        value_column: str,
        window: int
    ) -> str:
        """
        統計的モーメント（平均、分散、歪度、尖度、JB統計量）計算用のSQLを生成
        ネストされた分析関数を避けるために2段階のアプローチを使用
        
        Args:
            table_id: ソーステーブル名
            date_column: 日付/時系列カラム名
            value_column: 計算対象の値カラム名
            window: 計算ウィンドウサイズ
            
        Returns:
            実行可能なSQL文字列
        """
        # 2段階のクエリでネスト分析関数を回避
        sql = f"""
        -- ステップ1: 基本的な統計量を計算
        WITH base_stats AS (
          SELECT
            {date_column},
            {value_column},
            AVG({value_column}) OVER w AS mean,
            STDDEV({value_column}) OVER w AS stddev,
            VARIANCE({value_column}) OVER w AS variance,
            COUNT(*) OVER w AS count
          FROM {table_id}
          WINDOW w AS (ORDER BY {date_column} ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW)
        ),
        
        -- ステップ2: 各行について中心化した値を計算
        centered_vals AS (
          SELECT
            a.{date_column},
            (a.{value_column} - b.mean) AS centered_val,
            POW(a.{value_column} - b.mean, 2) AS squared_centered,
            POW(a.{value_column} - b.mean, 3) AS cubed_centered,
            POW(a.{value_column} - b.mean, 4) AS fourth_pow_centered,
            b.mean,
            b.stddev,
            b.variance,
            b.count
          FROM {table_id} a
          JOIN base_stats b ON a.{date_column} = b.{date_column}
        ),
        
        -- ステップ3: 同じウィンドウ範囲で集計して歪度と尖度を計算
        moments_calc AS (
          SELECT
            {date_column},
            mean AS rolling_mean,
            variance AS rolling_var,
            count,
            CASE
              WHEN count < 3 OR stddev = 0 THEN NULL
              ELSE (
                SUM(cubed_centered) OVER w / (count * POW(stddev, 3))
              ) * (count / ((count - 1) * (count - 2)))
            END AS rolling_skew,
            CASE
              WHEN count < 4 OR variance = 0 THEN NULL
              ELSE (
                SUM(fourth_pow_centered) OVER w / (count * POW(variance, 2))
              ) * (count * (count + 1)) / ((count - 1) * (count - 2) * (count - 3)) - 3
            END AS rolling_kurt
          FROM centered_vals
          WINDOW w AS (ORDER BY {date_column} ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW)
        )
        
        -- 最終結果: 名前付け規則に従ったカラム名で出力
        SELECT
          {date_column},
          rolling_mean AS rolling_mean_{window},
          rolling_var AS rolling_var_{window},
          rolling_skew AS rolling_skew_{window},
          rolling_kurt AS rolling_kurt_{window},
          CASE
            WHEN rolling_skew IS NULL OR rolling_kurt IS NULL THEN NULL
            ELSE (count / 6) * (
              POW(COALESCE(rolling_skew, 0), 2) + POW(COALESCE(rolling_kurt, 0), 2) / 4
            )
          END AS rolling_jb_{window}
        FROM moments_calc
        ORDER BY {date_column}
        """
        return sql
    
    @staticmethod
    def get_returns_query(
        table_id: str,
        date_column: str,
        price_column: str,
        period: int,
        method: str = 'arithmetic'
    ) -> str:
        """
        リターン計算用のSQLを生成
        
        Args:
            table_id: ソーステーブル名
            date_column: 日付/時系列カラム名
            price_column: 価格カラム名
            period: リターン計算期間
            method: 'arithmetic'または'log'
            
        Returns:
            実行可能なSQL文字列
        """
        if method.lower() == 'log':
            return_expr = f"LN({price_column} / LAG({price_column}, {period}) OVER (ORDER BY {date_column}))"
        else:  # arithmetic
            return_expr = f"({price_column} - LAG({price_column}, {period}) OVER (ORDER BY {date_column})) / LAG({price_column}, {period}) OVER (ORDER BY {date_column})"
        
        sql = f"""
        SELECT
            {date_column},
            {price_column},
            {return_expr} AS return_{period}
        FROM {table_id}
        ORDER BY {date_column}
        """
        return sql
    
    @staticmethod
    def get_moving_average_query(
        table_id: str,
        date_column: str,
        price_column: str,
        window: int
    ) -> str:
        """
        移動平均計算用のSQLを生成
        
        Args:
            table_id: ソーステーブル名
            date_column: 日付/時系列カラム名
            price_column: 価格カラム名
            window: ウィンドウサイズ
            
        Returns:
            実行可能なSQL文字列
        """
        sql = f"""
        SELECT
            {date_column},
            {price_column},
            AVG({price_column}) OVER (
                ORDER BY {date_column} 
                ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW
            ) AS ma_{window}
        FROM {table_id}
        ORDER BY {date_column}
        """
        return sql

# =============================================================================
# 特徴量計算サービス
# =============================================================================

class DuckDBFeatureService:
    """
    DuckDBを使用した金融特徴量計算サービス
    
    各コンポーネントを統合し、高レベルのファサードを提供する
    """
    
    def __init__(
        self, 
        database_path: Optional[str] = None,
        memory_db: bool = False,
        **kwargs
    ):
        """
        DuckDB特徴量計算サービスを初期化
        
        Args:
            database_path: DuckDBデータベースファイルパス
            memory_db: メモリ内データベースを使用するかどうか
            **kwargs: その他の設定オプション
        """
        check_duckdb_requirements()
        
        self.config = DuckDBConfig(
            database_path=database_path,
            memory_db=memory_db,
            **kwargs
        )
        
        # 単一のデータベース接続を作成
        if memory_db:
            logger.info("DuckDBFeatureService: メモリ内データベースに接続します")
            self._conn = duckdb.connect(":memory:")
        else:
            logger.info(f"DuckDBFeatureService: データベースファイル '{database_path}' に接続します")
            db_path = pathlib.Path(database_path or "phunt.db")
            # 親ディレクトリが存在しなければ作成
            if not db_path.parent.exists():
                db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = duckdb.connect(str(db_path))
        
        # 内部コンポーネント
        self._table_manager = None
        self._data_fetcher = None
        self._feature_generator = DuckDBFeatureGenerator()
    
    @property
    def table_manager(self) -> DuckDBTableManager:
        """遅延初期化されたテーブルマネージャーを取得"""
        if self._table_manager is None:
            self._table_manager = DuckDBTableManager(self.config, self._conn)
        return self._table_manager
    
    @property
    def data_fetcher(self) -> DuckDBDataFetcher:
        """遅延初期化されたデータフェッチャーを取得"""
        if self._data_fetcher is None:
            self._data_fetcher = DuckDBDataFetcher(self.config, self._conn)
        return self._data_fetcher
    
    def _convert_to_pandas(self, df: pl.DataFrame) -> pd.DataFrame:
        """
        Polars DataFrameをPandas DataFrameに変換
        
        Args:
            df: 変換対象のPolars DataFrame
            
        Returns:
            変換後のPandas DataFrame
        """
        return df.to_pandas()
    
    def _prepare_data(
        self,
        data: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        date_column: str = None,
        value_column: str = None,
        value_type: str = "generic"
    ) -> Tuple[pl.DataFrame, str, str]:
        """
        入力データを統一形式に準備
        
        Args:
            data: 入力データ（Series または DataFrame）
            date_column: 日付カラム名（DataFrameの場合）
            value_column: 値カラム名（DataFrameの場合）
            value_type: 値のタイプ（"returns", "prices", "generic"）
            
        Returns:
            (準備されたDataFrame, 日付カラム名, 値カラム名)
        """
        # Pandasの場合はPolarsに変換する前処理を行う
        if isinstance(data, (pd.Series, pd.DataFrame)):
            # Pandas Series
            if isinstance(data, pd.Series):
                # 値のカラム名を決定
                if value_column is None:
                    if data.name is not None:
                        value_column = str(data.name)
                    else:
                        if value_type == "returns":
                            value_column = "return"
                        elif value_type == "prices":
                            value_column = "price"
                        else:
                            value_column = "value"
                
                # インデックス付きDataFrameに変換
                pandas_df = pd.DataFrame({value_column: data})
                pandas_df = pandas_df.reset_index()
                
                # 日付カラム名を決定
                if date_column is None:
                    if data.index.name is not None:
                        date_column = str(data.index.name)
                    else:
                        date_column = "index"
                
                # PolarsへのデータフレームをPandasで準備
                data_df = pandas_df

            # Pandas DataFrame
            else:
                # 値のカラム名を決定
                if value_column is None:
                    if len(data.columns) > 1:
                        value_column = str(data.columns[1])
                    else:
                        raise ValidationError("DataFrameには少なくとも2つのカラムが必要です")
                
                # 日付カラム名を決定
                if date_column is None:
                    date_column = str(data.columns[0])
                
                # 必要なカラムのみ選択
                if value_column in data.columns and date_column in data.columns:
                    data_df = data[[date_column, value_column]]
                else:
                    raise ValidationError(f"指定されたカラムが存在しません: {date_column}, {value_column}")

            # Pandasをpolarsに変換
            df = pl.from_pandas(data_df)
            
        # Polarsデータ
        else:
            # Polars Series
            if isinstance(data, pl.Series):
                # 値のカラム名を決定
                if value_column is None:
                    if data.name is not None:
                        value_column = str(data.name)
                    else:
                        if value_type == "returns":
                            value_column = "return"
                        elif value_type == "prices":
                            value_column = "price"
                        else:
                            value_column = "value"
                
                # インデックスベースの行ID列を作成
                df = pl.DataFrame({
                    "row_id": pl.arange(0, len(data)),
                    value_column: data
                })
                date_column = "row_id"
                
            # Polars DataFrame
            else:
                df = data
                
                # 日付カラムが指定されていない場合、最初のカラムを使用
                if date_column is None:
                    date_column = df.columns[0]
                
                # 値カラムが指定されていない場合、2番目のカラムを使用
                if value_column is None:
                    if len(df.columns) > 1:
                        value_column = df.columns[1]
                    else:
                        raise ValidationError("DataFrameには少なくとも2つのカラムが必要です。日付カラムと値カラム。")
                
                # 必要なカラムのみを選択
                if value_column in df.columns and date_column in df.columns:
                    df = df.select([date_column, value_column])
                else:
                    raise ValidationError(f"指定されたカラムが存在しません: {date_column}, {value_column}")
        
        return df, date_column, value_column
    
    def _combine_results(
        self,
        dataframes: List[pl.DataFrame],
        join_column: str = None
    ) -> pl.DataFrame:
        """
        複数のDataFrameを結合
        
        Args:
            dataframes: 結合するDataFrameのリスト
            join_column: 結合に使用するカラム名
            
        Returns:
            結合されたDataFrame
        """
        if not dataframes:
            return pl.DataFrame()
        
        if len(dataframes) == 1:
            return dataframes[0]
        
        # 結合列が指定されていなければ最初のカラムを使用
        if join_column is None:
            join_column = dataframes[0].columns[0]
        
        # 基本DataFrame
        result_df = dataframes[0]
        
        # 残りのDataFrameを結合
        for df in dataframes[1:]:
            if join_column in df.columns:
                # 結合列が存在する場合
                result_df = result_df.join(
                    df.drop([col for col in df.columns if col in result_df.columns and col != join_column]),
                    on=join_column,
                    how="left"
                )
            else:
                # 結合列がない場合（インデックスベースの結合）
                result_df = pl.concat([result_df, df], how="horizontal")
        
        return result_df
        
    def calculate_statistical_moments(
        self,
        returns: Union[pl.Series, pl.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: str = None,
        returns_column: str = None
    ) -> pd.DataFrame:
        """
        統計的モーメント（平均、分散、歪度、尖度、JB統計量）を計算
        
        Args:
            returns: リターンデータ（Series または DataFrame）
            windows: 計算ウィンドウサイズのリスト
            date_column: 日付カラム名（DataFrameの場合）
            returns_column: リターンカラム名（DataFrameの場合）
            
        Returns:
            統計的モーメントを含むPandas DataFrame
        """
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=returns,
            date_column=date_column,
            value_column=returns_column,
            value_type="returns"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("returns_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 各ウィンドウサイズに対してクエリ実行
            results = []
            for window in windows:
                # クエリ生成
                query = self._feature_generator.get_moments_query(
                    temp_table_id, date_col, value_col, window
                )
                
                # クエリ実行、結果取得
                window_df = self.data_fetcher.execute_query_to_polars(query)
                
                # 日付カラム処理
                if date_col == "row_id":
                    result_cols = [col for col in window_df.columns if col != date_col]
                    results.append(window_df.select(result_cols))
                else:
                    results.append(window_df)
        
        # 結果の結合とPandas形式への変換
        result_df = self._convert_to_pandas(self._combine_results(results, date_col))
        
        # 標準化のために不要なカラムを削除
        if date_col in result_df.columns:
            result_df = result_df.drop(columns=[date_col])
            
        return result_df
        
    def calculate_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        リターンを計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            periods: 計算期間（整数または整数のリスト）
            method: 計算方法 ('arithmetic' または 'log')
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            リターンを含むPandas DataFrame
        """
        # リスト変換
        if isinstance(periods, int):
            periods = [periods]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 各期間に対してクエリ実行
            results = []
            for period in periods:
                # クエリ生成
                query = self._feature_generator.get_returns_query(
                    temp_table_id, date_col, value_col, period, method
                )
                
                # クエリ実行、結果取得
                period_df = self.data_fetcher.execute_query_to_polars(query)
                
                # 日付カラム処理
                if date_col == "row_id":
                    # 行IDは結果に含めない
                    selected_cols = [col for col in period_df.columns if col != date_col and col != value_col]
                    results.append(period_df.select(selected_cols))
                else:
                    # 原価格以外のカラムを選択
                    selected_cols = [date_col] + [col for col in period_df.columns if col != date_col and col != value_col]
                    results.append(period_df.select(selected_cols))
        
        # 結果の結合とPandas形式への変換
        result_df = self._convert_to_pandas(self._combine_results(results, date_col))
        
        # 標準化のために不要なカラムを削除
        if date_col in result_df.columns:
            result_df = result_df.drop(columns=[date_col])
            
        return result_df
        
    def calculate_moving_averages(
        self,
        prices: Union[pl.Series, pl.DataFrame],
        windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        移動平均を計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            windows: 計算ウィンドウサイズ（整数または整数のリスト）
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            移動平均を含むPandas DataFrame
        """
        # リスト変換
        if isinstance(windows, int):
            windows = [windows]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 各ウィンドウサイズに対してクエリ実行
            results = []
            for window in windows:
                # クエリ生成
                query = self._feature_generator.get_moving_average_query(
                    temp_table_id, date_col, value_col, window
                )
                
                # クエリ実行、結果取得
                window_df = self.data_fetcher.execute_query_to_polars(query)
                
                # 日付カラム処理
                if date_col == "row_id":
                    # 行IDは結果に含めない
                    selected_cols = [col for col in window_df.columns if col != date_col and col != value_col]
                    results.append(window_df.select(selected_cols))
                else:
                    # 原価格以外のカラムを選択
                    selected_cols = [date_col] + [col for col in window_df.columns if col != date_col and col != value_col]
                    results.append(window_df.select(selected_cols))
        
        # 結果の結合とPandas形式への変換
        result_df = self._convert_to_pandas(self._combine_results(results, date_col))
        
        # 標準化のために不要なカラムを削除
        if date_col in result_df.columns:
            result_df = result_df.drop(columns=[date_col])
            
        return result_df
    
    async def calculate_statistical_moments_async(
        self,
        returns: Union[pl.Series, pl.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: str = None,
        returns_column: str = None
    ) -> pd.DataFrame:
        """
        統計的モーメント（平均、分散、歪度、尖度、JB統計量）を非同期計算
        
        Args:
            returns: リターンデータ（Series または DataFrame）
            windows: 計算ウィンドウサイズのリスト
            date_column: 日付カラム名（DataFrameの場合）
            returns_column: リターンカラム名（DataFrameの場合）
            
        Returns:
            統計的モーメントを含むPandas DataFrame
        """
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=returns,
            date_column=date_column,
            value_column=returns_column,
            value_type="returns"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("returns_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # クエリタスク作成
            tasks = []
            for window in windows:
                query = self._feature_generator.get_moments_query(
                    temp_table_id, date_col, value_col, window
                )
                tasks.append(self.data_fetcher.execute_query_async(query))
            
            # 並列実行
            results_df = await asyncio.gather(*tasks)
            
            # 結果を結合するための前処理
            results = []
            for window_idx, window_df in enumerate(results_df):
                # DataFrameをPolarsに変換
                window_pl_df = pl.from_pandas(window_df)
                
                # 日付カラム処理
                if date_col == "row_id":
                    result_cols = [col for col in window_pl_df.columns if col != date_col]
                    results.append(window_pl_df.select(result_cols))
                else:
                    results.append(window_pl_df)
        
        # 結果の結合とPandas形式への変換
        return self._convert_to_pandas(self._combine_results(results, date_col))
        
    async def calculate_returns_async(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        DuckDBバックエンドを使用してリターンを計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            periods: 計算期間（整数または整数のリスト）
            method: 計算方法 ('arithmetic' または 'log')
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            リターンを含むDataFrame
        """
        # サービスインスタンスを作成
        service = DuckDBFeatureService(
            database_path=None,
            memory_db=False,
            **{}
        )
        
        # 非同期実行
        if isinstance(periods, int):
            periods = [periods]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # クエリタスク作成
            tasks = []
            for period in periods:
                query = self._feature_generator.get_returns_query(
                    temp_table_id, date_col, value_col, period, method
                )
                tasks.append(self.data_fetcher.execute_query_async(query))
            
            # 並列実行
            results_df = await asyncio.gather(*tasks)
            
            # 結果を結合するための前処理
            results = []
            for period_idx, period_df in enumerate(results_df):
                # DataFrameをPolarsに変換
                period_pl_df = pl.from_pandas(period_df)
                
                # 日付カラム処理
                if date_col == "row_id":
                    # 行IDは結果に含めない
                    selected_cols = [col for col in period_pl_df.columns if col != date_col and col != value_col]
                    results.append(period_pl_df.select(selected_cols))
                else:
                    # 原価格以外のカラムを選択
                    selected_cols = [date_col] + [col for col in period_pl_df.columns if col != date_col and col != value_col]
                    results.append(period_pl_df.select(selected_cols))
        
        # 結果の結合とPandas形式への変換
        return self._convert_to_pandas(self._combine_results(results, date_col))
        
    async def calculate_moving_averages_async(
        self,
        prices: Union[pl.Series, pl.DataFrame],
        windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        移動平均を非同期計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            windows: 計算ウィンドウサイズ（整数または整数のリスト）
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            移動平均を含むPandas DataFrame
        """
        # リスト変換
        if isinstance(windows, int):
            windows = [windows]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # クエリタスク作成
            tasks = []
            for window in windows:
                query = self._feature_generator.get_moving_average_query(
                    temp_table_id, date_col, value_col, window
                )
                tasks.append(self.data_fetcher.execute_query_async(query))
            
            # 並列実行
            results_df = await asyncio.gather(*tasks)
            
            # 結果を結合するための前処理
            results = []
            for window_idx, window_df in enumerate(results_df):
                # DataFrameをPolarsに変換
                window_pl_df = pl.from_pandas(window_df)
                
                # 日付カラム処理
                if date_col == "row_id":
                    # 行IDは結果に含めない
                    selected_cols = [col for col in window_pl_df.columns if col != date_col and col != value_col]
                    results.append(window_pl_df.select(selected_cols))
                else:
                    # 日付のみ残して価格は除外
                    selected_cols = [date_col] + [col for col in window_pl_df.columns if col != date_col and col != value_col]
                    results.append(window_pl_df.select(selected_cols))
        
        # 結果の結合とPandas形式への変換
        return self._convert_to_pandas(self._combine_results(results, date_col))


# =============================================================================
# 便利な関数
# =============================================================================

def calculate_statistical_moments_duckdb(
    returns: Union[pl.Series, pl.DataFrame],
    windows: List[int] = [20, 60, 120],
    date_column: str = None,
    returns_column: str = None,
    database_path: str = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    リターンデータから統計的モーメント（平均、分散、歪度、尖度、JB統計量）を計算
    
    Args:
        returns: リターンデータ（Series または DataFrame）
        windows: 計算ウィンドウサイズのリスト
        date_column: 日付カラム名（DataFrameの場合）
        returns_column: リターンカラム名（DataFrameの場合）
        database_path: DuckDBデータベースファイルパス
        memory_db: メモリ内データベースを使用するかどうか
        async_execution: 非同期実行するかどうか
        **kwargs: その他のパラメータ
    
    Returns:
        統計的モーメントを含むPandas DataFrame
    """
    service = DuckDBFeatureService(
        database_path=database_path,
        memory_db=memory_db,
        **kwargs
    )
    
    if async_execution:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_statistical_moments_async(
                returns, windows, date_column, returns_column
            )
        )
    else:
        return service.calculate_statistical_moments(
            returns, windows, date_column, returns_column
        )

def calculate_returns_duckdb(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    date_column: str = None,
    price_column: str = None,
    database_path: str = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    DuckDBバックエンドを使用してリターンを計算
    
    Args:
        prices: 価格データ（Series または DataFrame）
        periods: 計算期間（整数または整数のリスト）
        method: 計算方法 ('arithmetic' または 'log')
        date_column: 日付カラム名（DataFrameの場合）
        price_column: 価格カラム名（DataFrameの場合）
        database_path: DuckDBデータベースファイルパス
        memory_db: メモリ内データベースを使用するかどうか
        async_execution: 非同期実行を使用するかどうか
        **kwargs: 追加のオプション
        
    Returns:
        リターンを含むDataFrame
    """
    # サービスインスタンスを作成
    service = DuckDBFeatureService(
        database_path=database_path,
        memory_db=memory_db,
        **kwargs
    )
    
    # 非同期実行
    if async_execution:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_returns_async(
                prices=prices,
                periods=periods,
                method=method,
                date_column=date_column,
                price_column=price_column
            )
        )
    
    # 同期実行
    return service.calculate_returns(
        prices=prices,
        periods=periods,
        method=method,
        date_column=date_column,
        price_column=price_column
    )

def calculate_moving_averages_duckdb(
    prices: Union[pl.Series, pl.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    date_column: str = None,
    price_column: str = None,
    database_path: str = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    価格データから移動平均を計算
    
    Args:
        prices: 価格データ（Series または DataFrame）
        windows: 計算ウィンドウサイズ（整数または整数のリスト）
        date_column: 日付カラム名（DataFrameの場合）
        price_column: 価格カラム名（DataFrameの場合）
        database_path: DuckDBデータベースファイルパス
        memory_db: メモリ内データベースを使用するかどうか
        async_execution: 非同期実行するかどうか
        **kwargs: その他のパラメータ
    
    Returns:
        移動平均を含むPandas DataFrame
    """
    service = DuckDBFeatureService(
        database_path=database_path,
        memory_db=memory_db,
        **kwargs
    )
    
    if async_execution:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_moving_averages_async(
                prices, windows, date_column, price_column
            )
        )
    else:
        return service.calculate_moving_averages(
            prices, windows, date_column, price_column
        ) 