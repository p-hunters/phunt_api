import polars as pl
import numpy as np
from typing import Union, List, Optional
from scipy import stats
import math

# =======================
#     Basic Features
# =======================

def calculate_returns(
    prices: pl.Series,
    periods: Union[int, List[int]] = 1,
    method: str = 'arithmetic'
) -> pl.DataFrame:
    """
    Calculate returns for given price series.
    
    Args:
        prices (pl.Series): Price series
        periods (Union[int, List[int]]): Period(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
    
    Returns:
        pl.DataFrame: DataFrame with calculated returns
    """
    if isinstance(periods, int):
        periods = [periods]
    
    df = pl.DataFrame({prices.name: prices})
    exprs = []
    
    for period in periods:
        # Create mask for pandas-like NaN handling
        idx_col = pl.int_range(0, pl.len())
        first_valid_idx = pl.lit(period)
        use_nan = idx_col < first_valid_idx
        
        # Calculate returns
        if method == 'arithmetic':
            raw_returns = ((pl.col(prices.name) - pl.col(prices.name).shift(period)) / 
                         pl.col(prices.name).shift(period))
        elif method == 'log':
            raw_returns = (pl.col(prices.name) / pl.col(prices.name).shift(period)).log()
        else:
            raise ValueError("method must be either 'arithmetic' or 'log'")
        
        # Set first period values to None to match Pandas behavior
        expr = pl.when(use_nan).then(None).otherwise(raw_returns).alias(f'return_{period}')
        exprs.append(expr)
    
    return df.select(exprs)


def calculate_moving_averages(
    prices: pl.Series,
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200]
) -> pl.DataFrame:
    """
    Calculate simple moving averages for given windows.
    
    Args:
        prices (pl.Series): Price series
        windows (Union[int, List[int]]): List of window sizes for moving averages
    
    Returns:
        pl.DataFrame: DataFrame with calculated moving averages
    """
    if isinstance(windows, int):
        windows = [windows]
    
    # Handle single value case: for a single value, the MA should equal that value
    if len(prices) == 1:
        result = {}
        value = prices[0]
        for window in windows:
            result[f'ma_{window}'] = [float('nan')]  # Change to NaN to match pandas
        return pl.DataFrame(result)
    
    # For regular cases, calculate rolling means
    df = pl.DataFrame({prices.name: prices})
    
    exprs = []
    for window in windows:
        # Create mask for pandas-like NaN handling
        idx_col = pl.int_range(0, pl.len())
        first_valid_idx = pl.lit(window - 1)
        use_nan = idx_col < first_valid_idx
        
        # Calculate rolling mean and apply NaN mask
        ma_raw = pl.col(prices.name).rolling_mean(window_size=window)
        ma_expr = pl.when(use_nan).then(None).otherwise(ma_raw).alias(f'ma_{window}')
        exprs.append(ma_expr)
    
    return df.select(exprs)


def calculate_bollinger_bands(
    prices: pl.Series,
    window: int = 20,
    num_std: float = 2.0
) -> pl.DataFrame:
    """
    Calculate Bollinger Bands.
    
    Args:
        prices (pl.Series): Price series
        window (int): Window size for moving average
        num_std (float): Number of standard deviations for bands
    
    Returns:
        pl.DataFrame: DataFrame with middle band (MA), upper and lower bands
    """
    df = pl.DataFrame({prices.name: prices})
    
    # Calculate middle band (simple moving average)
    middle_band = pl.col(prices.name).rolling_mean(window_size=window)
    
    # Calculate standard deviation
    std = pl.col(prices.name).rolling_std(window_size=window)
    
    # Create mask for pandas-like NaN handling
    idx_col = pl.int_range(0, pl.len())
    first_valid_idx = pl.lit(window - 1)
    use_nan = idx_col < first_valid_idx
    
    # Set first (window-1) values to NaN for all bands
    bb_middle = pl.when(use_nan).then(None).otherwise(middle_band).alias('bb_middle')
    bb_upper = pl.when(use_nan).then(None).otherwise(middle_band + (std * num_std)).alias('bb_upper')
    bb_lower = pl.when(use_nan).then(None).otherwise(middle_band - (std * num_std)).alias('bb_lower')
    
    return df.select([bb_middle, bb_upper, bb_lower])


def calculate_volatility(
    prices: pl.Series,
    windows: Union[int, List[int]] = [5, 10, 20],
    returns_method: str = 'log'
) -> pl.DataFrame:
    """
    Calculate volatility (standard deviation of returns) for different windows.
    
    Args:
        prices (pl.Series): Price series
        windows (Union[int, List[int]]): Window sizes for volatility calculation
        returns_method (str): Method to calculate returns ('arithmetic' or 'log')
    
    Returns:
        pl.DataFrame: DataFrame with volatility measures
    """
    if isinstance(windows, int):
        windows = [windows]
    
    df = pl.DataFrame({prices.name: prices})
    
    # Calculate returns
    if returns_method == 'arithmetic':
        returns = (pl.col(prices.name) - pl.col(prices.name).shift(1)) / pl.col(prices.name).shift(1)
    else:  # log returns
        returns = (pl.col(prices.name) / pl.col(prices.name).shift(1)).log()
    
    exprs = []
    for window in windows:
        # Calculate rolling standard deviation and annualize
        rolling_std = returns.rolling_std(window_size=window)
        annualized_vol = rolling_std * np.sqrt(252)
        
        # Check for constant price series (all returns in window are 0)
        is_constant = returns.abs().rolling_max(window_size=window) < 1e-10
        
        # Apply condition: Set volatility to 0 for constant price series
        volatility = (pl.when(is_constant)
                     .then(0.0)
                     .otherwise(annualized_vol)
                     .alias(f'volatility_{window}'))
        
        exprs.append(volatility)
    
    # Fill all NaN values with 0 to match pandas behavior
    result_df = df.select(exprs).fill_null(0.0)
    
    return result_df


# =======================
#  Statistical Features
# =======================

def rolling_window_apply(series: pl.Series, window: int, func) -> pl.Series:
    """Helper function to apply custom window function"""
    # Convert to native Python list for easier manipulation
    values = series.to_list()
    result = [None] * len(values)
    
    # Apply function to rolling windows starting from window-1
    # Only process if we have enough data points
    if len(values) >= window:
        for i in range(window - 1, len(values)):
            window_vals = values[i - window + 1:i + 1]
            # Skip if any value in window is None/NaN
            if any(x is None or (isinstance(x, float) and np.isnan(x)) for x in window_vals):
                result[i] = None
            else:
                result[i] = func(window_vals)
    
    return pl.Series(result, dtype=pl.Float64)


def calculate_statistical_moments(
    returns: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling statistical moments (mean, variance, skewness, kurtosis, JB test).
    
    Args:
        returns (pl.Series): Return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with statistical moments
    """
    df = pl.DataFrame({returns.name: returns})
    
    results = []
    
    for window in windows:
        # Create mask for pandas-like NaN handling
        idx_col = pl.int_range(0, pl.len())
        first_valid_idx = pl.lit(window - 1)
        use_nan = idx_col < first_valid_idx
        
        # Mean and variance calculations with explicit NaN handling
        mean_raw = pl.col(returns.name).rolling_mean(window_size=window)
        var_raw = pl.col(returns.name).rolling_var(window_size=window)
        
        mean_expr = pl.when(use_nan).then(None).otherwise(mean_raw).alias(f'rolling_mean_{window}')
        var_expr = pl.when(use_nan).then(None).otherwise(var_raw).alias(f'rolling_var_{window}')
        
        results.append(df.select([mean_expr, var_expr]))
        
        # For skewness, kurtosis, and JB test we need custom functions
        def rolling_skew_with_constant(x):
            if all(val == x[0] for val in x):
                return 0.0
            return float(stats.skew(x))
        
        def rolling_kurt_with_constant(x):
            if all(val == x[0] for val in x):
                return 0.0
            return float(stats.kurtosis(x))
        
        def rolling_jb(x):
            if all(val == x[0] for val in x):
                return 0.0
            n = len(x)
            skew = stats.skew(x)
            kurt = stats.kurtosis(x)
            jb = n/6.0 * (skew**2 + (kurt**2)/4.0)
            return float(jb)
        
        # Apply custom functions using rolling_apply
        skew_series = rolling_window_apply(returns, window, rolling_skew_with_constant)
        kurt_series = rolling_window_apply(returns, window, rolling_kurt_with_constant)
        jb_series = rolling_window_apply(returns, window, rolling_jb)
        
        # Create DataFrame with the results
        moments_df = pl.DataFrame({
            f'rolling_skew_{window}': skew_series,
            f'rolling_kurt_{window}': kurt_series,
            f'rolling_jb_{window}': jb_series
        })
        
        results.append(moments_df)
    
    # Combine all results
    return pl.concat(results, how='horizontal')


def calculate_rolling_correlation(
    series1: pl.Series,
    series2: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling correlation between two series.
    
    Args:
        series1 (pl.Series): First series
        series2 (pl.Series): Second series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with rolling correlations
    """
    # Convert to pandas for exact calculation
    import pandas as pd
    
    pd_series1 = pd.Series(series1.to_list())
    pd_series2 = pd.Series(series2.to_list())
    
    result_dfs = []
    
    for window in windows:
        # Calculate rolling correlation using pandas with min_periods=1
        rolling_corr = pd_series1.rolling(window=window, min_periods=window).corr(pd_series2)
        
        # Create a DataFrame for this window
        result_df = pl.DataFrame({
            f'rolling_corr_{window}': rolling_corr.values
        })
        
        result_dfs.append(result_df)
    
    # Combine all window results
    return pl.concat(result_dfs, how='horizontal')


def calculate_rolling_beta(
    asset_returns: pl.Series,
    benchmark_returns: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling beta (market sensitivity) of an asset against a benchmark.
    
    Args:
        asset_returns (pl.Series): Asset return series
        benchmark_returns (pl.Series): Benchmark return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with rolling betas and R-squared values
    """
    result_dfs = []
    
    # Convert Series to lists for easier manipulation
    asset_values = asset_returns.to_list()
    bench_values = benchmark_returns.to_list()
    
    for window in windows:
        # Pre-allocate result arrays with NaN values
        beta_values = [float('nan')] * len(asset_values)
        r2_values = [float('nan')] * len(asset_values)
        
        # Implement rolling window calculations in the same way pandas does
        for i in range(window - 1, len(asset_values)):
            # Get window values
            asset_window = asset_values[i - window + 1:i + 1]
            bench_window = bench_values[i - window + 1:i + 1]
            
            # Skip calculation if any window value is None or NaN
            if any(x is None or (isinstance(x, float) and math.isnan(x)) for x in asset_window) or \
               any(x is None or (isinstance(x, float) and math.isnan(x)) for x in bench_window):
                continue
                
            # Calculate mean of window values
            asset_mean = np.mean(asset_window)
            bench_mean = np.mean(bench_window)
            
            # Calculate covariance
            cov_sum = sum((a - asset_mean) * (b - bench_mean) for a, b in zip(asset_window, bench_window))
            cov = cov_sum / (window - 1)  # N-1 degrees of freedom
            
            # Calculate variance
            var_sum = sum((b - bench_mean) ** 2 for b in bench_window)
            var = var_sum / (window - 1)  # N-1 degrees of freedom
            
            # Calculate correlation for R-squared
            asset_std = np.sqrt(sum((a - asset_mean) ** 2 for a in asset_window) / (window - 1))
            bench_std = np.sqrt(var)
            
            # Check for nearly-zero variance
            if var < 1e-10:
                beta = float('nan')
                r2 = float('nan')
            else:
                beta = cov / var
                if asset_std < 1e-10 or bench_std < 1e-10:
                    r2 = float('nan')
                else:
                    corr = cov / (asset_std * bench_std)
                    r2 = corr ** 2
            
            # Store results
            beta_values[i] = beta
            r2_values[i] = r2
        
        # Create a DataFrame for this window
        result_df = pl.DataFrame({
            f'rolling_beta_{window}': beta_values,
            f'rolling_r2_{window}': r2_values
        })
        
        result_dfs.append(result_df)
    
    # Combine all window results
    return pl.concat(result_dfs, how='horizontal')


# =======================
#   Range-Based Features
# =======================

def calculate_range_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the range position of the close price in the past 'window' range.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size for calculation
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Range position values (0 to 1)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        high = pl.col('high').shift(offset)
        low = pl.col('low').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        high = pl.col('high')
        low = pl.col('low')
        close = pl.col('close')
    
    # Calculate rolling maximum of high prices
    max_high = high.rolling_max(window_size=window).alias('max_high')
    
    # Calculate rolling minimum of low prices
    min_low = low.rolling_min(window_size=window).alias('min_low')
    
    # Calculate range position
    range_pos_raw = ((close - min_low) / (max_high - min_low)).clip(0, 1)
    
    # Set NaN for the first window-1 values to match pandas behavior
    idx_col = pl.int_range(0, pl.len())
    first_valid_idx = pl.lit(window - 1)
    use_nan = idx_col < first_valid_idx
    
    range_pos = pl.when(use_nan).then(None).otherwise(range_pos_raw).alias('range_position')
    
    return ohlc.select(range_pos).to_series()


def calculate_relative_high_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the ratio of the close price to the highest high in the past 'window'.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Relative high position values (close / max_high)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        high = pl.col('high').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        high = pl.col('high')
        close = pl.col('close')
    
    # Calculate rolling maximum of high prices
    max_high = high.rolling_max(window_size=window).alias('max_high')
    
    # Calculate relative high position
    rel_high_pos_raw = (close / max_high).clip(0, 1)
    
    # Set NaN for the first window-1 values to match pandas behavior
    idx_col = pl.int_range(0, pl.len())
    first_valid_idx = pl.lit(window - 1)
    use_nan = idx_col < first_valid_idx
    
    rel_high_pos = pl.when(use_nan).then(None).otherwise(rel_high_pos_raw).alias('relative_high_position')
    
    return ohlc.select(rel_high_pos).to_series()


def calculate_relative_low_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the ratio of the close price to the lowest low in the past 'window'.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Relative low position values (close / min_low)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        low = pl.col('low').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        low = pl.col('low')
        close = pl.col('close')
    
    # Calculate rolling minimum of low prices
    min_low = low.rolling_min(window_size=window).alias('min_low')
    
    # Calculate relative low position, ensuring ratio is not less than 1
    rel_low_pos_raw = (close / min_low).clip(1, None)
    
    # Set NaN for the first window-1 values to match pandas behavior
    idx_col = pl.int_range(0, pl.len())
    first_valid_idx = pl.lit(window - 1)
    use_nan = idx_col < first_valid_idx
    
    rel_low_pos = pl.when(use_nan).then(None).otherwise(rel_low_pos_raw).alias('relative_low_position')
    
    return ohlc.select(rel_low_pos).to_series()


def calculate_rsi(prices: pl.Series, window: int = 14) -> pl.Series:
    """Calculate the Relative Strength Index (RSI) for a given price series.

    Args:
        prices: Price series
        window: Look-back period for RSI calculation (default: 14)

    Returns:
        Series containing RSI values
    """
    # Convert to pandas Series for exact calculations
    import pandas as pd
    import numpy as np
    
    # Special case for constants - match pandas behavior
    df = pl.DataFrame({"price": prices})
    delta_std = df.select(pl.col("price").std()).item()
    if delta_std is not None and delta_std < 1e-10:
        return pl.Series([50.0] * len(prices))  # All 50s for constant price
    
    # Transform polars Series to pandas Series
    pd_prices = pd.Series(prices.to_list())
    
    # Use the pandas implementation directly
    # Price changes
    delta = pd_prices.diff(1)
    
    # Handle monotonic increasing/decreasing series
    if (delta >= -1e-10).all():
        return pl.Series([None] + [100.0] * (len(prices)-1))  # RSI = 100 for all positive changes
    
    if (delta <= 1e-10).all():
        return pl.Series([None] + [0.0] * (len(prices)-1))   # RSI = 0 for all negative changes
    
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    
    # Exponential moving average for gains/losses
    roll_up = up.ewm(span=window, adjust=False).mean()
    roll_down = down.ewm(span=window, adjust=False).mean()
    
    # Avoid division by zero and handle edge cases
    rs = np.where(
        roll_down < 1e-10,
        np.inf,
        roll_up / roll_down
    )
    
    # Calculate RSI
    rsi = np.where(
        np.isinf(rs),
        100,
        100 - (100 / (1 + rs))
    )
    
    # Handle remaining edge cases
    rsi = np.where(roll_up < 1e-10, 0, rsi)  # All downs = RSI 0
    rsi = np.where(
        (roll_up < 1e-10) & (roll_down < 1e-10),
        50,  # Both zero = neutral RSI
        rsi
    )
    
    # Convert back to polars Series
    return pl.Series(rsi)


def calculate_macd(
    prices: pl.Series,
    short_window: int = 12,
    long_window: int = 26,
    signal_window: int = 9
) -> pl.DataFrame:
    """
    Calculate MACD (Moving Average Convergence Divergence) indicator.
    
    Args:
        prices (pl.Series): Price series
        short_window (int): Short EMA window
        long_window (int): Long EMA window
        signal_window (int): Signal line EMA window
    
    Returns:
        pl.DataFrame: DataFrame with MACD line, signal line, and histogram
    """
    # Convert to pandas for exact calculation
    import pandas as pd
    import numpy as np
    
    pd_prices = pd.Series(prices.to_list())
    
    # Special case for constant price series
    if pd_prices.std() < 1e-10:
        # For constant prices, all components should be 0
        n = len(prices)
        return pl.DataFrame({
            "macd": np.zeros(n),
            "macd_signal": np.zeros(n),
            "macd_hist": np.zeros(n)
        })
    
    # Calculate EMAs
    short_ema = pd_prices.ewm(span=short_window, adjust=False).mean()
    long_ema = pd_prices.ewm(span=long_window, adjust=False).mean()
    
    # Calculate MACD line
    macd_line = short_ema - long_ema
    
    # Calculate signal line
    signal_line = macd_line.ewm(span=signal_window, adjust=False).mean()
    
    # Calculate histogram
    histogram = macd_line - signal_line
    
    # Convert to Polars DataFrame
    return pl.DataFrame({
        "macd": macd_line.values,
        "macd_signal": signal_line.values,
        "macd_hist": histogram.values
    })


def calculate_atr(ohlc: pl.DataFrame, window: int = 14) -> pl.Series:
    """
    Calculate the Average True Range (ATR).
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['high', 'low', 'close']
        window (int): Look-back period
    
    Returns:
        pl.Series: ATR values
    """
    # Convert to pandas for exact calculation
    import pandas as pd
    import numpy as np
    
    # First select required columns to ensure they exist
    df = ohlc.select(['high', 'low', 'close'])
    pd_df = df.to_pandas()
    
    # Calculate true range components
    tr1 = pd_df['high'] - pd_df['low']
    tr2 = (pd_df['high'] - pd_df['close'].shift(1)).abs()
    tr3 = (pd_df['low'] - pd_df['close'].shift(1)).abs()
    
    # Get maximum of the three components
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Calculate ATR using simple moving average
    atr = true_range.rolling(window=window).mean()
    
    # Convert back to polars Series
    return pl.Series(atr.values)


def calculate_obv(ohlc: pl.DataFrame) -> pl.Series:
    """
    Calculate the On-Balance Volume (OBV).
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['close', 'volume']
    
    Returns:
        pl.Series: OBV values
    """
    # Calculate price direction using when/then/otherwise
    direction = pl.when(pl.col('close') > pl.col('close').shift(1)).then(1)\
                  .when(pl.col('close') < pl.col('close').shift(1)).then(-1)\
                  .otherwise(0)
    
    # Calculate OBV increment
    obv_increment = (direction * pl.col('volume')).fill_null(0)
    
    # Cumulative sum
    obv = obv_increment.cum_sum().alias('obv')
    
    return ohlc.select(obv).to_series()


def calculate_vwap(ohlc: pl.DataFrame, window: int = 20) -> pl.Series:
    """
    Calculate the Volume Weighted Average Price (VWAP) over a rolling window.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['high', 'low', 'close', 'volume']
        window (int): Rolling window for VWAP
    
    Returns:
        pl.Series: Rolling VWAP values
    """
    # Calculate typical price
    typical_price = ((pl.col('high') + pl.col('low') + pl.col('close')) / 3).alias('typical_price')
    
    # Calculate price * volume
    tp_vol = (typical_price * pl.col('volume')).alias('tp_vol')
    
    # Calculate rolling sums
    rolling_tp_vol = tp_vol.rolling_sum(window_size=window).alias('rolling_tp_vol')
    rolling_vol = pl.col('volume').rolling_sum(window_size=window).alias('rolling_vol')
    
    # Calculate VWAP
    vwap_raw = (rolling_tp_vol / rolling_vol)
    
    # Set NaN for the first window-1 values to match pandas behavior
    idx_col = pl.int_range(0, pl.len())
    first_valid_idx = pl.lit(window - 1)
    use_nan = idx_col < first_valid_idx
    
    vwap = pl.when(use_nan).then(None).otherwise(vwap_raw).alias('vwap')
    
    return ohlc.select(vwap).to_series()


# =======================
#     Main Aggregation
# =======================

def calculate_price_features(
    prices: Union[pl.Series, pl.DataFrame],
    ohlc: Optional[pl.DataFrame] = None,
    benchmark_returns: Optional[pl.Series] = None,
    return_periods: List[int] = [1, 5, 10, 15],
    ma_windows: List[int] = [5, 10, 20, 50, 200],
    volatility_windows: List[int] = [5, 10, 20],
    moment_windows: List[int] = [20, 60, 120],
    bb_window: int = 20,
    bb_num_std: float = 2.0,
    range_window: int = 20,
    range_offset: int = 0,
    rsi_window: int = 14,
    macd_short_window: int = 12,
    macd_long_window: int = 26,
    macd_signal_window: int = 9,
    atr_window: int = 14,
    add_obv: bool = True,
    add_vwap: bool = True,
) -> pl.DataFrame:
    """
    Calculate an extensive set of price-based and OHLC-based features.
    
    Args:
        prices (Union[pl.Series, pl.DataFrame]): Price series or DataFrame with 'close' column
        ohlc (Optional[pl.DataFrame]): OHLC DataFrame
        benchmark_returns (Optional[pl.Series]): Benchmark return series for beta calculation
        return_periods (List[int]): Periods for return calculation
        ma_windows (List[int]): Windows for moving averages
        volatility_windows (List[int]): Windows for volatility calculation
        moment_windows (List[int]): Windows for statistical moments calculation
        bb_window (int): Window for Bollinger Bands
        bb_num_std (float): Number of standard deviations for Bollinger Bands
        range_window (int): Window for range-based calculations
        range_offset (int): Offset for range-based calculations
        rsi_window (int): RSI look-back window
        macd_short_window (int): MACD short EMA window
        macd_long_window (int): MACD long EMA window
        macd_signal_window (int): MACD signal EMA window
        atr_window (int): ATR look-back window
        add_obv (bool): Whether to calculate OBV
        add_vwap (bool): Whether to calculate VWAP
    
    Returns:
        pl.DataFrame: DataFrame with all calculated features
        
    Raises:
        TypeError: If prices is not a polars Series or DataFrame
        ValueError: If OHLC data is provided but missing required columns
    """
    # Input validation
    if not isinstance(prices, (pl.Series, pl.DataFrame)):
        raise TypeError("prices must be a polars Series or DataFrame")
    
    # Convert input to Series if DataFrame
    if isinstance(prices, pl.DataFrame):
        if 'close' not in prices.columns:
            raise ValueError("DataFrame must contain 'close' column")
        price_series = prices['close']
    else:
        price_series = prices
    
    # OHLC validation
    if ohlc is not None:
        required_cols = ['high', 'low', 'close']
        if add_obv or add_vwap:
            required_cols.append('volume')
        missing_cols = [col for col in required_cols if col not in ohlc.columns]
        if missing_cols:
            raise ValueError(f"OHLC data is missing required columns: {missing_cols}")
    
    # Initialize features list
    feature_dfs = []
    
    # 1. Basic Returns
    returns_df = calculate_returns(price_series, return_periods)
    feature_dfs.append(returns_df)
    
    # 2. Moving Averages
    feature_dfs.append(calculate_moving_averages(price_series, ma_windows))
    
    # 3. Bollinger Bands
    feature_dfs.append(calculate_bollinger_bands(price_series, bb_window, bb_num_std))
    
    # 4. Volatility
    feature_dfs.append(calculate_volatility(price_series, volatility_windows))
    
    # 5. RSI
    feature_dfs.append(pl.DataFrame({'rsi': calculate_rsi(price_series, rsi_window)}))
    
    # 6. MACD
    feature_dfs.append(calculate_macd(
        price_series,
        short_window=macd_short_window,
        long_window=macd_long_window,
        signal_window=macd_signal_window
    ))
    
    # 7. Statistical Moments (using shortest return period)
    returns_series = returns_df[f'return_{return_periods[0]}']
    feature_dfs.append(calculate_statistical_moments(returns_series, moment_windows))
    
    # 8. OHLC-based features
    if ohlc is not None:
        # Range-based features
        feature_dfs.append(pl.DataFrame({
            'range_position': calculate_range_position(ohlc, range_window, range_offset),
            'relative_high_position': calculate_relative_high_position(ohlc, range_window, range_offset),
            'relative_low_position': calculate_relative_low_position(ohlc, range_window, range_offset)
        }))
        
        # ATR
        feature_dfs.append(pl.DataFrame({'atr': calculate_atr(ohlc, atr_window)}))
        
        # OBV
        if add_obv and 'volume' in ohlc.columns:
            feature_dfs.append(pl.DataFrame({'obv': calculate_obv(ohlc)}))
        
        # VWAP
        if add_vwap and 'volume' in ohlc.columns:
            feature_dfs.append(pl.DataFrame({'vwap': calculate_vwap(ohlc)}))
    
    # 9. Benchmark-based features (Beta, Correlation) if provided
    if benchmark_returns is not None:
        # Make sure we align the index properly (in pandas equivalent)
        # For Polars, we assume aligned data or should implement index alignment logic
        asset_rets = returns_series
        
        feature_dfs.append(calculate_rolling_beta(asset_rets, benchmark_returns, moment_windows))
        feature_dfs.append(calculate_rolling_correlation(asset_rets, benchmark_returns, moment_windows))
    
    # Combine all features
    return pl.concat(feature_dfs, how='horizontal')