import polars as pl
import numpy as np
from typing import Union, List, Optional
from scipy import stats

# =======================
#     Basic Features
# =======================

def calculate_returns(
    prices: pl.Series,
    periods: Union[int, List[int]] = 1,
    method: str = 'arithmetic'
) -> pl.DataFrame:
    """
    Calculate returns for given price series.
    
    Args:
        prices (pl.Series): Price series
        periods (Union[int, List[int]]): Period(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
    
    Returns:
        pl.DataFrame: DataFrame with calculated returns
    """
    if isinstance(periods, int):
        periods = [periods]
    
    # Initialize empty expressions list
    exprs = []
    
    for period in periods:
        if method == 'arithmetic':
            # (prices - prices.shift(period)) / prices.shift(period)
            expr = ((pl.col(prices.name) - pl.col(prices.name).shift(period)) / 
                   pl.col(prices.name).shift(period)).alias(f'return_{period}')
        elif method == 'log':
            # log(prices / prices.shift(period))
            expr = (pl.col(prices.name) / pl.col(prices.name).shift(period)).log().alias(f'return_{period}')
        else:
            raise ValueError("method must be either 'arithmetic' or 'log'")
        
        exprs.append(expr)
    
    return pl.DataFrame({prices.name: prices}).select(exprs)


def calculate_moving_averages(
    prices: pl.Series,
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200]
) -> pl.DataFrame:
    """
    Calculate simple moving averages for given windows.
    
    Args:
        prices (pl.Series): Price series
        windows (Union[int, List[int]]): List of window sizes for moving averages
    
    Returns:
        pl.DataFrame: DataFrame with calculated moving averages
    """
    if isinstance(windows, int):
        windows = [windows]
    
    exprs = [
        pl.col(prices.name).rolling_mean(window=window).alias(f'ma_{window}')
        for window in windows
    ]
    
    return pl.DataFrame({prices.name: prices}).select(exprs)


def calculate_bollinger_bands(
    prices: pl.Series,
    window: int = 20,
    num_std: float = 2.0
) -> pl.DataFrame:
    """
    Calculate Bollinger Bands.
    
    Args:
        prices (pl.Series): Price series
        window (int): Window size for moving average
        num_std (float): Number of standard deviations for bands
    
    Returns:
        pl.DataFrame: DataFrame with middle band (MA), upper and lower bands
    """
    df = pl.DataFrame({prices.name: prices})
    
    middle_band = pl.col(prices.name).rolling_mean(window=window)
    std = pl.col(prices.name).rolling_std(window=window)
    
    return df.select([
        middle_band.alias('bb_middle'),
        (middle_band + (std * num_std)).alias('bb_upper'),
        (middle_band - (std * num_std)).alias('bb_lower')
    ])


def calculate_volatility(
    prices: pl.Series,
    windows: Union[int, List[int]] = [5, 10, 20],
    returns_method: str = 'log'
) -> pl.DataFrame:
    """
    Calculate volatility (standard deviation of returns) for different windows.
    
    Args:
        prices (pl.Series): Price series
        windows (Union[int, List[int]]): Window sizes for volatility calculation
        returns_method (str): Method to calculate returns ('arithmetic' or 'log')
    
    Returns:
        pl.DataFrame: DataFrame with volatility measures
    """
    if isinstance(windows, int):
        windows = [windows]
    
    df = pl.DataFrame({prices.name: prices})
    
    # Calculate returns
    if returns_method == 'arithmetic':
        returns = (pl.col(prices.name) - pl.col(prices.name).shift(1)) / pl.col(prices.name).shift(1)
    else:  # log returns
        returns = (pl.col(prices.name) / pl.col(prices.name).shift(1)).log()
    
    exprs = []
    for window in windows:
        # Calculate rolling standard deviation and annualize
        # Handle constant price case (all returns are 0)
        vol = (returns.rolling_std(window=window) * np.sqrt(252)).alias(f'volatility_{window}')
        exprs.append(vol)
    
    return df.select(exprs)


# =======================
#  Statistical Features
# =======================

def rolling_window_apply(series: pl.Series, window: int, func) -> pl.Series:
    """Helper function to apply custom window function"""
    # Convert to native Python list for easier manipulation
    values = series.to_list()
    result = [None] * len(values)
    
    for i in range(window - 1, len(values)):
        window_vals = values[i - window + 1:i + 1]
        if all(x is None for x in window_vals):
            result[i] = None
        else:
            # Filter out None values
            window_vals = [x for x in window_vals if x is not None]
            if len(window_vals) > 0:
                result[i] = func(window_vals)
    
    return pl.Series(result, dtype=pl.Float64)


def calculate_statistical_moments(
    returns: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling statistical moments (mean, variance, skewness, kurtosis, JB test).
    
    Args:
        returns (pl.Series): Return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with statistical moments
    """
    df = pl.DataFrame({returns.name: returns})
    
    results = []
    
    for window in windows:
        # Mean and variance can use Polars built-in functions
        mean_expr = pl.col(returns.name).rolling_mean(window=window).alias(f'rolling_mean_{window}')
        var_expr = pl.col(returns.name).rolling_var(window=window).alias(f'rolling_var_{window}')
        
        results.append(df.select([mean_expr, var_expr]))
        
        # For skewness, kurtosis, and JB test we need custom functions
        def rolling_skew_with_constant(x):
            if all(val == x[0] for val in x):
                return 0.0
            return float(stats.skew(x))
        
        def rolling_kurt_with_constant(x):
            if all(val == x[0] for val in x):
                return 0.0
            return float(stats.kurtosis(x))
        
        def rolling_jb(x):
            if all(val == x[0] for val in x):
                return 0.0
            n = len(x)
            skew = stats.skew(x)
            kurt = stats.kurtosis(x)
            jb = n/6.0 * (skew**2 + (kurt**2)/4.0)
            return float(jb)
        
        # Apply custom functions
        skew_series = rolling_window_apply(returns, window, rolling_skew_with_constant)
        kurt_series = rolling_window_apply(returns, window, rolling_kurt_with_constant)
        jb_series = rolling_window_apply(returns, window, rolling_jb)
        
        # Create DataFrame with the results
        moments_df = pl.DataFrame({
            f'rolling_skew_{window}': skew_series,
            f'rolling_kurt_{window}': kurt_series,
            f'rolling_jb_{window}': jb_series
        })
        
        results.append(moments_df)
    
    # Combine all results
    return pl.concat(results, how='horizontal')


def calculate_rolling_correlation(
    series1: pl.Series,
    series2: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling correlation between two series.
    
    Args:
        series1 (pl.Series): First series
        series2 (pl.Series): Second series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with rolling correlations
    """
    # Create a combined DataFrame
    df = pl.DataFrame({
        "series1": series1,
        "series2": series2
    })
    
    exprs = []
    for window in windows:
        # Use Polars rolling_corr
        expr = pl.col("series1").rolling_corr(
            pl.col("series2"), window=window
        ).alias(f'rolling_corr_{window}')
        exprs.append(expr)
    
    return df.select(exprs)


def calculate_rolling_beta(
    asset_returns: pl.Series,
    benchmark_returns: pl.Series,
    windows: List[int] = [20, 60, 120]
) -> pl.DataFrame:
    """
    Calculate rolling beta (market sensitivity) of an asset against a benchmark.
    
    Args:
        asset_returns (pl.Series): Asset return series
        benchmark_returns (pl.Series): Benchmark return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pl.DataFrame: DataFrame with rolling betas and R-squared values
    """
    # Create a combined DataFrame
    df = pl.DataFrame({
        "asset": asset_returns,
        "benchmark": benchmark_returns
    })
    
    results = []
    
    for window in windows:
        # Calculate rolling covariance
        rolling_cov = pl.col("asset").rolling_cov(
            pl.col("benchmark"), window=window
        )
        
        # Calculate rolling variance of benchmark
        rolling_var = pl.col("benchmark").rolling_var(window=window)
        
        # Calculate beta
        beta_expr = (rolling_cov / rolling_var).alias(f'rolling_beta_{window}')
        
        # Calculate rolling correlation
        rolling_corr = pl.col("asset").rolling_corr(
            pl.col("benchmark"), window=window
        )
        
        # Calculate R-squared (square of correlation)
        r2_expr = (rolling_corr ** 2).alias(f'rolling_r2_{window}')
        
        results.append(df.select([beta_expr, r2_expr]))
    
    # Combine all results
    return pl.concat(results, how='horizontal')


# =======================
#   Range-Based Features
# =======================

def calculate_range_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the range position of the close price in the past 'window' range.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size for calculation
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Range position values (0 to 1)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        high = pl.col('high').shift(offset)
        low = pl.col('low').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        high = pl.col('high')
        low = pl.col('low')
        close = pl.col('close')
    
    # Calculate rolling maximum of high prices
    max_high = high.rolling_max(window=window)
    
    # Calculate rolling minimum of low prices
    min_low = low.rolling_min(window=window)
    
    # Calculate range position
    range_pos = ((close - min_low) / (max_high - min_low)).clip(0, 1).alias('range_position')
    
    return ohlc.select(range_pos).to_series()


def calculate_relative_high_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the ratio of the close price to the highest high in the past 'window'.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Relative high position values (close / max_high)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        high = pl.col('high').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        high = pl.col('high')
        close = pl.col('close')
    
    # Calculate rolling maximum of high prices
    max_high = high.rolling_max(window=window)
    
    # Calculate relative high position
    rel_high_pos = (close / max_high).clip(0, 1).alias('relative_high_position')
    
    return ohlc.select(rel_high_pos).to_series()


def calculate_relative_low_position(
    ohlc: pl.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pl.Series:
    """
    Calculate the ratio of the close price to the lowest low in the past 'window'.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pl.Series: Relative low position values (close / min_low)
    """
    # Shift data if offset is non-zero
    if offset > 0:
        low = pl.col('low').shift(offset)
        close = pl.col('close').shift(offset)
    else:
        low = pl.col('low')
        close = pl.col('close')
    
    # Calculate rolling minimum of low prices
    min_low = low.rolling_min(window=window)
    
    # Calculate relative low position, ensuring ratio is not less than 1
    rel_low_pos = (close / min_low).clip(1, None).alias('relative_low_position')
    
    return ohlc.select(rel_low_pos).to_series()


def calculate_rsi(prices: pl.Series, window: int = 14) -> pl.Series:
    """
    Calculate the Relative Strength Index (RSI).
    
    Args:
        prices (pl.Series): Price series
        window (int): Look-back period for RSI calculation
    
    Returns:
        pl.Series: RSI values
    """
    df = pl.DataFrame({prices.name: prices})
    
    # Price changes
    delta = pl.col(prices.name) - pl.col(prices.name).shift(1)
    
    # Separate gains and losses
    gains = delta.clip_min(0)
    losses = -delta.clip_max(0)
    
    # Apply EMAs to gains and losses
    avg_gains = gains.ewm_mean(span=window)
    avg_losses = losses.ewm_mean(span=window)
    
    # Handle constant price series cases
    
    # Calculate RS value
    # Using when/otherwise to handle division by zero
    rs = (avg_gains / (avg_losses + 1e-10))
    
    # Calculate RSI
    rsi = (100 - (100 / (1 + rs))).alias('rsi')
    
    return df.select(rsi).to_series()


def calculate_macd(
    prices: pl.Series,
    short_window: int = 12,
    long_window: int = 26,
    signal_window: int = 9
) -> pl.DataFrame:
    """
    Calculate MACD (Moving Average Convergence Divergence) indicator.
    
    Args:
        prices (pl.Series): Price series
        short_window (int): Short EMA window
        long_window (int): Long EMA window
        signal_window (int): Signal line EMA window
    
    Returns:
        pl.DataFrame: DataFrame with MACD line, signal line, and histogram
    """
    df = pl.DataFrame({prices.name: prices})
    
    # Calculate EMAs
    ema_short = pl.col(prices.name).ewm_mean(span=short_window)
    ema_long = pl.col(prices.name).ewm_mean(span=long_window)
    
    # Calculate MACD line
    macd_line = (ema_short - ema_long).alias('macd')
    
    # Calculate signal line (EMA of MACD line)
    # We need to calculate this in two steps
    df_with_macd = df.select([pl.col(prices.name), macd_line])
    signal_line = pl.col('macd').ewm_mean(span=signal_window).alias('macd_signal')
    
    # Calculate histogram
    df_with_macd_signal = df_with_macd.select([pl.col(prices.name), pl.col('macd'), signal_line])
    histogram = (pl.col('macd') - pl.col('macd_signal')).alias('macd_hist')
    
    return df_with_macd_signal.select([pl.col('macd'), pl.col('macd_signal'), histogram])


def calculate_atr(ohlc: pl.DataFrame, window: int = 14) -> pl.Series:
    """
    Calculate the Average True Range (ATR).
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['high', 'low', 'close'] columns
        window (int): Look-back period
    
    Returns:
        pl.Series: ATR values
    """
    # Calculate true range components
    tr1 = pl.col('high') - pl.col('low')
    tr2 = (pl.col('high') - pl.col('close').shift(1)).abs()
    tr3 = (pl.col('low') - pl.col('close').shift(1)).abs()
    
    # Get maximum of the three components
    true_range = pl.max_horizontal([tr1, tr2, tr3]).alias('true_range')
    
    # Calculate ATR
    atr = true_range.rolling_mean(window=window).alias('atr')
    
    return ohlc.select(atr).to_series()


def calculate_obv(ohlc: pl.DataFrame) -> pl.Series:
    """
    Calculate the On-Balance Volume (OBV).
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['close', 'volume'] columns
    
    Returns:
        pl.Series: OBV values
    """
    # Calculate price direction
    direction = pl.sign(pl.col('close') - pl.col('close').shift(1))
    
    # Calculate OBV increment
    obv_increment = direction * pl.col('volume')
    
    # Cumulative sum
    obv = obv_increment.fill_null(0).cum_sum().alias('obv')
    
    return ohlc.select(obv).to_series()


def calculate_vwap(ohlc: pl.DataFrame, window: int = 20) -> pl.Series:
    """
    Calculate the Volume Weighted Average Price (VWAP) over a rolling window.
    
    Args:
        ohlc (pl.DataFrame): DataFrame with ['high', 'low', 'close', 'volume'] columns
        window (int): Rolling window for VWAP
    
    Returns:
        pl.Series: Rolling VWAP values
    """
    # Calculate typical price
    typical_price = ((pl.col('high') + pl.col('low') + pl.col('close')) / 3).alias('typical_price')
    
    # Calculate price * volume
    tp_vol = (typical_price * pl.col('volume')).alias('tp_vol')
    
    # Calculate rolling sums
    rolling_tp_vol = tp_vol.rolling_sum(window=window)
    rolling_vol = pl.col('volume').rolling_sum(window=window)
    
    # Calculate VWAP
    vwap = (rolling_tp_vol / rolling_vol).alias('vwap')
    
    return ohlc.select(vwap).to_series()


# =======================
#     Main Aggregation
# =======================

def calculate_price_features(
    prices: Union[pl.Series, pl.DataFrame],
    ohlc: Optional[pl.DataFrame] = None,
    benchmark_returns: Optional[pl.Series] = None,
    return_periods: List[int] = [1, 5, 10, 15],
    ma_windows: List[int] = [5, 10, 20, 50, 200],
    volatility_windows: List[int] = [5, 10, 20],
    moment_windows: List[int] = [20, 60, 120],
    bb_window: int = 20,
    bb_num_std: float = 2.0,
    range_window: int = 20,
    range_offset: int = 0,
    rsi_window: int = 14,
    macd_short_window: int = 12,
    macd_long_window: int = 26,
    macd_signal_window: int = 9,
    atr_window: int = 14,
    add_obv: bool = True,
    add_vwap: bool = True,
) -> pl.DataFrame:
    """
    Calculate an extensive set of price-based and OHLC-based features.
    
    Args:
        prices (Union[pl.Series, pl.DataFrame]): Price series or DataFrame with 'close' column
        ohlc (Optional[pl.DataFrame]): OHLC DataFrame
        benchmark_returns (Optional[pl.Series]): Benchmark return series for beta calculation
        return_periods (List[int]): Periods for return calculation
        ma_windows (List[int]): Windows for moving averages
        volatility_windows (List[int]): Windows for volatility calculation
        moment_windows (List[int]): Windows for statistical moments calculation
        bb_window (int): Window for Bollinger Bands
        bb_num_std (float): Number of standard deviations for Bollinger Bands
        range_window (int): Window for range-based calculations
        range_offset (int): Offset for range-based calculations
        rsi_window (int): RSI look-back window
        macd_short_window (int): MACD short EMA window
        macd_long_window (int): MACD long EMA window
        macd_signal_window (int): MACD signal EMA window
        atr_window (int): ATR look-back window
        add_obv (bool): Whether to calculate OBV
        add_vwap (bool): Whether to calculate VWAP
    
    Returns:
        pl.DataFrame: DataFrame with all calculated features
        
    Raises:
        TypeError: If prices is not a polars Series or DataFrame
        ValueError: If OHLC data is provided but missing required columns
    """
    # Input validation
    if not isinstance(prices, (pl.Series, pl.DataFrame)):
        raise TypeError("prices must be a polars Series or DataFrame")
    
    # Convert input to Series if DataFrame
    if isinstance(prices, pl.DataFrame):
        if 'close' not in prices.columns:
            raise ValueError("DataFrame must contain 'close' column")
        price_series = prices['close']
    else:
        price_series = prices
    
    # OHLC validation
    if ohlc is not None:
        required_cols = ['high', 'low', 'close']
        if add_obv or add_vwap:
            required_cols.append('volume')
        missing_cols = [col for col in required_cols if col not in ohlc.columns]
        if missing_cols:
            raise ValueError(f"OHLC data is missing required columns: {missing_cols}")
    
    # Initialize features list
    feature_dfs = []
    
    # 1. Basic Returns
    returns_df = calculate_returns(price_series, return_periods)
    feature_dfs.append(returns_df)
    
    # 2. Moving Averages
    feature_dfs.append(calculate_moving_averages(price_series, ma_windows))
    
    # 3. Bollinger Bands
    feature_dfs.append(calculate_bollinger_bands(price_series, bb_window, bb_num_std))
    
    # 4. Volatility
    feature_dfs.append(calculate_volatility(price_series, volatility_windows))
    
    # 5. RSI
    feature_dfs.append(pl.DataFrame({'rsi': calculate_rsi(price_series, rsi_window)}))
    
    # 6. MACD
    feature_dfs.append(calculate_macd(
        price_series,
        short_window=macd_short_window,
        long_window=macd_long_window,
        signal_window=macd_signal_window
    ))
    
    # 7. Statistical Moments (using shortest return period)
    returns_series = returns_df[f'return_{return_periods[0]}']
    feature_dfs.append(calculate_statistical_moments(returns_series, moment_windows))
    
    # 8. OHLC-based features
    if ohlc is not None:
        # Range-based features
        feature_dfs.append(pl.DataFrame({
            'range_position': calculate_range_position(ohlc, range_window, range_offset),
            'relative_high_position': calculate_relative_high_position(ohlc, range_window, range_offset),
            'relative_low_position': calculate_relative_low_position(ohlc, range_window, range_offset)
        }))
        
        # ATR
        feature_dfs.append(pl.DataFrame({'atr': calculate_atr(ohlc, atr_window)}))
        
        # OBV
        if add_obv and 'volume' in ohlc.columns:
            feature_dfs.append(pl.DataFrame({'obv': calculate_obv(ohlc)}))
        
        # VWAP
        if add_vwap and 'volume' in ohlc.columns:
            feature_dfs.append(pl.DataFrame({'vwap': calculate_vwap(ohlc)}))
    
    # 9. Benchmark-based features (Beta, Correlation) if provided
    if benchmark_returns is not None:
        # Make sure we align the index properly (in pandas equivalent)
        # For Polars, we assume aligned data or should implement index alignment logic
        asset_rets = returns_df[f'return_{return_periods[0]}']
        
        feature_dfs.append(calculate_rolling_beta(asset_rets, benchmark_returns, moment_windows))
        feature_dfs.append(calculate_rolling_correlation(asset_rets, benchmark_returns, moment_windows))
    
    # Combine all features
    return pl.concat(feature_dfs, how='horizontal')