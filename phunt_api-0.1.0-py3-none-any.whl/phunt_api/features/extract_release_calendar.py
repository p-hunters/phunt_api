import pandas as pd
from bs4 import BeautifulSoup
import re
from datetime import datetime, timezone
import requests
import time
import pytz

def extract_from_pre(soup, year):
    """preタグ形式からデータを抽出"""
    pre_text = soup.find('pre').text.strip()
    lines = pre_text.split('\n')
    data_lines = [line for line in lines if line.strip() and not line.startswith(' ' * 10)]
    releases = []
    
    for line in data_lines[0:]:  # ヘッダー3行をスキップ
        line = line.replace('\t', '   ')
        # space2つ以上を | に変換
        for i in [4,3,2]:
            line = re.sub(r'\s{' + str(i) + ',}', '|', line)
            match = re.match(r'(.+?)\|(.+?)\|(.+?)$', line)
            if match:
                break
            else:
                print(f"Error parsing line(i={i}): {line}")
                continue
        if not match:
            continue

        name, date_str, time_str = match.groups()
        date_str = date_str.split(',')[0]
        date_str = date_str.replace('.', '')
        time_str = time_str.strip()
        date_time_str = f"{year} {date_str} {time_str}"
        #space2つ以上を1つに変換
        date_time_str = date_time_str.replace('  ', ' ')
        try:
            date_time = datetime.strptime(date_time_str, f'%Y %B %d %I:%M %p')
            est = pytz.timezone('US/Eastern')
            date_time = est.localize(date_time)
        except ValueError:
            try:
                date_time = datetime.strptime(date_time_str, f'%Y %b %d %I:%M %p')
                est = pytz.timezone('US/Eastern')
                date_time = est.localize(date_time)
            except ValueError:
                print(f"Error parsing date: {date_time_str}")
                print(f"line: {name}|{date_str}|{time_str}")
                continue
        except Exception as e:
            print(f"Error parsing date: {date_time_str} - {e}")
            print(f"line: {name}|{date_str}|{time_str}")
            continue        
        releases.append({
            'name': name.strip(),
            'date': date_time.date(),
            'datetime': date_time,
            'year': year
        })

    return releases

def extract_from_table(soup, year):
    """tableタグ形式からデータを抽出"""
    releases = []
    tables = soup.find_all('table', class_='release-list')
    est = pytz.timezone('US/Eastern')
    
    for table in tables:
        rows = table.find_all('tr')[1:]  # ヘッダー行をスキップ
        for row in rows:
            cells = row.find_all(['td'])
            if len(cells) >= 3:
                date_cell = cells[0].text.strip()
                time_cell = cells[1].text.strip()
                name_cell = cells[2].text.strip()
                
                if not time_cell or time_cell == '\xa0':  # 時間が空の場合（祝日など）
                    continue
                
                # 日付文字列から年を削除（yearパラメータを使用）
                date_str = re.sub(r',\s*\d{4}', f', {year}', date_cell)
                
                try:
                    date_time = datetime.strptime(f"{date_str} {time_cell}", '%A, %B %d, %Y %I:%M %p')
                    date_time = est.localize(date_time)
                    releases.append({
                        'name': name_cell,
                        'date': date_time.date(),
                        'datetime': date_time,
                        'year': year
                    })
                except ValueError as e:
                    print(f"Error parsing date: {date_str} {time_cell} - {e}")
                    continue
    
    return releases

def extract_release_calendar(year):
    """
    BLSのリリーススケジュールをスクレイピングしてデータフレームを返す
    
    Args:
        year (int): 取得したい年（例：2001）
    
    Returns:
        pd.DataFrame: リリーススケジュールのデータフレーム
    """
    url = f"https://www.bls.gov/schedule/{year}/home.htm"
    
    # Enhanced headers to better mimic a browser
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'max-age=0',
        'Sec-Ch-Ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"macOS"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'Referer': 'https://www.bls.gov/',
    }
    
    try:
        # Add a small delay before making the request
        time.sleep(2)
        
        session = requests.Session()
        response = session.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # フォーマットを判定して適切な抽出方法を選択
        releases = []
        if soup.find('pre'):
            releases = extract_from_pre(soup, year)
        elif soup.find('table', class_='release-list'):
            releases = extract_from_table(soup, year)
        else:
            raise ValueError("Unsupported format: Neither pre tag nor release-list table found")
        
        if not releases:
            raise ValueError("No releases found")
        
        return pd.DataFrame(releases)
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data for year {year}: {e}")
        return None
    except Exception as e:
        print(f"Error processing data for year {year}: {e}")
        return None

if __name__ == "__main__":
    df = pd.DataFrame()
    for year in range(2000, 2025):
        print(f"Extracting data for year {year}")
        df_year = extract_release_calendar(year)
        if df_year is not None:
            df = pd.concat([df, df_year], ignore_index=True)
    df.to_parquet('economic_release_calendar_us.parquet')