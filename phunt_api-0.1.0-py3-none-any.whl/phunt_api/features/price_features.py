import numpy as np
import pandas as pd
from typing import Union, List, Optional
from scipy import stats

# =======================
#     Basic Features
# =======================

def calculate_returns(
    prices: pd.Series,
    periods: Union[int, List[int]] = 1,
    method: str = 'arithmetic'
) -> pd.DataFrame:
    """
    Calculate returns for given price series.
    
    Args:
        prices (pd.Series): Price series
        periods (Union[int, List[int]]): Period(s) to calculate returns for
        method (str): 'arithmetic' for (p2-p1)/p1 or 'log' for log(p2/p1)
    
    Returns:
        pd.DataFrame: DataFrame with calculated returns
    """
    if isinstance(periods, int):
        periods = [periods]
    
    returns = pd.DataFrame(index=prices.index)
    
    for period in periods:
        if method == 'arithmetic':
            ret = prices.pct_change(period, fill_method=None)
        elif method == 'log':
            ret = np.log(prices / prices.shift(period))
        else:
            raise ValueError("method must be either 'arithmetic' or 'log'")
        
        returns[f'return_{period}'] = ret
    
    return returns


def calculate_moving_averages(
    prices: pd.Series,
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200]
) -> pd.DataFrame:
    """
    Calculate simple moving averages for given windows.
    
    Args:
        prices (pd.Series): Price series
        windows (Union[int, List[int]]): List of window sizes for moving averages
    
    Returns:
        pd.DataFrame: DataFrame with calculated moving averages
    """
    if isinstance(windows, int):
        windows = [windows]
    
    mas = pd.DataFrame(index=prices.index)
    
    for window in windows:
        mas[f'ma_{window}'] = prices.rolling(window=window).mean()
    
    return mas


def calculate_bollinger_bands(
    prices: pd.Series,
    window: int = 20,
    num_std: float = 2.0
) -> pd.DataFrame:
    """
    Calculate Bollinger Bands.
    
    Args:
        prices (pd.Series): Price series
        window (int): Window size for moving average
        num_std (float): Number of standard deviations for bands
    
    Returns:
        pd.DataFrame: DataFrame with middle band (MA), upper and lower bands
    """
    bb = pd.DataFrame(index=prices.index)
    
    # Calculate middle band (simple moving average)
    middle_band = prices.rolling(window=window).mean()
    
    # Calculate standard deviation
    std = prices.rolling(window=window).std()
    
    # Calculate upper and lower bands
    bb['bb_middle'] = middle_band
    bb['bb_upper'] = middle_band + (std * num_std)
    bb['bb_lower'] = middle_band - (std * num_std)
    
    return bb


def calculate_volatility(
    prices: pd.Series,
    windows: Union[int, List[int]] = [5, 10, 20],
    returns_method: str = 'log'
) -> pd.DataFrame:
    """
    Calculate volatility (standard deviation of returns) for different windows.
    
    Args:
        prices (pd.Series): Price series
        windows (Union[int, List[int]]): Window sizes for volatility calculation
        returns_method (str): Method to calculate returns ('arithmetic' or 'log')
    
    Returns:
        pd.DataFrame: DataFrame with volatility measures
    """
    if isinstance(windows, int):
        windows = [windows]
    
    # Calculate returns first
    if returns_method == 'arithmetic':
        returns = prices.pct_change()
    else:  # log returns
        returns = np.log(prices / prices.shift(1))
    
    vol = pd.DataFrame(index=prices.index)
    
    for window in windows:
        # For constant prices, returns will be 0, so volatility should be 0
        rolling_std = returns.rolling(window=window).std()
        # Check if all values in the window are the same
        is_constant = returns.rolling(window=window).apply(
            lambda x: np.allclose(x, 0, rtol=1e-10, atol=1e-10)
        )
        vol[f'volatility_{window}'] = np.where(
            is_constant,
            0,
            rolling_std * np.sqrt(252)  # Annualized volatility (assuming daily data)
        )
        # Fill initial NaN values with 0 for constant price sequences
        vol[f'volatility_{window}'].fillna(0, inplace=True)
    
    return vol

# =======================
#  Statistical Features
# =======================

def calculate_statistical_moments(
    returns: pd.Series,
    windows: List[int] = [20, 60, 120]
) -> pd.DataFrame:
    """
    Calculate rolling statistical moments (mean, variance, skewness, kurtosis, JB test).
    
    Args:
        returns (pd.Series): Return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pd.DataFrame: DataFrame with statistical moments
    """
    features = pd.DataFrame(index=returns.index)
    
    for window in windows:
        # Rolling mean and variance
        features[f'rolling_mean_{window}'] = returns.rolling(window=window).mean()
        features[f'rolling_var_{window}'] = returns.rolling(window=window).var()
        
        # For constant returns, skewness should be 0 and kurtosis should be 0 (excess kurtosis)
        def rolling_skew_with_constant(x):
            if np.allclose(x, x.iloc[0], rtol=1e-10, atol=1e-10):
                return 0.0
            return stats.skew(x)
        
        def rolling_kurt_with_constant(x):
            if np.allclose(x, x.iloc[0], rtol=1e-10, atol=1e-10):
                return 0.0  # Excess kurtosis for constant series
            return stats.kurtosis(x)
        
        # Rolling skewness and kurtosis with constant value handling
        features[f'rolling_skew_{window}'] = returns.rolling(window=window).apply(rolling_skew_with_constant)
        features[f'rolling_kurt_{window}'] = returns.rolling(window=window).apply(rolling_kurt_with_constant)
        
        # Rolling Jarque-Bera test statistic
        def rolling_jb(x):
            if np.allclose(x, x.iloc[0], rtol=1e-10, atol=1e-10):
                return 0.0  # JB test statistic for constant series
            n = len(x)
            skew = stats.skew(x)
            kurt = stats.kurtosis(x)
            jb = n/6.0 * (skew**2 + (kurt**2)/4.0)
            return jb
        
        features[f'rolling_jb_{window}'] = (
            returns.rolling(window=window, min_periods=window)
                   .apply(rolling_jb)
        )
    
    return features


def calculate_rolling_correlation(
    series1: pd.Series,
    series2: pd.Series,
    windows: List[int] = [20, 60, 120]
) -> pd.DataFrame:
    """
    Calculate rolling correlation between two series.
    
    Args:
        series1 (pd.Series): First series
        series2 (pd.Series): Second series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pd.DataFrame: DataFrame with rolling correlations
    """
    features = pd.DataFrame(index=series1.index)
    
    for window in windows:
        features[f'rolling_corr_{window}'] = series1.rolling(
            window=window
        ).corr(series2)
    
    return features


def calculate_rolling_beta(
    asset_returns: pd.Series,
    benchmark_returns: pd.Series,
    windows: List[int] = [20, 60, 120]
) -> pd.DataFrame:
    """
    Calculate rolling beta (market sensitivity) of an asset against a benchmark.
    
    Args:
        asset_returns (pd.Series): Asset return series
        benchmark_returns (pd.Series): Benchmark return series
        windows (List[int]): List of window sizes for rolling calculations
    
    Returns:
        pd.DataFrame: DataFrame with rolling betas and R-squared values
    """
    features = pd.DataFrame(index=asset_returns.index)
    
    for window in windows:
        rolling_cov = asset_returns.rolling(window=window).cov(benchmark_returns)
        rolling_var = benchmark_returns.rolling(window=window).var()
        
        # Calculate beta
        features[f'rolling_beta_{window}'] = rolling_cov / rolling_var
        
        # Calculate R-squared (square of correlation)
        rolling_corr = asset_returns.rolling(window=window).corr(benchmark_returns)
        features[f'rolling_r2_{window}'] = rolling_corr ** 2
    
    return features

# =======================
#   Range-Based Features
# =======================

def calculate_range_position(
    ohlc: pd.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pd.Series:
    """
    Calculate the range position of the close price in the past 'window' range.
    
    Args:
        ohlc (pd.DataFrame): OHLC DataFrame with columns ['high', 'low', 'close']
        window (int): Window size for calculation
        offset (int): Offset for lagged calculation
    
    Returns:
        pd.Series: Range position values (0 to 1)
    """
    high = ohlc['high'].shift(offset).rolling(window=window).max()
    low = ohlc['low'].shift(offset).rolling(window=window).min()
    close = ohlc['close'].shift(offset)
    
    # Ensure denominator is not zero and clip result between 0 and 1
    range_pos = (close - low) / (high - low).replace(0, np.nan)
    return range_pos.clip(0, 1)  # Clip values to ensure they're between 0 and 1


def calculate_relative_high_position(
    ohlc: pd.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pd.Series:
    """
    Calculate the ratio of the close price to the highest high in the past 'window'.
    
    Args:
        ohlc (pd.DataFrame): OHLC DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pd.Series: Relative high position values (close / max_high)
    """
    high = ohlc['high'].shift(offset).rolling(window=window).max()
    close = ohlc['close'].shift(offset)
    return (close / high).clip(upper=1.0)  # Ensure ratio is not greater than 1


def calculate_relative_low_position(
    ohlc: pd.DataFrame,
    window: int = 20,
    offset: int = 0
) -> pd.Series:
    """
    Calculate the ratio of the close price to the lowest low in the past 'window'.
    
    Args:
        ohlc (pd.DataFrame): OHLC DataFrame with columns ['high', 'low', 'close']
        window (int): Window size
        offset (int): Offset for lagged calculation
    
    Returns:
        pd.Series: Relative low position values (close / min_low)
    """
    low = ohlc['low'].shift(offset).rolling(window=window).min()
    close = ohlc['close'].shift(offset)
    return (close / low).clip(lower=1.0)  # Ensure ratio is not less than 1

# =======================
#   Additional Indicators
# =======================

def calculate_rsi(prices: pd.Series, window: int = 14) -> pd.Series:
    """
    Calculate the Relative Strength Index (RSI).
    
    Args:
        prices (pd.Series): Price series (e.g., close)
        window (int): Look-back period for RSI calculation
    
    Returns:
        pd.Series: RSI values
    """
    # Price changes
    delta = prices.diff(1)
    
    # Handle constant price series
    if (delta.abs() < 1e-10).all():
        return pd.Series(50, index=prices.index)  # RSI = 50 for constant prices
    
    # Handle monotonic increasing/decreasing series
    if (delta >= -1e-10).all():
        return pd.Series(100, index=prices.index)  # RSI = 100 for all positive changes
    if (delta <= 1e-10).all():
        return pd.Series(0, index=prices.index)   # RSI = 0 for all negative changes
    
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    
    # Exponential moving average for gains/losses
    roll_up = up.ewm(span=window, adjust=False).mean()
    roll_down = down.ewm(span=window, adjust=False).mean()
    
    # Avoid division by zero and handle edge cases
    rs = np.where(
        roll_down < 1e-10,
        np.inf,
        roll_up / roll_down
    )
    
    # Calculate RSI
    rsi = np.where(
        np.isinf(rs),
        100,
        100 - (100 / (1 + rs))
    )
    
    # Handle remaining edge cases
    rsi = np.where(roll_up < 1e-10, 0, rsi)  # All downs = RSI 0
    rsi = np.where(
        (roll_up < 1e-10) & (roll_down < 1e-10),
        50,  # Both zero = neutral RSI
        rsi
    )
    
    return pd.Series(rsi, index=prices.index)


def calculate_macd(
    prices: pd.Series,
    short_window: int = 12,
    long_window: int = 26,
    signal_window: int = 9
) -> pd.DataFrame:
    """
    Calculate MACD (Moving Average Convergence Divergence) indicator.
    
    Args:
        prices (pd.Series): Price series
        short_window (int): Short EMA window
        long_window (int): Long EMA window
        signal_window (int): Signal line EMA window
    
    Returns:
        pd.DataFrame: DataFrame with columns [MACD, Signal, Histogram]
    """
    ema_short = prices.ewm(span=short_window, adjust=False).mean()
    ema_long = prices.ewm(span=long_window, adjust=False).mean()
    
    macd_line = ema_short - ema_long
    signal_line = macd_line.ewm(span=signal_window, adjust=False).mean()
    histogram = macd_line - signal_line
    
    return pd.DataFrame({
        'macd': macd_line,
        'macd_signal': signal_line,
        'macd_hist': histogram
    }, index=prices.index)


def calculate_atr(ohlc: pd.DataFrame, window: int = 14) -> pd.Series:
    """
    Calculate the Average True Range (ATR).
    
    Args:
        ohlc (pd.DataFrame): DataFrame with ['high', 'low', 'close']
        window (int): Look-back period
    
    Returns:
        pd.Series: ATR values
    """
    high = ohlc['high']
    low = ohlc['low']
    close = ohlc['close']
    
    # True range components
    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Simple moving average for ATR (commonly used)
    atr = true_range.rolling(window=window).mean()
    return atr


def calculate_obv(ohlc: pd.DataFrame) -> pd.Series:
    """
    Calculate the On-Balance Volume (OBV).
    
    Args:
        ohlc (pd.DataFrame): DataFrame with ['close', 'volume']
    
    Returns:
        pd.Series: OBV values
    """
    close = ohlc['close']
    volume = ohlc['volume']
    
    # Sign of price change
    direction = np.sign(close.diff())
    # OBV increment
    obv_increment = direction * volume
    
    # Cumulative sum
    obv = obv_increment.fillna(0).cumsum()
    return obv


def calculate_vwap(ohlc: pd.DataFrame, window: int = 20) -> pd.Series:
    """
    Calculate the Volume Weighted Average Price (VWAP) over a rolling window.
    Note: For intraday data, typically VWAP is from market open to current.
    Here we implement a rolling-window VWAP as a demonstration.
    
    Args:
        ohlc (pd.DataFrame): DataFrame with ['high', 'low', 'close', 'volume']
        window (int): Rolling window for VWAP
    
    Returns:
        pd.Series: Rolling VWAP values
    """
    typical_price = (ohlc['high'] + ohlc['low'] + ohlc['close']) / 3
    tp_vol = typical_price * ohlc['volume']
    
    rolling_tp_vol = tp_vol.rolling(window=window).sum()
    rolling_vol = ohlc['volume'].rolling(window=window).sum()
    
    vwap = rolling_tp_vol / rolling_vol
    return vwap


# =======================
#     Main Aggregation
# =======================

def calculate_price_features(
    prices: pd.Series,
    ohlc: Optional[pd.DataFrame] = None,
    benchmark_returns: Optional[pd.Series] = None,
    return_periods: List[int] = [1, 5, 10, 15],
    ma_windows: List[int] = [5, 10, 20, 50, 200],
    volatility_windows: List[int] = [5, 10, 20],
    moment_windows: List[int] = [20, 60, 120],
    bb_window: int = 20,
    bb_num_std: float = 2.0,
    range_window: int = 20,
    range_offset: int = 0,
    rsi_window: int = 14,
    macd_short_window: int = 12,
    macd_long_window: int = 26,
    macd_signal_window: int = 9,
    atr_window: int = 14,
    add_obv: bool = True,
    add_vwap: bool = True,
) -> pd.DataFrame:
    """
    Calculate an extensive set of price-based and OHLC-based features.
    
    Args:
        prices (pd.Series): Price series (e.g. close price)
        ohlc (Optional[pd.DataFrame]): OHLC DataFrame
        benchmark_returns (Optional[pd.Series]): Benchmark return series for beta calculation
        return_periods (List[int]): Periods for return calculation
        ma_windows (List[int]): Windows for moving averages
        volatility_windows (List[int]): Windows for volatility calculation
        moment_windows (List[int]): Windows for statistical moments calculation
        bb_window (int): Window for Bollinger Bands
        bb_num_std (float): Number of standard deviations for Bollinger Bands
        range_window (int): Window for range-based calculations
        range_offset (int): Offset for range-based calculations
        rsi_window (int): RSI look-back window
        macd_short_window (int): MACD short EMA window
        macd_long_window (int): MACD long EMA window
        macd_signal_window (int): MACD signal EMA window
        atr_window (int): ATR look-back window
        add_obv (bool): Whether to calculate OBV
        add_vwap (bool): Whether to calculate VWAP
    
    Returns:
        pd.DataFrame: DataFrame with all calculated features
        
    Raises:
        TypeError: If prices is not a pandas Series
        ValueError: If OHLC data is provided but missing required columns
    """
    # Input validation
    if not isinstance(prices, pd.Series):
        raise TypeError("prices must be a pandas Series")
    
    if ohlc is not None:
        required_cols = ['high', 'low', 'close']
        if add_obv or add_vwap:
            required_cols.append('volume')
        missing_cols = [col for col in required_cols if col not in ohlc.columns]
        if missing_cols:
            raise ValueError(f"OHLC data is missing required columns: {missing_cols}")
    
    # Initialize features DataFrame
    features = pd.DataFrame(index=prices.index)
    
    # 1. Basic Returns
    returns_df = calculate_returns(prices, return_periods)
    # Use the shortest return period for moment calculations
    returns_for_moments = returns_df[f'return_{return_periods[0]}'].dropna()
    
    # 2. Combine initial price-based features
    features = pd.concat([
        returns_df,
        calculate_moving_averages(prices, ma_windows),
        calculate_bollinger_bands(prices, bb_window, bb_num_std),
        calculate_volatility(prices, volatility_windows),
        calculate_statistical_moments(returns_for_moments, moment_windows)
    ], axis=1)
    
    # 3. RSI
    features['rsi'] = calculate_rsi(prices, window=rsi_window)
    
    # 4. MACD
    macd_df = calculate_macd(
        prices,
        short_window=macd_short_window,
        long_window=macd_long_window,
        signal_window=macd_signal_window
    )
    features = pd.concat([features, macd_df], axis=1)
    
    # 5. OHLC-based features (if OHLC is provided)
    if ohlc is not None:
        # Range-based
        range_pos = calculate_range_position(ohlc, range_window, range_offset)
        rel_high_pos = calculate_relative_high_position(ohlc, range_window, range_offset)
        rel_low_pos = calculate_relative_low_position(ohlc, range_window, range_offset)
        
        # ATR
        atr = calculate_atr(ohlc, window=atr_window)
        
        # OBV, VWAP
        extra_ohlc_features = {}
        if add_obv and 'volume' in ohlc.columns:
            extra_ohlc_features['obv'] = calculate_obv(ohlc)
        if add_vwap and 'volume' in ohlc.columns:
            extra_ohlc_features['vwap'] = calculate_vwap(ohlc)
        
        ohlc_feats_df = pd.DataFrame({
            'range_position': range_pos,
            'relative_high_position': rel_high_pos,
            'relative_low_position': rel_low_pos,
            'atr': atr,
            **extra_ohlc_features
        }, index=prices.index)
        
        features = pd.concat([features, ohlc_feats_df], axis=1)
    
    # 6. Benchmark-based features (Beta, Correlation) if provided
    if benchmark_returns is not None:
        # Make sure we align the index properly
        common_index = features.index.intersection(benchmark_returns.index)
        asset_rets = returns_for_moments.reindex(common_index)
        bench_rets = benchmark_returns.reindex(common_index)
        
        beta_features = calculate_rolling_beta(asset_rets, bench_rets, moment_windows)
        correlation_features = calculate_rolling_correlation(asset_rets, bench_rets, moment_windows)
        
        # Concat using the common index
        features = pd.concat([features, beta_features, correlation_features], axis=1)
    
    return features
