"""
BigQueryを使用した価格データからの特徴量計算モジュール

このモジュールは、価格データから統計的モーメント（平均、分散、歪度、尖度、JB統計量）などの
時系列特徴量をBigQueryを用いて計算します。
"""

import polars as pl
import pandas as pd
import asyncio
from typing import Union, List, Dict, Optional, Any, Tuple, TypeVar
import os
# 共通BigQueryコンポーネントのインポート
from phunt_api.misc.bq import (
    BIGQUERY_AVAILABLE,
    BigQueryConfig,
    BigQueryTableManager,
    BigQueryDataFetcher,
    BigQueryResourceError,
    QueryExecutionError,
    ValidationError,
    check_bigquery_requirements,
)

GCP_PROJECT_ID = os.environ.get('gcp_project_id')

# =============================================================================
# 特徴量SQL生成クラス
# =============================================================================

class BigQueryFeatureGenerator:
    """
    BigQueryでの特徴量計算用SQLクエリを生成するクラス
    
    主な責務:
    - 各種特徴量計算のためのSQL生成
    - クエリの最適化と標準化
    - 複雑なウィンドウ関数とSQL式の構築
    """
    
    @staticmethod
    def get_moments_query(
        table_id: str,
        date_column: str,
        value_column: str,
        window: int
    ) -> str:
        """
        統計的モーメント（平均、分散、歪度、尖度、JB統計量）計算用のSQLを生成
        
        Args:
            table_id: ソーステーブルID
            date_column: 日付/時系列カラム名
            value_column: 計算対象の値カラム名
            window: 計算ウィンドウサイズ
            
        Returns:
            実行可能なSQL文字列
        """
        sql = f"""
        WITH moments AS (
            SELECT
                {date_column},
                {value_column},
                AVG({value_column}) OVER w AS rolling_mean,
                VARIANCE({value_column}) OVER w AS rolling_var,
                
                /* Skewness calculation */
                CASE
                    WHEN COUNT(*) OVER w < 3 THEN NULL
                    WHEN STDDEV({value_column}) OVER w = 0 THEN 0
                    ELSE (
                        SUM(POW({value_column} - AVG({value_column}) OVER w, 3)) OVER w 
                        / POW(STDDEV({value_column}) OVER w, 3)
                    ) * COUNT(*) OVER w / ((COUNT(*) OVER w - 1) * (COUNT(*) OVER w - 2))
                END AS rolling_skew,
                
                /* Kurtosis calculation (excess kurtosis) */
                CASE
                    WHEN COUNT(*) OVER w < 4 THEN NULL
                    WHEN STDDEV({value_column}) OVER w = 0 THEN 0
                    ELSE (
                        SUM(POW({value_column} - AVG({value_column}) OVER w, 4)) OVER w
                        / POW(VARIANCE({value_column}) OVER w, 2)
                    ) * COUNT(*) OVER w * (COUNT(*) OVER w + 1) / 
                        ((COUNT(*) OVER w - 1) * (COUNT(*) OVER w - 2) * (COUNT(*) OVER w - 3)) - 3
                END AS rolling_kurt,
                
                /* Capture window count for JB calculation */
                COUNT(*) OVER w AS window_count
                
            FROM `{table_id}`
            WINDOW w AS (ORDER BY {date_column} ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW)
        )
        
        /* Calculate Jarque-Bera statistic without nesting window functions */
        SELECT 
            {date_column},
            rolling_mean AS rolling_mean_{window},
            rolling_var AS rolling_var_{window},
            rolling_skew AS rolling_skew_{window},
            rolling_kurt AS rolling_kurt_{window},
            /* Calculate JB statistic directly without window function */
            CASE
                WHEN rolling_skew IS NULL OR rolling_kurt IS NULL THEN NULL
                ELSE (window_count / 6) * (
                    POW(COALESCE(rolling_skew, 0), 2) + POW(COALESCE(rolling_kurt, 0), 2) / 4
                )
            END AS rolling_jb_{window}
        FROM moments
        ORDER BY {date_column}
        """
        return sql
    
    @staticmethod
    def get_returns_query(
        table_id: str,
        date_column: str,
        price_column: str,
        period: int,
        method: str = 'arithmetic'
    ) -> str:
        """
        リターン計算用のSQLを生成
        
        Args:
            table_id: ソーステーブルID
            date_column: 日付/時系列カラム名
            price_column: 価格カラム名
            period: リターン計算期間
            method: 'arithmetic'または'log'
            
        Returns:
            実行可能なSQL文字列
        """
        if method.lower() == 'log':
            return_expr = f"LN({price_column} / LAG({price_column}, {period}) OVER (ORDER BY {date_column}))"
        else:  # arithmetic
            return_expr = f"({price_column} - LAG({price_column}, {period}) OVER (ORDER BY {date_column})) / LAG({price_column}, {period}) OVER (ORDER BY {date_column})"
        
        sql = f"""
        SELECT
            {date_column},
            {price_column},
            {return_expr} AS return_{period}
        FROM `{table_id}`
        ORDER BY {date_column}
        """
        return sql
    
    @staticmethod
    def get_moving_average_query(
        table_id: str,
        date_column: str,
        price_column: str,
        window: int
    ) -> str:
        """
        移動平均計算用のSQLを生成
        
        Args:
            table_id: ソーステーブルID
            date_column: 日付/時系列カラム名
            price_column: 価格カラム名
            window: ウィンドウサイズ
            
        Returns:
            実行可能なSQL文字列
        """
        sql = f"""
        SELECT
            {date_column},
            {price_column},
            AVG({price_column}) OVER (
                ORDER BY {date_column} 
                ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW
            ) AS ma_{window}
        FROM `{table_id}`
        ORDER BY {date_column}
        """
        return sql 

# =============================================================================
# 特徴量計算サービス
# =============================================================================

class BigQueryFeatureService:
    """
    BigQueryを使用した金融特徴量計算サービス
    
    各コンポーネントを統合し、高レベルのファサードを提供する
    """
    
    def __init__(
        self, 
        project_id: str = GCP_PROJECT_ID,
        dataset_id: str = 'phunt_api',
        location: str = "asia-northeast1",
        **kwargs
    ):
        """
        BigQuery特徴量計算サービスを初期化
        
        Args:
            project_id: GCPプロジェクトID
            dataset_id: BigQueryデータセットID
            location: BigQueryロケーション
            **kwargs: その他の設定オプション
        """
        check_bigquery_requirements()
        
        self.config = BigQueryConfig(
            project_id=GCP_PROJECT_ID if project_id is None else project_id,
            dataset_id=dataset_id,
            location=location,
            **kwargs
        )
        
        # 内部コンポーネント
        self._table_manager = None
        self._data_fetcher = None
        self._feature_generator = BigQueryFeatureGenerator()
    
    @property
    def table_manager(self) -> BigQueryTableManager:
        """遅延初期化されたテーブルマネージャーを取得"""
        if self._table_manager is None:
            self._table_manager = BigQueryTableManager(self.config)
        return self._table_manager
    
    @property
    def data_fetcher(self) -> BigQueryDataFetcher:
        """遅延初期化されたデータフェッチャーを取得"""
        if self._data_fetcher is None:
            self._data_fetcher = BigQueryDataFetcher(self.config)
        return self._data_fetcher
    
    def _convert_to_pandas(self, df: pl.DataFrame) -> pd.DataFrame:
        """
        Polars DataFrameをPandas DataFrameに変換
        
        Args:
            df: 変換対象のPolars DataFrame
            
        Returns:
            変換後のPandas DataFrame
        """
        return df.to_pandas()
    
    def calculate_statistical_moments(
        self,
        returns: Union[pl.Series, pl.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: str = None,
        returns_column: str = None
    ) -> pd.DataFrame:
        """
        統計的モーメント（平均、分散、歪度、尖度、JB統計量）を計算
        
        Args:
            returns: リターンデータ（Series または DataFrame）
            windows: 計算ウィンドウサイズのリスト
            date_column: 日付カラム名（DataFrameの場合）
            returns_column: リターンカラム名（DataFrameの場合）
            
        Returns:
            統計的モーメントを含むPandas DataFrame
        """
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=returns,
            date_column=date_column,
            value_column=returns_column,
            value_type="returns"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("returns_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 各ウィンドウサイズに対してクエリ実行
            results = []
            for window in windows:
                # クエリ生成
                query = self._feature_generator.get_moments_query(
                    temp_table_id, date_col, value_col, window
                )
                
                # クエリ実行、結果取得
                window_df = self.data_fetcher.execute_query_to_polars(query)
                
                # 日付カラム処理
                if date_col == "row_id":
                    result_cols = [col for col in window_df.columns if col != date_col]
                    results.append(window_df.select(result_cols))
                else:
                    results.append(window_df)
        
        # 結果の結合とPandas形式への変換
        return self._convert_to_pandas(self._combine_results(results, date_col))
    
    def calculate_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        リターンを計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            periods: 計算期間（整数または整数のリスト）
            method: 計算方法 ('arithmetic' または 'log')
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            リターンを含むPandas DataFrame
        """
        # リスト変換
        if isinstance(periods, int):
            periods = [periods]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 各期間に対してクエリ実行
            results = []
            for period in periods:
                # クエリ生成
                query = self._feature_generator.get_returns_query(
                    temp_table_id, date_col, value_col, period, method
                )
                
                # クエリ実行、結果取得
                period_df = self.data_fetcher.execute_query_to_polars(query)
                
                # 必要なカラムのみ選択
                if period == periods[0]:
                    # 最初の結果にはすべてのカラムを含める
                    results.append(period_df)
                else:
                    # 以降の結果はリターンカラムのみ追加
                    results.append(period_df.select([f"return_{period}"]))
            
        # 結果の結合とPandas形式への変換
        return self._convert_to_pandas(self._combine_results(results, date_col))
    
    async def calculate_statistical_moments_async(
        self,
        returns: Union[pl.Series, pl.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: str = None,
        returns_column: str = None
    ) -> pd.DataFrame:
        """
        統計的モーメントを非同期計算
        
        Args:
            returns: リターンデータ（Series または DataFrame）
            windows: 計算ウィンドウサイズのリスト
            date_column: 日付カラム名（DataFrameの場合）
            returns_column: リターンカラム名（DataFrameの場合）
            
        Returns:
            統計的モーメントを含むPandas DataFrame
        """
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=returns,
            date_column=date_column,
            value_column=returns_column,
            value_type="returns"
        )
        
        # 非同期コンテキストで実行
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("returns_data_async")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 並列クエリ実行タスク準備
            async_tasks = []
            for window in windows:
                query = self._feature_generator.get_moments_query(
                    temp_table_id, date_col, value_col, window
                )
                # 非同期タスク作成
                async_tasks.append(self.data_fetcher.execute_query_async(query))
            
            # タスク並列実行
            results_dfs = await asyncio.gather(*async_tasks)
            
            # タスク結果はすでにPandas DataFrame形式
            polars_results = [pl.from_pandas(df) for df in results_dfs]
            
            # 日付列処理
            if date_col == "row_id":
                for i, df in enumerate(polars_results):
                    result_cols = [col for col in df.columns if col != date_col]
                    polars_results[i] = df.select(result_cols)
                        
        # 結果の結合 - そのままPandas形式で返す
        combined_polars = self._combine_results(polars_results, date_col)
        return self._convert_to_pandas(combined_polars)
        
    async def calculate_returns_async(
        self,
        prices: Union[pl.Series, pl.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        リターンを非同期計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            periods: 計算期間（整数または整数のリスト）
            method: 計算方法 ('arithmetic' または 'log')
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            リターンを含むPandas DataFrame
        """
        # リスト変換
        if isinstance(periods, int):
            periods = [periods]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data_async")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 並列クエリ実行タスク準備
            async_tasks = []
            for period in periods:
                query = self._feature_generator.get_returns_query(
                    temp_table_id, date_col, value_col, period, method
                )
                async_tasks.append(self.data_fetcher.execute_query_async(query))
            
            # タスク並列実行
            results_dfs = await asyncio.gather(*async_tasks)
            
            # Pandas DataFrameをPolarsに変換
            polars_results = [pl.from_pandas(df) for df in results_dfs]
            
            # カラム選択
            for i, period in enumerate(periods):
                if i > 0:  # 最初以外の結果はリターンカラムのみ保持
                    polars_results[i] = polars_results[i].select([f"return_{period}"])
                    
        # 結果の結合をPolarsで行い、PandasへのDataFrameへ変換して返す
        combined_polars = self._combine_results(polars_results, date_col)
        return self._convert_to_pandas(combined_polars)
        
    async def calculate_moving_averages_async(
        self,
        prices: Union[pl.Series, pl.DataFrame],
        windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
        date_column: str = None,
        price_column: str = None
    ) -> pd.DataFrame:
        """
        移動平均を非同期計算
        
        Args:
            prices: 価格データ（Series または DataFrame）
            windows: 計算ウィンドウサイズ（整数または整数のリスト）
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            
        Returns:
            移動平均を含むPandas DataFrame
        """
        # リスト変換
        if isinstance(windows, int):
            windows = [windows]
        
        # データ準備
        data_df, date_col, value_col = self._prepare_data(
            data=prices,
            date_column=date_column,
            value_column=price_column,
            value_type="prices"
        )
        
        with self.table_manager as manager:
            # 一時テーブル作成
            temp_table_id = manager.create_temp_table_id("price_data_ma_async")
            
            # データロード
            manager.load_dataframe(data_df, temp_table_id)
            
            # 並列クエリ実行タスク準備
            async_tasks = []
            for window in windows:
                query = self._feature_generator.get_moving_average_query(
                    temp_table_id, date_col, value_col, window
                )
                async_tasks.append(self.data_fetcher.execute_query_async(query))
            
            # タスク並列実行
            results_dfs = await asyncio.gather(*async_tasks)
            
            # Pandas DataFrameをPolarsに変換
            polars_results = [pl.from_pandas(df) for df in results_dfs]
            
            # カラム選択
            for i, window in enumerate(windows):
                if i > 0:  # 最初以外の結果は移動平均カラムのみ保持
                    polars_results[i] = polars_results[i].select([f"ma_{window}"])
                    
        # 結果の結合をPolarsで行い、PandasへのDataFrameへ変換して返す
        combined_polars = self._combine_results(polars_results, date_col)
        return self._convert_to_pandas(combined_polars)
    
    def _prepare_data(
        self,
        data: Union[pl.Series, pl.DataFrame],
        date_column: str = None,
        value_column: str = None,
        value_type: str = "generic"
    ) -> Tuple[pl.DataFrame, str, str]:
        """
        データ準備と列名解決
        
        Args:
            data: 入力データ
            date_column: 日付列名
            value_column: 値列名
            value_type: データタイプ（"returns", "prices"など）
            
        Returns:
            (DataFrame, 日付列名, 値列名)のタプル
        """
        if isinstance(data, pl.Series):
            # Seriesの場合、DataFrameに変換
            value_name = data.name
            if value_name is None:
                value_name = f"{value_type}_value"
            
            # インデックス列と値列を持つDataFrameを作成
            data_df = pl.DataFrame({
                "row_id": list(range(len(data))),  # pl.arangeの代わりにリストを使用
                value_name: data
            })
            return data_df, "row_id", value_name
            
        else:
            # DataFrameの場合
            data_df = data
            
            # 日付列の解決
            if date_column is None:
                # 日付列の自動検出
                date_candidates = [
                    col for col in data_df.columns 
                    if any(kw in col.lower() for kw in ["date", "time", "timestamp"])
                ]
                
                if date_candidates:
                    date_column = date_candidates[0]
                else:
                    # 日付列がない場合は行IDを追加
                    if "row_id" not in data_df.columns:
                        data_df = data_df.with_columns(
                            pl.Series("row_id", list(range(len(data_df))))  # pl.arangeの代わりにリストを使用
                        )
                    date_column = "row_id"
            
            # 値列の解決
            if value_column is None:
                # 値列の自動検出
                value_pattern = value_type.rstrip('s')  # 単数形に変換（例: "returns" -> "return"）
                value_candidates = [
                    col for col in data_df.columns
                    if value_pattern in col.lower()
                ]
                
                if value_candidates:
                    value_column = value_candidates[0]
                else:
                    raise ValidationError(
                        f"{value_type} column must be specified when using a DataFrame without an obvious {value_type} column"
                    )
            
            return data_df, date_column, value_column
    
    def _combine_results(
        self,
        dataframes: List[pl.DataFrame],
        join_column: str = None
    ) -> pl.DataFrame:
        """
        複数のDataFrameを結合
        
        Args:
            dataframes: 結合対象のDataFrameリスト
            join_column: 結合キー列
            
        Returns:
            結合されたDataFrame
        """
        if not dataframes:
            return pl.DataFrame()
        
        if len(dataframes) == 1:
            return dataframes[0]
        
        # 結合処理
        if join_column and join_column in dataframes[0].columns:
            # 日付/キー列による結合
            result = dataframes[0]
            for df in dataframes[1:]:
                # すでに持っているカラムをスキップ
                existing_cols = set(result.columns)
                if join_column in df.columns:
                    # 結合キーあり
                    new_cols = [c for c in df.columns if c != join_column]
                    if new_cols:
                        result = result.join(df.select([join_column] + new_cols), on=join_column, how="left")
                else:
                    # 結合キーなし
                    result = pl.concat([result, df], how="horizontal")
            
            return result
        else:
            # 単純な横方向結合
            return pl.concat(dataframes, how="horizontal")

# =============================================================================
# パブリックAPI関数
# =============================================================================

def calculate_statistical_moments_bq(
    returns: Union[pl.Series, pl.DataFrame],
    windows: List[int] = [20, 60, 120],
    date_column: str = None,
    returns_column: str = None,
    project_id: str = None,
    dataset_id: str = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    BigQueryを使用して統計的モーメント（平均、分散、歪度、尖度、JB統計量）を計算
    
    Args:
        returns: リターンデータ（Series または DataFrame）
        windows: 計算ウィンドウサイズのリスト
        date_column: 日付カラム名（DataFrameの場合）
        returns_column: リターンカラム名（DataFrameの場合）
        project_id: GCPプロジェクトID
        dataset_id: BigQueryデータセットID
        async_execution: 非同期実行するかどうか
        **kwargs: その他のBigQuery設定オプション
        
    Returns:
        統計的モーメントを含むPandas DataFrame
    
    Raises:
        ValidationError: 必要なパラメータが不足している場合
        BigQueryResourceError: BigQueryリソースエラーが発生した場合
        QueryExecutionError: クエリ実行中にエラーが発生した場合
    """
    # BigQuery要件確認
    check_bigquery_requirements()
    
    # パラメータ検証
    if dataset_id is None:
        raise ValidationError("dataset_id must be specified")
    
    # サービス初期化
    service = BigQueryFeatureService(
        project_id=project_id,
        dataset_id=dataset_id,
        **kwargs
    )
    
    # 計算実行（同期または非同期）
    if async_execution:
        # 非同期実行の場合はイベントループで実行
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_statistical_moments_async(
                returns=returns,
                windows=windows,
                date_column=date_column,
                returns_column=returns_column
            )
        )
    else:
        # 同期実行
        return service.calculate_statistical_moments(
            returns=returns,
            windows=windows,
            date_column=date_column,
            returns_column=returns_column
        )

def calculate_returns_bq(
    prices: Union[pl.Series, pl.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    date_column: str = None,
    price_column: str = None,
    project_id: str = None,
    dataset_id: str = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    BigQueryを使用してリターンを計算
    
    Args:
        prices: 価格データ（Series または DataFrame）
        periods: 計算期間（整数または整数のリスト）
        method: 計算方法 ('arithmetic' または 'log')
        date_column: 日付カラム名（DataFrameの場合）
        price_column: 価格カラム名（DataFrameの場合）
        project_id: GCPプロジェクトID
        dataset_id: BigQueryデータセットID
        async_execution: 非同期実行するかどうか
        **kwargs: その他のBigQuery設定オプション
        
    Returns:
        リターンを含むPandas DataFrame
    
    Raises:
        ValidationError: 必要なパラメータが不足している場合
        BigQueryResourceError: BigQueryリソースエラーが発生した場合
        QueryExecutionError: クエリ実行中にエラーが発生した場合
    """
    # BigQuery要件確認
    check_bigquery_requirements()
    
    if project_id is None:
        project_id = GCP_PROJECT_ID

    if dataset_id is None:
        raise ValidationError("dataset_id must be specified")
    

    
    # サービス初期化
    service = BigQueryFeatureService(
        project_id=project_id,
        dataset_id=dataset_id,
        **kwargs
    )
    
    # 計算実行（同期または非同期）
    if async_execution:
        # 非同期実行の場合はイベントループで実行
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_returns_async(
                prices=prices,
                periods=periods,
                method=method,
                date_column=date_column,
                price_column=price_column
            )
        )
    else:
        # 同期実行
        return service.calculate_returns(
            prices=prices,
            periods=periods,
            method=method,
            date_column=date_column,
            price_column=price_column
        )

def calculate_moving_averages_bq(
    prices: Union[pl.Series, pl.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    date_column: str = None,
    price_column: str = None,
    project_id: str = None,
    dataset_id: str = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    BigQueryを使用して移動平均を計算
    
    Args:
        prices: 価格データ（Series または DataFrame）
        windows: 計算ウィンドウサイズ（整数または整数のリスト）
        date_column: 日付カラム名（DataFrameの場合）
        price_column: 価格カラム名（DataFrameの場合）
        project_id: GCPプロジェクトID
        dataset_id: BigQueryデータセットID
        async_execution: 非同期実行するかどうか
        **kwargs: その他のBigQuery設定オプション
        
    Returns:
        移動平均を含むPandas DataFrame
    
    Raises:
        ValidationError: 必要なパラメータが不足している場合
        BigQueryResourceError: BigQueryリソースエラーが発生した場合
        QueryExecutionError: クエリ実行中にエラーが発生した場合
    """
    # BigQuery要件確認
    check_bigquery_requirements()
    if dataset_id is None:
        raise ValidationError("dataset_id must be specified")
    
    # サービス初期化
    service = BigQueryFeatureService(
        project_id=project_id,
        dataset_id=dataset_id,
        **kwargs
    )
    
    # 計算実行（同期または非同期）
    if async_execution:
        # 非同期実行の場合はイベントループで実行
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_moving_averages_async(
                prices=prices,
                windows=windows,
                date_column=date_column,
                price_column=price_column
            )
        )
    else:
        # 同期実行時は通常の関数を呼び出す
        # ここで移動平均用の同期関数を実装する必要があるが、まだないので代替として非同期版を同期的に呼び出す
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            service.calculate_moving_averages_async(
                prices=prices,
                windows=windows,
                date_column=date_column,
                price_column=price_column
            )
        ) 