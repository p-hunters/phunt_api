import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict

# Import market_features functions using relative import
from .market_features import (
    calculate_returns,
    calculate_cross_currency_features,
    calculate_futures_features,
    calculate_market_turbulence,
    calculate_currency_strength_features,
    calculate_all_market_features,
)

# ==============================================================================
# Fixtures
# ==============================================================================

@pytest.fixture
def sample_dates():
    base_date = datetime(2024, 1, 1)
    return [base_date + timedelta(minutes=i) for i in range(100)]

@pytest.fixture
def sample_currency_data(sample_dates):
    np.random.seed(42)
    
    def generate_price_series(start_price: float = 1.0, volatility: float = 0.001):
        returns = np.random.normal(0, volatility, len(sample_dates))
        price = start_price * np.exp(np.cumsum(returns))
        return pd.Series(price, index=sample_dates)
    
    return {
        "EURUSD": generate_price_series(1.2),
        "GBPUSD": generate_price_series(1.5),
        "USDJPY": generate_price_series(110.0),
        "AUDUSD": generate_price_series(0.8),
        "XAUUSD": generate_price_series(2000.0),
    }

@pytest.fixture
def sample_futures_data(sample_dates):
    np.random.seed(42)
    
    def generate_futures_data(
        price_start: float = 100.0,
        price_vol: float = 0.001,
        volume_mean: float = 1000,
        volume_std: float = 100
    ):
        # Price series
        returns = np.random.normal(0, price_vol, len(sample_dates))
        price = price_start * np.exp(np.cumsum(returns))
        
        # Volume series
        volume = np.abs(np.random.normal(volume_mean, volume_std, len(sample_dates)))
        
        # Open interest series
        open_interest = np.cumsum(np.random.normal(0, 100, len(sample_dates))) + volume_mean * 10
        
        return {
            "price": pd.Series(price, index=sample_dates),
            "volume": pd.Series(volume, index=sample_dates),
            "open_interest": pd.Series(open_interest, index=sample_dates)
        }
    
    return {
        "E6": generate_futures_data(100.0),
        "VIX": generate_futures_data(15.0),
    }

# ==============================================================================
# Test Basic Return Calculations
# ==============================================================================

def test_calculate_returns():
    dates = pd.date_range(start="2024-01-01", periods=5, freq="D")
    prices = pd.Series([100, 102, 99, 103, 101], index=dates)
    
    returns = calculate_returns(prices, return_periods=[1, 2])
    
    assert isinstance(returns, pd.DataFrame)
    assert list(returns.columns) == ["ret_1", "ret_2"]
    assert len(returns) == len(prices)
    
    # 1期間リターンの検証
    expected_ret_1 = [np.nan, 0.02, -0.0294, 0.0404, -0.0194]
    np.testing.assert_array_almost_equal(
        returns["ret_1"].values,
        expected_ret_1,
        decimal=4
    )

# ==============================================================================
# Test Cross-Currency Features
# ==============================================================================

def test_cross_currency_features(sample_currency_data):
    features = calculate_cross_currency_features(
        sample_currency_data,
        base_currency="EURUSD",
        return_periods=[1, 5],
        correlation_window=10
    )
    
    assert isinstance(features, pd.DataFrame)
    
    # 基本的なカラム存在チェック
    expected_columns = [
        "EURUSD_ret_1", "EURUSD_ret_5",
        "GBPUSD_ret_1", "GBPUSD_ret_5",
        "GBPUSD_corr_EURUSD_10"
    ]
    for col in expected_columns:
        assert col in features.columns

def test_cross_currency_features_invalid_base(sample_currency_data):
    with pytest.raises(ValueError, match="Base currency 'INVALID' not found"):
        calculate_cross_currency_features(
            sample_currency_data,
            base_currency="INVALID"
        )

# ==============================================================================
# Test Futures Features
# ==============================================================================

def test_futures_features(sample_futures_data):
    features = calculate_futures_features(
        sample_futures_data,
        return_periods=[1, 5],
        volume_ma_windows=[5],
        volatility_windows=[10]
    )
    
    assert isinstance(features, pd.DataFrame)
    
    # 基本的なカラム存在チェック
    for future in ["E6", "VIX"]:
        expected_columns = [
            f"{future}_ret_1",
            f"{future}_ret_5",
            f"{future}_volume_ma_5",
            f"{future}_volume_ratio_5",
            f"{future}_oi_ma_5",
            f"{future}_oi_ratio_5",
            f"{future}_volatility_10"
        ]
        for col in expected_columns:
            assert col in features.columns

def test_futures_features_missing_price(sample_futures_data):
    del sample_futures_data["E6"]["price"]
    
    with pytest.raises(ValueError, match="No 'price' series found"):
        calculate_futures_features(sample_futures_data)

# ==============================================================================
# Test Market Turbulence
# ==============================================================================

def test_market_turbulence(sample_currency_data):
    turbulence = calculate_market_turbulence(
        sample_currency_data,
        window=10,
        chunk_size=20
    )
    
    assert isinstance(turbulence, pd.Series)
    # turbulenceはwindow分のNaNを含むため、長さは入力と同じになる
    assert len(turbulence) == len(next(iter(sample_currency_data.values())))
    # 最初のwindow-1分はNaN
    assert turbulence.iloc[:10].isna().all()
    # window以降は計算される
    assert not turbulence.iloc[10:].isna().all()

# ==============================================================================
# Test Currency Strength Features
# ==============================================================================

def test_currency_strength_features(sample_currency_data):
    features = calculate_currency_strength_features(
        sample_currency_data,
        base_value_index=0,
        fill_method="ffill",
        combine_groups=True,
        n_jobs=2
    )
    
    assert isinstance(features, pd.DataFrame)
    
    # 個別通貨の強度
    expected_currencies = ["EUR", "USD", "GBP", "JPY", "AUD", "XAU"]
    for curr in expected_currencies:
        assert f"{curr}_strength" in features.columns
    
    # グループ強度（存在する通貨の組み合わせのみ）
    available_groups = {
        "EUROPE_strength": ["EUR", "GBP"],
        "RISK_OFF_strength": ["JPY"],  # CHFがないため部分的なグループ
        "OCEANIA_strength": ["AUD"],   # NZDがないため部分的なグループ
    }
    
    for group, currencies in available_groups.items():
        if all(f"{curr}_strength" in features.columns for curr in currencies):
            assert group in features.columns

def test_currency_strength_features_no_groups(sample_currency_data):
    features = calculate_currency_strength_features(
        sample_currency_data,
        combine_groups=False
    )
    
    assert "AMERICA_strength" not in features.columns

# ==============================================================================
# Test All Market Features
# ==============================================================================

def test_calculate_all_market_features(sample_currency_data, sample_futures_data):
    features = calculate_all_market_features(
        currency_data=sample_currency_data,
        futures_data=sample_futures_data,
        base_currency="EURUSD",
        return_periods=[1, 5],
        correlation_window=10,
        volume_ma_windows=[5],
        volatility_windows=[10],
        turbulence_window=10,
        turbulence_chunk_size=20,
        currency_strength_kwargs={"combine_groups": True, "n_jobs": 2}
    )
    
    assert isinstance(features, pd.DataFrame)
    
    # 各機能のカラムが存在することを確認
    column_checks = {
        "Cross-currency": ["GBPUSD_ret_1", "GBPUSD_corr_EURUSD_10"],
        "Currency strength": ["USD_strength", "EUR_strength"],  # 基本的な通貨強度のみチェック
        "Futures": ["E6_volume_ma_5", "E6_volatility_10"],     # VIXは除外（サンプルデータにない）
        "Turbulence": ["market_turbulence"]
    }
    
    for feature_type, columns in column_checks.items():
        for col in columns:
            assert col in features.columns, f"Missing {feature_type} feature: {col}"

def test_calculate_all_market_features_invalid_data():
    invalid_currency_data = {
        "EURUSD": pd.Series([1.0, 2.0]),
        "GBPUSD": pd.Series([1.0, 2.0, 3.0])  # Different length
    }
    
    with pytest.raises(ValueError, match="same index"):
        calculate_all_market_features(
            currency_data=invalid_currency_data,
            futures_data={}
        )

# ==============================================================================
# Test Edge Cases and Error Handling
# ==============================================================================

def test_empty_data():
    with pytest.raises(ValueError):
        calculate_all_market_features({}, {})

def test_single_currency_pair(sample_dates):
    single_pair = {
        "EURUSD": pd.Series(np.random.random(100), index=sample_dates)
    }
    
    features = calculate_all_market_features(
        currency_data=single_pair,
        futures_data={},
        base_currency="EURUSD"
    )
    
    assert isinstance(features, pd.DataFrame)
    assert "EURUSD_ret_1" in features.columns

def test_non_series_input():
    invalid_data = {
        "EURUSD": [1.0, 2.0]  # リストは不可
    }
    
    with pytest.raises(ValueError, match="must be pandas Series"):
        calculate_all_market_features(
            currency_data=invalid_data,
            futures_data={}
        ) 