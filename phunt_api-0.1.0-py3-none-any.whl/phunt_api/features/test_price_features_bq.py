import pytest
import numpy as np
import pandas as pd
import polars as pl
from datetime import datetime, timedelta
import os
import sys

# Check if google-cloud-bigquery is installed
try:
    from unittest.mock import patch, MagicMock
    from phunt_api.features.price_features_polars import (
        calculate_statistical_moments as pl_calculate_statistical_moments
    )
    from phunt_api.features.price_features_bq import (
        calculate_statistical_moments_bq,
        BigQueryFeatureService,
        BIGQUERY_AVAILABLE
    )
    from phunt_api.misc.bq import (
        BigQueryConfig,
        BigQueryTableManager,
        BigQueryDataFetcher,
        ValidationError
    )
except ImportError:
    BIGQUERY_AVAILABLE = False
    print("Warning: google-cloud-bigquery is not installed. Some tests will be skipped.")

# Skip the entire module if BigQuery is not available
pytestmark = pytest.mark.skipif(
    not BIGQUERY_AVAILABLE,
    reason="BigQuery libraries not installed"
)

# =============================================================================
#  Test Configuration
# =============================================================================

# Set this to True to run integration tests with actual BigQuery
# This requires proper GCP credentials and permissions
RUN_BQ_INTEGRATION_TESTS = os.environ.get("RUN_BQ_INTEGRATION_TESTS", "False").lower() == "true"

# Test project and dataset for integration tests
TEST_PROJECT_ID = os.environ.get("TEST_BQ_PROJECT_ID", "test-project-id")
TEST_DATASET_ID = os.environ.get("TEST_BQ_DATASET_ID", "test_dataset")

# Skip mark for BigQuery integration tests
bq_integration = pytest.mark.skipif(
    not RUN_BQ_INTEGRATION_TESTS,
    reason="BigQuery integration tests are disabled"
)

# =============================================================================
#  Test Fixtures
# =============================================================================

@pytest.fixture
def sample_returns_series():
    """Create a sample returns series for testing."""
    np.random.seed(42)  # For reproducibility
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    # Generate synthetic returns with some autocorrelation
    returns = np.random.randn(len(dates)) * 0.01
    return pl.Series("returns", returns)


@pytest.fixture
def sample_returns_df():
    """Create a sample returns DataFrame with date column for testing."""
    np.random.seed(42)  # For reproducibility
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    # Generate synthetic returns with some autocorrelation
    returns = np.random.randn(len(dates)) * 0.01
    
    return pl.DataFrame({
        "date": [d.date() for d in dates],
        "returns": returns
    })


@pytest.fixture
def mock_bq_client():
    """Create a mock BigQuery client for testing."""
    # Create the mock using patch only if BigQuery is available
    if BIGQUERY_AVAILABLE:
        with patch('google.cloud.bigquery.Client') as mock_client:
            # Set up the query job mock
            mock_query_job = MagicMock()
            
            # Set up the to_dataframe method to return test data
            def side_effect_func(*args, **kwargs):
                """
                Handle different test queries.
                Note: This function is now called without query argument directly,
                but the query is available in the mock_client.query call.
                """
                # Create test data based on query
                # Get the query from the most recent call to query
                call_args = mock_client.return_value.query.call_args
                if call_args:
                    query = call_args[0][0]  # First positional argument to query()
                else:
                    # Default query parameters if can't extract
                    query = ""
                
                # Parse the window size from the query
                import re
                window_match = re.search(r'ROWS BETWEEN (\d+) PRECEDING', query)
                window = int(window_match.group(1)) + 1 if window_match else 20
                
                # Detect date column name from query
                date_col = "date"
                if "timestamp" in query:
                    date_col = "timestamp"
                elif "row_id" in query:
                    date_col = "row_id"
                
                # Create test data based on window size
                dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
                n = len(dates)
                
                # Generate sample statistics that somewhat resemble real stats
                data = {
                    date_col: dates,
                    f'rolling_mean_{window}': np.random.randn(n) * 0.001,
                    f'rolling_var_{window}': np.abs(np.random.randn(n) * 0.0001),
                    f'rolling_skew_{window}': np.random.randn(n) * 0.5,
                    f'rolling_kurt_{window}': np.random.randn(n) * 2 + 3,
                    f'rolling_jb_{window}': np.abs(np.random.randn(n) * 10)
                }
                
                # Set NaN values for the initial rows to simulate proper windowing
                # 安全のため、window サイズが n より大きい場合は調整
                nan_rows = min(window - 1, n - 1)  # 少なくとも1行のデータは残す
                
                for col in data.keys():
                    if col != date_col:
                        for i in range(nan_rows):
                            data[col][i] = np.nan
                
                return pd.DataFrame(data)
            
            # Apply the side effect to to_dataframe method
            mock_query_job.to_dataframe.side_effect = side_effect_func
            mock_client.return_value.query.return_value = mock_query_job
            
            # Mock load job for loading data to BigQuery
            mock_load_job = MagicMock()
            mock_client.return_value.load_table_from_dataframe.return_value = mock_load_job
            
            yield mock_client
    else:
        # Just yield None if BigQuery is not available
        yield None


# =============================================================================
#  Unit Tests with Mocks
# =============================================================================

def test_calculate_statistical_moments_bq_with_series(sample_returns_series, mock_bq_client):
    """Test statistical moments calculation with a Series using mocked BigQuery."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
        
    # Configure mocked client
    windows = [20, 60]
    
    # Call the function with the mocked client
    with patch('phunt_api.misc.bq.bigquery.Client', mock_bq_client):
        moments_df = calculate_statistical_moments_bq(
            returns=sample_returns_series,
            windows=windows,
            project_id=TEST_PROJECT_ID,
            dataset_id=TEST_DATASET_ID
        )
    
    # Verify the results structure
    expected_cols = []
    for window in windows:
        expected_cols.extend([
            f'rolling_mean_{window}',
            f'rolling_var_{window}',
            f'rolling_skew_{window}',
            f'rolling_kurt_{window}',
            f'rolling_jb_{window}'
        ])
    
    for col in expected_cols:
        assert col in moments_df.columns, f"Column {col} missing from results"
    
    # Basic sanity checks on the data
    for window in windows:
        mean_col = f'rolling_mean_{window}'
        var_col = f'rolling_var_{window}'
        
        # Means and variances should be finite after initial window
        non_nan_means = moments_df[window:][mean_col].to_numpy()
        non_nan_vars = moments_df[window:][var_col].to_numpy()
        
        assert np.all(np.isfinite(non_nan_means)), f"Non-finite values in {mean_col}"
        assert np.all(np.isfinite(non_nan_vars)), f"Non-finite values in {var_col}"
        assert np.all(non_nan_vars >= 0), f"Negative variances in {var_col}"


def test_calculate_statistical_moments_bq_with_df(sample_returns_df, mock_bq_client):
    """Test statistical moments calculation with a DataFrame using mocked BigQuery."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
        
    # Configure mocked client
    windows = [20, 60]
    
    # Call the function with the mocked client
    with patch('phunt_api.misc.bq.bigquery.Client', mock_bq_client):
        moments_df = calculate_statistical_moments_bq(
            returns=sample_returns_df,
            windows=windows,
            project_id=TEST_PROJECT_ID,
            dataset_id=TEST_DATASET_ID,
            date_column="date",
            returns_column="returns"
        )
    
    # Verify the results structure
    expected_cols = ['date']
    for window in windows:
        expected_cols.extend([
            f'rolling_mean_{window}',
            f'rolling_var_{window}',
            f'rolling_skew_{window}',
            f'rolling_kurt_{window}',
            f'rolling_jb_{window}'
        ])
    
    for col in expected_cols:
        assert col in moments_df.columns, f"Column {col} missing from results"
    
    assert len(moments_df) == len(sample_returns_df)
    
    # Verify date column is preserved
    assert 'date' in moments_df.columns


def test_error_handling(sample_returns_series):
    """Test error handling for missing required parameters."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
        
    # Test missing project_id
    with pytest.raises(ValidationError, match="project_id must be specified"):
        calculate_statistical_moments_bq(
            returns=sample_returns_series,
            dataset_id=TEST_DATASET_ID,
            project_id=None
        )
    
    # Test missing dataset_id
    with pytest.raises(ValidationError, match="dataset_id must be specified"):
        calculate_statistical_moments_bq(
            returns=sample_returns_series,
            project_id=TEST_PROJECT_ID,
            dataset_id=None
        )


def test_automatic_column_detection(mock_bq_client):
    """Test automatic detection of date and returns columns."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
        
    # Create a DataFrame with differently named columns
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    returns = np.random.randn(len(dates)) * 0.01
    
    df = pl.DataFrame({
        "timestamp": [d.date() for d in dates],
        "daily_return": returns
    })
    
    # Call the function with the mocked client without specifying column names
    with patch('phunt_api.misc.bq.bigquery.Client', mock_bq_client):
        moments_df = calculate_statistical_moments_bq(
            returns=df,
            windows=[20],
            project_id=TEST_PROJECT_ID,
            dataset_id=TEST_DATASET_ID
        )
    
    # Verify correct columns were used
    assert "timestamp" in moments_df.columns, "Automatic detection of date column failed"
    assert "rolling_mean_20" in moments_df.columns, "Mean column missing from results"


# =============================================================================
#  Integration Tests with Actual BigQuery
# =============================================================================

@bq_integration
def test_bq_feature_service_integration():
    """Integration test for BigQueryFeatureService."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
        
    # Create a test DataFrame
    df = pl.DataFrame({
        "date": [datetime(2024, 1, i).date() for i in range(1, 11)],
        "value": np.random.randn(10)
    })
    
    # Initialize the service
    service = BigQueryFeatureService(
        project_id=TEST_PROJECT_ID,
        dataset_id=TEST_DATASET_ID
    )
    
    try:
        # Test table management
        with service.table_manager as manager:
            # Create a temporary table
            table_id = manager.create_temp_table_id("test_data")
            
            # Load the DataFrame to the table
            manager.load_dataframe(df, table_id)
            
            # Execute a simple test query
            query = f"""
            SELECT 
                date, 
                value,
                AVG(value) OVER(ORDER BY date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS rolling_mean
            FROM `{table_id}`
            ORDER BY date
            """
            
            result_df = service.data_fetcher.execute_query_to_polars(query)
            
            # Verify the result
            assert "date" in result_df.columns
            assert "value" in result_df.columns
            assert "rolling_mean" in result_df.columns
            assert len(result_df) == len(df)
    
    except Exception as e:
        # This ensures we get the actual error rather than the fixture's cleanup errors
        pytest.fail(f"Integration test failed: {str(e)}")


@bq_integration
def test_statistical_moments_integration(sample_returns_df):
    """Integration test for calculate_statistical_moments_bq with actual BigQuery."""
    # Skip test if BigQuery is not available
    if not BIGQUERY_AVAILABLE:
        pytest.skip("BigQuery is not available")
    
    try:
        # Call the actual function
        result_df = calculate_statistical_moments_bq(
            returns=sample_returns_df,
            windows=[5],  # Use a small window size for quick testing
            date_column="date",
            returns_column="returns",
            project_id=TEST_PROJECT_ID,
            dataset_id=TEST_DATASET_ID
        )
        
        # Check basic structure
        assert "date" in result_df.columns
        assert "rolling_mean_5" in result_df.columns
        assert "rolling_var_5" in result_df.columns
        assert "rolling_skew_5" in result_df.columns
        assert "rolling_kurt_5" in result_df.columns
        assert "rolling_jb_5" in result_df.columns
        
        # Basic validation of values
        assert len(result_df) == len(sample_returns_df)
        
        # First n-1 rows should have NaNs for a window of n
        assert result_df["rolling_mean_5"][:4].null_count() == 4
        
        # Remaining values should be finite
        assert pl.col("rolling_mean_5").is_finite().sum().to_numpy() >= len(sample_returns_df) - 4
        
        # Variances should be non-negative
        non_nan_vars = result_df.filter(pl.col("rolling_var_5").is_not_null())["rolling_var_5"]
        assert (non_nan_vars >= 0).all()
    
    except Exception as e:
        pytest.fail(f"Integration test failed: {str(e)}")


if __name__ == "__main__":
    if not BIGQUERY_AVAILABLE:
        print("BigQuery libraries not installed. Please install google-cloud-bigquery package.")
        sys.exit(1)
        
    # If run directly, use pytest to execute the tests
    import sys
    sys.exit(pytest.main(["-xvs", __file__])) 