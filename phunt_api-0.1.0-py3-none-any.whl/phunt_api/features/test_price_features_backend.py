"""
統一Price Features APIのテスト

このモジュールは、統一されたPrice Features APIが意図通りに動作することを検証するテストを含みます。
"""

import pytest
import pandas as pd
import polars as pl
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Union, Optional

# 統一APIをインポート
try:
    from phunt_api.features import (
        calculate_returns,
        calculate_moving_averages,
        calculate_statistical_moments,
        PriceFeatureBackend
    )
except ImportError:
    # インポートパスが異なる場合（例：直接実行時）
    from src.phunt_api.features import (
        calculate_returns,
        calculate_moving_averages,
        calculate_statistical_moments,
        PriceFeatureBackend
    )

# バックエンド固有のアダプターをインポート
try:
    from phunt_api.features.price_features._adapters.pandas_adapter import calculate_returns_pandas
    from phunt_api.features.price_features._adapters.polars_adapter import calculate_returns_polars
except ImportError:
    # インポートパスが異なる場合（例：直接実行時）
    from src.phunt_api.features.price_features._adapters.pandas_adapter import calculate_returns_pandas
    from src.phunt_api.features.price_features._adapters.polars_adapter import calculate_returns_polars

# DuckDBとBigQueryは環境によって利用できない場合があるため、条件付きインポート
DUCKDB_AVAILABLE = False
BIGQUERY_AVAILABLE = False

try:
    from phunt_api.features.price_features._adapters.duckdb_adapter import calculate_returns_duckdb
    DUCKDB_AVAILABLE = True
except ImportError:
    try:
        from src.phunt_api.features.price_features._adapters.duckdb_adapter import calculate_returns_duckdb
        DUCKDB_AVAILABLE = True
    except ImportError:
        pass

try:
    from phunt_api.features.price_features._adapters.bigquery_adapter import calculate_returns_bigquery
    BIGQUERY_AVAILABLE = True
except ImportError:
    try:
        from src.phunt_api.features.price_features._adapters.bigquery_adapter import calculate_returns_bigquery
        BIGQUERY_AVAILABLE = True
    except ImportError:
        pass

# ========================================
# フィクスチャー
# ========================================

@pytest.fixture
def sample_pandas_series():
    """テスト用のpandas Series"""
    return pd.Series(
        data=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        index=pd.date_range(start='2023-01-01', periods=10)
    )

@pytest.fixture
def sample_polars_series():
    """テスト用のpolars Series"""
    return pl.Series(
        values=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        name="price"
    )

@pytest.fixture
def sample_pandas_dataframe():
    """テスト用のpandas DataFrame"""
    dates = pd.date_range(start='2023-01-01', periods=10)
    return pd.DataFrame({
        'date': dates,
        'price': np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105])
    })

@pytest.fixture
def sample_polars_dataframe():
    """テスト用のpolars DataFrame"""
    return pl.DataFrame({
        'date': pl.date_range(
            start=datetime(2023, 1, 1),
            end=datetime(2023, 1, 10),
            interval="1d"
        ),
        'price': np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105])
    })

# ========================================
# バックエンド選択テスト
# ========================================

def test_backend_selection(sample_pandas_series):
    """バックエンド選択が正しく機能することをテスト"""
    # デフォルトはpandasバックエンド
    result_default = calculate_returns(sample_pandas_series, periods=[1])
    assert isinstance(result_default, pd.DataFrame)
    
    # 明示的にpandasバックエンドを指定
    result_pandas = calculate_returns(
        sample_pandas_series, periods=[1], backend="pandas"
    )
    assert isinstance(result_pandas, pd.DataFrame)
    
    # polarsバックエンドを指定
    result_polars = calculate_returns(
        sample_pandas_series, periods=[1], backend="polars"
    )
    assert isinstance(result_polars, pl.DataFrame)
    
    # 無効なバックエンドを指定するとエラー
    with pytest.raises(ValueError):
        calculate_returns(sample_pandas_series, periods=[1], backend="invalid")

# ========================================
# 入出力データ形式テスト
# ========================================

def test_input_format_conversion(sample_pandas_series, sample_polars_series):
    """入力フォーマットの自動変換をテスト"""
    # pandas入力、pandasバックエンド
    result1 = calculate_returns(
        sample_pandas_series, periods=[1], backend="pandas"
    )
    assert isinstance(result1, pd.DataFrame)
    
    # polars入力、pandasバックエンド（入力が自動変換される）
    result2 = calculate_returns(
        sample_polars_series, periods=[1], backend="pandas"
    )
    assert isinstance(result2, pd.DataFrame)
    
    # pandas入力、polarsバックエンド（入力が自動変換される）
    result3 = calculate_returns(
        sample_pandas_series, periods=[1], backend="polars"
    )
    assert isinstance(result3, pl.DataFrame)
    
    # polars入力、polarsバックエンド
    result4 = calculate_returns(
        sample_polars_series, periods=[1], backend="polars"
    )
    assert isinstance(result4, pl.DataFrame)

def test_output_format_specification(sample_pandas_series, sample_polars_series):
    """出力フォーマットの指定をテスト"""
    # pandas入力、出力をpolarsに指定
    result1 = calculate_returns(
        sample_pandas_series, periods=[1], output_format="polars"
    )
    assert isinstance(result1, pl.DataFrame)
    
    # polars入力、出力をpandasに指定
    result2 = calculate_returns(
        sample_polars_series, periods=[1], output_format="pandas"
    )
    assert isinstance(result2, pd.DataFrame)
    
    # 無効な出力フォーマットを指定するとエラー
    with pytest.raises(ValueError):
        calculate_returns(
            sample_pandas_series, periods=[1], output_format="invalid"
        )

def test_input_output_match():
    """入力に合わせて出力フォーマットが自動選択されることをテスト"""
    # pandasデータ作成
    pandas_data = pd.Series([100, 102, 104, 106, 108])
    
    # polarsデータ作成
    polars_data = pl.Series([100, 102, 104, 106, 108])
    
    # pandas入力の場合は出力もpandas
    pandas_result = calculate_returns(pandas_data, periods=[1])
    assert isinstance(pandas_result, pd.DataFrame)
    
    # polars入力の場合は出力もpolars
    polars_result = calculate_returns(polars_data, periods=[1])
    assert isinstance(polars_result, pl.DataFrame)

# ========================================
# PriceFeatureBackendクラステスト
# ========================================

def test_backend_class():
    """PriceFeatureBackendクラスが正しく動作することをテスト"""
    # テストデータ
    data = pd.Series([100, 102, 104, 106, 108])
    
    # backendクラスのインスタンス化
    backend = PriceFeatureBackend(
        backend="polars",
        output_format="pandas"
    )
    
    # バックエンドを再利用して複数の計算
    returns_df = backend.calculate_returns(data, periods=[1, 2])
    assert isinstance(returns_df, pd.DataFrame)
    
    ma_df = backend.calculate_moving_averages(data, windows=[2, 3])
    assert isinstance(ma_df, pd.DataFrame)
    
    # 不正なバックエンドを指定するとエラー
    with pytest.raises(ValueError):
        PriceFeatureBackend(backend="invalid")
    
    # 不正な出力フォーマットを指定するとエラー
    with pytest.raises(ValueError):
        PriceFeatureBackend(output_format="invalid")

# ========================================
# 計算結果の一貫性テスト
# ========================================

def test_returns_calculation_consistency():
    """各バックエンドでのリターン計算結果が一貫していることをテスト"""
    # テストデータ
    prices = np.array([100, 102, 104, 103, 105])
    pandas_prices = pd.Series(prices)
    polars_prices = pl.Series(prices)
    
    # バックエンドごとの計算
    returns_pandas = calculate_returns(
        pandas_prices, periods=[1], backend="pandas", output_format="pandas"
    )
    returns_polars = calculate_returns(
        polars_prices, periods=[1], backend="polars", output_format="pandas"
    )
    
    # 各バックエンドの結果を比較
    pd.testing.assert_frame_equal(
        returns_pandas, returns_polars, check_dtype=False
    )

def test_moving_averages_calculation_consistency():
    """各バックエンドでの移動平均計算結果が一貫していることをテスト"""
    # テストデータ
    prices = np.array([100, 102, 104, 103, 105])
    pandas_prices = pd.Series(prices)
    polars_prices = pl.Series(prices)
    
    # バックエンドごとの計算
    ma_pandas = calculate_moving_averages(
        pandas_prices, windows=[3], backend="pandas", output_format="pandas"
    )
    ma_polars = calculate_moving_averages(
        polars_prices, windows=[3], backend="polars", output_format="pandas"
    )
    
    # 各バックエンドの結果を比較
    pd.testing.assert_frame_equal(
        ma_pandas, ma_polars, check_dtype=False
    )

# ========================================
# DuckDBバックエンドテスト（オプショナル）
# ========================================

@pytest.mark.skipif(not DUCKDB_AVAILABLE, reason="DuckDB is not installed")
def test_duckdb_backend(sample_pandas_dataframe):
    """DuckDBバックエンドの動作確認（DuckDBがインストールされている場合のみ実行）"""
    # DuckDBバックエンドでリターン計算
    returns_df = calculate_returns(
        sample_pandas_dataframe,
        periods=[1],
        date_column="date",
        price_column="price",
        backend="duckdb",
        memory_db=True
    )
    
    assert isinstance(returns_df, pd.DataFrame)
    assert "return_1" in returns_df.columns

# ========================================
# BigQueryバックエンドテスト（オプショナル）
# ========================================

@pytest.mark.skipif(not BIGQUERY_AVAILABLE, reason="BigQuery is not installed")
def test_bigquery_backend(sample_pandas_dataframe):
    """BigQueryバックエンドの動作確認（BigQueryがインストールされている場合のみ実行）"""
    # テストは環境変数やGCPプロジェクト設定に依存するため複雑
    # 実際の場合はモックを使用するか、実行環境を適切に設定する必要がある
    pass

# =============================================================================
# バックエンド一貫性検証ユーティリティ
# =============================================================================

def validate_dataframe_consistency(
    dataframes: Dict[str, pd.DataFrame],
    expected_columns: List[str],
    expected_rows: Optional[int] = None,
    tolerance: float = 1e-10
) -> Dict[str, Any]:
    """
    複数のバックエンドから返されたDataFrameの一貫性を検証する

    Args:
        dataframes: バックエンド名をキー、DataFrameを値とする辞書
        expected_columns: 期待されるカラム名のリスト
        expected_rows: 期待される行数（指定がなければチェックしない）
        tolerance: 数値比較の許容誤差

    Returns:
        検証結果を含む辞書
    """
    results = {
        "is_consistent": True,
        "issues": [],
        "row_counts": {},
        "column_consistency": {},
        "value_consistency": {}
    }

    # 各DataFrameをチェック
    for backend, df in dataframes.items():
        # 行数チェック
        row_count = len(df)
        results["row_counts"][backend] = row_count
        
        if expected_rows is not None and row_count != expected_rows:
            results["is_consistent"] = False
            results["issues"].append(f"{backend}: 行数が期待値と異なる ({row_count} vs {expected_rows})")
        
        # カラム存在チェック
        for col in expected_columns:
            if col not in df.columns:
                results["is_consistent"] = False
                results["issues"].append(f"{backend}: 期待される列 '{col}' が存在しない")
    
    # バックエンド間での値の一貫性チェック
    reference_backend = list(dataframes.keys())[0]
    reference_df = dataframes[reference_backend]
    
    for backend, df in dataframes.items():
        if backend == reference_backend:
            continue
            
        # 共通カラムのみを比較
        common_cols = [col for col in expected_columns if col in df.columns and col in reference_df.columns]
        
        for col in common_cols:
            # 各カラムのNull値でない行について比較
            both_valid_mask = ~reference_df[col].isna() & ~df[col].isna()
            
            if both_valid_mask.sum() > 0:
                ref_values = reference_df.loc[both_valid_mask, col].values
                curr_values = df.loc[both_valid_mask, col].values
                
                if len(ref_values) == len(curr_values):
                    # 値の差の最大値を計算
                    max_diff = np.max(np.abs(ref_values - curr_values))
                    
                    # 一貫性のある値かチェック
                    is_consistent = max_diff <= tolerance
                    results["value_consistency"][(backend, col)] = is_consistent
                    
                    if not is_consistent:
                        results["is_consistent"] = False
                        results["issues"].append(
                            f"{backend}: '{col}' の値が {reference_backend} と一致しない (最大差: {max_diff})"
                        )
    
    return results

def test_backend_consistency(sample_pandas_dataframe):
    """バックエンド間の一貫性をテスト"""
    # テスト対象の期間
    periods = [1, 5]
    
    # 各バックエンドでリターン計算
    results = {}
    
    # Pandas バックエンド
    results["pandas"] = calculate_returns(
        sample_pandas_dataframe,
        periods=periods,
        date_column="date",
        price_column="price",
        backend="pandas"
    )
    
    # Polars バックエンド
    results["polars"] = calculate_returns(
        sample_pandas_dataframe,
        periods=periods,
        date_column="date",
        price_column="price",
        backend="polars",
        output_format="pandas"
    )
    
    # DuckDB バックエンド (利用可能な場合)
    if DUCKDB_AVAILABLE:
        results["duckdb"] = calculate_returns(
            sample_pandas_dataframe,
            periods=periods,
            date_column="date",
            price_column="price",
            backend="duckdb",
            memory_db=True
        )
    
    # 結果の一貫性を検証
    expected_columns = [f"return_{p}" for p in periods]
    validation = validate_dataframe_consistency(
        dataframes=results,
        expected_columns=expected_columns,
        expected_rows=len(sample_pandas_dataframe)
    )
    
    # 検証結果を確認
    assert validation["is_consistent"], f"バックエンド間で結果が一致しません: {validation['issues']}"
    
    # 各バックエンドの行数が一致することを確認
    row_counts = list(validation["row_counts"].values())
    assert all(count == row_counts[0] for count in row_counts), "バックエンド間で行数が異なります"
    
    # すべてのバックエンドが期待されるカラムを含むことを確認
    for backend, df in results.items():
        for col in expected_columns:
            assert col in df.columns, f"{backend} バックエンドには列 '{col}' がありません"

def create_test_df():
    """簡単なテスト用データを作成"""
    import pandas as pd
    import numpy as np
    from datetime import datetime, timedelta
    
    # 日付インデックスの作成
    dates = [datetime(2023, 1, 1) + timedelta(minutes=i) for i in range(100)]
    
    # ランダムな価格データ
    data = {
        'date': dates,
        'close': np.cumsum(np.random.normal(0, 1, 100)) + 100,
        'open': np.cumsum(np.random.normal(0, 1, 100)) + 100,
        'high': np.cumsum(np.random.normal(0, 1, 100)) + 102,
        'low': np.cumsum(np.random.normal(0, 1, 100)) + 98,
        'volume': np.random.randint(100, 1000, 100)
    }
    
    return pd.DataFrame(data)

def test_backends_with_synthetic_data():
    """合成データを使用してバックエンド間の一貫性をテスト"""
    # テストデータ作成
    test_df = create_test_df()
    test_series = test_df['close']
    
    # テスト設定
    periods = [2, 5]
    
    # 各バックエンドでリターン計算
    results = {}
    
    # Pandas バックエンド
    results["pandas"] = calculate_returns(
        test_series, 
        periods=periods, 
        backend="pandas"
    )
    
    # Polars バックエンド
    results["polars"] = calculate_returns(
        test_series,
        periods=periods,
        backend="polars",
        output_format="pandas"
    )
    
    # DuckDB バックエンド
    if DUCKDB_AVAILABLE:
        results["duckdb"] = calculate_returns(
            test_series,
            periods=periods,
            backend="duckdb",
            memory_db=True
        )
    
    # 一貫性検証
    expected_columns = [f"return_{p}" for p in periods]
    validation_results = validate_dataframe_consistency(
        dataframes=results,
        expected_columns=expected_columns
    )
    
    # 結果表示
    print("\nテスト結果:")
    print(f"一貫性検証結果: {'成功' if validation_results['is_consistent'] else '失敗'}")
    
    if not validation_results["is_consistent"]:
        for issue in validation_results["issues"]:
            print(f"- {issue}")
    
    print("\n行数:")
    for backend, count in validation_results["row_counts"].items():
        print(f"- {backend}: {count} 行")
    
    # サンプル表示
    for backend, df in results.items():
        print(f"\n{backend} 結果 (先頭5行):")
        print(df.head())
    
    return validation_results["is_consistent"]

def test_minimal(df):
    """最小限のテストケース"""
    # 最小限のテストデータを作成
    import pandas as pd
    import numpy as np
    import sys
    
    # サンプルデータ
    prices = df.close
    
    # Pandasバックエンド
    print("\nTesting pandas backend:")
    result1 = calculate_returns(prices, periods=[2, 5], backend="pandas")
    print(result1)
    
    # Polarsバックエンド
    print("\nTesting polars backend:")
    result2 = calculate_returns(prices, periods=[2, 5], backend="polars", output_format="pandas")
    print(result2)
    
    # DuckDBバックエンド（利用可能な場合）
    if DUCKDB_AVAILABLE:
        try:
            print("\nTesting duckdb backend:")
            result3 = calculate_returns(prices, periods=[2, 5], backend="duckdb", memory_db=True)
            print(result3)

            # BigQueryバックエンド（利用可能な場合）
            if BIGQUERY_AVAILABLE:
                print("\nTesting bigquery backend:")
                result4 = calculate_returns(prices, periods=[2, 5], backend="bigquery")
                print(result4)
            
            # 3つのバックエンドの一貫性を確認
            results = {
                "pandas": result1,
                "polars": result2,
                "duckdb": result3,
                "bigquery": result4
            }
        except Exception as e:
            import traceback
            print(f"\nDuckDBバックエンドでエラー発生: {e}")
            traceback.print_exc()
            results = {
                "pandas": result1,
                "polars": result2
            }
    else:
        results = {
            "pandas": result1,
            "polars": result2
        }
    
    # 結果の一貫性を確認
    print("\nValidating consistency between backends:")
    validation_results = validate_dataframe_consistency(
        dataframes=results,
        expected_columns=["return_2", "return_5"]
    )
    
    print(f"一貫性検証結果: {'成功' if validation_results['is_consistent'] else '失敗'}")
    for issue in validation_results["issues"]:
        print(f"- {issue}")
    
    return validation_results["is_consistent"]

if __name__ == "__main__":
    from phunt_api import PHuntAPI
    # Create sample data
    api = PHuntAPI(debug=True) 
    # login成功するとbigqueryが使えるようになる.
    api.login(p12_path="/Users/shin/workspace/MT4_ARB/phunt/client.p12", p12_password="aaa")

    df = api.get_dataset('EURUSD_1MIN_2024')

    import sys
    print("最小限のバックエンドテストを実行中...")
    is_consistent = test_minimal(df)
    
    if is_consistent:
        print("\n✅ テスト成功: すべてのバックエンドで一貫した結果が得られました。")
    else:
        print("\n❌ テスト失敗: バックエンド間で結果に不整合があります。")
    
    sys.exit(0 if is_consistent else 1) 