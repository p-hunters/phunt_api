"""
Adapter factory for price features backends

This module provides factory functions that select the appropriate adapter based on the requested backend.
"""

from typing import Callable, Any, Dict, Union, List

import pandas as pd
import polars as pl

from .pandas_adapter import (
    calculate_returns_pandas,
    calculate_moving_averages_pandas,
    calculate_statistical_moments_pandas,
)

from .polars_adapter import (
    calculate_returns_polars,
    calculate_moving_averages_polars,
    calculate_statistical_moments_polars,
)

from .bigquery_adapter import (
    calculate_returns_bigquery,
    calculate_moving_averages_bigquery,
    calculate_statistical_moments_bigquery,
)

from .duckdb_adapter import (
    calculate_returns_duckdb,
    calculate_moving_averages_duckdb,
    calculate_statistical_moments_duckdb,
)

def calculate_returns_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]],
    method: str,
    date_column: str,
    price_column: str,
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate returns calculation adapter based on the backend.
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (only for DataFrame inputs)
        price_column: Column name for price (only for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated returns using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_returns_pandas(prices, periods, method, **backend_options)
    elif backend == "polars":
        return calculate_returns_polars(prices, periods, method, **backend_options)
    elif backend == "bigquery":
        return calculate_returns_bigquery(prices, periods, method, date_column, price_column, **backend_options)
    elif backend == "duckdb":
        return calculate_returns_duckdb(prices, periods, method, date_column, price_column, **backend_options)
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, bigquery, duckdb")

def calculate_moving_averages_adapter(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]],
    date_column: str,
    price_column: str,
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate moving averages calculation adapter based on the backend.
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        date_column: Column name for date (only for DataFrame inputs)
        price_column: Column name for price (only for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated moving averages using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_moving_averages_pandas(prices, windows, **backend_options)
    elif backend == "polars":
        return calculate_moving_averages_polars(prices, windows, **backend_options)
    elif backend == "bigquery":
        return calculate_moving_averages_bigquery(prices, windows, date_column, price_column, **backend_options)
    elif backend == "duckdb":
        return calculate_moving_averages_duckdb(prices, windows, date_column, price_column, **backend_options)
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, bigquery, duckdb")

def calculate_statistical_moments_adapter(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int],
    date_column: str,
    returns_column: str,
    backend: str,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Factory function to select the appropriate statistical moments calculation adapter based on the backend.
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        date_column: Column name for date (only for DataFrame inputs)
        returns_column: Column name for returns (only for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated statistical moments using the specified backend
        
    Raises:
        ValueError: If an unknown backend is specified
    """
    if backend == "pandas":
        return calculate_statistical_moments_pandas(returns, windows, **backend_options)
    elif backend == "polars":
        return calculate_statistical_moments_polars(returns, windows, **backend_options)
    elif backend == "bigquery":
        return calculate_statistical_moments_bigquery(returns, windows, date_column, returns_column, **backend_options)
    elif backend == "duckdb":
        return calculate_statistical_moments_duckdb(returns, windows, date_column, returns_column, **backend_options)
    else:
        raise ValueError(f"Unknown backend: {backend}. Must be one of: pandas, polars, bigquery, duckdb") 