"""
Adapter functions for DuckDB backend for price features calculation
"""

from typing import Union, List, Dict, Any, Optional
import pandas as pd
import polars as pl

def calculate_returns_duckdb(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    database_path: Optional[str] = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating returns using DuckDB backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        database_path: DuckDB database file path
        memory_db: Whether to use in-memory database
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated returns
    """
    # Import the DuckDB implementation
    from ...price_features_duckdb import calculate_returns_duckdb as duckdb_returns
    
    # Call the DuckDB implementation
    return duckdb_returns(
        prices=prices,
        periods=periods,
        method=method,
        date_column=date_column,
        price_column=price_column,
        database_path=database_path,
        memory_db=memory_db,
        async_execution=async_execution,
        **kwargs
    )

def calculate_moving_averages_duckdb(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    database_path: Optional[str] = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating moving averages using DuckDB backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        database_path: DuckDB database file path
        memory_db: Whether to use in-memory database
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated moving averages
    """
    # Import the DuckDB implementation
    from ...price_features_duckdb import calculate_moving_averages_duckdb as duckdb_ma
    
    # Call the DuckDB implementation
    return duckdb_ma(
        prices=prices,
        windows=windows,
        date_column=date_column,
        price_column=price_column,
        database_path=database_path,
        memory_db=memory_db,
        async_execution=async_execution,
        **kwargs
    )

def calculate_statistical_moments_duckdb(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    date_column: Optional[str] = None,
    returns_column: Optional[str] = None,
    database_path: Optional[str] = None,
    memory_db: bool = True,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating statistical moments using DuckDB backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        date_column: Column name for date (for DataFrame inputs)
        returns_column: Column name for returns (for DataFrame inputs)
        database_path: DuckDB database file path
        memory_db: Whether to use in-memory database
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated statistical moments
    """
    # Import the DuckDB implementation
    from ...price_features_duckdb import calculate_statistical_moments_duckdb as duckdb_moments
    
    # Call the DuckDB implementation
    return duckdb_moments(
        returns=returns,
        windows=windows,
        date_column=date_column,
        returns_column=returns_column,
        database_path=database_path,
        memory_db=memory_db,
        async_execution=async_execution,
        **kwargs
    ) 