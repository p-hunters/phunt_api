"""
Adapter functions for polars backend for price features calculation
"""

from typing import Union, List, Dict, Any
import pandas as pd
import polars as pl

def calculate_returns_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    **kwargs
) -> pl.DataFrame:
    """
    Adapter function for calculating returns using polars backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated returns
    """
    # Import the polars implementation
    from ...price_features_polars import calculate_returns
    
    # Convert to polars if needed
    if isinstance(prices, pd.Series):
        prices = pl.from_pandas(prices)
    elif isinstance(prices, pd.DataFrame):
        prices = pl.from_pandas(prices)
    
    # Call the polars implementation
    return calculate_returns(prices, periods, method)

def calculate_moving_averages_polars(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    **kwargs
) -> pl.DataFrame:
    """
    Adapter function for calculating moving averages using polars backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated moving averages
    """
    # Import the polars implementation
    from ...price_features_polars import calculate_moving_averages
    
    # Convert to polars if needed
    if isinstance(prices, pd.Series):
        prices = pl.from_pandas(prices)
    elif isinstance(prices, pd.DataFrame):
        prices = pl.from_pandas(prices)
    
    # Call the polars implementation
    return calculate_moving_averages(prices, windows)

def calculate_statistical_moments_polars(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    **kwargs
) -> pl.DataFrame:
    """
    Adapter function for calculating statistical moments using polars backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated statistical moments
    """
    # Import the polars implementation
    from ...price_features_polars import calculate_statistical_moments
    
    # Convert to polars if needed
    if isinstance(returns, pd.Series):
        returns = pl.from_pandas(returns)
    elif isinstance(returns, pd.DataFrame):
        returns = pl.from_pandas(returns)
    
    # Call the polars implementation
    return calculate_statistical_moments(returns, windows) 