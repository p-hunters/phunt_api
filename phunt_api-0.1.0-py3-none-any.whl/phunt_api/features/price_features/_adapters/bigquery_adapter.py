"""
Adapter functions for BigQuery backend for price features calculation
"""

from typing import Union, List, Dict, Any, Optional
import pandas as pd
import polars as pl

def calculate_returns_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: Optional[str] = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating returns using BigQuery backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        project_id: GCP project ID
        dataset_id: BigQuery dataset ID
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated returns
    """
    # Import the BigQuery implementation
    from ...price_features_bq import calculate_returns_bq
    
    # Convert to pandas if needed (BigQuery functions work with both pandas and polars)
    
    # Call the BigQuery implementation
    return calculate_returns_bq(
        prices=prices,
        periods=periods,
        method=method,
        date_column=date_column,
        price_column=price_column,
        project_id=project_id,
        dataset_id=dataset_id,
        async_execution=async_execution,
        **kwargs
    )

def calculate_moving_averages_bigquery(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: Optional[str] = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating moving averages using BigQuery backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        project_id: GCP project ID
        dataset_id: BigQuery dataset ID
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated moving averages
    """
    # Import the BigQuery implementation
    from ...price_features_bq import calculate_moving_averages_bq
    
    # Call the BigQuery implementation
    return calculate_moving_averages_bq(
        prices=prices,
        windows=windows,
        date_column=date_column,
        price_column=price_column,
        project_id=project_id,
        dataset_id=dataset_id,
        async_execution=async_execution,
        **kwargs
    )

def calculate_statistical_moments_bigquery(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    date_column: Optional[str] = None,
    returns_column: Optional[str] = None,
    project_id: Optional[str] = None,
    dataset_id: Optional[str] = None,
    async_execution: bool = False,
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating statistical moments using BigQuery backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        date_column: Column name for date (for DataFrame inputs)
        returns_column: Column name for returns (for DataFrame inputs)
        project_id: GCP project ID
        dataset_id: BigQuery dataset ID
        async_execution: Whether to use async execution
        **kwargs: Additional backend-specific options
    
    Returns:
        DataFrame with calculated statistical moments
    """
    # Import the BigQuery implementation
    from ...price_features_bq import calculate_statistical_moments_bq
    
    # Call the BigQuery implementation
    return calculate_statistical_moments_bq(
        returns=returns,
        windows=windows,
        date_column=date_column,
        returns_column=returns_column,
        project_id=project_id,
        dataset_id=dataset_id,
        async_execution=async_execution,
        **kwargs
    ) 