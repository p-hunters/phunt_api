"""
Backend adapters for price features calculation

This module provides adapter functions to normalize interface between different backends
(pandas, polars, BigQuery, DuckDB) for price feature calculations.
"""

from .pandas_adapter import (
    calculate_returns_pandas,
    calculate_moving_averages_pandas,
    calculate_statistical_moments_pandas,
)

from .polars_adapter import (
    calculate_returns_polars,
    calculate_moving_averages_polars,
    calculate_statistical_moments_polars,
)

from .bigquery_adapter import (
    calculate_returns_bigquery,
    calculate_moving_averages_bigquery,
    calculate_statistical_moments_bigquery,
)

from .duckdb_adapter import (
    calculate_returns_duckdb,
    calculate_moving_averages_duckdb,
    calculate_statistical_moments_duckdb,
)

from .adapter_factory import (
    calculate_returns_adapter,
    calculate_moving_averages_adapter,
    calculate_statistical_moments_adapter,
)

__all__ = [
    # Factory functions
    'calculate_returns_adapter',
    'calculate_moving_averages_adapter',
    'calculate_statistical_moments_adapter',
    
    # Pandas adapters
    'calculate_returns_pandas',
    'calculate_moving_averages_pandas',
    'calculate_statistical_moments_pandas',
    
    # Polars adapters
    'calculate_returns_polars',
    'calculate_moving_averages_polars',
    'calculate_statistical_moments_polars',
    
    # BigQuery adapters
    'calculate_returns_bigquery',
    'calculate_moving_averages_bigquery',
    'calculate_statistical_moments_bigquery',
    
    # DuckDB adapters
    'calculate_returns_duckdb',
    'calculate_moving_averages_duckdb',
    'calculate_statistical_moments_duckdb',
] 