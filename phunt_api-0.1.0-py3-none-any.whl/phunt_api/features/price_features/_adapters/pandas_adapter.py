"""
Adapter functions for pandas backend for price features calculation
"""

from typing import Union, List, Dict, Any
import pandas as pd
import polars as pl

def calculate_returns_pandas(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating returns using pandas backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated returns
    """
    # Import the pandas implementation
    from ...price_features import calculate_returns
    
    # Convert to pandas if needed
    if isinstance(prices, pl.Series):
        prices = prices.to_pandas()
    elif isinstance(prices, pl.DataFrame):
        prices = prices.to_pandas()
    
    # Call the pandas implementation
    return calculate_returns(prices, periods, method)

def calculate_moving_averages_pandas(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating moving averages using pandas backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated moving averages
    """
    # Import the pandas implementation
    from ...price_features import calculate_moving_averages
    
    # Convert to pandas if needed
    if isinstance(prices, pl.Series):
        prices = prices.to_pandas()
    elif isinstance(prices, pl.DataFrame):
        prices = prices.to_pandas()
    
    # Call the pandas implementation
    return calculate_moving_averages(prices, windows)

def calculate_statistical_moments_pandas(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating statistical moments using pandas backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated statistical moments
    """
    # Import the pandas implementation
    from ...price_features import calculate_statistical_moments
    
    # Convert to pandas if needed
    if isinstance(returns, pl.Series):
        returns = returns.to_pandas()
    elif isinstance(returns, pl.DataFrame):
        returns = returns.to_pandas()
    
    # Call the pandas implementation
    return calculate_statistical_moments(returns, windows) 