"""
Adapter functions for pandas backend for price features calculation
"""

from typing import Union, List, Dict, Any
import pandas as pd
import polars as pl
import numpy as np

def calculate_returns_pandas(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating returns using pandas backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated returns
    """
    # Convert to pandas if needed
    if isinstance(prices, pl.Series):
        prices = prices.to_pandas()
    elif isinstance(prices, pl.DataFrame):
        prices = prices.to_pandas()
    
    # Directly implement pandas calculation to avoid import looping issues
    if not isinstance(prices, pd.Series):
        raise ValueError("Prices must be a pandas Series")
    
    # リスト変換
    if isinstance(periods, int):
        periods = [periods]
    
    # 結果格納用のDataFrame
    result = pd.DataFrame(index=prices.index)
    
    # 各期間に対してリターン計算
    for period in periods:
        if method.lower() == 'log':
            # 対数リターン
            result[f'return_{period}'] = np.log(prices / prices.shift(period))
        else:
            # 算術リターン
            result[f'return_{period}'] = (prices - prices.shift(period)) / prices.shift(period)
    
    return result

def calculate_moving_averages_pandas(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating moving averages using pandas backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated moving averages
    """
    # Convert to pandas if needed
    if isinstance(prices, pl.Series):
        prices = prices.to_pandas()
    elif isinstance(prices, pl.DataFrame):
        prices = prices.to_pandas()
    
    # Directly implement pandas calculation to avoid import looping issues
    if not isinstance(prices, pd.Series):
        raise ValueError("Prices must be a pandas Series")
    
    # リスト変換
    if isinstance(windows, int):
        windows = [windows]
    
    # 結果格納用のDataFrame
    result = pd.DataFrame(index=prices.index)
    
    # 各ウィンドウサイズに対して移動平均計算
    for window in windows:
        result[f'ma_{window}'] = prices.rolling(window=window).mean()
    
    return result

def calculate_statistical_moments_pandas(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    **kwargs
) -> pd.DataFrame:
    """
    Adapter function for calculating statistical moments using pandas backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        **kwargs: Additional options (ignored)
    
    Returns:
        DataFrame with calculated statistical moments
    """
    # Convert to pandas if needed
    if isinstance(returns, pl.Series):
        returns = returns.to_pandas()
    elif isinstance(returns, pl.DataFrame):
        returns = returns.to_pandas()
    
    # Directly implement pandas calculation to avoid import looping issues
    if not isinstance(returns, pd.Series):
        raise ValueError("Returns must be a pandas Series")
    
    # 結果格納用のDataFrame
    result = pd.DataFrame(index=returns.index)
    
    # 各ウィンドウサイズに対して統計的モーメント計算
    for window in windows:
        # 平均
        result[f'rolling_mean_{window}'] = returns.rolling(window=window).mean()
        
        # 分散
        result[f'rolling_var_{window}'] = returns.rolling(window=window).var()
        
        # 歪度 (skewness)
        result[f'rolling_skew_{window}'] = returns.rolling(window=window).skew()
        
        # 尖度 (kurtosis)
        result[f'rolling_kurt_{window}'] = returns.rolling(window=window).kurt()
        
        # Jarque-Bera統計量
        jb = (window / 6) * (
            result[f'rolling_skew_{window}'].pow(2) + 
            (result[f'rolling_kurt_{window}'].pow(2) / 4)
        )
        result[f'rolling_jb_{window}'] = jb
    
    return result 