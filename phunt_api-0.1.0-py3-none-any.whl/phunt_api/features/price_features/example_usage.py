"""
Unified Price Features API使用例

このモジュールは、統一された金融価格特徴量計算APIの使用例を提供します。
"""

import pandas as pd
import polars as pl
import numpy as np

# 統一APIをインポート
from . import (
    calculate_returns,
    calculate_moving_averages,
    calculate_statistical_moments,
    PriceFeatureBackend
)

def pandas_example():
    """pandasバックエンドの使用例"""
    print("\n=== Pandas Backend Example ===")
    
    # サンプルデータ作成
    prices = pd.Series(
        data=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        index=pd.date_range(start='2023-01-01', periods=10)
    )
    print(f"Price data (pandas):\n{prices}")
    
    # リターン計算（デフォルトはpandasバックエンド）
    returns_df = calculate_returns(prices, periods=[1, 3], method='arithmetic')
    print(f"\nReturns (pandas backend):\n{returns_df}")
    
    # 移動平均計算
    ma_df = calculate_moving_averages(prices, windows=[3, 5])
    print(f"\nMoving Averages (pandas backend):\n{ma_df}")
    
    # 統計的モーメント計算
    moments_df = calculate_statistical_moments(
        returns_df['return_1'], windows=[3, 5]
    )
    print(f"\nStatistical Moments (pandas backend):\n{moments_df}")

def polars_example():
    """polarsバックエンドの使用例"""
    print("\n=== Polars Backend Example ===")
    
    # サンプルデータ作成
    prices = pl.Series(
        values=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        name="price"
    )
    print(f"Price data (polars):\n{prices}")
    
    # リターン計算（polarsバックエンド）
    returns_df = calculate_returns(
        prices, periods=[1, 3], method='arithmetic', backend="polars"
    )
    print(f"\nReturns (polars backend):\n{returns_df}")
    
    # 移動平均計算
    ma_df = calculate_moving_averages(
        prices, windows=[3, 5], backend="polars"
    )
    print(f"\nMoving Averages (polars backend):\n{ma_df}")
    
    # 統計的モーメント計算
    returns_series = returns_df.select(pl.col("return_1")).to_series()
    moments_df = calculate_statistical_moments(
        returns_series, windows=[3, 5], backend="polars"
    )
    print(f"\nStatistical Moments (polars backend):\n{moments_df}")

def duckdb_example():
    """DuckDBバックエンドの使用例"""
    print("\n=== DuckDB Backend Example ===")
    
    # サンプルデータ作成
    dates = pd.date_range(start='2023-01-01', periods=10)
    prices_df = pd.DataFrame({
        'date': dates,
        'price': np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105])
    })
    print(f"Price data (DataFrame):\n{prices_df}")
    
    # DuckDBバックエンドを使用
    returns_df = calculate_returns(
        prices_df,
        periods=[1, 3],
        method='arithmetic',
        date_column='date',
        price_column='price',
        backend="duckdb",
        memory_db=True
    )
    print(f"\nReturns (DuckDB backend):\n{returns_df}")
    
    # 移動平均計算
    ma_df = calculate_moving_averages(
        prices_df,
        windows=[3, 5],
        date_column='date',
        price_column='price',
        backend="duckdb",
        memory_db=True
    )
    print(f"\nMoving Averages (DuckDB backend):\n{ma_df}")

def backend_class_example():
    """PriceFeatureBackendクラスの使用例"""
    print("\n=== PriceFeatureBackend Class Example ===")
    
    # サンプルデータ作成
    prices = pd.Series(
        data=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        index=pd.date_range(start='2023-01-01', periods=10)
    )
    print(f"Price data (pandas):\n{prices}")
    
    # バックエンドクラスのインスタンス化
    backend = PriceFeatureBackend(
        backend="polars",  # polarsバックエンドを使用
        output_format="pandas"  # 出力はpandas形式
    )
    
    # バックエンド設定を再利用して複数の計算
    returns_df = backend.calculate_returns(prices, periods=[1, 3])
    print(f"\nReturns (polars backend, pandas output):\n{returns_df}")
    
    ma_df = backend.calculate_moving_averages(prices, windows=[3, 5])
    print(f"\nMoving Averages (polars backend, pandas output):\n{ma_df}")

def mixed_format_example():
    """入出力フォーマット変換の例"""
    print("\n=== Mixed Format Example ===")
    
    # pandas Seriesデータ作成
    pandas_prices = pd.Series(
        data=np.array([100, 102, 104, 103, 105, 107, 108, 106, 104, 105]),
        index=pd.date_range(start='2023-01-01', periods=10)
    )
    print(f"Original pandas data:\n{pandas_prices}")
    
    # pandas入力, polars出力
    polars_returns = calculate_returns(
        pandas_prices, 
        periods=[1, 3], 
        output_format="polars"
    )
    print(f"\nReturns (pandas input, polars output):\n{polars_returns}")
    
    # polars入力, pandas出力
    pandas_ma = calculate_moving_averages(
        polars_returns['return_1'], 
        windows=[3], 
        output_format="pandas"
    )
    print(f"\nMoving average (polars input, pandas output):\n{pandas_ma}")

def main():
    """すべての例を実行"""
    pandas_example()
    polars_example()
    duckdb_example()
    backend_class_example()
    mixed_format_example()

if __name__ == "__main__":
    main() 