"""
Unified Price Features API

This module provides unified access to price feature calculation functions
with support for multiple backends (pandas, polars, BigQuery, DuckDB).
"""

# Export the unified interface
from .unified_api import (
    calculate_returns,
    calculate_moving_averages,
    calculate_statistical_moments,
)

# Export the backend class
from .unified_api import PriceFeatureBackend

# Set default backend (could be configurable)
__default_backend__ = "pandas"

__all__ = [
    'calculate_returns',
    'calculate_moving_averages',
    'calculate_statistical_moments',
    'PriceFeatureBackend',
    '__default_backend__',
] 