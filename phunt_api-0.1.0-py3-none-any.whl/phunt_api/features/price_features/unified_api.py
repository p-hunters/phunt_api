"""
Unified Price Features API

This module provides a unified interface for price feature calculations across different backends
(pandas, polars, BigQuery, DuckDB).
"""

from typing import Union, List, Dict, Any, Optional, Callable, TypeVar
import pandas as pd
import polars as pl

from ._adapters import (
    calculate_returns_adapter,
    calculate_moving_averages_adapter,
    calculate_statistical_moments_adapter,
)

# Default backend
DEFAULT_BACKEND = "pandas"

DataFrameType = TypeVar('DataFrameType', pd.DataFrame, pl.DataFrame)

def _determine_output_format(
    input_data: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    output_format: Optional[str]
) -> str:
    """
    Determine the output format based on input data and requested format
    
    Args:
        input_data: Input data
        output_format: Requested output format ('pandas', 'polars', or None)
        
    Returns:
        Determined output format ('pandas' or 'polars')
    """
    if output_format is not None:
        if output_format not in ["pandas", "polars"]:
            raise ValueError(f"Invalid output_format: {output_format}. Must be 'pandas', 'polars', or None")
        return output_format
    
    # If no format specified, match input format
    if isinstance(input_data, (pl.Series, pl.DataFrame)):
        return "polars"
    else:
        return "pandas"

def _convert_output(
    result: Union[pd.DataFrame, pl.DataFrame],
    output_format: str
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Convert the result to the desired output format
    
    Args:
        result: Result DataFrame
        output_format: Desired output format ('pandas' or 'polars')
        
    Returns:
        DataFrame in the desired format
    """
    if output_format == "pandas" and isinstance(result, pl.DataFrame):
        return result.to_pandas()
    elif output_format == "polars" and isinstance(result, pd.DataFrame):
        return pl.from_pandas(result)
    return result

def _standardize_output(
    result: Union[pd.DataFrame, pl.DataFrame],
    required_columns: List[str] = None,
    index_name: str = None
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    標準化された結果を返す
    
    Args:
        result: 結果のDataFrame
        required_columns: 必要なカラムのリスト（指定された場合はこれらのカラムのみを返す）
        index_name: インデックスにする列名
        
    Returns:
        標準化されたDataFrame
    """
    # 不要なカラムを削除
    if required_columns is not None:
        existing_columns = [col for col in required_columns if col in result.columns]
        missing_columns = [col for col in required_columns if col not in result.columns]
        
        # 既存の列のみを選択
        if isinstance(result, pd.DataFrame):
            if existing_columns:
                result = result[existing_columns]
            # 欠けている列を追加（NaN値で）
            for col in missing_columns:
                result[col] = None
        else:  # Polars DataFrame
            if existing_columns:
                result = result.select(existing_columns)
            # 欠けている列を追加（null値で）
            for col in missing_columns:
                result = result.with_columns(pl.lit(None).alias(col))
    
    # インデックス設定（Pandas DataFrame のみ）
    if index_name is not None and isinstance(result, pd.DataFrame) and index_name in result.columns:
        result = result.set_index(index_name)
    
    return result

def calculate_returns(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    periods: Union[int, List[int]] = [1, 5, 10],
    method: str = 'arithmetic',
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate returns for price data with the selected backend
    
    Args:
        prices: Price data
        periods: Periods for return calculation
        method: Return calculation method ('arithmetic' or 'log')
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated returns in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_returns_adapter(
        prices=prices,
        periods=periods,
        method=method,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected return columns
    if isinstance(periods, int):
        periods = [periods]
    required_columns = [f"return_{p}" for p in periods]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

def calculate_moving_averages(
    prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
    date_column: Optional[str] = None,
    price_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate moving averages for price data with the selected backend
    
    Args:
        prices: Price data
        windows: Window sizes for moving average calculation
        date_column: Column name for date (for DataFrame inputs)
        price_column: Column name for price (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated moving averages in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(prices, output_format)
    
    # Call the adapter function
    result = calculate_moving_averages_adapter(
        prices=prices,
        windows=windows,
        date_column=date_column,
        price_column=price_column,
        backend=backend,
        **backend_options
    )
    
    # Get the list of expected MA columns
    if isinstance(windows, int):
        windows = [windows]
    required_columns = [f"ma_{w}" for w in windows]
    
    # Index column name for pandas format
    index_column = date_column
    if isinstance(prices, (pd.Series, pl.Series)):
        index_column = None
    
    # Standardize the output
    result = _standardize_output(result, required_columns, index_column)
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

def calculate_statistical_moments(
    returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
    windows: List[int] = [20, 60, 120],
    date_column: Optional[str] = None,
    returns_column: Optional[str] = None,
    backend: str = DEFAULT_BACKEND,
    output_format: Optional[str] = None,
    **backend_options
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Calculate statistical moments for returns data with the selected backend
    
    Args:
        returns: Returns data
        windows: Window sizes for statistical moments calculation
        date_column: Column name for date (for DataFrame inputs)
        returns_column: Column name for returns (for DataFrame inputs)
        backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
        output_format: Force output format ('pandas' or 'polars'), if None matches input
        **backend_options: Additional backend-specific options
        
    Returns:
        DataFrame with calculated statistical moments in the desired format
    """
    # Determine the output format
    determined_format = _determine_output_format(returns, output_format)
    
    # Call the adapter function
    result = calculate_statistical_moments_adapter(
        returns=returns,
        windows=windows,
        date_column=date_column,
        returns_column=returns_column,
        backend=backend,
        **backend_options
    )
    
    # Convert to the desired output format
    return _convert_output(result, determined_format)

class PriceFeatureBackend:
    """
    Backend configuration for price feature calculations
    
    This class stores configuration for multiple price feature calculations
    using the same backend and output format.
    """
    
    def __init__(
        self,
        backend: str = DEFAULT_BACKEND,
        output_format: Optional[str] = None,
        **backend_options
    ):
        """
        Initialize the backend configuration
        
        Args:
            backend: Backend to use ('pandas', 'polars', 'bigquery', 'duckdb')
            output_format: Output format ('pandas', 'polars', or None)
            **backend_options: Backend-specific options
        """
        # Validate backend
        if backend not in ["pandas", "polars", "bigquery", "duckdb"]:
            raise ValueError(f"Invalid backend: {backend}. Must be one of: pandas, polars, bigquery, duckdb")
        
        # Validate output_format if specified
        if output_format is not None and output_format not in ["pandas", "polars"]:
            raise ValueError(f"Invalid output_format: {output_format}. Must be 'pandas', 'polars', or None")
        
        self.backend = backend
        self.output_format = output_format
        self.backend_options = backend_options
    
    def calculate_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate returns using the configured backend
        
        Args:
            prices: Price data
            periods: Periods for return calculation
            method: Return calculation method ('arithmetic' or 'log')
            date_column: Column name for date (for DataFrame inputs)
            price_column: Column name for price (for DataFrame inputs)
            
        Returns:
            DataFrame with calculated returns
        """
        return calculate_returns(
            prices=prices,
            periods=periods,
            method=method,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        )
    
    def calculate_moving_averages(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
        date_column: Optional[str] = None,
        price_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate moving averages using the configured backend
        
        Args:
            prices: Price data
            windows: Window sizes for moving average calculation
            date_column: Column name for date (for DataFrame inputs)
            price_column: Column name for price (for DataFrame inputs)
            
        Returns:
            DataFrame with calculated moving averages
        """
        return calculate_moving_averages(
            prices=prices,
            windows=windows,
            date_column=date_column,
            price_column=price_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        )
    
    def calculate_statistical_moments(
        self,
        returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: Optional[str] = None,
        returns_column: Optional[str] = None
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Calculate statistical moments using the configured backend
        
        Args:
            returns: Returns data
            windows: Window sizes for statistical moments calculation
            date_column: Column name for date (for DataFrame inputs)
            returns_column: Column name for returns (for DataFrame inputs)
            
        Returns:
            DataFrame with calculated statistical moments
        """
        return calculate_statistical_moments(
            returns=returns,
            windows=windows,
            date_column=date_column,
            returns_column=returns_column,
            backend=self.backend,
            output_format=self.output_format,
            **self.backend_options
        ) 