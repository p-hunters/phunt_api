"""
統一Price Features APIの簡単なテスト

このモジュールは、統一されたPrice Features APIの基本的な動作を確認するための簡単なテストを含みます。
"""

import pandas as pd
import polars as pl
import numpy as np

# 統一APIをインポート
from phunt_api.features.price_features import (
    calculate_returns,
    calculate_moving_averages,
    calculate_statistical_moments,
    PriceFeatureBackend
)

def run_simple_test():
    """簡単なテストを実行する関数"""
    # テスト用のデータ
    prices = pd.Series([100, 102, 104, 103, 105])
    
    # 各バックエンドでのリターン計算
    print("=== Testing Pandas Backend ===")
    try:
        result_pandas = calculate_returns(prices, periods=[1], backend="pandas")
        print(f"Pandas backend result:\n{result_pandas}")
    except Exception as e:
        print(f"Pandas backend failed: {str(e)}")
    
    print("\n=== Testing Polars Backend ===")
    try:
        result_polars = calculate_returns(prices, periods=[1], backend="polars")
        print(f"Polars backend result:\n{result_polars}")
    except Exception as e:
        print(f"Polars backend failed: {str(e)}")
    
    print("\n=== Testing Output Format ===")
    try:
        result_format = calculate_returns(prices, periods=[1], backend="pandas", output_format="polars")
        print(f"Pandas backend with polars output format:\nType: {type(result_format)}")
        print(result_format)
    except Exception as e:
        print(f"Output format test failed: {str(e)}")
    
    print("\n=== Testing Backend Class ===")
    try:
        backend = PriceFeatureBackend(backend="polars", output_format="pandas")
        result_backend = backend.calculate_returns(prices, periods=[1])
        print(f"Backend class result:\n{result_backend}")
    except Exception as e:
        print(f"Backend class test failed: {str(e)}")

if __name__ == "__main__":
    run_simple_test() 