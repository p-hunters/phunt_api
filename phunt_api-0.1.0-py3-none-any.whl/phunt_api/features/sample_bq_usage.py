#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
BigQuery特徴量計算のサンプルスクリプト

このスクリプトでは、リファクタリングされたBigQuery特徴量計算機能の使用方法を示します。
実行するには、GCPの認証情報とBigQueryデータセットが必要です。
"""

import os
import numpy as np
import pandas as pd
import polars as pl
from datetime import datetime, timedelta

# 必要なプロジェクト関数のインポート
from phunt_api.features.price_features_bq import (
    calculate_statistical_moments_bq,
    calculate_returns_bq,
    calculate_moving_averages_bq
)

# GCP設定
# 実際のプロジェクトIDとデータセットIDに置き換えてください
PROJECT_ID = "your-project-id"
DATASET_ID = "your_dataset_id"

def create_sample_data():
    """サンプル価格データを作成"""
    # 日付の生成
    dates = pd.date_range(start='2024-01-01', end='2024-03-31', freq='D')
    
    # ランダムウォークによる価格データの生成
    n = len(dates)
    np.random.seed(42)  # 再現性のために乱数シードを固定
    
    # 初期価格
    initial_price = 100.0
    
    # 日々の変化率（正規分布から生成、標準偏差0.01=1%）
    daily_changes = np.random.normal(0.0005, 0.01, n)
    
    # ランダムウォークで価格を生成
    prices = initial_price * np.cumprod(1 + daily_changes)
    
    # Polars DataFrameに変換
    price_df = pl.DataFrame({
        "date": [d.date() for d in dates],
        "price": prices
    })
    
    return price_df

def main():
    """メイン処理"""
    print("BigQuery特徴量計算サンプルの実行")
    
    # サンプルデータ生成
    price_df = create_sample_data()
    print(f"サンプルデータ作成完了: {len(price_df)}行")
    print(price_df.head(5))
    
    try:
        # リターン計算
        print("\n1. リターン計算...")
        returns_df = calculate_returns_bq(
            prices=price_df,
            periods=[1, 5, 10],
            date_column="date",
            price_column="price",
            project_id=PROJECT_ID,
            dataset_id=DATASET_ID
        )
        
        print(f"リターン計算完了: {len(returns_df)}行")
        print(returns_df.head(5))
        
        # 統計的モーメント計算
        print("\n2. 統計的モーメント計算...")
        # リターン列を使用
        returns_data = returns_df.select(["date", "return_1"])
        
        moments_df = calculate_statistical_moments_bq(
            returns=returns_data,
            windows=[20, 60],
            date_column="date",
            returns_column="return_1",
            project_id=PROJECT_ID,
            dataset_id=DATASET_ID
        )
        
        print(f"統計的モーメント計算完了: {len(moments_df)}行")
        print(moments_df.head(5))
        
        # 移動平均計算
        print("\n3. 移動平均計算...")
        ma_df = calculate_moving_averages_bq(
            prices=price_df,
            windows=[5, 10, 20],
            date_column="date",
            price_column="price",
            project_id=PROJECT_ID,
            dataset_id=DATASET_ID
        )
        
        print(f"移動平均計算完了: {len(ma_df)}行")
        print(ma_df.head(5))
        
        # 非同期実行例
        print("\n4. 非同期実行例...")
        async_moments_df = calculate_statistical_moments_bq(
            returns=returns_data,
            windows=[20, 60],
            date_column="date",
            returns_column="return_1",
            project_id=PROJECT_ID,
            dataset_id=DATASET_ID,
            async_execution=True
        )
        
        print(f"非同期実行完了: {len(async_moments_df)}行")
        
        print("\nすべての計算が正常に完了しました！")
        
    except Exception as e:
        print(f"エラーが発生しました: {str(e)}")
        # トレースバックを表示する場合はコメントを外す
        # import traceback
        # traceback.print_exc()

if __name__ == "__main__":
    main() 