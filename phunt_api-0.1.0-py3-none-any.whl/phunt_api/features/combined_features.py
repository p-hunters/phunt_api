import numpy as np
import pandas as pd
from typing import List, Dict, Optional
from .price_features import calculate_returns
from .market_features import calculate_market_turbulence


def calculate_lagged_features(
    features: pd.DataFrame,
    lag_periods: List[int] = [1, 5, 10, 15],
    columns: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    Calculate lagged versions of features.
    
    Args:
        features: DataFrame with features to lag
        lag_periods: List of periods to lag
        columns: Optional list of columns to lag (if None, all columns are lagged)
    
    Returns:
        DataFrame with lagged features
    """
    if columns is None:
        columns = features.columns
    
    lagged_features = pd.DataFrame(index=features.index)
    
    for col in columns:
        for lag in lag_periods:
            lagged_features[f'{col}_lag_{lag}'] = features[col].shift(lag)
    
    return lagged_features


def calculate_interaction_features(
    price_features: pd.DataFrame,
    market_features: pd.DataFrame,
    vix_column: str = 'VIX_close'
) -> pd.DataFrame:
    """
    Calculate interaction features between different feature types.
    
    Args:
        price_features: DataFrame with price-based features
        market_features: DataFrame with market-based features
        vix_column: Name of the VIX column in market_features
    
    Returns:
        DataFrame with interaction features
    """
    features = pd.DataFrame(index=price_features.index)
    
    # Interaction between returns and VIX
    return_columns = [col for col in price_features.columns if 'return' in col]
    for return_col in return_columns:
        features[f'{return_col}_vix_interaction'] = (
            price_features[return_col] * market_features[vix_column]
        )
    
    # Interaction between volatility and VIX
    vol_columns = [col for col in price_features.columns if 'volatility' in col]
    for vol_col in vol_columns:
        features[f'{vol_col}_vix_interaction'] = (
            price_features[vol_col] * market_features[vix_column]
        )
    
    return features


def calculate_rolling_correlation_features(
    returns: pd.Series,
    other_series: Dict[str, pd.Series],
    windows: List[int] = [5, 10, 20]
) -> pd.DataFrame:
    """
    Calculate rolling correlations between returns and other series.
    
    Args:
        returns: Series of returns
        other_series: Dictionary of other series to calculate correlations with
        windows: List of window sizes for rolling calculations
    
    Returns:
        DataFrame with rolling correlation features
    """
    features = pd.DataFrame(index=returns.index)
    
    for name, series in other_series.items():
        for window in windows:
            correlation = returns.rolling(window=window).corr(series)
            features[f'correlation_{name}_{window}'] = correlation
    
    return features


def calculate_regime_features(
    returns: pd.Series,
    volatility: pd.Series,
    vix: pd.Series,
    n_regimes: int = 3
) -> pd.DataFrame:
    """
    Calculate regime-based features using various market indicators.
    
    Args:
        returns: Series of returns
        volatility: Series of volatility
        vix: Series of VIX values
        n_regimes: Number of regimes to identify
    
    Returns:
        DataFrame with regime-based features
    """
    features = pd.DataFrame(index=returns.index)
    
    # Volatility regime
    vol_quantiles = volatility.rolling(window=252).quantile(
        q=[i/n_regimes for i in range(1, n_regimes)]
    )
    features['volatility_regime'] = 0
    for i in range(n_regimes-1):
        features.loc[volatility > vol_quantiles.iloc[:, i], 'volatility_regime'] = i + 1
    
    # VIX regime
    vix_quantiles = vix.rolling(window=252).quantile(
        q=[i/n_regimes for i in range(1, n_regimes)]
    )
    features['vix_regime'] = 0
    for i in range(n_regimes-1):
        features.loc[vix > vix_quantiles.iloc[:, i], 'vix_regime'] = i + 1
    
    # Trend regime (using rolling returns)
    rolling_returns = returns.rolling(window=20).mean()
    features['trend_regime'] = np.sign(rolling_returns)
    
    return features


def calculate_technical_interaction_features(
    price_data: pd.DataFrame,
    ma_windows: List[int] = [5, 10, 20, 50, 200]
) -> pd.DataFrame:
    """
    Calculate interaction features between different technical indicators.
    
    Args:
        price_data: DataFrame with price data
        ma_windows: List of moving average windows
    
    Returns:
        DataFrame with technical interaction features
    """
    features = pd.DataFrame(index=price_data.index)
    
    # Calculate moving averages
    mas = {}
    for window in ma_windows:
        mas[window] = price_data['close'].rolling(window=window).mean()
    
    # MA crossovers
    for i in range(len(ma_windows)):
        for j in range(i + 1, len(ma_windows)):
            short_window = ma_windows[i]
            long_window = ma_windows[j]
            
            # MA difference
            features[f'ma_{short_window}_{long_window}_diff'] = (
                mas[short_window] - mas[long_window]
            )
            
            # MA crossover signal
            features[f'ma_{short_window}_{long_window}_cross'] = np.sign(
                features[f'ma_{short_window}_{long_window}_diff']
            )
    
    return features


def calculate_all_combined_features(
    price_features: pd.DataFrame,
    market_features: pd.DataFrame,
    orderbook_features: pd.DataFrame,
    time_features: pd.DataFrame,
    price_data: pd.DataFrame,
    vix_column: str = 'VIX_close',
    lag_periods: List[int] = [1, 5, 10, 15],
    ma_windows: List[int] = [5, 10, 20, 50, 200],
    correlation_windows: List[int] = [5, 10, 20],
    n_regimes: int = 3
) -> pd.DataFrame:
    """
    Calculate all combined and interaction features.
    
    Args:
        price_features: DataFrame with price-based features
        market_features: DataFrame with market-based features
        orderbook_features: DataFrame with orderbook features
        time_features: DataFrame with time-based features
        price_data: DataFrame with raw price data
        vix_column: Name of the VIX column
        lag_periods: List of periods for lagged features
        ma_windows: List of moving average windows
        correlation_windows: List of windows for correlation calculation
        n_regimes: Number of regimes to identify
    
    Returns:
        DataFrame with all combined features
    """
    # Initialize combined features DataFrame
    features = pd.DataFrame(index=price_features.index)
    
    # Calculate lagged features
    important_columns = (
        [col for col in price_features.columns if any(x in col for x in ['return', 'volatility'])] +
        [col for col in market_features.columns if any(x in col for x in ['return', vix_column])] +
        [col for col in orderbook_features.columns if 'imbalance' in col]
    )
    lagged = calculate_lagged_features(
        pd.concat([price_features, market_features, orderbook_features], axis=1),
        lag_periods,
        important_columns
    )
    
    # Calculate interaction features
    interactions = calculate_interaction_features(
        price_features,
        market_features,
        vix_column
    )
    
    # Calculate rolling correlations
    returns = price_data['close'].pct_change()
    other_series = {
        'vix': market_features[vix_column],
        'orderbook_imbalance': orderbook_features['best_bid_ask_imbalance']
    }
    correlations = calculate_rolling_correlation_features(
        returns,
        other_series,
        correlation_windows
    )
    
    # Calculate regime features
    volatility = price_features[[col for col in price_features.columns if 'volatility' in col][0]]
    regimes = calculate_regime_features(
        returns,
        volatility,
        market_features[vix_column],
        n_regimes
    )
    
    # Calculate technical interaction features
    technical = calculate_technical_interaction_features(price_data, ma_windows)
    
    # Combine all features
    features = pd.concat([
        lagged,
        interactions,
        correlations,
        regimes,
        technical
    ], axis=1)
    
    return features 