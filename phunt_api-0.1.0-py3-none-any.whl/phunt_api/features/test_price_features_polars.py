import pytest
import numpy as np
import pandas as pd
import polars as pl
from datetime import datetime, timedelta

# Import pandas implementations
from phunt_api.features.price_features import (
    calculate_returns as pd_calculate_returns,
    calculate_moving_averages as pd_calculate_moving_averages,
    calculate_bollinger_bands as pd_calculate_bollinger_bands,
    calculate_volatility as pd_calculate_volatility,
    calculate_statistical_moments as pd_calculate_statistical_moments,
    calculate_rolling_correlation as pd_calculate_rolling_correlation,
    calculate_rolling_beta as pd_calculate_rolling_beta,
    calculate_range_position as pd_calculate_range_position,
    calculate_relative_high_position as pd_calculate_relative_high_position,
    calculate_relative_low_position as pd_calculate_relative_low_position,
    calculate_rsi as pd_calculate_rsi,
    calculate_macd as pd_calculate_macd,
    calculate_atr as pd_calculate_atr,
    calculate_obv as pd_calculate_obv,
    calculate_vwap as pd_calculate_vwap,
    calculate_price_features as pd_calculate_price_features
)

# Import polars implementations
from phunt_api.features.price_features_polars import (
    calculate_returns as pl_calculate_returns,
    calculate_moving_averages as pl_calculate_moving_averages,
    calculate_bollinger_bands as pl_calculate_bollinger_bands,
    calculate_volatility as pl_calculate_volatility,
    calculate_statistical_moments as pl_calculate_statistical_moments,
    calculate_rolling_correlation as pl_calculate_rolling_correlation,
    calculate_rolling_beta as pl_calculate_rolling_beta,
    calculate_range_position as pl_calculate_range_position,
    calculate_relative_high_position as pl_calculate_relative_high_position,
    calculate_relative_low_position as pl_calculate_relative_low_position,
    calculate_rsi as pl_calculate_rsi,
    calculate_macd as pl_calculate_macd,
    calculate_atr as pl_calculate_atr,
    calculate_obv as pl_calculate_obv,
    calculate_vwap as pl_calculate_vwap,
    calculate_price_features as pl_calculate_price_features
)


# =============================================================================
#  Helper Functions for Comparison
# =============================================================================

def compare_dataframes(pd_df, pl_df, rtol=1e-5, atol=1e-8):
    """
    Compare pandas DataFrame and polars DataFrame results.
    
    Args:
        pd_df (pd.DataFrame): pandas DataFrame result
        pl_df (pl.DataFrame): polars DataFrame result
        rtol (float): Relative tolerance for numeric comparison
        atol (float): Absolute tolerance for numeric comparison
    """
    # Convert polars to pandas for comparison
    pl_as_pd = pl_df.to_pandas()
    
    # Check dimensions match
    assert pd_df.shape == pl_as_pd.shape, f"Shape mismatch: {pd_df.shape} vs {pl_as_pd.shape}"
    
    # Check column names (might be in different order)
    assert set(pd_df.columns) == set(pl_as_pd.columns), f"Column mismatch: {set(pd_df.columns)} vs {set(pl_as_pd.columns)}"
    
    # Compare values column by column
    for col in pd_df.columns:
        pd_series = pd_df[col].fillna(np.nan)  # Handle None/NaN differences
        pl_series = pl_as_pd[col].fillna(np.nan)
        
        # Check if values are close
        is_close = np.isclose(
            pd_series.values, 
            pl_series.values,
            rtol=rtol,
            atol=atol,
            equal_nan=True  # Treat NaNs as equal
        )
        
        # For values that aren't close, print details
        if not is_close.all():
            not_close_indices = np.where(~is_close)[0]
            pd_values = pd_series.iloc[not_close_indices].values
            pl_values = pl_series.iloc[not_close_indices].values
            
            for i, (pd_val, pl_val) in enumerate(zip(pd_values, pl_values)):
                print(f"Mismatch at index {not_close_indices[i]}: pandas={pd_val}, polars={pl_val}")
                
            assert False, f"Values in column {col} don't match between pandas and polars implementations"


def compare_series(pd_series, pl_series, rtol=1e-5, atol=1e-8):
    """
    Compare pandas Series and polars Series results.
    
    Args:
        pd_series (pd.Series): pandas Series result
        pl_series (pl.Series): polars Series result
        rtol (float): Relative tolerance for numeric comparison
        atol (float): Absolute tolerance for numeric comparison
    """
    # Convert polars to pandas for comparison
    pl_as_pd = pl_series.to_pandas()
    
    # Check lengths match
    assert len(pd_series) == len(pl_as_pd), f"Length mismatch: {len(pd_series)} vs {len(pl_as_pd)}"
    
    # Fill NaN values for comparison
    pd_values = pd_series.fillna(np.nan).values
    pl_values = pl_as_pd.fillna(np.nan).values
    
    # Check if values are close
    is_close = np.isclose(
        pd_values,
        pl_values,
        rtol=rtol,
        atol=atol,
        equal_nan=True  # Treat NaNs as equal
    )
    
    # For values that aren't close, print details
    if not is_close.all():
        not_close_indices = np.where(~is_close)[0]
        pd_vals = pd_values[not_close_indices]
        pl_vals = pl_values[not_close_indices]
        
        for i, (pd_val, pl_val) in enumerate(zip(pd_vals, pl_vals)):
            print(f"Mismatch at index {not_close_indices[i]}: pandas={pd_val}, polars={pl_val}")
            
        assert False, f"Values don't match between pandas and polars Series"


# =============================================================================
#  Fixtures
# =============================================================================

@pytest.fixture
def sample_price_series():
    """Create a sample price series for testing."""
    np.random.seed(42)  # For reproducibility
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    # Generate synthetic prices with some trend and noise
    prices = 100 * (1 + np.random.randn(len(dates)) * 0.02).cumprod()
    return pd.Series(prices, index=dates)


@pytest.fixture
def sample_price_series_polars(sample_price_series):
    """Convert pandas price series to polars."""
    return pl.from_pandas(sample_price_series).to_series()


@pytest.fixture
def sample_ohlc_data():
    """Create sample OHLC data for testing."""
    np.random.seed(42)  # For reproducibility
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    n = len(dates)
    
    # Generate synthetic OHLC data
    base_price = 100 * (1 + np.random.randn(n) * 0.02).cumprod()
    high = base_price * (1 + abs(np.random.randn(n) * 0.01))
    low = base_price * (1 - abs(np.random.randn(n) * 0.01))
    close = base_price * (1 + np.random.randn(n) * 0.005)
    volume = np.random.randint(1000, 10000, n)
    
    return pd.DataFrame({
        'open': base_price,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume
    }, index=dates)


@pytest.fixture
def sample_ohlc_data_polars(sample_ohlc_data):
    """Convert pandas OHLC data to polars."""
    return pl.from_pandas(sample_ohlc_data)


@pytest.fixture
def sample_benchmark_returns():
    """Create sample benchmark returns for testing."""
    np.random.seed(42)  # For reproducibility
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='D')
    returns = np.random.randn(len(dates)) * 0.01
    return pd.Series(returns, index=dates)


@pytest.fixture
def sample_benchmark_returns_polars(sample_benchmark_returns):
    """Convert pandas benchmark returns to polars."""
    return pl.from_pandas(sample_benchmark_returns).to_series()


# =============================================================================
#  Tests for Basic Features
# =============================================================================

def test_calculate_returns(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars return calculations match."""
    periods = [1, 5, 10]
    
    # Calculate with pandas
    pd_returns = pd_calculate_returns(sample_price_series, periods=periods)
    
    # Calculate with polars
    pl_returns = pl_calculate_returns(sample_price_series_polars, periods=periods)
    
    # Compare results
    compare_dataframes(pd_returns, pl_returns)
    
    # Test different methods
    for method in ['arithmetic', 'log']:
        pd_returns = pd_calculate_returns(sample_price_series, periods=1, method=method)
        pl_returns = pl_calculate_returns(sample_price_series_polars, periods=1, method=method)
        compare_dataframes(pd_returns, pl_returns)


def test_calculate_moving_averages(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars moving average calculations match."""
    windows = [5, 10, 20]
    
    # Calculate with pandas
    pd_mas = pd_calculate_moving_averages(sample_price_series, windows=windows)
    
    # Calculate with polars
    pl_mas = pl_calculate_moving_averages(sample_price_series_polars, windows=windows)
    
    # Compare results
    compare_dataframes(pd_mas, pl_mas)


def test_calculate_bollinger_bands(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars Bollinger Bands calculations match."""
    window = 20
    num_std = 2.0
    
    # Calculate with pandas
    pd_bb = pd_calculate_bollinger_bands(sample_price_series, window=window, num_std=num_std)
    
    # Calculate with polars
    pl_bb = pl_calculate_bollinger_bands(sample_price_series_polars, window=window, num_std=num_std)
    
    # Compare results
    compare_dataframes(pd_bb, pl_bb)


def test_calculate_volatility(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars volatility calculations match."""
    windows = [5, 10, 20]
    
    for method in ['arithmetic', 'log']:
        # Calculate with pandas
        pd_vol = pd_calculate_volatility(sample_price_series, windows=windows, returns_method=method)
        
        # Calculate with polars
        pl_vol = pl_calculate_volatility(sample_price_series_polars, windows=windows, returns_method=method)
        
        # Compare results
        compare_dataframes(pd_vol, pl_vol, rtol=1e-3)  # Slightly higher tolerance for volatility


# =============================================================================
#  Tests for Statistical Features
# =============================================================================

def test_calculate_statistical_moments(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars statistical moments calculations match."""
    # Calculate returns first
    pd_returns = pd_calculate_returns(sample_price_series, periods=1)['return_1']
    pl_returns = pl_calculate_returns(sample_price_series_polars, periods=1)['return_1']
    
    windows = [20, 60]
    
    # Calculate with pandas
    pd_moments = pd_calculate_statistical_moments(pd_returns, windows=windows)
    
    # Calculate with polars
    pl_moments = pl_calculate_statistical_moments(pl_returns, windows=windows)
    
    # Compare results 
    # Note: Higher tolerance for statistical moments due to potential implementation differences
    compare_dataframes(pd_moments, pl_moments, rtol=1e-3, atol=1e-5)


def test_calculate_rolling_correlation(
    sample_price_series, sample_price_series_polars,
    sample_benchmark_returns, sample_benchmark_returns_polars
):
    """Test that pandas and polars correlation calculations match."""
    windows = [20, 60]
    
    # Calculate with pandas
    pd_corr = pd_calculate_rolling_correlation(
        sample_price_series,
        sample_benchmark_returns,
        windows=windows
    )
    
    # Calculate with polars
    pl_corr = pl_calculate_rolling_correlation(
        sample_price_series_polars,
        sample_benchmark_returns_polars,
        windows=windows
    )
    
    # Compare results
    compare_dataframes(pd_corr, pl_corr, rtol=1e-3)


def test_calculate_rolling_beta(
    sample_price_series, sample_price_series_polars,
    sample_benchmark_returns, sample_benchmark_returns_polars
):
    """Test that pandas and polars beta calculations match."""
    windows = [20, 60]
    
    # Calculate returns first
    pd_returns = pd_calculate_returns(sample_price_series, periods=1)['return_1']
    pl_returns = pl_calculate_returns(sample_price_series_polars, periods=1)['return_1']
    
    # Calculate with pandas
    pd_beta = pd_calculate_rolling_beta(
        pd_returns,
        sample_benchmark_returns,
        windows=windows
    )
    
    # Calculate with polars
    pl_beta = pl_calculate_rolling_beta(
        pl_returns,
        sample_benchmark_returns_polars,
        windows=windows
    )
    
    # Compare results
    compare_dataframes(pd_beta, pl_beta, rtol=1e-3)


# =============================================================================
#  Tests for Range-Based Features
# =============================================================================

def test_calculate_range_position(sample_ohlc_data, sample_ohlc_data_polars):
    """Test that pandas and polars range position calculations match."""
    window = 20
    
    # Calculate with pandas
    pd_range_pos = pd_calculate_range_position(sample_ohlc_data, window=window)
    
    # Calculate with polars
    pl_range_pos = pl_calculate_range_position(sample_ohlc_data_polars, window=window)
    
    # Compare results
    compare_series(pd_range_pos, pl_range_pos)


def test_calculate_relative_positions(sample_ohlc_data, sample_ohlc_data_polars):
    """Test that pandas and polars relative high/low position calculations match."""
    window = 20
    
    # Calculate with pandas
    pd_high_pos = pd_calculate_relative_high_position(sample_ohlc_data, window=window)
    pd_low_pos = pd_calculate_relative_low_position(sample_ohlc_data, window=window)
    
    # Calculate with polars
    pl_high_pos = pl_calculate_relative_high_position(sample_ohlc_data_polars, window=window)
    pl_low_pos = pl_calculate_relative_low_position(sample_ohlc_data_polars, window=window)
    
    # Compare results
    compare_series(pd_high_pos, pl_high_pos)
    compare_series(pd_low_pos, pl_low_pos)


# =============================================================================
#  Tests for Technical Indicators
# =============================================================================

def test_calculate_rsi(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars RSI calculations match."""
    window = 14
    
    # Calculate with pandas
    pd_rsi = pd_calculate_rsi(sample_price_series, window=window)
    
    # Calculate with polars
    pl_rsi = pl_calculate_rsi(sample_price_series_polars, window=window)
    
    # Compare results
    compare_series(pd_rsi, pl_rsi, rtol=1e-3)  # Higher tolerance for RSI


def test_calculate_macd(sample_price_series, sample_price_series_polars):
    """Test that pandas and polars MACD calculations match."""
    # Calculate with pandas
    pd_macd = pd_calculate_macd(sample_price_series)
    
    # Calculate with polars
    pl_macd = pl_calculate_macd(sample_price_series_polars)
    
    # Compare results
    compare_dataframes(pd_macd, pl_macd, rtol=1e-3)  # Higher tolerance for MACD


def test_calculate_atr(sample_ohlc_data, sample_ohlc_data_polars):
    """Test that pandas and polars ATR calculations match."""
    window = 14
    
    # Calculate with pandas
    pd_atr = pd_calculate_atr(sample_ohlc_data, window=window)
    
    # Calculate with polars
    pl_atr = pl_calculate_atr(sample_ohlc_data_polars, window=window)
    
    # Compare results
    compare_series(pd_atr, pl_atr)


def test_calculate_obv(sample_ohlc_data, sample_ohlc_data_polars):
    """Test that pandas and polars OBV calculations match."""
    # Calculate with pandas
    pd_obv = pd_calculate_obv(sample_ohlc_data)
    
    # Calculate with polars
    pl_obv = pl_calculate_obv(sample_ohlc_data_polars)
    
    # Compare results
    compare_series(pd_obv, pl_obv)


def test_calculate_vwap(sample_ohlc_data, sample_ohlc_data_polars):
    """Test that pandas and polars VWAP calculations match."""
    window = 20
    
    # Calculate with pandas
    pd_vwap = pd_calculate_vwap(sample_ohlc_data, window=window)
    
    # Calculate with polars
    pl_vwap = pl_calculate_vwap(sample_ohlc_data_polars, window=window)
    
    # Compare results
    compare_series(pd_vwap, pl_vwap)


# =============================================================================
#  Test Main Feature Aggregation
# =============================================================================

def test_calculate_price_features(
    sample_price_series, sample_price_series_polars,
    sample_ohlc_data, sample_ohlc_data_polars,
    sample_benchmark_returns, sample_benchmark_returns_polars
):
    """Test that the main price feature calculation functions match."""
    # Test parameters
    params = {
        'return_periods': [1, 5],
        'ma_windows': [5, 10, 20],
        'volatility_windows': [5, 10],
        'moment_windows': [20, 60],
        'bb_window': 20,
        'bb_num_std': 2.0,
        'range_window': 20,
        'range_offset': 0,
        'rsi_window': 14,
        'macd_short_window': 12,
        'macd_long_window': 26,
        'macd_signal_window': 9,
        'atr_window': 14,
        'add_obv': True,
        'add_vwap': True
    }
    
    # Calculate with pandas
    pd_features = pd_calculate_price_features(
        sample_price_series,
        ohlc=sample_ohlc_data,
        benchmark_returns=sample_benchmark_returns,
        **params
    )
    
    # Calculate with polars
    pl_features = pl_calculate_price_features(
        sample_price_series_polars,
        ohlc=sample_ohlc_data_polars,
        benchmark_returns=sample_benchmark_returns_polars,
        **params
    )
    
    # Compare results with higher tolerance due to combined calculations
    compare_dataframes(pd_features, pl_features, rtol=1e-3, atol=1e-5)


# =============================================================================
#  Test Edge Cases
# =============================================================================

def test_edge_cases():
    """Test edge cases to ensure both implementations handle them similarly."""
    # Test with constant prices
    dates = pd.date_range(start='2024-01-01', end='2024-01-10', freq='D')
    constant_price_pd = pd.Series([100.0] * len(dates), index=dates)
    constant_price_pl = pl.from_pandas(constant_price_pd).to_series()
    
    # Test returns with constant prices
    pd_returns = pd_calculate_returns(constant_price_pd, periods=[1, 2])
    pl_returns = pl_calculate_returns(constant_price_pl, periods=[1, 2])
    compare_dataframes(pd_returns, pl_returns)
    
    # Test volatility with constant prices
    pd_vol = pd_calculate_volatility(constant_price_pd, windows=[5])
    pl_vol = pl_calculate_volatility(constant_price_pl, windows=[5])
    compare_dataframes(pd_vol, pl_vol, rtol=1e-3)
    
    # Test with small series
    small_price_pd = pd.Series([100.0, 101.0, 99.0], index=dates[:3])
    small_price_pl = pl.from_pandas(small_price_pd).to_series()
    
    # Test moving averages with small series
    pd_ma = pd_calculate_moving_averages(small_price_pd, windows=[2])
    pl_ma = pl_calculate_moving_averages(small_price_pl, windows=[2])
    compare_dataframes(pd_ma, pl_ma)


if __name__ == '__main__':
    pytest.main([__file__]) 