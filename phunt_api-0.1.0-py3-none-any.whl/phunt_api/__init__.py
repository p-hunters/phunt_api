# -*- coding: utf-8 -*-

import os
import sys
from typing import Optional, Dict, Any, List, Tuple, Callable
import importlib

# Add the current directory to sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# try:
#     from .pytransform import pyarmor_runtime
#     pyarmor_runtime()
# except Exception as e:
#     print(f"Error initializing pyarmor_runtime: {str(e)}")

# 循環インポートを避けるため、PHuntAPIのインポートを削除
# ユーザーは from phunt_api.api import PHuntAPI として直接インポートする必要があります
from .exceptions import AuthenticationError, PHuntAPIException
from .evaluations import ModelEvaluator, generate_evaluation_report
from .evaluations import calculate_mape, calculate_wmape, calculate_smape

# 遅延インポートのためのPHuntAPIプロキシクラス
class _PHuntAPIImportProxy:
    """PHuntAPIクラスの遅延インポートプロキシ"""
    
    def __new__(cls, *args, **kwargs):
        # 実際のPHuntAPIクラスを動的にインポート
        from .api import PHuntAPI as RealPHuntAPI
        # 実際のPHuntAPIインスタンスを作成して返す
        return RealPHuntAPI(*args, **kwargs)

# エクスポートするシンボルとしてプロキシを設定
PHuntAPI = _PHuntAPIImportProxy

__all__ = [
    "PHuntAPI",  # プロキシを通して再度エクスポート
    "AuthenticationError", 
    "PHuntAPIException",
    "ModelEvaluator",
    "generate_evaluation_report",
    "calculate_mape",
    "calculate_wmape",
    "calculate_smape"
]

__version__ = "0.1.0"
