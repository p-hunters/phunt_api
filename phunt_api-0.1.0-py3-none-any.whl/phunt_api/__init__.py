# -*- coding: utf-8 -*-

import os
import sys
from typing import Optional, Dict, Any, List, Tuple, Callable

# Add the current directory to sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# try:
#     from .pytransform import pyarmor_runtime
#     pyarmor_runtime()
# except Exception as e:
#     print(f"Error initializing pyarmor_runtime: {str(e)}")

from .api import PHuntAPI
from .exceptions import AuthenticationError, PHuntAPIException
from .evaluations import ModelEvaluator, generate_evaluation_report
from .evaluations import calculate_mape, calculate_wmape, calculate_smape

__all__ = [
    "PHuntAPI", 
    "AuthenticationError", 
    "PHuntAPIException",
    "ModelEvaluator",
    "generate_evaluation_report",
    "calculate_mape",
    "calculate_wmape",
    "calculate_smape"
]

__version__ = "0.1.0"
