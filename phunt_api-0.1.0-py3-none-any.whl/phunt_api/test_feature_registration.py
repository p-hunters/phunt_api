"""
特徴量登録機能のテスト

このスクリプトは、プラグインシステムの特徴量登録機能をテストします。
"""

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from phunt_api import PHuntAPI

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_feature_registration():
    """
    特徴量登録機能をテストする
    """
    logger.info("=== 特徴量登録機能のテスト ===")
    
    # PHuntAPIの初期化
    logger.info("\n1. PHuntAPIを初期化中...")
    api = PHuntAPI(debug=True)
    logger.info("PHuntAPIを初期化しました。")
    
    # インストール済みのプラグインを一覧表示
    logger.info("\n2. インストール済みのプラグインを一覧表示...")
    plugins = api.list_plugins()
    logger.info(f"プラグインの数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']}: {plugin['info']['description']}")
    
    # サンプルデータを生成
    logger.info("\n3. テスト用のサンプルデータを生成...")
    dates = pd.date_range(start='2022-01-01', periods=100)
    np.random.seed(42)
    close_prices = 100 + np.cumsum(np.random.normal(0, 1, 100))
    sample_data = pd.DataFrame({
        'date': dates,
        'close': close_prices
    }).set_index('date')
    logger.info("サンプルデータを生成しました:")
    logger.info(sample_data.head())
    
    # RSIを計算して特徴量として登録
    logger.info("\n4. RSIを計算して特徴量として登録...")
    try:
        feature_id = api.register_plugin_feature(
            name='test_plugin_rsi',
            plugin_name='sample_feature_plugin',
            function_name='calculate_rsi',
            prices=sample_data['close'],
            window=14
        )
        logger.info(f"特徴量を登録しました: {feature_id}")
        
        # 登録した特徴量を取得
        logger.info("\n5. 登録した特徴量を取得...")
        feature = api.get_feature(feature_id)
        logger.info("登録した特徴量:")
        logger.info(feature.head())
        
        # 特徴量を可視化
        logger.info("\n6. 特徴量を可視化...")
        plt.figure(figsize=(10, 6))
        plt.plot(feature.index, feature['rsi'])
        plt.axhline(y=70, color='r', linestyle='-')
        plt.axhline(y=30, color='g', linestyle='-')
        plt.title('RSI (14)')
        plt.tight_layout()
        plt.savefig('plugin_rsi_feature.png')
        logger.info("特徴量を 'plugin_rsi_feature.png' に保存しました。")
        
    except Exception as e:
        logger.error(f"特徴量の登録/取得中にエラーが発生: {str(e)}", exc_info=True)
    
    # ボリンジャーバンドを計算して特徴量として登録
    logger.info("\n7. ボリンジャーバンドを計算して特徴量として登録...")
    try:
        feature_id = api.register_plugin_feature(
            name='test_plugin_bb',
            plugin_name='sample_feature_plugin',
            function_name='calculate_bollinger_bands',
            prices=sample_data['close'],
            window=20,
            num_std=2.0
        )
        logger.info(f"特徴量を登録しました: {feature_id}")
        
        # 登録した特徴量を取得
        logger.info("\n8. 登録した特徴量を取得...")
        feature = api.get_feature(feature_id)
        logger.info("登録した特徴量:")
        logger.info(feature.head())
        
        # 特徴量を可視化
        logger.info("\n9. 特徴量を可視化...")
        plt.figure(figsize=(10, 6))
        plt.plot(sample_data.index, sample_data['close'], label='Close Price')
        plt.plot(feature.index, feature['bb_middle'], label='Middle Band')
        plt.plot(feature.index, feature['bb_upper'], label='Upper Band')
        plt.plot(feature.index, feature['bb_lower'], label='Lower Band')
        plt.legend()
        plt.title('Price with Bollinger Bands')
        plt.tight_layout()
        plt.savefig('plugin_bb_feature.png')
        logger.info("特徴量を 'plugin_bb_feature.png' に保存しました。")
        
    except Exception as e:
        logger.error(f"特徴量の登録/取得中にエラーが発生: {str(e)}", exc_info=True)
    
    logger.info("\n=== テスト完了 ===")


if __name__ == "__main__":
    test_feature_registration() 