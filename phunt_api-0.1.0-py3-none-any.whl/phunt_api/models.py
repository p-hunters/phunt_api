# -*- coding: utf-8 -*-
"""
Common Pydantic models for PHunt API.
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from datetime import datetime

class DatasetMetadata(BaseModel):
    """
    Metadata for a dataset.
    """
    name: str = Field(..., description="Name of the dataset")
    description: Optional[str] = Field(None, description="Description of the dataset")
    columns: Dict[str, str] = Field(default_factory=dict, description="Dictionary of column names and their types/descriptions")
    frequency: Optional[str] = Field(None, description="Frequency of the data (e.g., '1h', '1d')")
    start_date: Optional[datetime] = Field(None, description="Start date of the data")
    end_date: Optional[datetime] = Field(None, description="End date of the data")
    source: Optional[str] = Field(None, description="Source of the data")
    tags: List[str] = Field(default_factory=list, description="Tags associated with the dataset")
    extra: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
