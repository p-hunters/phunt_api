# -*- coding: utf-8 -*-

class PHuntAPIException(Exception):
    """Base exception class for P-Hunter API"""

class AuthenticationError(PHuntAPIException):
    """Raised when authentication fails"""

class DatasetError(PHuntAPIException):
    """Raised when there's an error with dataset operations"""

class FeatureError(PHuntAPIException):
    """Raised when there's an error with feature operations"""

class ModelError(PHuntAPIException):
    """Raised when there's an error with model operations"""

class TargetError(PHuntAPIException):
    """Raised when there's an error with target operations"""

class CompetitionError(PHuntAPIException):
    """Raised when there's an error with competition operations"""
