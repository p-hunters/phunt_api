# -*- coding: utf-8 -*-

import boto3
import os
from typing import List, Dict
from feast import FeatureStore, FeatureView, Field, FileSource, Entity, ValueType
from feast.data_source import DataSource
from feast.data_format import ParquetFormat
import pandas as pd
from .exceptions import DatasetError
from feast.repo_config import RepoConfig
import sqlalchemy
from sqlalchemy_utils import database_exists, create_database
import pyarrow as pa
import pyarrow.parquet as pq
from pyarrow.fs import S3FileSystem

class FeastManager:
    _instance = None

    def __new__(cls, repo_path):
        if cls._instance is None:
            cls._instance = super(FeastManager, cls).__new__(cls)
            cls._instance._initialize(repo_path)
        return cls._instance

    def _initialize(self, repo_path):
        try:
            self.repo_path = repo_path
            
            # データベース接続情報
            db_host = "feast-registry.c9jdh8eweihk.ap-northeast-1.rds.amazonaws.com"
            db_port = "5432"
            db_user = "postgres"
            db_password = "your_secure_password_here"
            db_name = "feast"

            # データベース作成用のURL
            db_url = f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"

            # データベースが存在しない場合は作成
            # print(f'db_url: {db_url}')
            engine = sqlalchemy.create_engine(db_url)
            # print(f'engine: {engine}')
            if not database_exists(engine.url):
                print(f'database_exists: {database_exists(engine.url)}')
                create_database(engine.url)
            
            self.config = {
                'project': 'p_hunters_feast',
                'provider': 'aws',
                'online_store': {
                    'type': 'redis',
                    'connection_string': 'feast-online-store.gnr8wb.0001.apne1.cache.amazonaws.com:6379,db=0'
                },
                'offline_store': {
                    'type': 'duckdb'
                },
                'registry': {
                    'registry_type': 'sql',
                    'path': db_url,
                    'cache_ttl_seconds': 0,
                    'sqlalchemy_config_kwargs': {
                        'echo': False,
                        'pool_pre_ping': True
                    }
                },
                'entity_key_serialization_version': 2
            }
            self.fs = FeatureStore(config=RepoConfig(**self.config))
            self.typed_views = {}
            self.cache = {}
            print(f'connected to feast server.')
        except Exception as e:
            raise DatasetError(f"Feastマネージャーの初期化中にエラーが発生しました: {str(e)}")
        
    def run_ui(self, background: bool=False, port: int=8888):
        # self.config -> feature_store.yaml
        import yaml
        import subprocess
        with open('./feature_store.yaml', 'w') as f:
            yaml.dump(self.config, f)
        if background:
            subprocess.Popen(['feast', 'ui', '--port', str(port)])
        else:
            subprocess.run(['feast', 'ui', '--port', str(port)])

    def list_feature_views(self, view_type=None):
        try:
            all_views = self.fs.list_feature_views()
            if view_type:
                return [v for v in all_views if v.tags.get('type') == view_type]
            return all_views
        except Exception as e:
            raise DatasetError(f"特徴量ビューのリスト取得中にエラーが発生しました: {str(e)}")

    def create_feature_view(self, name: str, entities: List[str], schema: List[Field], view_type: str, **kwargs):
        try:
            print(kwargs.get("source"))
            if kwargs.get("is_sample", False):
                name = f"{name}_sample"

            feature_view = FeatureView(
                name=name,
                entities=entities,
                schema=schema,
                # tags={"type": view_type, "is_sample": str(kwargs.get("is_sample", False)), "code_path": kwargs.get("code_path", None)},
                tags={"type": view_type, "is_sample": str(kwargs.get("is_sample", False)), "code_path": str(kwargs.get("code_path", None))},
                source=kwargs.get("source"),
                online=False
            )
            print(f'feature_view: {feature_view}')
            self.fs.apply([feature_view])
            print(f'feature_view applied')
            self.typed_views[name] = {"type": view_type, "view": feature_view}
            return feature_view
        except Exception as e:
            raise DatasetError(f"特徴量ビューの作成中にエラーが発生しました: {str(e)}")

    def get_feature_view(self, name: str):
        return self.fs.get_feature_view(name)

    def delete_feature_view(self, name: str):
        self.fs.delete_feature_view(name)
        if name in self.typed_views:
            del self.typed_views[name]

    def add_data_source_from_parquet(self, file_path: str):
        from feast.data_format import ParquetFormat
        parquet_file_source = FileSource(
            file_format=ParquetFormat(),
            path=file_path,
            timestamp_field="timestamp"
        )
        self.fs.apply([parquet_file_source])

    def get_online_features(self, feature_view: str, entity_rows: List[Dict]):
        return self.fs.get_online_features(
            features=[f"{feature_view}:*"],
            entity_rows=entity_rows
        ).to_dict()

    def get_historical_features(self, feature_view: str, entity_df: pd.DataFrame, feature_names: List[str] = None):
        if feature_names is None:
            feature_names = [f.name for f in self.fs.get_feature_view(feature_view).features]
        cache_id = f"{feature_view}_{entity_df['ts'].min()}_{entity_df['ts'].max()}_{'_'.join(feature_names)}"
        print(f'cache_id: {cache_id}')
        if cache_id in self.cache:
            print(f'cache hit: {cache_id}')
            return self.cache[cache_id]
        print(f'feature_names: {feature_names}')
        df = self.fs._provider.offline_store.pull_all_from_table_or_query(
            config = self.fs.config,
            data_source = self.fs.get_feature_view(feature_view).batch_source,
            join_key_columns = self.fs.get_feature_view(feature_view).entities,
            feature_name_columns = feature_names,
            timestamp_field = 'ts',
            start_date = entity_df['ts'].min(),
            end_date = entity_df['ts'].max()
        ).to_df().set_index('ts').sort_index()
        self.cache[cache_id] = df
        return df

def upload_to_s3(name: str, view_type: str, local_path: str, is_sample: bool):
    s3 = boto3.client('s3', region_name='ap-northeast-1',
                      aws_access_key_id=os.environ.get('PHUNT_ACCESS_KEY'),
                      aws_secret_access_key=os.environ.get('PHUNT_SECRET_KEY'),
                      aws_session_token=os.environ.get('PHUNT_SESSION_TOKEN')) 
    bucket_name = 'porory-data'
    prefix = f'phunt/data/{view_type}/{name}'
    if is_sample:
        prefix = f'phunt/sample/{view_type}/{name}'
    file_name = os.path.basename(local_path)
    s3.upload_file(local_path, bucket_name, f'{prefix}/{file_name}')
    print(f'S3にアップロードしました: s3://{bucket_name}/{prefix}/{file_name}')
    return f's3://{bucket_name}/{prefix}/{file_name}'

def upload_script_to_s3(local_path: str, code_hash: str=''):
    s3 = boto3.client('s3', region_name='ap-northeast-1',
                      aws_access_key_id=os.environ.get('PHUNT_ACCESS_KEY'),
                      aws_secret_access_key=os.environ.get('PHUNT_SECRET_KEY'),
                      aws_session_token=os.environ.get('PHUNT_SESSION_TOKEN')) 
    bucket_name = 'porory-data'
    prefix = f'phunt/scripts/{code_hash}'
    file_name = os.path.basename(local_path)
    s3.upload_file(local_path, bucket_name, f'{prefix}/{file_name}')
    print(f'S3にアップロードしました: s3://{bucket_name}/{prefix}/{file_name}')
    return f's3:///{bucket_name}/{prefix}/{file_name}'

def read_s3_file(s3_path: str) -> str:
    s3 = boto3.client('s3', region_name='ap-northeast-1',
                      aws_access_key_id=os.environ.get('PHUNT_ACCESS_KEY'),
                      aws_secret_access_key=os.environ.get('PHUNT_SECRET_KEY'),
                      aws_session_token=os.environ.get('PHUNT_SESSION_TOKEN')) 
    bucket_name, key = s3_path.replace('s3://', '').split('/', 1)
    return s3.get_object(Bucket=bucket_name, Key=key)['Body'].read().decode('utf-8')

def create_from_local_base(feast_manager: FeastManager, name: str, local_path: str, view_type: str, sample_ratio: float, code_path: str = None):
    try:
        os.makedirs('/tmp/' + os.path.dirname(local_path), exist_ok=True)
        df = pd.read_parquet(local_path)
        df['ts'] = pd.to_datetime(df['timestamp'] * 1000000, utc=True)
        tmp_path = '/tmp/' + local_path
        df.to_parquet(tmp_path, index=False)
        
        # サンプルデータを作成
        sample_df = df.sample(frac=sample_ratio)
        sample_tmp_path = '/tmp/' + local_path.replace('.parquet', '_sample.parquet')
        sample_df.to_parquet(sample_tmp_path, index=False)

        # Create schema excluding timestamp fields
        from feast import Field, Entity, FeatureView, FileSource, ValueType
        from feast.types import Float32, Float64, Int32, Int64, String
        
        # Create dummy entity with value_type
        dummy_entity = Entity(
            name="__dummy",
            value_type=ValueType.STRING,
            description="Dummy entity for feature view"
        )
        
        def get_feast_type(dtype):
            dtype_str = str(dtype).lower()
            if 'float32' in dtype_str:
                return Float32
            elif 'float64' in dtype_str or 'float' in dtype_str:
                return Float64
            elif 'int32' in dtype_str:
                return Int32
            elif 'int64' in dtype_str or 'int' in dtype_str:
                return Int64
            else:
                return String

        # Create schema excluding timestamp fields
        schema = []
        for col in df.columns:
            if col not in ['ts', 'timestamp']:
                try:
                    feast_type = get_feast_type(df[col].dtype)
                    schema.append(Field(name=col, dtype=feast_type))
                except Exception as e:
                    print(f"Warning: Skipping column {col} due to type conversion error: {e}")

        for is_sample in [True, False]:
            _local_path = sample_tmp_path if is_sample else tmp_path
            s3_path = upload_to_s3(name, view_type, _local_path, is_sample)
            print(f's3_path: {s3_path}')
            
            current_name = f"{name}_sample" if is_sample else name

            # Create FileSource with correct configuration
            print(f'FileSource: {s3_path}')
            source = FileSource(
                path=s3_path,
                timestamp_field="ts",
                file_format=ParquetFormat()
            )

            print(f'create_feature_view: {source}')
            # Add dummy entity to entities list
            view = feast_manager.create_feature_view(name, entities=[dummy_entity], schema=schema, view_type=view_type, source=source, is_sample=is_sample, code_path=code_path)
            print(f'view: {view}')
        
        return f"{view_type} '{name}' created successfully"
    except Exception as e:
        raise DatasetError(f"{view_type}の作成中にエラーが発生しました: {str(e)}")


def query_s3_duckdb(path_to_parquet: str, creds: Dict):
    import duckdb
    print(f'creds!!!: {creds}')
    if creds is None:
        creds = {}
    try:
        # Connect to DuckDB and load Parquet file
        conn = duckdb.connect()
        conn.execute("INSTALL httpfs")
        conn.execute("LOAD httpfs")
        conn.execute("SET TimeZone='UTC'")
        conn.execute("SET s3_region='ap-northeast-1'")
        conn.execute(f"SET s3_access_key_id='{creds['aws_access_key_id']}'")
        conn.execute(f"SET s3_secret_access_key='{creds['aws_secret_access_key']}'")
        conn.execute(f"SET s3_session_token='{creds['aws_session_token']}'")
        conn.execute(f"CREATE TABLE data AS SELECT ts FROM read_parquet('{path_to_parquet}')")
        # Query data
        result = conn.execute("SELECT ts FROM data").df()
        result['ts'] = pd.to_datetime(result['ts'], utc=True)
        result['ts'] = result['ts'].dt.tz_convert('UTC')
        # Cleanup
        conn.close()
        return result
    except Exception as e:
        print(f"Error querying data from S3: {e}")
        return None