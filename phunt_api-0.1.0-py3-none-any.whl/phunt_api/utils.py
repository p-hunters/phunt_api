import boto3
import os
from typing import List, Dict, Any, Optional
import pandas as pd
import threading
import pickle
import json
import hashlib
import inspect
from typing import Callable


def upload_script_to_s3(local_path: str, code_hash: str='') -> str:
    s3 = boto3.client('s3', region_name='ap-northeast-1',
                      aws_access_key_id=os.environ.get('PHUNT_ACCESS_KEY'),
                      aws_secret_access_key=os.environ.get('PHUNT_SECRET_KEY'),
                      aws_session_token=os.environ.get('PHUNT_SESSION_TOKEN')) 
    bucket_name = 'porory-data'
    prefix = f'phunt/scripts/{code_hash}'
    file_name = os.path.basename(local_path)
    s3.upload_file(local_path, bucket_name, f'{prefix}/{file_name}')
    return f's3://{bucket_name}/{prefix}/{file_name}'

def read_s3_file(s3_path: str) -> str:
    s3 = boto3.client('s3', region_name='ap-northeast-1',
                      aws_access_key_id=os.environ.get('PHUNT_ACCESS_KEY'),
                      aws_secret_access_key=os.environ.get('PHUNT_SECRET_KEY'),
                      aws_session_token=os.environ.get('PHUNT_SESSION_TOKEN')) 
    bucket_name, key = s3_path.replace('s3://', '').split('/', 1)
    return s3.get_object(Bucket=bucket_name, Key=key)['Body'].read().decode('utf-8')

def query_s3_duckdb(path_to_parquet: str, creds: Dict):
    import duckdb
    print(f'creds!!!: {creds}')
    if creds is None:
        creds = {}
    try:
        # Connect to DuckDB and load Parquet file
        conn = duckdb.connect()
        conn.execute("INSTALL httpfs")
        conn.execute("LOAD httpfs")
        conn.execute("SET TimeZone='UTC'")
        conn.execute("SET s3_region='ap-northeast-1'")
        conn.execute(f"SET s3_access_key_id='{creds['aws']['aws_access_key_id']}'")
        conn.execute(f"SET s3_secret_access_key='{creds['aws']['aws_secret_access_key']}'")
        conn.execute(f"SET s3_session_token='{creds['aws']['aws_session_token']}'")
        conn.execute(f"CREATE TABLE data AS SELECT ts FROM read_parquet('{path_to_parquet}')")
        # Query data
        result = conn.execute("SELECT ts FROM data").df()
        result['ts'] = pd.to_datetime(result['ts'], utc=True)
        result['ts'] = result['ts'].dt.tz_convert('UTC')
        # Cleanup
        conn.close()
        return result
    except Exception as e:
        print(f"Error querying data from S3: {e}")
        return None

def calculate_hash(obj) -> str:
    """
    Calculate a consistent hash for different types of objects, including pandas DataFrames.
    
    Args:
        obj: Any Python object to hash
        
    Returns:
        str: A hash string representing the object's content
    """
    import hashlib
    import json
    import pandas as pd
    import numpy as np
    
    def _handle_item(item):
        if isinstance(item, (str, int, float, bool, type(None))):
            return str(item)
        elif isinstance(item, (list, tuple)):
            return [_handle_item(i) for i in item]
        elif isinstance(item, dict):
            return {k: _handle_item(v) for k, v in sorted(item.items())}
        elif isinstance(item, pd.DataFrame):
            # For DataFrames, hash a combination of:
            # 1. Column names (to catch schema differences)
            # 2. DataFrame shape
            # 3. String representation of data (with NaN handling)
            
            # Convert to a standard format with specific NaN handling
            df_dict = {
                'columns': list(item.columns),
                'shape': item.shape,
                # 安全に型情報を取得する
                'dtypes': {}
            }
            
            # 各列のデータ型を安全に取得
            for col in item.columns:
                col_value = item[col]
                # 列の値がDataFrameかSeriesの場合
                if isinstance(col_value, (pd.DataFrame, pd.Series)):
                    # 入れ子のDataFrameやSeriesの場合、特別な処理を行う
                    df_dict['dtypes'][str(col)] = f"complex_type:{type(col_value).__name__}"
                else:
                    try:
                        # 通常のデータ型を取得
                        df_dict['dtypes'][str(col)] = str(item[col].dtype)
                    except AttributeError:
                        # dtype属性がない場合、型名だけ記録
                        df_dict['dtypes'][str(col)] = f"other_type:{type(item[col]).__name__}"
            
            try:
                # CSVへの変換を試みる
                df_dict['data'] = item.fillna('__NA__').to_csv(index=True)
            except Exception as e:
                # 失敗した場合、代替方法
                df_dict['data_summary'] = f"DataFrame conversion failed: {str(e)}"
                df_dict['data_head'] = str(item.head(5))
                df_dict['data_tail'] = str(item.tail(5))
            
            return _handle_item(df_dict)
        elif isinstance(item, pd.Series):
            # Seriesの場合も安全に処理
            series_dict = {
                'name': item.name,
                'shape': item.shape,
                'dtype': str(item.dtype),
                'values': item.fillna('__NA__').to_list()[:100]  # 長すぎる場合は先頭100件のみ
            }
            return _handle_item(series_dict)
        elif isinstance(item, np.ndarray):
            return _handle_item(item.tolist())
        # funcの場合はソースコードを文字列に変換してハッシュ化
        elif isinstance(item, Callable):
            try:
                return _handle_item(inspect.getsource(item))
            except (IOError, TypeError):
                # ソースコードが取得できない場合（ビルトイン関数など）
                return f"callable:{item.__module__}.{item.__qualname__}" if hasattr(item, '__qualname__') else str(item)
        else:
            # その他の型は文字列表現を使用
            try:
                return str(item)
            except Exception:
                # どうしても文字列化できない場合
                return f"unhashable:{type(item).__name__}"
    
    # Process the object
    processed_obj = _handle_item(obj)
    
    # Convert to JSON string for hashing
    json_str = json.dumps(processed_obj, sort_keys=True)
    
    # Calculate hash
    return hashlib.md5(json_str.encode('utf-8')).hexdigest()

class RedisCache:
    """Redisを使用したキャッシュクライアント"""
    
    def __init__(self, connection_string: str, namespace: str = "phunt_cache", db: int = 0):
        """
        Args:
            connection_string: Redis接続文字列 (host:port)
            namespace: キャッシュのキー接頭辞
            db: Redisデータベース番号
        """
        # 接続文字列からホストとポートを抽出
        if ',' in connection_string:
            connection_string = connection_string.split(',')[0]
        
        host, port = connection_string.split(':')
        self.client = redis.Redis(host=host, port=int(port), db=db)
        self.namespace = namespace
        
    def _make_key(self, key: str) -> str:
        """キーにネームスペースを追加"""
        return f"{self.namespace}:{key}"
    
    def set(self, key: str, value: Any, expire: Optional[int] = None) -> bool:
        """
        キャッシュにデータを設定
        
        Args:
            key: キャッシュキー
            value: キャッシュする値（シリアライズ可能なオブジェクト）
            expire: キャッシュの有効期限（秒）
            
        Returns:
            成功した場合はTrue
        """
        try:
            # 値をバイトにシリアライズ
            serialized = pickle.dumps(value)
            full_key = self._make_key(key)
            
            if expire:
                return self.client.setex(full_key, expire, serialized)
            else:
                return self.client.set(full_key, serialized)
        except Exception as e:
            print(f"Redis cache set error: {str(e)}")
            return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        キャッシュからデータを取得
        
        Args:
            key: キャッシュキー
            default: キーが存在しない場合のデフォルト値
            
        Returns:
            キャッシュされた値、またはデフォルト値
        """
        try:
            full_key = self._make_key(key)
            data = self.client.get(full_key)
            
            if data:
                return pickle.loads(data)
            return default
        except Exception as e:
            print(f"Redis cache get error: {str(e)}")
            return default
    
    def exists(self, key: str) -> bool:
        """
        キーが存在するかどうかを確認
        
        Args:
            key: キャッシュキー
            
        Returns:
            キーが存在する場合はTrue
        """
        try:
            full_key = self._make_key(key)
            return bool(self.client.exists(full_key))
        except Exception as e:
            print(f"Redis cache exists error: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """
        キャッシュからデータを削除
        
        Args:
            key: キャッシュキー
            
        Returns:
            成功した場合はTrue
        """
        try:
            full_key = self._make_key(key)
            return bool(self.client.delete(full_key))
        except Exception as e:
            print(f"Redis cache delete error: {str(e)}")
            return False
    
    def clear(self, pattern: str = "*") -> int:
        """
        パターンに一致するすべてのキャッシュキーを削除
        
        Args:
            pattern: 削除するキーのパターン
            
        Returns:
            削除されたキーの数
        """
        try:
            full_pattern = self._make_key(pattern)
            keys = self.client.keys(full_pattern)
            if keys:
                return self.client.delete(*keys)
            return 0
        except Exception as e:
            print(f"Redis cache clear error: {str(e)}")
            return 0
    
    def __contains__(self, key: str) -> bool:
        """
        `in` 演算子をサポート
        
        Args:
            key: キャッシュキー
            
        Returns:
            キーが存在する場合はTrue
        """
        return self.exists(key)
    
    def keys(self, pattern: str = "*") -> list:
        """
        パターンに一致するすべてのキーを取得
        
        Args:
            pattern: キーのパターン
            
        Returns:
            キーのリスト
        """
        try:
            full_pattern = self._make_key(pattern)
            keys = self.client.keys(full_pattern)
            return [k.decode('utf-8').replace(f"{self.namespace}:", "") for k in keys]
        except Exception as e:
            print(f"Redis cache keys error: {str(e)}")
            return []

class JsonFileCache:
    """ローカルJSONファイルをベースにしたキャッシュ実装。
    
    Redisキャッシュの代わりに使用するシンプルなローカルファイルベースのキャッシュです。
    ユーザー名ごとに異なるJSONファイルを使用します。
    """
    
    def __init__(self, cache_dir: str = "/tmp/phunt_cache", namespace: str = "default"):
        """JsonFileCacheの初期化
        
        Args:
            cache_dir: キャッシュファイルを保存するディレクトリ
            namespace: 名前空間（通常はユーザー名を指定）
        """
        self.cache_dir = cache_dir
        self.namespace = namespace
        self.cache_file = os.path.join(cache_dir, f"{namespace}.json")
        self.lock = threading.Lock()
        
        # キャッシュディレクトリがなければ作成
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir, exist_ok=True)
        
        # キャッシュファイルがなければ空のキャッシュを作成
        if not os.path.exists(self.cache_file):
            self._write_cache({})
    
    def _read_cache(self) -> Dict[str, Any]:
        """キャッシュファイルから全データを読み込む"""
        try:
            with open(self.cache_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            # 読み込みエラーの場合は空のキャッシュを返す
            return {}
    
    def _write_cache(self, cache_data: Dict[str, Any]) -> None:
        """キャッシュデータをファイルに書き込む"""
        with open(self.cache_file, 'w') as f:
            json.dump(cache_data, f)
    
    def get(self, key: str, default: Any = None) -> Any:
        """キャッシュからキーに対応する値を取得
        
        Args:
            key: 取得するキャッシュキー
            default: キーが存在しない場合のデフォルト値
            
        Returns:
            キャッシュ内の値またはデフォルト値
        """
        with self.lock:
            cache_data = self._read_cache()
            return cache_data.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """キャッシュにキーと値のペアを保存
        
        Args:
            key: キャッシュキー
            value: 保存する値
        """
        with self.lock:
            cache_data = self._read_cache()
            cache_data[key] = value
            self._write_cache(cache_data)
    
    def delete(self, key: str) -> None:
        """キャッシュからキーを削除
        
        Args:
            key: 削除するキャッシュキー
        """
        with self.lock:
            cache_data = self._read_cache()
            if key in cache_data:
                del cache_data[key]
                self._write_cache(cache_data)
    
    def exists(self, key: str) -> bool:
        """キーがキャッシュに存在するかを確認
        
        Args:
            key: 確認するキャッシュキー
            
        Returns:
            キーが存在する場合はTrue、それ以外はFalse
        """
        with self.lock:
            cache_data = self._read_cache()
            return key in cache_data
    
    def clear(self) -> None:
        """キャッシュを全てクリア"""
        with self.lock:
            self._write_cache({})
    
    def keys(self) -> List[str]:
        """全てのキャッシュキーのリストを返す
        
        Returns:
            キャッシュ内の全てのキーのリスト
        """
        with self.lock:
            cache_data = self._read_cache()
            return list(cache_data.keys())
    
    def __contains__(self, key: str) -> bool:
        """'in'演算子のサポート"""
        return self.exists(key)

class PickleFileCache:
    """Pickleを使用したファイルベースのキャッシュ
    
    JSONでシリアライズできないオブジェクト（pandas DataFrameなど）のキャッシュに適しています。
    """
    
    def __init__(self, cache_dir: str = "/tmp/phunt_cache", namespace: str = "default"):
        """PickleFileCache初期化
        
        Args:
            cache_dir: キャッシュファイルを格納するディレクトリ
            namespace: キャッシュの名前空間（ユーザーごとに分けるため）
        """
        import os
        import threading
        import getpass
        
        # 現在のユーザー名を取得してデフォルト名前空間に使用
        current_user = getpass.getuser()
        self.namespace = f"{namespace}_{current_user}"
        
        # キャッシュディレクトリの設定
        self.cache_dir = os.path.expanduser(cache_dir)
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # キャッシュファイルのパス
        self.cache_file = os.path.join(self.cache_dir, f"{self.namespace}.pickle")
        
        # スレッドセーフ操作のためのロック
        self.lock = threading.RLock()
    
    def _read_cache(self) -> Dict[str, Any]:
        """キャッシュファイルから全データを読み込む"""
        try:
            with open(self.cache_file, 'rb') as f:
                return pickle.load(f)
        except (pickle.PickleError, FileNotFoundError):
            # 読み込みエラーの場合は空のキャッシュを返す
            return {}
    
    def _write_cache(self, cache_data: Dict[str, Any]) -> None:
        """キャッシュデータをファイルに書き込む"""
        with open(self.cache_file, 'wb') as f:
            pickle.dump(cache_data, f)
    
    def get(self, key: str, default: Any = None) -> Any:
        """キャッシュからキーに対応する値を取得
        
        Args:
            key: 取得するキャッシュキー
            default: キーが存在しない場合のデフォルト値
            
        Returns:
            キャッシュ内の値またはデフォルト値
        """
        with self.lock:
            cache_data = self._read_cache()
            return cache_data.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """キャッシュにキーと値のペアを保存
        
        Args:
            key: キャッシュキー
            value: 保存する値
        """
        with self.lock:
            cache_data = self._read_cache()
            cache_data[key] = value
            self._write_cache(cache_data)
    
    def delete(self, key: str) -> None:
        """キャッシュからキーを削除
        
        Args:
            key: 削除するキャッシュキー
        """
        with self.lock:
            cache_data = self._read_cache()
            if key in cache_data:
                del cache_data[key]
                self._write_cache(cache_data)
    
    def exists(self, key: str) -> bool:
        """キーがキャッシュに存在するかを確認
        
        Args:
            key: 確認するキャッシュキー
            
        Returns:
            キーが存在する場合はTrue、それ以外はFalse
        """
        with self.lock:
            cache_data = self._read_cache()
            return key in cache_data
    
    def clear(self) -> None:
        """キャッシュを全てクリア"""
        with self.lock:
            self._write_cache({})
    
    def keys(self) -> List[str]:
        """キャッシュ内の全キーのリストを取得
        
        Returns:
            キャッシュキーのリスト
        """
        with self.lock:
            cache_data = self._read_cache()
            return list(cache_data.keys())
    
    def __contains__(self, key: str) -> bool:
        """'in'演算子のサポート"""
        return self.exists(key)