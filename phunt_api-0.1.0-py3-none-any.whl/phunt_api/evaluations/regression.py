import os
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    mean_squared_error, mean_absolute_error, r2_score
)
from typing import Dict, Optional

logger = logging.getLogger(__name__)

def _generate_regression_report(
    evaluator, 
    X_train: pd.DataFrame, 
    X_val: pd.DataFrame, 
    y_train: pd.Series, 
    y_val: pd.Series,
    timestamp: str,
    run_id: str = None,
    feature_descriptions: Dict[str, str] = None
) -> str:
    """
    回帰モデルの評価レポートを生成する

    パラメータ:
        evaluator: ModelEvaluatorインスタンス
        X_train: 学習データの特徴量
        X_val: 検証データの特徴量
        y_train: 学習データの目的変数
        y_val: 検証データの目的変数
        timestamp: レポート生成日時
        run_id: 実行ID (MLflowなどの実験管理ツールのID)
        feature_descriptions: 特徴量の説明 {特徴量名: 説明} の辞書

    戻り値:
        生成されたレポート内容 (Markdown形式)
    """
    # モデル名と作成日時
    report = f"# {evaluator.model_name} 評価レポート\n\n"
    report += f"作成日時: {timestamp.replace('_', ' ')}\n\n"
    
    # 実行IDがあれば追加
    if run_id:
        report += f"実行ID: {run_id}\n\n"
    
    # 銘柄情報
    if evaluator.symbol:
        report += f"銘柄: {evaluator.symbol}\n\n"
    
    # 時間粒度
    if evaluator.granularity:
        report += f"時間粒度: {evaluator.granularity}\n\n"
    
    # 予測先行時間
    if evaluator.target_minutes_ahead:
        report += f"予測先行時間: {evaluator.target_minutes_ahead}分\n\n"
    
    # モデル概要
    report += "## 1. モデル概要\n\n"
    report += f"モデル名: {evaluator.model_name}\n\n"
    report += f"モデルタイプ: {type(evaluator.model).__name__}\n\n"
    report += f"タスクタイプ: 回帰\n\n"
    
    # データセット概要
    report += "## 2. データセット概要\n\n"
    
    # 学習期間と検証期間
    if evaluator.start_date and evaluator.end_date:
        report += f"学習期間: {evaluator.start_date} から {evaluator.end_date}\n\n"
    
    if evaluator.validation_year:
        report += f"検証期間: {evaluator.validation_year}年\n\n"
    
    # データサイズ
    report += f"学習データサイズ: {X_train.shape[0]} サンプル\n\n"
    report += f"検証データサイズ: {X_val.shape[0]} サンプル\n\n"
    
    # 目的変数の詳細
    report += "## 3. 目的変数の詳細\n\n"
    report += f"目的変数名: {evaluator.target_column}\n\n"
    
    # 目的変数の統計量
    train_target_stats = {
        "mean": y_train.mean(),
        "std": y_train.std(),
        "min": y_train.min(),
        "max": y_train.max(),
        "median": y_train.median()
    }
    
    val_target_stats = {
        "mean": y_val.mean(),
        "std": y_val.std(),
        "min": y_val.min(),
        "max": y_val.max(),
        "median": y_val.median()
    }
    
    # 統計量のテーブル
    report += "### 目的変数の統計量\n\n"
    report += "| 統計量 | 学習データ | 検証データ |\n"
    report += "|-------|----------|----------|\n"
    report += f"| 平均値 | {train_target_stats['mean']:.4f} | {val_target_stats['mean']:.4f} |\n"
    report += f"| 標準偏差 | {train_target_stats['std']:.4f} | {val_target_stats['std']:.4f} |\n"
    report += f"| 最小値 | {train_target_stats['min']:.4f} | {val_target_stats['min']:.4f} |\n"
    report += f"| 最大値 | {train_target_stats['max']:.4f} | {val_target_stats['max']:.4f} |\n"
    report += f"| 中央値 | {train_target_stats['median']:.4f} | {val_target_stats['median']:.4f} |\n\n"
    
    # 目的変数の分布を可視化
    target_dist_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_target_distribution.png")
    
    try:
        plt.figure(figsize=(12, 5))
        
        # 学習データの分布
        plt.subplot(1, 2, 1)
        plt.hist(y_train, bins=30, alpha=0.7)
        plt.axvline(train_target_stats['mean'], color='r', linestyle='--', label=f"平均値: {train_target_stats['mean']:.2f}")
        plt.axvline(train_target_stats['median'], color='g', linestyle='--', label=f"中央値: {train_target_stats['median']:.2f}")
        plt.legend()
        plt.title("学習データの目的変数分布")
        plt.xlabel(evaluator.target_column)
        plt.ylabel("頻度")
        
        # 検証データの分布
        plt.subplot(1, 2, 2)
        plt.hist(y_val, bins=30, alpha=0.7)
        plt.axvline(val_target_stats['mean'], color='r', linestyle='--', label=f"平均値: {val_target_stats['mean']:.2f}")
        plt.axvline(val_target_stats['median'], color='g', linestyle='--', label=f"中央値: {val_target_stats['median']:.2f}")
        plt.legend()
        plt.title("検証データの目的変数分布")
        plt.xlabel(evaluator.target_column)
        plt.ylabel("頻度")
        
        plt.tight_layout()
        plt.savefig(target_dist_fig_path)
        plt.close()
        
        report += f"![目的変数の分布]({os.path.basename(target_dist_fig_path)})\n\n"
    except Exception as e:
        logger.warning(f"目的変数の分布の可視化に失敗しました: {e}")
    
    # データ分割方法
    report += "## 4. データ分割方法\n\n"
    
    if evaluator.validation_year:
        report += f"時系列ベースの分割を使用\n\n"
        report += f"検証データ: {evaluator.validation_year}年のデータ\n\n"
    else:
        report += "ランダム分割を使用\n\n"
    
    # 特徴量の詳細
    report += "## 5. 特徴量の詳細\n\n"
    
    if evaluator.features_to_use:
        report += f"特徴量数: {len(evaluator.features_to_use)}\n\n"
        
        # 特徴量リスト
        report += "### 使用された特徴量\n\n"
        
        if feature_descriptions:
            report += "| 特徴量名 | 説明 |\n"
            report += "|---------|------|\n"
            
            for feature in evaluator.features_to_use:
                description = feature_descriptions.get(feature, "")
                report += f"| {feature} | {description} |\n"
        else:
            for feature in evaluator.features_to_use:
                report += f"- {feature}\n"
    else:
        report += f"特徴量数: {X_train.shape[1]}\n\n"
        
        # 特徴量リスト
        report += "### 使用された特徴量\n\n"
        
        if feature_descriptions:
            report += "| 特徴量名 | 説明 |\n"
            report += "|---------|------|\n"
            
            for feature in X_train.columns:
                description = feature_descriptions.get(feature, "")
                report += f"| {feature} | {description} |\n"
        else:
            for feature in X_train.columns:
                report += f"- {feature}\n"
    
    # モデルの詳細
    report += "\n## 6. モデルの詳細\n\n"
    
    # モデルの種類
    report += f"モデルタイプ: {type(evaluator.model).__name__}\n\n"
    
    # ハイパーパラメータ
    report += "### ハイパーパラメータ\n\n"
    
    try:
        hyperparams = evaluator.model.get_params()
        report += "| パラメータ | 値 |\n"
        report += "|-----------|----|\n"
        
        for param, value in hyperparams.items():
            report += f"| {param} | {value} |\n"
    except Exception as e:
        logger.warning(f"ハイパーパラメータ情報の取得に失敗しました: {e}")
        report += "このモデルでは、ハイパーパラメータ情報を取得できませんでした。\n\n"
    
    # パフォーマンス評価
    report += "\n## 7. パフォーマンス評価\n\n"
    
    # 予測の実行
    try:
        y_train_pred = evaluator.model.predict(X_train)
        y_val_pred = evaluator.model.predict(X_val)
        
        # MSE, RMSE, MAE, R²を計算
        train_mse = mean_squared_error(y_train, y_train_pred)
        train_rmse = np.sqrt(train_mse)
        train_mae = mean_absolute_error(y_train, y_train_pred)
        train_r2 = r2_score(y_train, y_train_pred)
        
        val_mse = mean_squared_error(y_val, y_val_pred)
        val_rmse = np.sqrt(val_mse)
        val_mae = mean_absolute_error(y_val, y_val_pred)
        val_r2 = r2_score(y_val, y_val_pred)
        
        # 指標テーブル
        report += "### 評価指標\n\n"
        report += "| 指標 | 学習データ | 検証データ |\n"
        report += "|------|----------|----------|\n"
        report += f"| MSE | {train_mse:.4f} | {val_mse:.4f} |\n"
        report += f"| RMSE | {train_rmse:.4f} | {val_rmse:.4f} |\n"
        report += f"| MAE | {train_mae:.4f} | {val_mae:.4f} |\n"
        report += f"| R² | {train_r2:.4f} | {val_r2:.4f} |\n"
        
        # カスタム指標があれば追加
        if evaluator.custom_metrics:
            for metric_name, metric_func in evaluator.custom_metrics.items():
                try:
                    train_metric = metric_func(y_train, y_train_pred)
                    val_metric = metric_func(y_val, y_val_pred)
                    report += f"| {metric_name} | {train_metric:.4f} | {val_metric:.4f} |\n"
                except Exception as e:
                    logger.warning(f"{metric_name}の計算中にエラーが発生しました: {e}")
        
        # 可視化: 予測値 vs 実際値の散布図
        scatter_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_prediction_scatter.png")
        
        try:
            plt.figure(figsize=(12, 5))
            
            # 学習データ
            plt.subplot(1, 2, 1)
            plt.scatter(y_train, y_train_pred, alpha=0.5)
            plt.plot([y_train.min(), y_train.max()], [y_train.min(), y_train.max()], 'k--', lw=2)
            plt.title("学習データ: 予測値 vs 実際値")
            plt.xlabel("実際値")
            plt.ylabel("予測値")
            plt.grid(True)
            plt.annotate(f"R² = {train_r2:.4f}", xy=(0.05, 0.95), xycoords='axes fraction')
            
            # 検証データ
            plt.subplot(1, 2, 2)
            plt.scatter(y_val, y_val_pred, alpha=0.5)
            plt.plot([y_val.min(), y_val.max()], [y_val.min(), y_val.max()], 'k--', lw=2)
            plt.title("検証データ: 予測値 vs 実際値")
            plt.xlabel("実際値")
            plt.ylabel("予測値")
            plt.grid(True)
            plt.annotate(f"R² = {val_r2:.4f}", xy=(0.05, 0.95), xycoords='axes fraction')
            
            plt.tight_layout()
            plt.savefig(scatter_fig_path)
            plt.close()
            
            report += f"\n![予測値 vs 実際値の散布図]({os.path.basename(scatter_fig_path)})\n\n"
        except Exception as e:
            logger.warning(f"散布図の可視化に失敗しました: {e}")
        
        # 可視化: 残差プロット
        residual_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_residual_plot.png")
        
        try:
            # 残差を計算
            train_residuals = y_train - y_train_pred
            val_residuals = y_val - y_val_pred
            
            plt.figure(figsize=(15, 10))
            
            # 学習データの残差散布図
            plt.subplot(2, 2, 1)
            plt.scatter(y_train_pred, train_residuals, alpha=0.5)
            plt.axhline(y=0, color='r', linestyle='--')
            plt.title("学習データ: 残差プロット")
            plt.xlabel("予測値")
            plt.ylabel("残差")
            plt.grid(True)
            
            # 検証データの残差散布図
            plt.subplot(2, 2, 2)
            plt.scatter(y_val_pred, val_residuals, alpha=0.5)
            plt.axhline(y=0, color='r', linestyle='--')
            plt.title("検証データ: 残差プロット")
            plt.xlabel("予測値")
            plt.ylabel("残差")
            plt.grid(True)
            
            # 学習データの残差ヒストグラム
            plt.subplot(2, 2, 3)
            plt.hist(train_residuals, bins=30, alpha=0.7)
            plt.axvline(x=0, color='r', linestyle='--')
            plt.title("学習データ: 残差分布")
            plt.xlabel("残差")
            plt.ylabel("頻度")
            plt.grid(True)
            
            # 検証データの残差ヒストグラム
            plt.subplot(2, 2, 4)
            plt.hist(val_residuals, bins=30, alpha=0.7)
            plt.axvline(x=0, color='r', linestyle='--')
            plt.title("検証データ: 残差分布")
            plt.xlabel("残差")
            plt.ylabel("頻度")
            plt.grid(True)
            
            plt.tight_layout()
            plt.savefig(residual_fig_path)
            plt.close()
            
            report += f"![残差プロット]({os.path.basename(residual_fig_path)})\n\n"
        except Exception as e:
            logger.warning(f"残差プロットの可視化に失敗しました: {e}")
        
    except Exception as e:
        logger.error(f"パフォーマンス評価中にエラーが発生しました: {e}")
        report += "モデルの予測実行中にエラーが発生したため、パフォーマンス評価を完了できませんでした。\n\n"
    
    # 特徴量の重要度
    report += "\n## 8. 特徴量の重要度\n\n"
    
    try:
        # モデルに feature_importances_ 属性があるか確認
        if hasattr(evaluator.model, 'feature_importances_'):
            importances = evaluator.model.feature_importances_
            feature_names = evaluator.features_to_use if evaluator.features_to_use else X_train.columns
            
            # 重要度でソート
            indices = np.argsort(importances)[::-1]
            
            # 上位N個の特徴量を表示
            top_n = min(20, len(feature_names))
            
            report += "### トップ特徴量\n\n"
            report += "| 特徴量 | 重要度 |\n"
            report += "|-------|-------|\n"
            
            for i in range(top_n):
                idx = indices[i]
                report += f"| {feature_names[idx]} | {importances[idx]:.4f} |\n"
            
            # 可視化: 特徴量の重要度
            fi_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_feature_importance.png")
            
            plt.figure(figsize=(10, 6))
            plt.title("特徴量の重要度")
            plt.bar(range(top_n), importances[indices][:top_n], align="center")
            plt.xticks(range(top_n), [feature_names[i] for i in indices][:top_n], rotation=90)
            plt.xlim([-1, top_n])
            plt.tight_layout()
            plt.savefig(fi_fig_path)
            plt.close()
            
            report += f"\n![特徴量の重要度]({os.path.basename(fi_fig_path)})\n\n"
        
        # coef_ 属性を持つ線形モデルの場合
        elif hasattr(evaluator.model, 'coef_'):
            coefs = evaluator.model.coef_
            feature_names = evaluator.features_to_use if evaluator.features_to_use else X_train.columns
            
            # 係数の絶対値でソート
            abs_coefs = np.abs(coefs)
            indices = np.argsort(abs_coefs)[::-1]
            
            # 上位N個の特徴量を表示
            top_n = min(20, len(feature_names))
            
            report += "### トップ特徴量 (係数の絶対値)\n\n"
            report += "| 特徴量 | 係数 | 絶対値 |\n"
            report += "|-------|------|-------|\n"
            
            for i in range(top_n):
                idx = indices[i]
                report += f"| {feature_names[idx]} | {coefs[idx]:.4f} | {abs_coefs[idx]:.4f} |\n"
            
            # 可視化: 特徴量の重要度
            fi_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_feature_importance.png")
            
            plt.figure(figsize=(10, 6))
            plt.title("特徴量の重要度 (係数の絶対値)")
            plt.bar(range(top_n), abs_coefs[indices][:top_n], align="center")
            plt.xticks(range(top_n), [feature_names[i] for i in indices][:top_n], rotation=90)
            plt.xlim([-1, top_n])
            plt.tight_layout()
            plt.savefig(fi_fig_path)
            plt.close()
            
            report += f"\n![特徴量の重要度]({os.path.basename(fi_fig_path)})\n\n"
        else:
            report += "このモデルは、特徴量の重要度の情報を提供していません。\n\n"
    except Exception as e:
        logger.warning(f"特徴量の重要度の計算中にエラーが発生しました: {e}")
        report += "特徴量の重要度の計算中にエラーが発生しました。\n\n"
    
    # 結論と改善案
    report += "\n## 9. 結論と改善案\n\n"
    
    # 結論
    report += "### 結論\n\n"
    
    # パフォーマンス情報があれば追加
    if 'val_r2' in locals():
        report += f"このモデルは検証データに対して R² = {val_r2:.4f} を達成しました。"
        
        if 'val_rmse' in locals() and 'val_mae' in locals():
            report += f" RMSE = {val_rmse:.4f}、MAE = {val_mae:.4f} でした。"
        
        report += "\n\n"
    else:
        report += "モデルのパフォーマンス評価は完了していません。\n\n"
    
    # 改善案
    report += "### 改善案\n\n"
    report += "モデルのパフォーマンスを向上させるための潜在的な改善点:\n\n"
    report += "- 特徴量エンジニアリング: 新しい特徴量の追加や既存特徴量の変換、多項式特徴量の追加\n"
    report += "- 異常値処理: 外れ値の検出と処理方法の改善\n"
    report += "- ハイパーパラメータのチューニング: グリッドサーチやベイズ最適化の使用\n"
    report += "- 複雑なモデルの試行: より表現力の高いモデルやアンサンブル手法の検討\n"
    report += "- データ拡張: 学習データの量を増やすための手法を検討\n"
    
    return report 