import os
import logging
from typing import Any, List, Dict, Callable, Optional
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from datetime import datetime

logger = logging.getLogger(__name__)

class ModelEvaluator:
    """モデル評価のためのクラス"""
    
    def __init__(
        self,
        model: Any,
        model_name: str = "モデル",
        task_type: str = "classification",  # "classification", "regression", "time_series"
        features_to_use: List[str] = None,
        target_column: str = "target",
        report_dir: str = "./reports",
        symbol: str = None,
        granularity: str = None,
        start_date: str = None,
        end_date: str = None,
        validation_year: int = None,
        target_minutes_ahead: int = None,
        japanese_fonts: bool = True,
        custom_metrics: Dict[str, Callable] = None
    ):
        """
        パラメータ:
            model: 評価対象のモデル
            model_name: モデル名
            task_type: タスクの種類 ("classification", "regression", "time_series")
            features_to_use: 使用する特徴量のリスト
            target_column: 目的変数のカラム名
            report_dir: レポートの出力ディレクトリ
            symbol: 対象の銘柄 (例: "EURUSD")
            granularity: データの粒度 (例: "1MIN", "5MIN")
            start_date: 学習データの開始日
            end_date: 学習データの終了日
            validation_year: 検証データの年
            target_minutes_ahead: 予測の何分先か
            japanese_fonts: 日本語フォントを使用するか
            custom_metrics: カスタム評価指標 {名前: 関数} の辞書
        """
        self.model = model
        self.model_name = model_name
        self.task_type = task_type
        self.features_to_use = features_to_use
        self.target_column = target_column
        self.report_dir = report_dir
        self.symbol = symbol
        self.granularity = granularity
        self.start_date = start_date
        self.end_date = end_date
        self.validation_year = validation_year
        self.target_minutes_ahead = target_minutes_ahead
        self.custom_metrics = custom_metrics or {}
        
        # レポート出力ディレクトリの作成
        os.makedirs(report_dir, exist_ok=True)
        
        # 日本語フォントのセットアップ
        if japanese_fonts:
            self._setup_japanese_fonts()
    
    def _setup_japanese_fonts(self):
        """日本語フォントをセットアップする"""
        try:
            import matplotlib
            matplotlib.rcParams['font.family'] = 'sans-serif'
            matplotlib.rcParams['font.sans-serif'] = ['Hiragino Sans', 'Yu Gothic', 'Meiryo', 'IPAGothic', 'IPAPGothic', 'VL Gothic', 'Noto Sans CJK JP']
            
            # Mac用
            if os.name == 'posix' and os.uname().sysname == 'Darwin':
                matplotlib.rcParams['font.family'] = 'Hiragino Sans'
                
            # フォントが正しく設定されているか確認
            logger.info("日本語フォントを設定しました")
        except Exception as e:
            logger.warning(f"日本語フォントの設定に失敗しました: {e}")
            
    def generate_evaluation_report(
        self, 
        X_train: pd.DataFrame, 
        X_val: pd.DataFrame, 
        y_train: pd.Series, 
        y_val: pd.Series,
        run_id: str = None,
        feature_descriptions: Dict[str, str] = None,
        custom_sections: Dict[str, str] = None,
        output_format: str = "markdown"  # "markdown", "html", "pdf"
    ) -> str:
        """
        モデルの評価レポートを生成する

        パラメータ:
            X_train: 学習データの特徴量
            X_val: 検証データの特徴量
            y_train: 学習データの目的変数
            y_val: 検証データの目的変数
            run_id: 実行ID (MLflowなどの実験管理ツールのID)
            feature_descriptions: 特徴量の説明 {特徴量名: 説明} の辞書
            custom_sections: カスタムセクション {セクション名: 内容} の辞書
            output_format: 出力形式 ("markdown", "html", "pdf")

        戻り値:
            生成されたレポートのパス
        """
        logger.info(f"{self.model_name}の評価レポートを生成します")
        
        # 検証データが空の場合は、学習データのみでレポートを生成
        if X_val is None or X_val.empty or y_val is None or y_val.empty:
            logger.warning("検証データが空のため、学習データのみでレポートを生成します")
            X_val = X_train
            y_val = y_train
        
        # タイムスタンプ
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # レポートのファイル名を生成
        file_extension = output_format.lower()
        if file_extension == "markdown":
            file_extension = "md"
            
        report_filename = f"{self.model_name.replace(' ', '_')}_{timestamp}.{file_extension}"
        report_path = os.path.join(self.report_dir, report_filename)
        
        # タスクタイプに応じてレポートを生成
        try:
            if self.task_type.lower() == "classification":
                from .classification import _generate_classification_report
                report_content = _generate_classification_report(
                    self, X_train, X_val, y_train, y_val, timestamp, run_id, feature_descriptions
                )
            elif self.task_type.lower() == "regression":
                from .regression import _generate_regression_report
                report_content = _generate_regression_report(
                    self, X_train, X_val, y_train, y_val, timestamp, run_id, feature_descriptions
                )
            elif self.task_type.lower() == "time_series":
                from .time_series import _generate_time_series_report
                report_content = _generate_time_series_report(
                    self, X_train, X_val, y_train, y_val, timestamp, run_id, feature_descriptions
                )
            else:
                raise ValueError(f"未対応のタスクタイプです: {self.task_type}")
            
            # カスタムセクションを追加
            if custom_sections:
                report_content += "\n\n## カスタムセクション\n\n"
                for section_name, content in custom_sections.items():
                    report_content += f"### {section_name}\n\n{content}\n\n"
            
            # レポートを保存
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(report_content)
                
            logger.info(f"評価レポートを保存しました: {report_path}")
            
            # HTMLやPDFへの変換 (将来的に実装)
            if output_format.lower() in ["html", "pdf"]:
                logger.warning(f"{output_format}形式への変換はまだ実装されていません")
                
            return report_path
            
        except Exception as e:
            logger.error(f"レポート生成中にエラーが発生しました: {e}")
            raise 