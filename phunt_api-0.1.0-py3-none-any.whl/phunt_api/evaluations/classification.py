import os
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    confusion_matrix, roc_curve, auc, classification_report
)
from typing import Dict, Optional

logger = logging.getLogger(__name__)

def _generate_classification_report(
    evaluator, 
    X_train: pd.DataFrame, 
    X_val: pd.DataFrame, 
    y_train: pd.Series, 
    y_val: pd.Series,
    timestamp: str,
    run_id: str = None,
    feature_descriptions: Dict[str, str] = None
) -> str:
    """
    分類モデルの評価レポートを生成する

    パラメータ:
        evaluator: ModelEvaluatorインスタンス
        X_train: 学習データの特徴量
        X_val: 検証データの特徴量
        y_train: 学習データの目的変数
        y_val: 検証データの目的変数
        timestamp: レポート生成日時
        run_id: 実行ID (MLflowなどの実験管理ツールのID)
        feature_descriptions: 特徴量の説明 {特徴量名: 説明} の辞書

    戻り値:
        生成されたレポート内容 (Markdown形式)
    """
    # モデル名と作成日時
    report = f"# {evaluator.model_name} 評価レポート\n\n"
    report += f"作成日時: {timestamp.replace('_', ' ')}\n\n"
    
    # 実行IDがあれば追加
    if run_id:
        report += f"実行ID: {run_id}\n\n"
    
    # 銘柄情報
    if evaluator.symbol:
        report += f"銘柄: {evaluator.symbol}\n\n"
    
    # 時間粒度
    if evaluator.granularity:
        report += f"時間粒度: {evaluator.granularity}\n\n"
    
    # 予測先行時間
    if evaluator.target_minutes_ahead:
        report += f"予測先行時間: {evaluator.target_minutes_ahead}分\n\n"
    
    # モデル概要
    report += "## 1. モデル概要\n\n"
    report += f"モデル名: {evaluator.model_name}\n\n"
    report += f"モデルタイプ: {type(evaluator.model).__name__}\n\n"
    report += f"タスクタイプ: 分類\n\n"
    
    # データセット概要
    report += "## 2. データセット概要\n\n"
    
    # 学習期間と検証期間
    if evaluator.start_date and evaluator.end_date:
        report += f"学習期間: {evaluator.start_date} から {evaluator.end_date}\n\n"
    
    if evaluator.validation_year:
        report += f"検証期間: {evaluator.validation_year}年\n\n"
    
    # データサイズ
    report += f"学習データサイズ: {X_train.shape[0]} サンプル\n\n"
    report += f"検証データサイズ: {X_val.shape[0]} サンプル\n\n"
    
    # 目的変数の詳細
    report += "## 3. 目的変数の詳細\n\n"
    report += f"目的変数名: {evaluator.target_column}\n\n"
    
    # クラス分布を計算
    train_class_dist = y_train.value_counts().sort_index()
    val_class_dist = y_val.value_counts().sort_index()
    
    # クラスラベルと分布を表示
    report += "### クラス分布\n\n"
    
    # 2値分類か多クラス分類かを判定
    unique_classes = np.unique(np.concatenate([y_train.unique(), y_val.unique()]))
    
    if len(unique_classes) == 2:
        report += "2値分類問題\n\n"
        
        # クラス分布のテーブル
        report += "| クラス | 学習データ | 検証データ |\n"
        report += "|-------|----------|----------|\n"
        
        for class_label in sorted(unique_classes):
            train_count = train_class_dist.get(class_label, 0)
            val_count = val_class_dist.get(class_label, 0)
            train_pct = 100 * train_count / len(y_train)
            val_pct = 100 * val_count / len(y_val)
            
            report += f"| {class_label} | {train_count} ({train_pct:.1f}%) | {val_count} ({val_pct:.1f}%) |\n"
    else:
        report += "多クラス分類問題\n\n"
        
        # クラス分布のテーブル
        report += "| クラス | 学習データ | 検証データ |\n"
        report += "|-------|----------|----------|\n"
        
        for class_label in sorted(unique_classes):
            train_count = train_class_dist.get(class_label, 0)
            val_count = val_class_dist.get(class_label, 0)
            train_pct = 100 * train_count / len(y_train)
            val_pct = 100 * val_count / len(y_val)
            
            report += f"| {class_label} | {train_count} ({train_pct:.1f}%) | {val_count} ({val_pct:.1f}%) |\n"
    
    # データ分割方法
    report += "\n## 4. データ分割方法\n\n"
    
    if evaluator.validation_year:
        report += f"時系列ベースの分割を使用\n\n"
        report += f"検証データ: {evaluator.validation_year}年のデータ\n\n"
    else:
        report += "ランダム分割を使用\n\n"
    
    # 特徴量の詳細
    report += "## 5. 特徴量の詳細\n\n"
    
    if evaluator.features_to_use:
        report += f"特徴量数: {len(evaluator.features_to_use)}\n\n"
        
        # 特徴量リスト
        report += "### 使用された特徴量\n\n"
        
        if feature_descriptions:
            report += "| 特徴量名 | 説明 |\n"
            report += "|---------|------|\n"
            
            for feature in evaluator.features_to_use:
                description = feature_descriptions.get(feature, "")
                report += f"| {feature} | {description} |\n"
        else:
            for feature in evaluator.features_to_use:
                report += f"- {feature}\n"
    else:
        report += f"特徴量数: {X_train.shape[1]}\n\n"
        
        # 特徴量リスト
        report += "### 使用された特徴量\n\n"
        
        if feature_descriptions:
            report += "| 特徴量名 | 説明 |\n"
            report += "|---------|------|\n"
            
            for feature in X_train.columns:
                description = feature_descriptions.get(feature, "")
                report += f"| {feature} | {description} |\n"
        else:
            for feature in X_train.columns:
                report += f"- {feature}\n"
    
    # モデルの詳細
    report += "\n## 6. モデルの詳細\n\n"
    
    # モデルの種類
    report += f"モデルタイプ: {type(evaluator.model).__name__}\n\n"
    
    # ハイパーパラメータ
    report += "### ハイパーパラメータ\n\n"
    
    try:
        hyperparams = evaluator.model.get_params()
        report += "| パラメータ | 値 |\n"
        report += "|-----------|----|\n"
        
        for param, value in hyperparams.items():
            report += f"| {param} | {value} |\n"
    except Exception as e:
        logger.warning(f"ハイパーパラメータ情報の取得に失敗しました: {e}")
        report += "このモデルでは、ハイパーパラメータ情報を取得できませんでした。\n\n"
    
    # パフォーマンス評価
    report += "\n## 7. パフォーマンス評価\n\n"
    
    # 予測の実行
    try:
        y_train_pred = evaluator.model.predict(X_train)
        y_val_pred = evaluator.model.predict(X_val)
        
        # 確率予測が可能であれば取得
        try:
            y_train_proba = evaluator.model.predict_proba(X_train)
            y_val_proba = evaluator.model.predict_proba(X_val)
            has_proba = True
        except:
            has_proba = False
        
        # 2値分類か多クラス分類かに応じて評価指標を計算
        if len(unique_classes) == 2:
            # 2値分類
            train_accuracy = accuracy_score(y_train, y_train_pred)
            val_accuracy = accuracy_score(y_val, y_val_pred)
            
            # Precision, Recall, F1スコア
            train_precision = precision_score(y_train, y_train_pred, average='binary')
            val_precision = precision_score(y_val, y_val_pred, average='binary')
            
            train_recall = recall_score(y_train, y_train_pred, average='binary')
            val_recall = recall_score(y_val, y_val_pred, average='binary')
            
            train_f1 = f1_score(y_train, y_train_pred, average='binary')
            val_f1 = f1_score(y_val, y_val_pred, average='binary')
            
            # 指標テーブル
            report += "### 評価指標\n\n"
            report += "| 指標 | 学習データ | 検証データ |\n"
            report += "|------|----------|----------|\n"
            report += f"| 正解率 (Accuracy) | {train_accuracy:.4f} | {val_accuracy:.4f} |\n"
            report += f"| 適合率 (Precision) | {train_precision:.4f} | {val_precision:.4f} |\n"
            report += f"| 再現率 (Recall) | {train_recall:.4f} | {val_recall:.4f} |\n"
            report += f"| F1スコア | {train_f1:.4f} | {val_f1:.4f} |\n"
            
            # カスタム指標があれば追加
            if evaluator.custom_metrics:
                for metric_name, metric_func in evaluator.custom_metrics.items():
                    try:
                        train_metric = metric_func(y_train, y_train_pred)
                        val_metric = metric_func(y_val, y_val_pred)
                        report += f"| {metric_name} | {train_metric:.4f} | {val_metric:.4f} |\n"
                    except Exception as e:
                        logger.warning(f"{metric_name}の計算中にエラーが発生しました: {e}")
            
            # 混同行列
            train_cm = confusion_matrix(y_train, y_train_pred)
            val_cm = confusion_matrix(y_val, y_val_pred)
            
            report += "\n### 混同行列\n\n"
            
            # 学習データの混同行列
            report += "#### 学習データ\n\n"
            report += "```\n"
            report += str(train_cm)
            report += "\n```\n\n"
            
            # 検証データの混同行列
            report += "#### 検証データ\n\n"
            report += "```\n"
            report += str(val_cm)
            report += "\n```\n\n"
            
            # 可視化: 混同行列
            cm_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_confusion_matrix.png")
            try:
                plt.figure(figsize=(12, 5))
                
                # 学習データの混同行列
                plt.subplot(1, 2, 1)
                plt.imshow(train_cm, interpolation='nearest', cmap=plt.cm.Blues)
                plt.title('学習データの混同行列')
                plt.colorbar()
                tick_marks = np.arange(len(unique_classes))
                plt.xticks(tick_marks, unique_classes, rotation=45)
                plt.yticks(tick_marks, unique_classes)
                
                # 値のアノテーション
                thresh = train_cm.max() / 2.
                for i in range(train_cm.shape[0]):
                    for j in range(train_cm.shape[1]):
                        plt.text(j, i, format(train_cm[i, j], 'd'),
                                 horizontalalignment="center",
                                 color="white" if train_cm[i, j] > thresh else "black")
                
                plt.ylabel('実際のクラス')
                plt.xlabel('予測クラス')
                
                # 検証データの混同行列
                plt.subplot(1, 2, 2)
                plt.imshow(val_cm, interpolation='nearest', cmap=plt.cm.Blues)
                plt.title('検証データの混同行列')
                plt.colorbar()
                plt.xticks(tick_marks, unique_classes, rotation=45)
                plt.yticks(tick_marks, unique_classes)
                
                # 値のアノテーション
                thresh = val_cm.max() / 2.
                for i in range(val_cm.shape[0]):
                    for j in range(val_cm.shape[1]):
                        plt.text(j, i, format(val_cm[i, j], 'd'),
                                 horizontalalignment="center",
                                 color="white" if val_cm[i, j] > thresh else "black")
                
                plt.ylabel('実際のクラス')
                plt.xlabel('予測クラス')
                
                plt.tight_layout()
                plt.savefig(cm_fig_path)
                plt.close()
                
                report += f"![混同行列]({os.path.basename(cm_fig_path)})\n\n"
            except Exception as e:
                logger.warning(f"混同行列の可視化に失敗しました: {e}")
            
            # ROC曲線とAUC (確率予測が可能な場合のみ)
            if has_proba:
                try:
                    # 2値分類のみROC曲線を計算
                    # 陽性クラスを選択 (通常は1)
                    if len(y_train_proba[0]) > 1:
                        pos_label = 1
                        pos_proba_index = 1  # 陽性クラスの確率インデックス
                        
                        # 確率を取得
                        train_pos_proba = y_train_proba[:, pos_proba_index]
                        val_pos_proba = y_val_proba[:, pos_proba_index]
                        
                        # ROC曲線とAUC
                        train_fpr, train_tpr, _ = roc_curve(y_train, train_pos_proba, pos_label=pos_label)
                        val_fpr, val_tpr, _ = roc_curve(y_val, val_pos_proba, pos_label=pos_label)
                        
                        train_auc = auc(train_fpr, train_tpr)
                        val_auc = auc(val_fpr, val_tpr)
                        
                        report += f"\n### ROC曲線とAUC\n\n"
                        report += f"学習データのAUC: {train_auc:.4f}\n\n"
                        report += f"検証データのAUC: {val_auc:.4f}\n\n"
                        
                        # 可視化: ROC曲線
                        roc_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_roc_curve.png")
                        
                        plt.figure(figsize=(8, 6))
                        plt.plot(train_fpr, train_tpr, lw=2, label=f'学習データ (AUC = {train_auc:.4f})')
                        plt.plot(val_fpr, val_tpr, lw=2, label=f'検証データ (AUC = {val_auc:.4f})')
                        plt.plot([0, 1], [0, 1], 'k--', lw=2)
                        plt.xlim([0.0, 1.0])
                        plt.ylim([0.0, 1.05])
                        plt.xlabel('偽陽性率 (False Positive Rate)')
                        plt.ylabel('真陽性率 (True Positive Rate)')
                        plt.title('ROC曲線')
                        plt.legend(loc="lower right")
                        plt.grid(True)
                        plt.savefig(roc_fig_path)
                        plt.close()
                        
                        report += f"![ROC曲線]({os.path.basename(roc_fig_path)})\n\n"
                except Exception as e:
                    logger.warning(f"ROC曲線の計算に失敗しました: {e}")
        else:
            # 多クラス分類
            train_accuracy = accuracy_score(y_train, y_train_pred)
            val_accuracy = accuracy_score(y_val, y_val_pred)
            
            # Precision, Recall, F1スコア
            train_precision = precision_score(y_train, y_train_pred, average='weighted')
            val_precision = precision_score(y_val, y_val_pred, average='weighted')
            
            train_recall = recall_score(y_train, y_train_pred, average='weighted')
            val_recall = recall_score(y_val, y_val_pred, average='weighted')
            
            train_f1 = f1_score(y_train, y_train_pred, average='weighted')
            val_f1 = f1_score(y_val, y_val_pred, average='weighted')
            
            # 指標テーブル
            report += "### 評価指標\n\n"
            report += "| 指標 | 学習データ | 検証データ |\n"
            report += "|------|----------|----------|\n"
            report += f"| 正解率 (Accuracy) | {train_accuracy:.4f} | {val_accuracy:.4f} |\n"
            report += f"| 適合率 (Precision) | {train_precision:.4f} | {val_precision:.4f} |\n"
            report += f"| 再現率 (Recall) | {train_recall:.4f} | {val_recall:.4f} |\n"
            report += f"| F1スコア | {train_f1:.4f} | {val_f1:.4f} |\n"
            
            # カスタム指標があれば追加
            if evaluator.custom_metrics:
                for metric_name, metric_func in evaluator.custom_metrics.items():
                    try:
                        train_metric = metric_func(y_train, y_train_pred)
                        val_metric = metric_func(y_val, y_val_pred)
                        report += f"| {metric_name} | {train_metric:.4f} | {val_metric:.4f} |\n"
                    except Exception as e:
                        logger.warning(f"{metric_name}の計算中にエラーが発生しました: {e}")
            
            # 詳細なクラスごとの指標
            report += "\n### クラスごとの詳細指標 (検証データ)\n\n"
            report += "```\n"
            report += classification_report(y_val, y_val_pred)
            report += "\n```\n\n"
            
            # 混同行列
            train_cm = confusion_matrix(y_train, y_train_pred)
            val_cm = confusion_matrix(y_val, y_val_pred)
            
            report += "\n### 混同行列\n\n"
            
            # 検証データの混同行列
            report += "#### 検証データ\n\n"
            report += "```\n"
            report += str(val_cm)
            report += "\n```\n\n"
            
            # 可視化: 混同行列
            cm_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_confusion_matrix.png")
            try:
                plt.figure(figsize=(8, 6))
                plt.imshow(val_cm, interpolation='nearest', cmap=plt.cm.Blues)
                plt.title('検証データの混同行列')
                plt.colorbar()
                tick_marks = np.arange(len(unique_classes))
                plt.xticks(tick_marks, unique_classes, rotation=45)
                plt.yticks(tick_marks, unique_classes)
                
                # 値のアノテーション
                thresh = val_cm.max() / 2.
                for i in range(val_cm.shape[0]):
                    for j in range(val_cm.shape[1]):
                        plt.text(j, i, format(val_cm[i, j], 'd'),
                                 horizontalalignment="center",
                                 color="white" if val_cm[i, j] > thresh else "black")
                
                plt.ylabel('実際のクラス')
                plt.xlabel('予測クラス')
                plt.tight_layout()
                plt.savefig(cm_fig_path)
                plt.close()
                
                report += f"![混同行列]({os.path.basename(cm_fig_path)})\n\n"
            except Exception as e:
                logger.warning(f"混同行列の可視化に失敗しました: {e}")
    
    except Exception as e:
        logger.error(f"パフォーマンス評価中にエラーが発生しました: {e}")
        report += "モデルの予測実行中にエラーが発生したため、パフォーマンス評価を完了できませんでした。\n\n"
    
    # 特徴量の重要度
    report += "\n## 8. 特徴量の重要度\n\n"
    
    try:
        # モデルに feature_importances_ 属性があるか確認
        if hasattr(evaluator.model, 'feature_importances_'):
            importances = evaluator.model.feature_importances_
            feature_names = evaluator.features_to_use if evaluator.features_to_use else X_train.columns
            
            # 重要度でソート
            indices = np.argsort(importances)[::-1]
            
            # 上位N個の特徴量を表示
            top_n = min(20, len(feature_names))
            
            report += "### トップ特徴量\n\n"
            report += "| 特徴量 | 重要度 |\n"
            report += "|-------|-------|\n"
            
            for i in range(top_n):
                idx = indices[i]
                report += f"| {feature_names[idx]} | {importances[idx]:.4f} |\n"
            
            # 可視化: 特徴量の重要度
            fi_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_feature_importance.png")
            
            plt.figure(figsize=(10, 6))
            plt.title("特徴量の重要度")
            plt.bar(range(top_n), importances[indices][:top_n], align="center")
            plt.xticks(range(top_n), [feature_names[i] for i in indices][:top_n], rotation=90)
            plt.xlim([-1, top_n])
            plt.tight_layout()
            plt.savefig(fi_fig_path)
            plt.close()
            
            report += f"\n![特徴量の重要度]({os.path.basename(fi_fig_path)})\n\n"
        
        # coef_ 属性を持つ線形モデルの場合
        elif hasattr(evaluator.model, 'coef_'):
            coefs = evaluator.model.coef_
            feature_names = evaluator.features_to_use if evaluator.features_to_use else X_train.columns
            
            # 多クラス分類の場合は、クラスごとの係数がある
            if len(coefs.shape) > 1:
                # 各特徴量の係数の絶対値平均でソート
                mean_abs_coefs = np.mean(np.abs(coefs), axis=0)
                indices = np.argsort(mean_abs_coefs)[::-1]
                
                # 上位N個の特徴量を表示
                top_n = min(20, len(feature_names))
                
                report += "### トップ特徴量 (係数の絶対値平均)\n\n"
                report += "| 特徴量 | 重要度 (絶対値平均) |\n"
                report += "|-------|-------------------|\n"
                
                for i in range(top_n):
                    idx = indices[i]
                    report += f"| {feature_names[idx]} | {mean_abs_coefs[idx]:.4f} |\n"
                
                # 可視化: 特徴量の重要度
                fi_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_feature_importance.png")
                
                plt.figure(figsize=(10, 6))
                plt.title("特徴量の重要度 (係数の絶対値平均)")
                plt.bar(range(top_n), mean_abs_coefs[indices][:top_n], align="center")
                plt.xticks(range(top_n), [feature_names[i] for i in indices][:top_n], rotation=90)
                plt.xlim([-1, top_n])
                plt.tight_layout()
                plt.savefig(fi_fig_path)
                plt.close()
                
                report += f"\n![特徴量の重要度]({os.path.basename(fi_fig_path)})\n\n"
            else:
                # 2値分類の場合
                abs_coefs = np.abs(coefs[0])
                indices = np.argsort(abs_coefs)[::-1]
                
                # 上位N個の特徴量を表示
                top_n = min(20, len(feature_names))
                
                report += "### トップ特徴量 (係数の絶対値)\n\n"
                report += "| 特徴量 | 係数 | 絶対値 |\n"
                report += "|-------|------|-------|\n"
                
                for i in range(top_n):
                    idx = indices[i]
                    report += f"| {feature_names[idx]} | {coefs[0][idx]:.4f} | {abs_coefs[idx]:.4f} |\n"
                
                # 可視化: 特徴量の重要度
                fi_fig_path = os.path.join(evaluator.report_dir, f"{evaluator.model_name.replace(' ', '_')}_{timestamp}_feature_importance.png")
                
                plt.figure(figsize=(10, 6))
                plt.title("特徴量の重要度 (係数の絶対値)")
                plt.bar(range(top_n), abs_coefs[indices][:top_n], align="center")
                plt.xticks(range(top_n), [feature_names[i] for i in indices][:top_n], rotation=90)
                plt.xlim([-1, top_n])
                plt.tight_layout()
                plt.savefig(fi_fig_path)
                plt.close()
                
                report += f"\n![特徴量の重要度]({os.path.basename(fi_fig_path)})\n\n"
        else:
            report += "このモデルは、特徴量の重要度の情報を提供していません。\n\n"
    except Exception as e:
        logger.warning(f"特徴量の重要度の計算中にエラーが発生しました: {e}")
        report += "特徴量の重要度の計算中にエラーが発生しました。\n\n"
    
    # 結論と改善案
    report += "\n## 9. 結論と改善案\n\n"
    
    # 結論
    report += "### 結論\n\n"
    
    # パフォーマンス情報があれば追加
    if 'val_accuracy' in locals():
        report += f"このモデルは検証データに対して {val_accuracy:.2%} の正解率を達成しました。"
        
        if 'val_precision' in locals() and 'val_recall' in locals():
            report += f" 適合率は {val_precision:.2%}、再現率は {val_recall:.2%} でした。"
        
        report += "\n\n"
    else:
        report += "モデルのパフォーマンス評価は完了していません。\n\n"
    
    # 改善案
    report += "### 改善案\n\n"
    report += "モデルのパフォーマンスを向上させるための潜在的な改善点:\n\n"
    report += "- 特徴量エンジニアリング: 新しい特徴量の追加や既存特徴量の変換\n"
    report += "- ハイパーパラメータのチューニング: グリッドサーチやベイズ最適化の使用\n"
    report += "- モデルアンサンブル: 複数のモデルを組み合わせて予測精度を向上\n"
    report += "- データ拡張: 学習データの量を増やすための手法を検討\n"
    report += "- クラス不均衡の処理: オーバーサンプリングやアンダーサンプリング手法の使用\n"
    
    return report 