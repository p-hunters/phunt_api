import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Callable, Any, Optional, Union, Tuple

logger = logging.getLogger(__name__)

def generate_evaluation_report(
    model, X_train, X_val, y_train, y_val, 
    model_name="モデル", 
    task_type="classification",
    features_to_use=None, 
    target_column="target",
    report_dir="./reports",
    symbol=None,
    granularity=None, 
    start_date=None,
    end_date=None,
    validation_year=None,
    target_minutes_ahead=None,
    run_id=None,
    feature_descriptions=None,
    custom_sections=None,
    output_format="markdown",
    japanese_fonts=True,
    custom_metrics=None
):
    """
    モデルの評価レポートを生成するヘルパー関数

    パラメータ:
        model: 評価対象のモデル
        X_train: 学習データの特徴量
        X_val: 検証データの特徴量
        y_train: 学習データの目的変数
        y_val: 検証データの目的変数
        model_name: モデル名
        task_type: タスクの種類 ("classification", "regression", "time_series")
        features_to_use: 使用する特徴量のリスト
        target_column: 目的変数のカラム名
        report_dir: レポートの出力ディレクトリ
        symbol: 対象の銘柄 (例: "EURUSD")
        granularity: データの粒度 (例: "1MIN", "5MIN")
        start_date: 学習データの開始日
        end_date: 学習データの終了日
        validation_year: 検証データの年
        target_minutes_ahead: 予測の何分先か
        run_id: 実行ID (MLflowなどの実験管理ツールのID)
        feature_descriptions: 特徴量の説明 {特徴量名: 説明} の辞書
        custom_sections: カスタムセクション {セクション名: 内容} の辞書
        output_format: 出力形式 ("markdown", "html", "pdf")
        japanese_fonts: 日本語フォントを使用するか
        custom_metrics: カスタム評価指標 {名前: 関数} の辞書

    戻り値:
        生成されたレポートのパス
    """
    from ..evaluations.base import ModelEvaluator
    
    # ModelEvaluatorインスタンスの作成
    evaluator = ModelEvaluator(
        model=model,
        model_name=model_name,
        task_type=task_type,
        features_to_use=features_to_use,
        target_column=target_column,
        report_dir=report_dir,
        symbol=symbol,
        granularity=granularity,
        start_date=start_date,
        end_date=end_date,
        validation_year=validation_year,
        target_minutes_ahead=target_minutes_ahead,
        japanese_fonts=japanese_fonts,
        custom_metrics=custom_metrics
    )
    
    # 評価レポートの生成
    report_path = evaluator.generate_evaluation_report(
        X_train=X_train,
        X_val=X_val,
        y_train=y_train,
        y_val=y_val,
        run_id=run_id,
        feature_descriptions=feature_descriptions,
        custom_sections=custom_sections,
        output_format=output_format
    )
    
    return report_path

def calculate_mape(y_true, y_pred):
    """
    MAPE (Mean Absolute Percentage Error) を計算する

    パラメータ:
        y_true: 実際の値
        y_pred: 予測値

    戻り値:
        MAPE値 (%)
    """
    # ゼロ除算を避ける
    mask = y_true != 0
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100

def calculate_wmape(y_true, y_pred):
    """
    WMAPE (Weighted Mean Absolute Percentage Error) を計算する

    パラメータ:
        y_true: 実際の値
        y_pred: 予測値

    戻り値:
        WMAPE値 (%)
    """
    return 100 * np.sum(np.abs(y_true - y_pred)) / np.sum(np.abs(y_true))

def calculate_smape(y_true, y_pred):
    """
    SMAPE (Symmetric Mean Absolute Percentage Error) を計算する

    パラメータ:
        y_true: 実際の値
        y_pred: 予測値

    戻り値:
        SMAPE値 (%)
    """
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

def get_classification_threshold(y_true, y_prob, method="youden", pos_label=1):
    """
    分類問題の最適な閾値を計算する

    パラメータ:
        y_true: 実際のラベル
        y_prob: 陽性クラスの確率予測
        method: 閾値決定方法 ("youden", "f1", "accuracy")
        pos_label: 陽性クラスのラベル

    戻り値:
        最適な閾値
    """
    from sklearn.metrics import roc_curve, f1_score, accuracy_score
    
    if method == "youden":
        # YoudenのJ統計量 (感度+特異度-1) を最大化
        fpr, tpr, thresholds = roc_curve(y_true, y_prob, pos_label=pos_label)
        j_scores = tpr - fpr
        best_idx = np.argmax(j_scores)
        return thresholds[best_idx]
    
    elif method == "f1":
        # F1スコアを最大化
        thresholds = np.linspace(0.01, 0.99, 99)
        best_threshold = 0.5
        best_f1 = 0
        
        for threshold in thresholds:
            y_pred = (y_prob >= threshold).astype(int)
            f1 = f1_score(y_true, y_pred, pos_label=pos_label)
            
            if f1 > best_f1:
                best_f1 = f1
                best_threshold = threshold
                
        return best_threshold
    
    elif method == "accuracy":
        # 正解率を最大化
        thresholds = np.linspace(0.01, 0.99, 99)
        best_threshold = 0.5
        best_accuracy = 0
        
        for threshold in thresholds:
            y_pred = (y_prob >= threshold).astype(int)
            accuracy = accuracy_score(y_true, y_pred)
            
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_threshold = threshold
                
        return best_threshold
    
    else:
        raise ValueError(f"未対応の閾値決定方法です: {method}")

def convert_markdown_to_html(markdown_path, output_path=None):
    """
    MarkdownファイルをHTMLに変換する

    パラメータ:
        markdown_path: Markdownファイルのパス
        output_path: 出力HTMLファイルのパス（Noneの場合は拡張子を.htmlに変更）

    戻り値:
        生成されたHTMLファイルのパス
    """
    try:
        import markdown
        
        # 出力パスが指定されていない場合は拡張子を変更
        if output_path is None:
            output_path = os.path.splitext(markdown_path)[0] + ".html"
        
        # Markdownファイルを読み込む
        with open(markdown_path, 'r', encoding='utf-8') as f:
            md_content = f.read()
        
        # HTMLに変換
        html = markdown.markdown(md_content, extensions=['tables', 'fenced_code', 'nl2br'])
        
        # スタイルを追加
        styled_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Model Evaluation Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
                h1 {{ color: #333; }}
                h2 {{ color: #444; margin-top: 30px; border-bottom: 1px solid #ddd; padding-bottom: 5px; }}
                h3 {{ color: #555; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ text-align: left; padding: 8px; border: 1px solid #ddd; }}
                th {{ background-color: #f2f2f2; }}
                tr:nth-child(even) {{ background-color: #f9f9f9; }}
                pre {{ background-color: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }}
                code {{ font-family: 'Courier New', monospace; background-color: #f5f5f5; padding: 2px 4px; }}
                img {{ max-width: 100%; height: auto; display: block; margin: 20px auto; }}
            </style>
        </head>
        <body>
            {html}
        </body>
        </html>
        """
        
        # HTMLファイルを保存
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(styled_html)
            
        logger.info(f"HTMLレポートを保存しました: {output_path}")
        return output_path
        
    except ImportError:
        logger.warning("markdown パッケージがインストールされていないため、HTML変換をスキップします")
        logger.warning("HTMLに変換するには、次のコマンドを実行してください: pip install markdown")
        return None
    except Exception as e:
        logger.error(f"HTMLへの変換中にエラーが発生しました: {e}")
        return None 