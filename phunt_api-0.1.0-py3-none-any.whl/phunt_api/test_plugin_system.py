"""
プラグインシステムのテスト

このスクリプトは、PHuntAPIに統合されたプラグインシステムをテストします。
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from phunt_api import PHuntAPI

def test_plugin_system():
    """
    プラグインシステムの基本機能をテストする
    """
    print("=== PHuntAPIプラグインシステムのテスト ===")
    
    # PHuntAPIの初期化
    print("\n1. PHuntAPIを初期化中...")
    api = PHuntAPI(debug=True)
    print("PHuntAPIを初期化しました。")
    
    # インストール済みのプラグインを一覧表示
    print("\n2. インストール済みのプラグインを一覧表示...")
    plugins = api.list_plugins()
    print(f"プラグインの数: {len(plugins)}")
    for plugin in plugins:
        print(f"- {plugin['name']}: {plugin['info']['description']}")
    
    # サンプルプラグインの関数一覧を表示
    print("\n3. サンプルプラグインの関数一覧を表示...")
    plugin_name = 'sample_feature_plugin'
    try:
        functions = api.get_plugin_functions(plugin_name)
        print(f"{plugin_name} の関数一覧:")
        for func in functions:
            print(f"- {func}")
    except Exception as e:
        print(f"プラグイン機能の一覧取得中にエラーが発生: {str(e)}")
    
    # サンプルデータを生成
    print("\n4. テスト用のサンプルデータを生成...")
    dates = pd.date_range(start='2022-01-01', periods=100)
    np.random.seed(42)
    close_prices = 100 + np.cumsum(np.random.normal(0, 1, 100))
    sample_data = pd.DataFrame({
        'date': dates,
        'close': close_prices
    }).set_index('date')
    print("サンプルデータを生成しました:")
    print(sample_data.head())
    
    # プラグイン機能を使用
    print("\n5. プラグイン機能を使用してRSIを計算...")
    try:
        rsi_df = api.get_plugin_feature(
            plugin_name='sample_feature_plugin',
            function_name='calculate_rsi',
            prices=sample_data['close'],
            window=14
        )
        print("RSI 計算結果:")
        print(rsi_df.head())
        print("\nRSIの計算に成功しました。")
    except Exception as e:
        print(f"RSIの計算中にエラーが発生: {str(e)}")
    
    # 特徴量として登録
    print("\n6. 計算した特徴量を登録...")
    try:
        feature_id = api.register_plugin_feature(
            name='test_rsi',
            plugin_name='sample_feature_plugin',
            function_name='calculate_rsi',
            prices=sample_data['close'],
            window=14
        )
        print(f"特徴量を登録しました: {feature_id}")
        
        # 登録した特徴量を取得
        feature = api.get_feature(feature_id)
        print("\n登録した特徴量を取得:")
        print(feature.head())
    except Exception as e:
        print(f"特徴量の登録/取得中にエラーが発生: {str(e)}")
    
    # ボリンジャーバンドを計算
    print("\n7. ボリンジャーバンドを計算...")
    try:
        bb_df = api.get_plugin_feature(
            plugin_name='sample_feature_plugin',
            function_name='calculate_bollinger_bands',
            prices=sample_data['close'],
            window=20,
            num_std=2.0
        )
        print("ボリンジャーバンド 計算結果:")
        print(bb_df.head())
    except Exception as e:
        print(f"ボリンジャーバンドの計算中にエラーが発生: {str(e)}")
    
    # MACDを計算
    print("\n8. MACDを計算...")
    try:
        macd_df = api.get_plugin_feature(
            plugin_name='sample_feature_plugin',
            function_name='calculate_macd',
            prices=sample_data['close']
        )
        print("MACD 計算結果:")
        print(macd_df.head())
    except Exception as e:
        print(f"MACDの計算中にエラーが発生: {str(e)}")
    
    # 結果を可視化
    if 'rsi_df' in locals() and 'bb_df' in locals() and 'macd_df' in locals():
        print("\n9. 結果を可視化...")
        plt.figure(figsize=(12, 10))
        
        # 価格チャートとボリンジャーバンド
        plt.subplot(3, 1, 1)
        plt.plot(sample_data.index, sample_data['close'], label='Close Price')
        plt.plot(bb_df.index, bb_df['bb_middle'], label='Middle Band')
        plt.plot(bb_df.index, bb_df['bb_upper'], label='Upper Band')
        plt.plot(bb_df.index, bb_df['bb_lower'], label='Lower Band')
        plt.legend()
        plt.title('Price with Bollinger Bands')
        
        # RSI
        plt.subplot(3, 1, 2)
        plt.plot(rsi_df.index, rsi_df['rsi'])
        plt.axhline(y=70, color='r', linestyle='-')
        plt.axhline(y=30, color='g', linestyle='-')
        plt.title('RSI (14)')
        
        # MACD
        plt.subplot(3, 1, 3)
        plt.plot(macd_df.index, macd_df['macd'], label='MACD')
        plt.plot(macd_df.index, macd_df['macd_signal'], label='Signal')
        plt.bar(macd_df.index, macd_df['macd_histogram'], width=1, label='Histogram')
        plt.legend()
        plt.title('MACD')
        
        plt.tight_layout()
        plt.savefig('plugin_test_results.png')
        print("結果を 'plugin_test_results.png' に保存しました。")
    
    print("\n=== テスト完了 ===")


if __name__ == "__main__":
    test_plugin_system() 