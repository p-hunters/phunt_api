# -*- coding: utf-8 -*-

# 仕様:
# - Google Colabでのみ実行を想定したパッケージ
# - Workspaceドメインのユーザーのみがアクセス可能
# - ロールをアサインして一時的なクレデンシャルを取得し、環境変数に保存する

import os
import requests
import boto3
import json
from functools import wraps
from datetime import datetime, timezone, timedelta
import logging
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
from .exceptions import AuthenticationError
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption
from cryptography.hazmat.primitives.serialization import pkcs12
from OpenSSL import crypto
import tempfile
import pytz
import uuid
import importlib
import time
from .auth_server.run import run_auth_server

# ロギングの設定
log_level = os.getenv("PHUNT_LOG_LEVEL", "INFO")
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class PHuntAuth:
    def __init__(self, 
                 auth_server_url: str = "https://feast.p-hunters.com",  # ALBのドメインをデフォルトに
                 cert_path: Optional[str] = None,
                 key_path: Optional[str] = None,
                 ca_path: Optional[str] = None,
                 workspace_domain: str = 'p-hunter.com',
                 session_id: Optional[str] = None,
                 force_google_auth: bool = False,
                 debug: bool = False):  # Google認証を強制するオプション
        
        """
        PHuntAuthの初期化
        
        Args:
            auth_server_url: 認証サーバーのURL（デフォルトはALBのドメイン）
            cert_path: クライアント証明書のパス
            key_path: クライアント秘密鍵のパス
            ca_path: CA証明書のパス
            workspace_domain: Workspaceドメイン（本番環境用）
            session_id: セッションID（ログ追跡用）
            force_google_auth: 開発環境でもGoogle認証を使用する
        """
        self.auth_server_url = auth_server_url.rstrip('/')
        self.workspace_domain = workspace_domain
        self.tmp_creds: Optional[Dict[str, Any]] = None
        self.session_id = session_id or str(uuid.uuid4())
        self.force_google_auth = force_google_auth
        self.debug = debug
        # 証明書のパスを設定
        self.cert_path = cert_path or os.environ.get('PHUNT_CLIENT_CERT')
        self.key_path = key_path or os.environ.get('PHUNT_CLIENT_KEY')
        self.ca_path = ca_path or os.environ.get('PHUNT_CA_CERT')
        
        # P12関連の情報を保持
        self.p12_path: Optional[str] = None
        self.p12_password: Optional[str] = None
        self.temp_dir: Optional[str] = None
        
        # 証明書の存在確認と有効期限チェック
        if not self._is_running_on_colab() and not self.force_google_auth:
            self._validate_certificates()

    def _is_running_on_colab(self) -> bool:
        """Google Colab環境で実行されているかを確認"""
        try:
            importlib.import_module('google.colab')
            return True
        except ImportError:
            return False

    def _check_certificate_expiration(self, cert_path: str) -> Tuple[datetime, bool]:
        """証明書の有効期限をチェック"""
        try:
            with open(cert_path, 'rb') as f:
                cert_data = f.read()
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
            expiration_date = cert.not_valid_after_utc
            now = datetime.now(timezone.utc)
            
            # 有効期限が1週間以内の場合は警告を出す
            warning_threshold = now + timedelta(days=7)
            is_warning = expiration_date <= warning_threshold
            
            if is_warning:
                logger.warning(f"Certificate {cert_path} will expire on {expiration_date}")
            
            return expiration_date, is_warning
        except Exception as e:
            raise AuthenticationError(f"証明書の有効期限チェックに失敗しました: {str(e)}")

    def _validate_certificates(self):
        if self.debug:
            return
        """証明書の存在と有効性を確認"""
        if not all([self.cert_path, self.key_path, self.ca_path]):
            raise AuthenticationError(
                "クライアント証明書、秘密鍵、CA証明書のパスが必要です。"
                "コンストラクタで指定するか、環境変数で設定してください。"
                "\n - PHUNT_CLIENT_CERT: クライアント証明書のパス"
                "\n - PHUNT_CLIENT_KEY: クライアント秘密鍵のパス"
                "\n - PHUNT_CA_CERT: CA証明書のパス"
            )
        
        # パスの存在確認と有効期限チェック
        for path, name in [
            (self.cert_path, "クライアント証明書"),
            (self.ca_path, "CA証明書")
        ]:
            if not Path(path).exists():
                raise AuthenticationError(f"{name}が見つかりません: {path}")
            
            # 証明書の有効期限をチェック
            expiration_date, is_warning = self._check_certificate_expiration(path)
            if expiration_date < datetime.now(timezone.utc):
                raise AuthenticationError(f"{name}の有効期限が切れています: {expiration_date}")
        
        # 秘密鍵の存在確認
        if not Path(self.key_path).exists():
            raise AuthenticationError(f"クライアント秘密鍵が見つかりません: {self.key_path}")

    def _log_auth_event(self, event_type: str, details: Dict[str, Any], success: bool = True):
        """認証関連イベントのログを記録"""
        log_data = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'session_id': self.session_id,
            'event_type': event_type,
            'success': success,
            'details': details,
            'environment': 'colab' if self._is_running_on_colab() else 'development'
        }
        
        if success:
            logger.debug(f"Auth event: {json.dumps(log_data)}")
        else:
            logger.error(f"Auth event: {json.dumps(log_data)}")

    def _get_credentials_from_auth_server(self, email: Optional[str] = None) -> Dict[str, Any]:
        """認証サーバーから一時的なクレデンシャルを取得（開発環境用）"""
        try:
            # 証明書の検証
            if not self.debug:
                self._validate_certificates()
            
            
            # リトライ設定
            max_retries = 3
            retry_delay = 1  # 秒
            
            for attempt in range(max_retries):
                try:
                    # 開発環境の場合はSSL検証をスキップ
                    verify = False if self.debug else self.ca_path
                    logger.debug(f'cert_path: {self.cert_path}, key_path: {self.key_path}, ca_path: {self.ca_path}')
                    
                    response = requests.post(
                        f"{self.auth_server_url}/credentials",
                        verify=verify,
                        cert=(self.cert_path, self.key_path),
                        timeout=10,
                        json={'email': email}  # メールアドレスを含める
                    )
                    response.raise_for_status()
                    
                    self._log_auth_event('get_credentials', {
                        'auth_server_url': self.auth_server_url,
                        'cert_path': self.cert_path,
                        'attempt': attempt + 1,
                        'debug_mode': self.debug
                    })
                    
                    return response.json()
                    
                except requests.exceptions.RequestException as e:
                    if attempt == max_retries - 1:
                        raise
                    logger.warning(f"認証リトライ {attempt + 1}/{max_retries}: {str(e)}")
                    time.sleep(retry_delay * (2 ** attempt))  # 指数バックオフ
                    
        except requests.exceptions.RequestException as e:
            error_details = {
                'error': str(e),
                'auth_server_url': self.auth_server_url,
                'debug_mode': self.debug
            }
            
            # SSL/TLS関連のエラーの詳細を追加
            if isinstance(e, requests.exceptions.SSLError):
                error_details['ssl_error'] = True
                error_details['error_type'] = 'SSL/TLS verification failed'
                error_details['cert_path'] = self.cert_path
                error_details['key_path'] = self.key_path
                error_details['ca_path'] = self.ca_path
            
            self._log_auth_event('get_credentials_error', error_details, success=False)
            
            if self.debug:
                logger.warning("開発環境では証明書検証をスキップします")
                # 開発環境での再試行（SSL検証スキップ）
                try:
                    response = requests.post(
                        f"{self.auth_server_url}/credentials",
                        verify=False,
                        cert=(self.cert_path, self.key_path),
                        timeout=10
                    )
                    response.raise_for_status()
                    return response.json()
                except Exception as retry_e:
                    logger.error(f"SSL検証スキップでも失敗: {str(retry_e)}")
                    raise
            
            raise AuthenticationError(
                f"認証サーバーからのクレデンシャル取得に失敗しました: {str(e)}\n"
                f"サーバーURL: {self.auth_server_url}\n"
                "考えられる原因:\n"
                "1. 証明書が無効または期限切れ\n"
                "2. サーバーが利用できない\n"
                "3. ネットワーク接続の問題"
            )

    def _get_google_credentials(self) -> Tuple[str, Dict[str, Any]]:
        """Google認証を使用してクレデンシャルを取得（本番環境用）"""
        logger.info("Google認証を使用します。")
        try:
            # Google認証の実行
            from google.colab import auth
            from google.auth import default
            from google.auth.transport.requests import Request
            import requests
            
            # ユーザー認証を明示的に実行
            auth.authenticate_user()
            
            # 資格情報の取得
            creds, _ = default()
            
            # 資格情報が存在しない場合は再認証を試みる
            if not creds:
                self._log_auth_event('google_auth_retry', {
                    'message': 'No credentials found, attempting re-authentication'
                })
                auth.authenticate_user(force_reauth=True)
                creds, _ = default()
            
            if not creds:
                raise AuthenticationError("Google認証の資格情報が取得できませんでした")
            
            # トークンの更新
            request = Request()
            creds.refresh(request)
            
            # ユーザー情報の取得
            response = requests.get(
                'https://www.googleapis.com/oauth2/v1/userinfo',
                params={'alt': 'json'},
                headers={'Authorization': f'Bearer {creds.token}'}
            )
            
            if response.status_code != 200:
                self._log_auth_event('google_auth_error', {
                    'error': 'Failed to get user info',
                    'response': response.content.decode()
                }, success=False)
                raise AuthenticationError(f'ユーザー情報の取得に失敗しました。レスポンス: {response.content}')
            
            email = response.json()['email']
            logger.info(f"Google認証成功: {email}")
            # Workspaceドメインの確認
            if not email.endswith(f'@{self.workspace_domain}'):
                self._log_auth_event('invalid_domain', {
                    'email': email,
                    'workspace_domain': self.workspace_domain
                }, success=False)
                raise AuthenticationError("Workspaceドメインのユーザーのみがアクセスできます。")
            
            self._log_auth_event('google_auth_success', {
                'email': email
            })
            
            return email
            
        except ImportError as e:
            self._log_auth_event('google_auth_error', {
                'error': 'Google Colab environment required'
            }, success=False)
            raise AuthenticationError("Google Colab環境で実行する必要があります。")
        except Exception as e:
            self._log_auth_event('google_auth_error', {
                'error': str(e)
            }, success=False)
            raise AuthenticationError(f"Google認証に失敗しました: {str(e)}")

    def _extract_from_p12(self, p12_path: str, password: Optional[str] = None) -> Tuple[str, str, str]:
        """
        P12ファイルから証明書と秘密鍵を抽出し、一時ファイルとして保存

        Args:
            p12_path: P12ファイルのパス
            password: P12ファイルのパスワード（オプション）

        Returns:
            Tuple[str, str, str]: (証明書パス, 秘密鍵パス, CA証明書パス)
        """
        try:
            # P12ファイルを読み込む
            with open(p12_path, 'rb') as f:
                p12_data = f.read()

            from cryptography.hazmat.primitives.serialization import pkcs12
            private_key, certificate, ca_certs = pkcs12.load_key_and_certificates(
                p12_data,
                password.encode() if password else None,
                default_backend()
            )
            
            # 一時ディレクトリを作成
            temp_dir = tempfile.mkdtemp()
            cert_path = os.path.join(temp_dir, 'client.crt')
            key_path = os.path.join(temp_dir, 'client.key')
            ca_path = os.path.join(temp_dir, 'ca.crt')
            
            # 証明書を保存
            with open(cert_path, 'wb') as f:
                f.write(certificate.public_bytes(Encoding.PEM))
            
            # 秘密鍵を保存
            with open(key_path, 'wb') as f:
                f.write(private_key.private_bytes(
                    encoding=Encoding.PEM,
                    format=PrivateFormat.PKCS8,
                    encryption_algorithm=NoEncryption()
                ))
            
            # CA証明書を保存
            with open(ca_path, 'wb') as f:
                if ca_certs:
                    for ca_cert in ca_certs:
                        f.write(ca_cert.public_bytes(Encoding.PEM))
                else:
                    # CA証明書が含まれていない場合は、クライアント証明書をCA証明書としても使用
                    f.write(certificate.public_bytes(Encoding.PEM))
            logger.debug(f"P12ファイルから証明書と秘密鍵を抽出: {cert_path}, {key_path}, {ca_path}")
            return cert_path, key_path, ca_path
            
            
        except Exception as e:
            logger.error(f"P12ファイルの処理中にエラー: {str(e)}", exc_info=True)
            raise AuthenticationError(f"P12ファイルの処理中にエラーが発生しました: {str(e)}")

    def _cleanup_temp_certificates(self):
        """一時的な証明書ファイルをクリーンアップ"""
        try:
            if self.temp_dir and os.path.exists(self.temp_dir):
                import shutil
                shutil.rmtree(self.temp_dir)
                self.temp_dir = None
        except ImportError:
            # Pythonシャットダウン時のImportErrorを無視
            pass
        except Exception as e:
            # その他のエラーはログに記録
            logger.warning(f"一時証明書のクリーンアップ中にエラーが発生: {str(e)}")

    def set_pem_environemnt_for_mlflow(self, cert_path: str):
        """
        MLflow用のクライアント証明書環境変数を設定する（mTLS用）
        
        Args:
            cert_path: クライアント証明書のパス
        """
        try:
            # 証明書と秘密鍵を1つのファイルにまとめる
            temp_dir = os.path.dirname(cert_path)
            combined_cert_path = os.path.join(temp_dir, 'combined.pem')
            
            # 証明書と秘密鍵の内容を結合
            with open(combined_cert_path, 'wb') as combined:
                # 秘密鍵を書き込み
                with open(self.key_path, 'rb') as key_file:
                    combined.write(key_file.read())
                # 証明書を書き込み
                with open(cert_path, 'rb') as cert_file:
                    combined.write(cert_file.read())
            
            # MLflow用のクライアント証明書環境変数を設定（mTLS用）
            os.environ['MLFLOW_TRACKING_CLIENT_CERT_PATH'] = combined_cert_path
            
            logger.debug(f"MLflow用のクライアント証明書を設定しました: {combined_cert_path}")
            
        except Exception as e:
            raise AuthenticationError(f"MLflow用の証明書設定中にエラーが発生しました: {str(e)}")

    def login(self, p12_path: Optional[str] = None, p12_password: Optional[str] = None) -> Dict[str, str]:
        """
        環境に応じた認証を実行し、一時的なAWSクレデンシャルを取得
        
        Args:
            p12_path: P12ファイルのパス（オプション）
            p12_password: P12ファイルのパスワード（オプション）
        
        Returns:
            Dict[str, str]: AWSクレデンシャル情報
        """
        try:
            # 既存の一時証明書をクリーンアップ
            self._cleanup_temp_certificates()
            email = None
            if self._is_running_on_colab() or self.force_google_auth:
                logger.info(f"{'Google Colab環境を検出' if self._is_running_on_colab() else 'Google認証を強制'}")
                email = self._get_google_credentials()
                logger.info(f"Google認証成功: {email}")

            logger.info("mTLS認証を使用します。")
            
            # P12ファイルが指定された場合は、そこから証明書を抽出
            if p12_path:
                logger.info(f"P12ファイルを使用して認証を実行: {p12_path}")
                self.p12_path = p12_path
                self.p12_password = p12_password
                self.cert_path, self.key_path, self.ca_path = self._extract_from_p12(p12_path, p12_password)
                self.temp_dir = os.path.dirname(self.cert_path)
                self.set_pem_environemnt_for_mlflow(self.cert_path)
            
            creds = self._get_credentials_from_auth_server(email=email)
            
            # 環境変数の設定
            self.set_environment_variables(creds)
            
            # 一時的なクレデンシャルを保存
            self.tmp_creds = creds
            
            self._log_auth_event('login_success', {
                'environment': 'colab' if self._is_running_on_colab() else 'development',
                'auth_method': 'google' if (self._is_running_on_colab() or self.force_google_auth) else 'mtls',
                'expiration': creds['expiration'],
                'using_p12': bool(p12_path)
            })
            
            return {
                'aws_access_key_id': creds['access_key_id'],
                'aws_secret_access_key': creds['secret_access_key'],
                'aws_session_token': creds['session_token'],
                'expiration': creds['expiration']
            }
            
        except Exception as e:
            self._log_auth_event('login_error', {
                'error': str(e),
                'auth_method': 'google' if (self._is_running_on_colab() or self.force_google_auth) else 'mtls',
                'using_p12': bool(p12_path)
            }, success=False)
            # エラー時も一時ファイルをクリーンアップ
            self._cleanup_temp_certificates()
            raise AuthenticationError(f"認証中にエラーが発生しました: {str(e)}")

    def set_environment_variables(self, credentials: Dict[str, Any]):
        """環境変数にクレデンシャルを設定"""
        os.environ['PHUNT_ACCESS_KEY'] = credentials['access_key_id']
        os.environ['PHUNT_SECRET_KEY'] = credentials['secret_access_key']
        os.environ['PHUNT_SESSION_TOKEN'] = credentials['session_token']
        os.environ['AWS_ACCESS_KEY_ID'] = credentials['access_key_id']
        os.environ['AWS_SECRET_ACCESS_KEY'] = credentials['secret_access_key']
        os.environ['AWS_SESSION_TOKEN'] = credentials['session_token']
        os.environ['AWS_REGION'] = 'ap-northeast-1'

    @classmethod
    def login_required(cls, func):
        """ログインが必要な操作のデコレータ"""
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            if not self.is_logged_in():
                raise AuthenticationError("この操作にはログインが必要です。login()メソッドを先に呼び出してください。")
            return func(self, *args, **kwargs)
        return wrapper

    def is_logged_in(self) -> bool:
        """ログイン状態を確認"""
        if not self.tmp_creds:
            return False
        
        # 有効期限の確認
        expiration = datetime.fromisoformat(self.tmp_creds['expiration'].replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        
        # 有効期限が近づいている場合は警告を出す
        warning_threshold = now + timedelta(minutes=5)
        if expiration <= warning_threshold:
            logger.warning(f"クレデンシャルの有効期限が近づいています。有効期限: {expiration}")
            
            # 有効期限が切れそうな場合、P12情報があれば再認証を試みる
            if expiration <= now and self.p12_path:
                logger.info("P12証明書を使用して再認証を実行します")
                self.login(self.p12_path, self.p12_password)
        
        return expiration > now
    
    def run_auth_server(self, block=True):
        run_auth_server(block=block)

    def __del__(self):
        """デストラクタでの一時ファイルのクリーンアップ"""
        try:
            self._cleanup_temp_certificates()
        except Exception:
            # デストラクタ内のエラーは無視
            pass

if __name__ == "__main__":
    # 開発環境でのテスト用
    auth = PHuntAuth(
        cert_path="auth_server/certs/client.crt",
        key_path="auth_server/certs/client.key",
        ca_path="auth_server/certs/ca.crt"
    )
    creds = auth.login()
    print(creds)
