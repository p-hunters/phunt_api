"""
Test script for target plugins

This script tests the target plugin functionality, calculating and registering
various target values using the PHuntAPI.
"""

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import os

from phunt_api import PHuntAPI

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_target_plugins():
    """
    Test target plugin functionality
    """
    logger.info("Initializing PHuntAPI")
    api = PHuntAPI(debug=True)
    
    # List available target plugins
    logger.info("Listing available target plugins")
    plugins = api.list_target_plugins()
    logger.info(f"Found {len(plugins)} target plugins:")
    for plugin in plugins:
        logger.info(f"- {plugin['name']}: {plugin['description']}")
    
    # Generate sample data for testing
    logger.info("Generating sample data")
    dates = pd.date_range(start='2023-01-01', end='2023-06-30', freq='D')
    prices = np.linspace(100, 200, len(dates))
    
    # Add some randomness and trend
    prices = prices + np.random.normal(0, 5, len(dates))
    prices = np.cumsum(np.random.normal(0, 1, len(dates))) + prices
    
    # Create sample DataFrame
    data = pd.DataFrame({
        'open': prices * 0.99,
        'high': prices * 1.03,
        'low': prices * 0.97,
        'close': prices,
        'volume': np.random.randint(1000, 10000, len(dates))
    }, index=dates)
    
    logger.info(f"Generated sample data with shape {data.shape}")
    
    try:
        # Calculate future returns target
        logger.info("Calculating future returns target")
        future_returns = api.calculate_target(
            data=data,
            plugin_name='price_targets',
            target_type='future_return',
            periods=[1, 5, 10, 20],
            price_col='close',
            threshold=0.01
        )
        
        logger.info(f"Future returns target shape: {future_returns.shape}")
        logger.info(f"Future returns columns: {future_returns.columns.tolist()}")
        
        # Calculate price movement target
        logger.info("Calculating price movement target")
        price_movement = api.calculate_target(
            data=data,
            plugin_name='price_targets',
            target_type='price_movement',
            periods=[1, 5, 10, 20],
            price_col='close',
            threshold=0.01
        )
        
        logger.info(f"Price movement target shape: {price_movement.shape}")
        logger.info(f"Price movement columns: {price_movement.columns.tolist()}")
        
        # Calculate volatility target
        logger.info("Calculating volatility target")
        volatility_target = api.calculate_target(
            data=data,
            plugin_name='price_targets',
            target_type='volatility_target',
            periods=[5, 10, 20],
            price_col='close',
            threshold=0.03
        )
        
        logger.info(f"Volatility target shape: {volatility_target.shape}")
        logger.info(f"Volatility target columns: {volatility_target.columns.tolist()}")
        
        # Register future returns target
        logger.info("Registering future returns target")
        future_returns_id = api.register_target(
            data=data,
            plugin_name='price_targets',
            target_name='future_returns_test',
            target_type='future_return',
            periods=[1, 5, 10, 20],
            price_col='close',
            threshold=0.01,
            description='Future returns target for sample data',
            tags=['test', 'returns', 'future']
        )
        
        logger.info(f"Registered future returns target with ID: {future_returns_id}")
        
        # Get target info
        target_info = api.get_target_info(future_returns_id)
        logger.info(f"Target info: {target_info}")
        
        # Visualize the target
        plot_target(api, future_returns_id, data, 'Future Returns')
        
        # Register price movement target
        logger.info("Registering price movement target")
        price_movement_id = api.register_target(
            data=data,
            plugin_name='price_targets',
            target_name='price_movement_test',
            target_type='price_movement',
            periods=[1, 5, 10],
            price_col='close',
            threshold=0.01,
            description='Price movement target for sample data',
            tags=['test', 'movement', 'direction']
        )
        
        logger.info(f"Registered price movement target with ID: {price_movement_id}")
        
        # Get target data
        price_movement_data = api.get_target(price_movement_id)
        logger.info(f"Price movement data shape: {price_movement_data.shape}")
        
        # List all registered targets
        targets = api.list_targets()
        logger.info(f"Registered targets: {len(targets)}")
        for target in targets:
            logger.info(f"- {target['name']} (ID: {target['id']})")
        
        # Delete target
        logger.info(f"Deleting target with ID: {price_movement_id}")
        success = api.delete_target(price_movement_id)
        logger.info(f"Target deletion {'successful' if success else 'failed'}")
        
        logger.info("Target plugin test completed successfully")
    except Exception as e:
        logger.error(f"Error in target plugin test: {e}")
        raise


def plot_target(api, target_id, price_data, title):
    """
    Plot a target with price data
    
    Args:
        api: PHuntAPI instance
        target_id: Target ID
        price_data: Price DataFrame
        title: Plot title
    """
    target_data = api.get_target(target_id)
    target_info = api.get_target_info(target_id)
    
    # Create a figure
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
    
    # Plot prices
    ax1.plot(price_data.index, price_data['close'], label='Close Price')
    ax1.set_title(f"Price Data: {title}")
    ax1.set_ylabel('Price')
    ax1.legend()
    ax1.grid(True)
    
    # Plot target (first column)
    target_col = target_data.columns[0]
    ax2.plot(target_data.index, target_data[target_col], label=target_col)
    
    # Plot additional target columns if available
    if len(target_data.columns) > 1:
        target_col2 = target_data.columns[1]
        ax2.plot(target_data.index, target_data[target_col2], label=target_col2, alpha=0.7)
    
    ax2.set_title(f"Target: {target_info['name']}")
    ax2.set_xlabel('Date')
    ax2.set_ylabel('Target Value')
    ax2.legend()
    ax2.grid(True)
    
    plt.tight_layout()
    
    # Create plots directory if it doesn't exist
    os.makedirs('plots', exist_ok=True)
    
    # Save the figure
    plot_path = f"plots/target_{target_info['name']}.png"
    plt.savefig(plot_path)
    logger.info(f"Saved target plot to {plot_path}")
    
    plt.close(fig)


if __name__ == "__main__":
    test_target_plugins() 