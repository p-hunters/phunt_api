from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Any, Union
import pandas as pd

class AbstractFeatureStore(ABC):
    """
    Abstract Interface for Feature Store operations.
    Supports both Feast (Legacy) and Datacatalog (New) backends.
    """

    @abstractmethod
    def list_feature_views(self, tags: Optional[Dict[str, str]] = None) -> List[Any]:
        """
        List available feature views or datasets.
        """
        pass

    @abstractmethod
    def get_feature_view(self, name: str) -> Any:
        """
        Get definition of a feature view.
        """
        pass

    @abstractmethod
    def get_historical_features(self, entity_df: pd.DataFrame, feature_refs: List[str]) -> pd.DataFrame:
        """
        Retrieve historical features for the given entities.
        
        Args:
            entity_df: DataFrame containing entity keys and timestamps.
            feature_refs: List of feature references (e.g. "view:col").
        """
        pass

    @abstractmethod
    def create_feature_view(self, name: str, entities: List[str], schema: Any, **kwargs) -> Any:
        """
        Create or register a new feature view.
        """
        pass
    
    @abstractmethod
    def update_feature_view(self, feature_view: Any) -> None:
        """
        Update an existing feature view.
        """
        pass

    @abstractmethod
    def delete_feature_view(self, name: str) -> None:
        """
        Delete a feature view.
        """
        pass
