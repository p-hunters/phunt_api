
import uvicorn
import os
import argparse

def main():
    parser = argparse.ArgumentParser(description="Run PHunt API Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    
    args = parser.parse_args()
    
    # We need to run uvicorn. run directly
    # Note: "phunt_api.api_server:app" string is needed for reload to work
    if args.reload:
        uvicorn.run("phunt_api.api_server:app", host=args.host, port=args.port, reload=True)
    else:
        from phunt_api.api_server import app
        uvicorn.run(app, host=args.host, port=args.port)

if __name__ == "__main__":
    main()
