import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta
import logging
from typing import Optional, Dict, List, Tuple, Union
import pickle
import joblib
from pathlib import Path
import glob
import numba
from numba import jit, njit, prange

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
# Matplotlibの日本語フォント設定
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Hiragino Sans', 'Yu Gothic', 'Meiryo']
plt.rcParams['axes.unicode_minus'] = False
    
# Numbaで最適化されたトレードシミュレーション用のヘルパー関数
@njit
def _calculate_trade_result(current_position, entry_price, exit_price, position_size_units, commission):
    """
    トレード結果を計算する最適化されたヘルパー関数
    
    Args:
        current_position: 現在のポジション ('long'=1, 'short'=-1)
        entry_price: エントリー価格
        exit_price: 決済価格
        position_size_units: ポジションサイズ（単位）
        commission: 手数料（単位あたり）
        
    Returns:
        pnl: 損益（手数料控除後）
    """
    if current_position == 1:  # long
        pnl = (exit_price - entry_price) * position_size_units
    else:  # short
        pnl = (entry_price - exit_price) * position_size_units
        
    # 手数料の差し引き
    commission_cost = commission * position_size_units * 2  # 往復手数料
    pnl -= commission_cost
    
    return pnl

@njit
def _check_stop_loss_take_profit(current_position, entry_price, current_high, current_low, 
                               stop_loss_price, take_profit_price):
    """
    損切り・利益確定条件をチェックする最適化されたヘルパー関数
    
    Returns:
        tuple: (stop_loss_triggered, take_profit_triggered, exit_price)
    """
    stop_loss_triggered = False
    take_profit_triggered = False
    exit_price = 0.0
    
    # 損切りチェック
    if stop_loss_price is not None:
        if (current_position == 1 and current_low <= stop_loss_price) or \
           (current_position == -1 and current_high >= stop_loss_price):
            stop_loss_triggered = True
            exit_price = stop_loss_price
            
    # 利益確定チェック
    elif take_profit_price is not None:
        if (current_position == 1 and current_high >= take_profit_price) or \
           (current_position == -1 and current_low <= take_profit_price):
            take_profit_triggered = True
            exit_price = take_profit_price
            
    return stop_loss_triggered, take_profit_triggered, exit_price

@njit
def _calculate_drawdown_numba(equity_array):
    """
    最大ドローダウンを計算する最適化されたヘルパー関数
    
    Args:
        equity_array: 資金曲線の配列
        
    Returns:
        tuple: (最大ドローダウン率, 最大ドローダウンの開始インデックス, 最大ドローダウンの終了インデックス)
    """
    n = len(equity_array)
    if n <= 1:
        return 0.0, 0, 0
        
    # 累積最大値を計算
    running_max = np.zeros(n)
    running_max[0] = equity_array[0]
    for i in range(1, n):
        running_max[i] = max(running_max[i-1], equity_array[i])
    
    # ドローダウンを計算
    drawdown = (equity_array - running_max) / running_max
    
    # 最大ドローダウンを特定
    max_dd_idx = np.argmin(drawdown)
    max_drawdown = drawdown[max_dd_idx]
    
    # 最後のピークを見つける
    last_peak_idx = 0
    max_equity = equity_array[0]
    for i in range(1, max_dd_idx + 1):
        if equity_array[i] > max_equity:
            max_equity = equity_array[i]
            last_peak_idx = i
    
    # 回復インデックスを見つける
    recovery_idx = n - 1  # デフォルトは最後のインデックス
    for i in range(max_dd_idx + 1, n):
        if equity_array[i] >= equity_array[last_peak_idx]:
            recovery_idx = i
            break
            
    return max_drawdown, last_peak_idx, recovery_idx

@njit
def _calculate_sharpe_ratio_numba(returns_array, risk_free_rate=0.0, periods_per_year=252):
    """
    シャープレシオを計算する最適化されたヘルパー関数
    
    Args:
        returns_array: リターンの配列
        risk_free_rate: リスクフリーレート
        periods_per_year: 年間期間数
        
    Returns:
        float: シャープレシオ
    """
    if len(returns_array) <= 1:
        return 0.0
        
    # 平均リターンと標準偏差を計算
    mean_return = np.mean(returns_array)
    std_return = np.std(returns_array)
    
    if std_return == 0:
        return 0.0
        
    # 年率化
    annual_return = mean_return * periods_per_year
    annual_std = std_return * np.sqrt(periods_per_year)
    
    # シャープレシオ
    sharpe_ratio = (annual_return - risk_free_rate) / annual_std
    
    return sharpe_ratio

class Backtest:
    """
    予測モデルの結果を使用してバックテストを実行するクラス。
    取引戦略のパフォーマンスを評価し、投資指標に基づいて分析を行います。
    """
    def __init__(self, 
                 pred_data_path: str = None, 
                 model_path: str = None,
                 output_dir: str = None,
                 initial_balance: float = 10000.0,
                 position_size: float = 0.1,
                 commission: float = 0.0,
                 spread_cost: Optional[float] = None,
                 stop_loss: Optional[float] = None,
                 take_profit: Optional[float] = None,
                 probability_threshold: float = 0.55,  # 0.5から0.55に変更
                 max_holding_time: int = 30,  # 最大保有時間（分）
                 min_time_between_trades: int = 60):  # 取引間の最小時間（分）
        """
        バックテストクラスの初期化メソッド
        
        Args:
            pred_data_path (str): 予測結果が含まれるCSVファイルのパス
            model_path (str): トレーニング済みモデルのパス
            output_dir (str): 結果出力ディレクトリ
            initial_balance (float): 初期資金
            position_size (float): ポジションサイズ（資金に対する割合）
            commission (float): 取引手数料（pip単位）
            spread_cost (float, optional): スプレッドコスト（pip単位）
            stop_loss (float, optional): 損切り値（pip単位）
            take_profit (float, optional): 利益確定値（pip単位）
            probability_threshold (float): 取引シグナルを生成する予測確率の閾値
            max_holding_time (int): 最大ポジション保有時間（分）
            min_time_between_trades: 取引間の最小時間（分）
        """
        self.pred_data_path = pred_data_path
        self.model_path = model_path
        self.output_dir = output_dir or "daily_outputs/backtest_results"
        
        # 取引パラメータ
        self.initial_balance = initial_balance
        self.position_size = position_size
        self.commission = commission
        self.spread_cost = spread_cost
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.probability_threshold = probability_threshold
        self.max_holding_time = max_holding_time
        self.min_time_between_trades = min_time_between_trades
        
        # データと結果を格納する変数
        self.data = None
        self.model = None
        self.trades = []
        self.equity_curve = None
        self.performance_metrics = {}
        
        # ディレクトリ作成
        os.makedirs(self.output_dir, exist_ok=True)
        logger.info(f"バックテスト結果の出力ディレクトリを作成しました: {self.output_dir}")

    def load_prediction_data(self) -> pd.DataFrame:
        """
        予測結果を含むデータセットを読み込みます。
        
        Returns:
            pd.DataFrame: 予測結果を含むデータフレーム
        """
        if self.pred_data_path is None:
            raise ValueError("予測データのパスが指定されていません")
            
        logger.info(f"予測データを読み込んでいます: {self.pred_data_path}")
        try:
            # CSVファイルからデータを読み込む
            data = pd.read_csv(self.pred_data_path)
            
            # タイムスタンプカラムを確認し、必要に応じて変換
            if 'ts' in data.columns:
                data['ts'] = pd.to_datetime(data['ts'])
                # インデックスを設定（オプション）
                data.set_index('ts', inplace=True)
                data.sort_index(inplace=True)
                logger.info(f"データのタイムスタンプ範囲: {data.index.min()} から {data.index.max()}")
            
            # 予測カラムの存在確認
            required_columns = ['price_direction_10', 'pred', 'pred_proba']
            missing_columns = [col for col in required_columns if col not in data.columns]
            if missing_columns:
                logger.warning(f"以下のカラムがデータセットにありません: {missing_columns}")
                
                # 予測カラムがない場合は、モデルから予測を生成する必要がある
                if 'pred' not in data.columns and self.model is not None:
                    logger.info("モデルを使用して予測を生成します")
                    # ここでモデル予測のロジックを追加できます
            
            # 必須のカラムを確認
            price_columns = ['open', 'high', 'low', 'close']
            if not all(col in data.columns for col in price_columns):
                logger.warning("価格データ (open, high, low, close) が不完全です")
            
            logger.info(f"データ読み込み完了: {len(data)} 行, {data.columns.tolist()} カラム")
            return data
            
        except Exception as e:
            logger.error(f"データの読み込み中にエラーが発生しました: {str(e)}")
            raise
    
    def load_model(self):
        """
        トレーニング済みのモデルを読み込みます。
        
        Returns:
            object: 読み込まれたモデル
        """
        if self.model_path is None:
            logger.warning("モデルパスが指定されていません。モデルなしで続行します。")
            return None
            
        logger.info(f"モデルを読み込んでいます: {self.model_path}")
        try:
            # ファイル拡張子に基づいてロード方法を決定
            file_ext = Path(self.model_path).suffix.lower()
            
            if file_ext == '.pkl':
                with open(self.model_path, 'rb') as f:
                    model = pickle.load(f)
            elif file_ext == '.joblib':
                model = joblib.load(self.model_path)
            elif file_ext == '.txt' or file_ext == '.model':
                # LightGBMモデルの場合
                import lightgbm as lgb
                model = lgb.Booster(model_file=self.model_path)
            else:
                raise ValueError(f"未対応のモデルファイル形式です: {file_ext}")
                
            logger.info("モデルの読み込みが完了しました")
            return model
            
        except Exception as e:
            logger.error(f"モデルの読み込み中にエラーが発生しました: {str(e)}")
            raise

    def run(self):
        """バックテストのメイン実行メソッド"""
        logger.info("バックテストを開始します...")
        
        # データとモデルの読み込み
        try:
            self.data = self.load_prediction_data()
            self.model = self.load_model()
        except Exception as e:
            logger.error(f"データまたはモデルの読み込みに失敗しました: {str(e)}")
            return
            
        # シグナル生成と取引シミュレーション
        self.generate_signals()
        self.simulate_trades()
        
        # パフォーマンス指標の計算と可視化
        self.calculate_performance_metrics()
        self.visualize_results()
        self.save_results()
        
        # Markdownレポートの生成
        self.generate_markdown_report()
        
        logger.info("バックテストが完了しました")

    def generate_signals(self):
        """
        モデル予測または既存の予測結果から取引シグナルを生成します。
        probability_thresholdより高い確率の予測のみを取引シグナルとして採用します。
        """
        logger.info("取引シグナルを生成しています...")
        logger.info(f"確率閾値: {self.probability_threshold}")
        
        # 'pred'カラムがなく、'pred_proba'がある場合は閾値に基づいて予測を生成
        if 'pred' not in self.data.columns and 'pred_proba' in self.data.columns:
            threshold = self.probability_threshold
            self.data['pred'] = (self.data['pred_proba'] > threshold).astype(int)
            logger.info(f"確率閾値 {threshold} に基づいて予測を生成しました")
            
        # 'pred'カラムも'pred_proba'カラムもない場合は、モデルを使って予測
        elif 'pred' not in self.data.columns and self.model is not None:
            logger.info("モデルを使用して予測を生成しています...")
            try:
                # 特徴量カラムを特定
                # LightGBMモデルの場合、特徴量名を取得
                if hasattr(self.model, 'feature_name'):
                    feature_cols = self.model.feature_name()
                else:
                    # モデルから特徴量を取得できない場合、データセットから推測
                    # ここでは単純化のために、価格・ボリューム・テクニカル指標を除外
                    exclude_cols = ['ts', 'open', 'high', 'low', 'close', 'volume', 'spread',
                                   'price_direction_10', 'pred', 'pred_proba']
                    feature_cols = [col for col in self.data.columns if col not in exclude_cols]
                
                # 予測を実行
                if hasattr(self.model, 'predict_proba'):
                    # scikit-learnスタイルのモデル
                    X = self.data[feature_cols]
                    self.data['pred_proba'] = self.model.predict_proba(X)[:, 1]
                    self.data['pred'] = (self.data['pred_proba'] > self.probability_threshold).astype(int)
                elif hasattr(self.model, 'predict'):
                    # 一般的な予測メソッド
                    X = self.data[feature_cols]
                    if hasattr(self.model, 'predict_proba'):
                        self.data['pred_proba'] = self.model.predict_proba(X)[:, 1]
                        self.data['pred'] = (self.data['pred_proba'] > self.probability_threshold).astype(int)
                    else:
                        self.data['pred'] = self.model.predict(X)
                else:
                    logger.error("モデルに互換性のある予測メソッドがありません")
                    return
                    
                logger.info("モデルを使用した予測生成が完了しました")
                
            except Exception as e:
                logger.error(f"予測生成中にエラーが発生しました: {str(e)}")
                return
                
        # 取引シグナルの生成
        # -1: ホールド（取引なし）、0: 売り（下落予測）、1: 買い（上昇予測）
        self.data['signal'] = -1  # デフォルトはホールド
        
        # 予測確率に基づくシグナルを設定
        if 'pred' in self.data.columns and 'pred_proba' in self.data.columns:
            # 上昇予測で高確率のみを買いシグナルとする
            high_prob_up = (self.data['pred'] == 1) & (self.data['pred_proba'] >= self.probability_threshold)
            self.data.loc[high_prob_up, 'signal'] = 1
            
            # 下降予測で高確率のみを売りシグナルとする
            high_prob_down = (self.data['pred'] == 0) & (self.data['pred_proba'] >= 0.55)  # 固定閾値を使用
            self.data.loc[high_prob_down, 'signal'] = 0
            
        elif 'pred' in self.data.columns:
            # 予測確率がない場合は予測値のみで判断
            self.data.loc[self.data['pred'] == 1, 'signal'] = 1
            self.data.loc[self.data['pred'] == 0, 'signal'] = 0
            
        # 取引間の最小時間に基づいてシグナルをフィルタリング
        if self.min_time_between_trades > 0:
            logger.info(f"取引間の最小時間: {self.min_time_between_trades}分")
            
            # 直近のトレードフラグとタイムスタンプを初期化
            last_trade_time = None
            min_time_delta = timedelta(minutes=self.min_time_between_trades)
            
            # シグナルを時系列順に走査
            for idx, row in self.data.iterrows():
                current_signal = row['signal']
                # シグナルがホールド以外（トレード候補）の場合
                if current_signal != -1:
                    if last_trade_time is None:
                        # 最初のトレードは許可
                        last_trade_time = idx
                    else:
                        # 前回のトレードからの経過時間を確認
                        time_since_last_trade = idx - last_trade_time
                        if time_since_last_trade < min_time_delta:
                            # 最小間隔未満の場合はシグナルをホールドに変更
                            self.data.loc[idx, 'signal'] = -1
                        else:
                            # 最小間隔以上経過している場合はシグナルを維持し、最終トレード時間を更新
                            last_trade_time = idx
        
        # シグナル統計
        signal_counts = self.data['signal'].value_counts()
        
        # シグナル統計のログ出力
        logger.info(f"シグナル統計: {signal_counts.to_dict()}")
        
        # シグナル有効率（ホールド以外のシグナルの割合）
        valid_signal_ratio = (len(self.data) - signal_counts.get(-1, 0)) / len(self.data) * 100
        logger.info(f"有効シグナル率: {valid_signal_ratio:.2f}%")
        
        return self.data

    def simulate_trades(self):
        """
        取引シミュレーションを実行
        
        Returns:
            tuple: (エクイティカーブ, トレード情報)
        """
        logger.info("取引シミュレーションを開始します...")
        
        # 必要なカラムの存在を確認
        if 'signal' not in self.data.columns:
            logger.error("データに 'signal' カラムがありません。generate_signals() を先に実行してください。")
            return None, []
        
        # 必要な価格データの確認
        required_price_cols = ['open', 'high', 'low', 'close']
        for col in required_price_cols:
            if col not in self.data.columns:
                logger.error(f"データに '{col}' カラムがありません。")
                return None, []
        
        # 損切り・利益確定値のログ
        if self.stop_loss is not None:
            logger.info(f"損切り設定: {self.stop_loss} pips")
        if self.take_profit is not None:
            logger.info(f"利益確定設定: {self.take_profit} pips")
        
        # 最大保有時間のログ
        logger.info(f"最大保有時間設定: {self.max_holding_time} 分")
        
        # トレード情報を格納するリストを初期化
        self.trades = []
        
        # スプレッドの取得
        spread = self.data['spread'].values if 'spread' in self.data.columns else None
        
        # numpy配列に変換
        timestamps = self.data.index.astype(np.int64).values / 10**9  # Unix timestamp (seconds)
        opens = self.data['open'].values
        highs = self.data['high'].values
        lows = self.data['low'].values
        closes = self.data['close'].values
        signals = self.data['signal'].values
        
        # 高速シミュレーション実行
        equity_curve, trades_data = self._simulate_trades_numba(
            timestamps, opens, highs, lows, closes, signals, spread,
            self.initial_balance, self.position_size, self.commission,
            self.stop_loss, self.take_profit, self.max_holding_time
        )
        
        # 結果の処理
        self.equity_curve = pd.Series(equity_curve, index=self.data.index)
        
        # トレード情報のDataFrame作成
        if len(trades_data) > 0:
            exit_reason_map = {
                1: 'シグナル変更',
                2: 'stop_loss',
                3: 'take_profit',
                4: 'max_holding_time',
                5: '最終バー強制決済'
            }
            
            for i in range(len(trades_data)):
                entry_time = datetime.fromtimestamp(trades_data[i, 0])
                position = 'buy' if trades_data[i, 1] == 1 else 'sell'
                entry_price = trades_data[i, 2]
                exit_time = datetime.fromtimestamp(trades_data[i, 3])
                exit_price = trades_data[i, 4]
                pnl = trades_data[i, 5]
                commission_cost = trades_data[i, 6]
                exit_reason_code = int(trades_data[i, 7])
                exit_reason = exit_reason_map.get(exit_reason_code, '不明')
                
                # トレード期間の計算
                duration = exit_time - entry_time
                
                trade_info = {
                    'entry_time': entry_time,
                    'position': position,
                    'entry_price': entry_price,
                    'exit_time': exit_time,
                    'exit_price': exit_price,
                    'pnl': pnl,
                    'commission': commission_cost,
                    'duration': duration,
                    'exit_reason': exit_reason
                }
                
                self.trades.append(trade_info)
        
        # トレード統計の出力
        if len(self.trades) > 0:
            # 勝率の計算
            winning_trades = sum(1 for trade in self.trades if trade['pnl'] > 0)
            total_trades = len(self.trades)
            win_rate = (winning_trades / total_trades) * 100
            
            # 決済理由の集計
            exit_reasons = {}
            for trade in self.trades:
                reason = trade['exit_reason']
                if reason in exit_reasons:
                    exit_reasons[reason] += 1
                else:
                    exit_reasons[reason] = 1
            
            logger.info(f"シミュレーション完了: {total_trades} 取引")
            logger.info(f"初期残高: {self.initial_balance}, 最終残高: {self.equity_curve.iloc[-1]}")
            logger.info(f"総利益: {self.equity_curve.iloc[-1] - self.initial_balance}")
            logger.info(f"決済理由統計: {exit_reasons}")
            logger.info(f"勝率: {win_rate:.2f}% ({winning_trades} 勝 / {total_trades - winning_trades} 敗)")
        else:
            logger.warning("シミュレーション期間中にトレードはありませんでした。")
        
        return self.equity_curve, self.trades

    def _simulate_trades_numba(self, timestamps, opens, highs, lows, closes, signals, spreads,
                               initial_balance, position_size, commission, stop_loss, take_profit, max_holding_time):
        """
        Numbaを使用した高速なトレードシミュレーション
        
        Returns:
            tuple: シミュレーション結果 (エクイティカーブ, トレード情報)
        """
        n = len(signals)
        # 最大トレード数を見積もる
        max_trades = min(n, 10000)  # 十分な大きさの配列を確保
        
        # トレード情報を保存する配列
        # [エントリー時刻, ポジション, エントリー価格, 決済時刻, 決済価格, 損益, コミッション, 決済理由]
        # 決済理由コード: 1=シグナル変更, 2=ストップロス, 3=テイクプロフィット, 4=最大保有時間, 5=最終バー
        trades_info = np.zeros((max_trades, 8), dtype=np.float64)
        
        # エクイティカーブ
        equity_curve = np.ones(n, dtype=np.float64) * initial_balance
        
        # ポジション情報 [現在のポジション, エントリー価格, エントリー時間インデックス, 保有時間]
        # 現在のポジション: 0=なし, 1=ロング, -1=ショート
        positions = np.zeros(4, dtype=np.float64)
        
        # コアシミュレーション関数を呼び出す
        total_trades = self._simulate_trades_core(
            timestamps, opens, highs, lows, closes, signals, spreads,
            initial_balance, position_size, commission,
            stop_loss, take_profit, max_holding_time, self.min_time_between_trades, 
            trades_info, max_trades, equity_curve, positions
        )
        
        # 有効なトレード情報のみを抽出
        valid_trades = trades_info[:total_trades]
        
        return equity_curve, valid_trades

    @staticmethod
    @njit
    def _simulate_trades_core(timestamps, opens, highs, lows, closes, signals, spreads,
                              initial_balance, position_size, commission,
                              stop_loss, take_profit, max_holding_time, min_time_between_trades, 
                              trades_info, max_trades, equity_curve, positions):
        """
        トレードシミュレーションのコア関数 (Numba JITコンパイル版)
        
        Args:
            timestamps: タイムスタンプ配列
            opens/highs/lows/closes: 価格データ配列
            signals: シグナル配列
            spreads: スプレッド配列
            initial_balance: 初期資金
            position_size: ポジションサイズ（割合）
            commission: 取引手数料
            stop_loss: 損切り値（pips）
            take_profit: 利益確定値（pips）
            max_holding_time: 最大保有時間（分）
            min_time_between_trades: 取引間の最小時間（分）
            trades_info: トレード情報を格納する配列
            max_trades: 最大トレード数
            equity_curve: エクイティカーブ配列
            positions: ポジション情報配列
            
        Returns:
            int: 実行されたトレードの総数
        """
        current_balance = initial_balance
        trade_count = 0
        
        # ポジション情報
        current_position = 0  # 0=なし, 1=ロング, -1=ショート
        entry_price = 0.0
        entry_index = 0
        holding_time = 0
        
        # 前回トレードクローズ時刻を記録
        last_trade_close_time = 0.0
        min_time_delta = min_time_between_trades * 60  # 分から秒へ変換
        
        for i in range(len(signals)):
            # 前のバーから引き継いだポジションがある場合は、保有時間をインクリメント
            if current_position != 0:
                holding_time += 1
            
            # 現在のバーのデータ
            current_signal = signals[i]
            current_open = opens[i]
            current_high = highs[i]
            current_low = lows[i]
            current_close = closes[i]
            current_spread = spreads[i] if spreads is not None else 0.0
            current_time = timestamps[i]
            
            # 現在のバーの開始時に決済判定（前のバーからポジションを持っている場合）
            exit_reason = 0  # 0=決済なし
            exit_price = 0.0
            
            if current_position != 0:
                # ストップロスとテイクプロフィットの計算
                sl_price = 0.0
                tp_price = 0.0
                
                if stop_loss is not None and stop_loss > 0:
                    if current_position == 1:  # ロング
                        sl_price = entry_price - stop_loss * 0.0001
                    else:  # ショート
                        sl_price = entry_price + stop_loss * 0.0001
                
                if take_profit is not None and take_profit > 0:
                    if current_position == 1:  # ロング
                        tp_price = entry_price + take_profit * 0.0001
                    else:  # ショート
                        tp_price = entry_price - take_profit * 0.0001
                
                # 前のバーでストップロスまたはテイクプロフィットに達したか確認
                if i > 0:
                    prev_high = highs[i-1]
                    prev_low = lows[i-1]
                    
                    # ストップロスチェック
                    if stop_loss is not None and stop_loss > 0:
                        if (current_position == 1 and prev_low <= sl_price) or \
                           (current_position == -1 and prev_high >= sl_price):
                            exit_reason = 2  # ストップロス
                            exit_price = sl_price
                    
                    # テイクプロフィットチェック
                    if exit_reason == 0 and take_profit is not None and take_profit > 0:
                        if (current_position == 1 and prev_high >= tp_price) or \
                           (current_position == -1 and prev_low <= tp_price):
                            exit_reason = 3  # テイクプロフィット
                            exit_price = tp_price
                
                # 最大保有時間チェック
                if exit_reason == 0 and max_holding_time > 0 and holding_time >= max_holding_time:
                    exit_reason = 4  # 最大保有時間
                    # スプレッドを考慮した決済価格
                    if current_position == 1:
                        exit_price = current_open - current_spread * 0.0001  # ロングポジションを閉じる (Bid価格)
                    else:
                        exit_price = current_open + current_spread * 0.0001  # ショートポジションを閉じる (Ask価格)
                
                # シグナル変更での決済
                if exit_reason == 0 and (current_signal != current_position and current_signal != 0):
                    exit_reason = 1  # シグナル変更
                    # スプレッドを考慮した決済価格
                    if current_position == 1:
                        exit_price = current_open - current_spread * 0.0001  # ロングポジションを閉じる (Bid価格)
                    else:
                        exit_price = current_open + current_spread * 0.0001  # ショートポジションを閉じる (Ask価格)
            
            # 決済処理
            if current_position != 0 and exit_reason > 0:
                # ポジションサイズの計算
                position_value = current_balance * position_size
                position_size_units = position_value / entry_price
                
                # 損益計算
                pnl = _calculate_trade_result(current_position, entry_price, exit_price, position_size_units, commission)
                
                # 残高更新
                current_balance += pnl
                
                # 往復手数料計算 (すでにpnlから差し引かれているが記録用に計算)
                commission_cost = commission * position_value * 2
                
                # トレード情報の記録
                if trade_count < max_trades:
                    trades_info[trade_count, 0] = timestamps[entry_index]  # エントリー時刻
                    trades_info[trade_count, 1] = current_position  # ポジション方向
                    trades_info[trade_count, 2] = entry_price  # エントリー価格
                    trades_info[trade_count, 3] = timestamps[i]  # 決済時刻
                    trades_info[trade_count, 4] = exit_price  # 決済価格
                    trades_info[trade_count, 5] = pnl  # 損益
                    trades_info[trade_count, 6] = commission_cost  # 往復手数料
                    trades_info[trade_count, 7] = exit_reason  # 決済理由
                    trade_count += 1
                
                # 前回トレードクローズ時刻を更新
                last_trade_close_time = current_time
                
                # ポジションをリセット
                current_position = 0
                entry_price = 0.0
                entry_index = 0
                holding_time = 0
            
            # 新規エントリー判定（ポジションがない場合のみ）
            if current_position == 0 and current_signal != 0:
                # 前回トレードクローズからの経過時間をチェック
                time_since_last_trade = current_time - last_trade_close_time
                
                # 最小トレード間隔を満たしている場合のみエントリー
                if last_trade_close_time == 0.0 or time_since_last_trade >= min_time_delta:
                    current_position = current_signal
                    
                    # スプレッドを考慮したエントリー価格
                    if current_position == 1:
                        entry_price = current_open + current_spread * 0.0001  # ロングポジションを開く (Ask価格)
                    else:
                        entry_price = current_open - current_spread * 0.0001  # ショートポジションを開く (Bid価格)
                    
                    entry_index = i
                    holding_time = 0
            
            # エクイティカーブの更新
            equity_curve[i] = current_balance
        
        # 最終バーでのポジション決済
        if current_position != 0:
            # 最終価格
            final_price = closes[-1]
            
            # スプレッドを考慮した決済価格
            if current_position == 1:
                exit_price = final_price - spreads[-1] * 0.0001 if spreads is not None else final_price  # ロングポジションを閉じる (Bid価格)
            else:
                exit_price = final_price + spreads[-1] * 0.0001 if spreads is not None else final_price  # ショートポジションを閉じる (Ask価格)
            
            # ポジションサイズの計算
            position_value = current_balance * position_size
            position_size_units = position_value / entry_price
            
            # 損益計算
            pnl = _calculate_trade_result(current_position, entry_price, exit_price, position_size_units, commission)
            
            # 残高更新
            current_balance += pnl
            
            # 往復手数料計算 (すでにpnlから差し引かれているが記録用に計算)
            commission_cost = commission * position_value * 2
            
            # トレード情報の記録
            if trade_count < max_trades:
                trades_info[trade_count, 0] = timestamps[entry_index]  # エントリー時刻
                trades_info[trade_count, 1] = current_position  # ポジション方向
                trades_info[trade_count, 2] = entry_price  # エントリー価格
                trades_info[trade_count, 3] = timestamps[-1]  # 決済時刻
                trades_info[trade_count, 4] = exit_price  # 決済価格
                trades_info[trade_count, 5] = pnl  # 損益
                trades_info[trade_count, 6] = commission_cost  # 往復手数料
                trades_info[trade_count, 7] = 5  # 決済理由: 最終バー強制決済
                trade_count += 1
            
            # 最終エクイティカーブの更新
            equity_curve[-1] = current_balance
        
        # ポジション情報の更新
        positions[0] = current_position
        positions[1] = entry_price
        positions[2] = entry_index
        positions[3] = holding_time
        
        return trade_count

    def calculate_performance_metrics(self):
        """
        パフォーマンス指標を計算します
        """
        logger.info("パフォーマンス指標の計算を開始します...")
        
        # トレードデータの確認
        if not hasattr(self, 'trades') or len(self.trades) == 0:
            logger.warning("トレード履歴がありません。パフォーマンス指標を計算できません。")
            return {}
        
        # エクイティカーブの確認
        if not hasattr(self, 'equity_curve') or self.equity_curve is None:
            logger.error("資金曲線データがありません。パフォーマンス指標の計算に必要です。")
            return {}
        
        # パフォーマンス指標の辞書を初期化
        self.performance_metrics = {}
        
        # 基本的な資金情報
        self.performance_metrics['initial_balance'] = self.initial_balance
        self.performance_metrics['final_balance'] = self.equity_curve.iloc[-1]
        self.performance_metrics['net_profit'] = self.equity_curve.iloc[-1] - self.initial_balance
        
        # リターン率
        self.performance_metrics['total_return_pct'] = (self.equity_curve.iloc[-1] / self.initial_balance - 1) * 100
        
        # 取引統計
        self.performance_metrics['total_trades'] = len(self.trades)
        winning_trades = sum(1 for trade in self.trades if trade['pnl'] > 0)
        losing_trades = sum(1 for trade in self.trades if trade['pnl'] <= 0)
        self.performance_metrics['winning_trades'] = winning_trades
        self.performance_metrics['losing_trades'] = losing_trades
        
        # 勝率
        win_rate = (winning_trades / len(self.trades)) * 100 if len(self.trades) > 0 else 0
        self.performance_metrics['win_rate'] = win_rate
        
        # 損益関連指標
        if winning_trades > 0:
            total_profit = sum(trade['pnl'] for trade in self.trades if trade['pnl'] > 0)
            avg_profit = total_profit / winning_trades
            self.performance_metrics['avg_profit'] = avg_profit
        else:
            self.performance_metrics['avg_profit'] = 0
        
        if losing_trades > 0:
            total_loss = abs(sum(trade['pnl'] for trade in self.trades if trade['pnl'] <= 0))
            avg_loss = total_loss / losing_trades
            self.performance_metrics['avg_loss'] = avg_loss
        else:
            self.performance_metrics['avg_loss'] = 0
        
        # 平均トレード損益
        avg_trade = sum(trade['pnl'] for trade in self.trades) / len(self.trades) if len(self.trades) > 0 else 0
        self.performance_metrics['avg_trade'] = avg_trade
        
        # プロフィットファクター
        if self.performance_metrics['avg_loss'] > 0:
            profit_factor = self.performance_metrics['avg_profit'] / self.performance_metrics['avg_loss']
        else:
            profit_factor = float('inf') if self.performance_metrics['avg_profit'] > 0 else 0
        self.performance_metrics['profit_factor'] = profit_factor
        
        # リスクリワード比率
        self.performance_metrics['risk_reward_ratio'] = profit_factor
        
        # トレード期間関連
        if len(self.trades) > 0:
            durations = [(trade['exit_time'] - trade['entry_time']) for trade in self.trades]
            avg_duration = sum(durations, timedelta()) / len(durations)
            self.performance_metrics['avg_trade_duration'] = avg_duration
            
            # 勝ちトレードと負けトレードの平均期間
            if winning_trades > 0:
                winning_durations = [(trade['exit_time'] - trade['entry_time']) for trade in self.trades if trade['pnl'] > 0]
                avg_winning_duration = sum(winning_durations, timedelta()) / len(winning_durations)
                self.performance_metrics['avg_winning_trade_duration'] = avg_winning_duration
            
            if losing_trades > 0:
                losing_durations = [(trade['exit_time'] - trade['entry_time']) for trade in self.trades if trade['pnl'] <= 0]
                avg_losing_duration = sum(losing_durations, timedelta()) / len(losing_durations)
                self.performance_metrics['avg_losing_trade_duration'] = avg_losing_duration
        
        # ドローダウン関連
        max_dd, max_dd_duration = self._calculate_drawdown(self.equity_curve)
        self.performance_metrics['max_drawdown_pct'] = max_dd * 100
        self.performance_metrics['max_drawdown_duration'] = max_dd_duration
        
        # 年率リターン
        annual_return = self._calculate_annual_return(self.equity_curve)
        self.performance_metrics['annual_return_pct'] = annual_return * 100
        
        # リスク調整済みリターン指標
        equity_returns = self.equity_curve.pct_change().dropna()
        
        # シャープレシオ
        sharpe_ratio = self._calculate_sharpe_ratio(equity_returns)
        self.performance_metrics['sharpe_ratio'] = sharpe_ratio
        
        # ソルティノレシオ
        sortino_ratio = self._calculate_sortino_ratio(equity_returns)
        self.performance_metrics['sortino_ratio'] = sortino_ratio
        
        # ===== BUY/SELL別のパフォーマンス指標 =====
        logger.info("BUY/SELL別のパフォーマンス指標を計算します...")
        
        # BUYとSELLのトレードを分離
        buy_trades = [trade for trade in self.trades if trade['position'] == 'buy']
        sell_trades = [trade for trade in self.trades if trade['position'] == 'sell']
        
        # BUYトレードの指標
        buy_metrics = {}
        if len(buy_trades) > 0:
            # 基本統計
            buy_metrics['total_trades'] = len(buy_trades)
            buy_winning_trades = sum(1 for trade in buy_trades if trade['pnl'] > 0)
            buy_losing_trades = sum(1 for trade in buy_trades if trade['pnl'] <= 0)
            buy_metrics['winning_trades'] = buy_winning_trades
            buy_metrics['losing_trades'] = buy_losing_trades
            
            # 勝率
            buy_win_rate = (buy_winning_trades / len(buy_trades)) * 100 if len(buy_trades) > 0 else 0
            buy_metrics['win_rate'] = buy_win_rate
            
            # 損益関連指標
            if buy_winning_trades > 0:
                buy_total_profit = sum(trade['pnl'] for trade in buy_trades if trade['pnl'] > 0)
                buy_avg_profit = buy_total_profit / buy_winning_trades
                buy_metrics['avg_profit'] = buy_avg_profit
            else:
                buy_metrics['avg_profit'] = 0
            
            if buy_losing_trades > 0:
                buy_total_loss = abs(sum(trade['pnl'] for trade in buy_trades if trade['pnl'] <= 0))
                buy_avg_loss = buy_total_loss / buy_losing_trades
                buy_metrics['avg_loss'] = buy_avg_loss
            else:
                buy_metrics['avg_loss'] = 0
            
            # 平均トレード損益
            buy_avg_trade = sum(trade['pnl'] for trade in buy_trades) / len(buy_trades)
            buy_metrics['avg_trade'] = buy_avg_trade
            
            # プロフィットファクター
            if buy_metrics['avg_loss'] > 0:
                buy_profit_factor = buy_metrics['avg_profit'] / buy_metrics['avg_loss']
            else:
                buy_profit_factor = float('inf') if buy_metrics['avg_profit'] > 0 else 0
            buy_metrics['profit_factor'] = buy_profit_factor
            
            # トレード期間
            buy_durations = [(trade['exit_time'] - trade['entry_time']) for trade in buy_trades]
            buy_avg_duration = sum(buy_durations, timedelta()) / len(buy_durations)
            buy_metrics['avg_trade_duration'] = buy_avg_duration
            
            # 合計損益
            buy_metrics['total_pnl'] = sum(trade['pnl'] for trade in buy_trades)
            
            # 決済理由分布
            buy_exit_reasons = {}
            for trade in buy_trades:
                reason = trade['exit_reason']
                if reason in buy_exit_reasons:
                    buy_exit_reasons[reason] += 1
                else:
                    buy_exit_reasons[reason] = 1
            buy_metrics['exit_reasons'] = buy_exit_reasons
            
        # SELLトレードの指標
        sell_metrics = {}
        if len(sell_trades) > 0:
            # 基本統計
            sell_metrics['total_trades'] = len(sell_trades)
            sell_winning_trades = sum(1 for trade in sell_trades if trade['pnl'] > 0)
            sell_losing_trades = sum(1 for trade in sell_trades if trade['pnl'] <= 0)
            sell_metrics['winning_trades'] = sell_winning_trades
            sell_metrics['losing_trades'] = sell_losing_trades
            
            # 勝率
            sell_win_rate = (sell_winning_trades / len(sell_trades)) * 100 if len(sell_trades) > 0 else 0
            sell_metrics['win_rate'] = sell_win_rate
            
            # 損益関連指標
            if sell_winning_trades > 0:
                sell_total_profit = sum(trade['pnl'] for trade in sell_trades if trade['pnl'] > 0)
                sell_avg_profit = sell_total_profit / sell_winning_trades
                sell_metrics['avg_profit'] = sell_avg_profit
            else:
                sell_metrics['avg_profit'] = 0
            
            if sell_losing_trades > 0:
                sell_total_loss = abs(sum(trade['pnl'] for trade in sell_trades if trade['pnl'] <= 0))
                sell_avg_loss = sell_total_loss / sell_losing_trades
                sell_metrics['avg_loss'] = sell_avg_loss
            else:
                sell_metrics['avg_loss'] = 0
            
            # 平均トレード損益
            sell_avg_trade = sum(trade['pnl'] for trade in sell_trades) / len(sell_trades)
            sell_metrics['avg_trade'] = sell_avg_trade
            
            # プロフィットファクター
            if sell_metrics['avg_loss'] > 0:
                sell_profit_factor = sell_metrics['avg_profit'] / sell_metrics['avg_loss']
            else:
                sell_profit_factor = float('inf') if sell_metrics['avg_profit'] > 0 else 0
            sell_metrics['profit_factor'] = sell_profit_factor
            
            # トレード期間
            sell_durations = [(trade['exit_time'] - trade['entry_time']) for trade in sell_trades]
            sell_avg_duration = sum(sell_durations, timedelta()) / len(sell_durations)
            sell_metrics['avg_trade_duration'] = sell_avg_duration
            
            # 合計損益
            sell_metrics['total_pnl'] = sum(trade['pnl'] for trade in sell_trades)
            
            # 決済理由分布
            sell_exit_reasons = {}
            for trade in sell_trades:
                reason = trade['exit_reason']
                if reason in sell_exit_reasons:
                    sell_exit_reasons[reason] += 1
                else:
                    sell_exit_reasons[reason] = 1
            sell_metrics['exit_reasons'] = sell_exit_reasons
        
        # BUY/SELL指標をメインの指標辞書に追加
        self.performance_metrics['buy_metrics'] = buy_metrics
        self.performance_metrics['sell_metrics'] = sell_metrics
        
        # BUY/SELL指標のログ出力
        logger.info("===== BUY取引の指標 =====")
        if buy_metrics:
            for key, value in buy_metrics.items():
                if key != 'exit_reasons':
                    logger.info(f"BUY_{key}: {value}")
            logger.info(f"BUY_exit_reasons: {buy_metrics.get('exit_reasons', {})}")
        else:
            logger.info("BUY取引がありません")
            
        logger.info("===== SELL取引の指標 =====")
        if sell_metrics:
            for key, value in sell_metrics.items():
                if key != 'exit_reasons':
                    logger.info(f"SELL_{key}: {value}")
            logger.info(f"SELL_exit_reasons: {sell_metrics.get('exit_reasons', {})}")
        else:
            logger.info("SELL取引がありません")
        
        # 計算結果のログ出力
        logger.info("===== 全体の指標 =====")
        for key, value in self.performance_metrics.items():
            if key not in ['buy_metrics', 'sell_metrics']:
                logger.info(f"{key}: {value}")
        
        logger.info("パフォーマンス指標の計算が完了しました")
        
        return self.performance_metrics

    def _calculate_drawdown(self, equity_series):
        """
        資金曲線からの最大ドローダウンとその期間を計算
        
        Returns:
            tuple: (最大ドローダウン率, 最大ドローダウン期間)
        """
        # numbaで最適化されたバージョンを使用
        equity_array = equity_series.to_numpy()
        max_drawdown, peak_idx, recovery_idx = _calculate_drawdown_numba(equity_array)
        
        max_drawdown_duration = timedelta(0)
        if isinstance(equity_series.index, pd.DatetimeIndex):
            if peak_idx < len(equity_series.index) and recovery_idx < len(equity_series.index):
                max_drawdown_duration = equity_series.index[recovery_idx] - equity_series.index[peak_idx]
        else:
            # インデックスがDatetimeでない場合
            max_drawdown_duration = timedelta(seconds=(recovery_idx - peak_idx) * 60)  # 1分足データと仮定
            
        return max_drawdown, max_drawdown_duration
    
    def _calculate_annual_return(self, equity_series):
        """
        年間リターンを計算
        
        Returns:
            float: 年間リターン率
        """
        if len(equity_series) <= 1:
            return 0.0
            
        start_value = equity_series.iloc[0]
        end_value = equity_series.iloc[-1]
        total_return = (end_value - start_value) / start_value
        
        # 日数の計算
        if isinstance(equity_series.index, pd.DatetimeIndex):
            start_date = equity_series.index[0]
            end_date = equity_series.index[-1]
            days = (end_date - start_date).days
        else:
            # インデックスがDatetimeでない場合
            days = len(equity_series) / (60 * 24)  # 1分足データと仮定
            
        if days > 0:
            annual_return = total_return * (365 / days)
        else:
            annual_return = 0.0
            
        return annual_return
    
    def _calculate_sharpe_ratio(self, returns, risk_free_rate=0.0, periods_per_year=252):
        """
        シャープレシオの計算
        
        Args:
            returns: リターンのSeries
            risk_free_rate: リスクフリーレート
            periods_per_year: 年間の期間数（日足データなら252、時間足なら252*24など）
            
        Returns:
            float: シャープレシオ
        """
        if len(returns) <= 1:
            return 0.0
            
        # numbaで最適化された計算を使用
        returns_array = returns.to_numpy()
        sharpe_ratio = _calculate_sharpe_ratio_numba(returns_array, risk_free_rate, periods_per_year)
        return sharpe_ratio
    
    def _calculate_sortino_ratio(self, returns, risk_free_rate=0.0, periods_per_year=252):
        """
        ソルティノレシオの計算（ダウンサイドリスクのみを考慮）
        
        Args:
            returns: リターンのSeries
            risk_free_rate: リスクフリーレート
            periods_per_year: 年間の期間数
            
        Returns:
            float: ソルティノレシオ
        """
        if len(returns) <= 1:
            return 0.0
            
        # numbaで最適化された計算を使用
        returns_array = returns.to_numpy()
        # ダウンサイドリターンのみ抽出
        downside_returns = returns_array[returns_array < 0]
        
        if len(downside_returns) > 0:
            # 平均リターンと標準偏差を計算
            mean_return = np.mean(returns_array)
            downside_std = np.std(downside_returns)
            
            if downside_std == 0:
                return float('inf')
                
            # 年率化
            annual_return = mean_return * periods_per_year
            annual_downside_std = downside_std * np.sqrt(periods_per_year)
            
            # ソルティノレシオ
            sortino_ratio = (annual_return - risk_free_rate) / annual_downside_std
            
            return sortino_ratio
        else:
            return float('inf')

    def visualize_results(self):
        """
        バックテスト結果の可視化
        """
        logger.info("バックテスト結果の可視化を開始します...")
        
        # エクイティカーブの確認
        if not hasattr(self, 'equity_curve') or self.equity_curve is None:
            logger.error("資金曲線データがありません。可視化を実行できません。")
            return
        
        # トレードデータの確認
        if not hasattr(self, 'trades') or len(self.trades) == 0:
            logger.warning("トレード履歴がありません。一部のグラフのみ生成します。")
        
        # 大きなデータセットの場合はダウンサンプリング
        equity_data = self.equity_curve
        if len(equity_data) > 10000:
            sample_step = len(equity_data) // 10000 + 1
            logger.info(f"データが多いため、{sample_step}ステップごとにダウンサンプリングします。"
                       f"元のデータ: {len(equity_data)}行 → 処理データ: 約{len(equity_data) // sample_step}行")
            equity_data = equity_data.iloc[::sample_step]
        
        # 出力ディレクトリの確認
        output_prefix = os.path.join(self.output_dir, f"backtest_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        
        # 1. 資金曲線の可視化
        start_time = datetime.now()
        fig, ax = plt.subplots(figsize=(12, 8))
        ax.plot(equity_data.index, equity_data.values, label='Equity')
        ax.axhline(y=self.initial_balance, color='r', linestyle='--', alpha=0.3, label='Initial Balance')
        ax.set_xlabel('Date')
        ax.set_ylabel('Equity')
        ax.set_title('Equity Curve')
        ax.legend()
        plt.tight_layout()
        plt.savefig(f"{output_prefix}_equity_curve.png", dpi=150)
        plt.close()
        logger.info(f"資金曲線のプロット完了：所要時間 {datetime.now() - start_time}")
        
        # 2. ドローダウンの可視化
        start_time = datetime.now()
        fig, ax = plt.subplots(figsize=(12, 8))
        running_max = equity_data.cummax()
        drawdown = (equity_data - running_max) / running_max * 100
        ax.plot(equity_data.index, drawdown, color='red')
        ax.fill_between(equity_data.index, drawdown, 0, color='red', alpha=0.1)
        ax.set_title('Drawdown (%)')
        ax.set_xlabel('Date')
        ax.set_ylabel('Drawdown (%)')
        plt.tight_layout()
        plt.savefig(f"{output_prefix}_drawdown.png", dpi=150)
        plt.close()
        logger.info(f"ドローダウンのプロット完了：所要時間 {datetime.now() - start_time}")
        
        # トレードデータが存在する場合の追加の可視化
        if self.trades and len(self.trades) > 0:
            # 3. PnL分布
            start_time = datetime.now()
            fig, ax = plt.subplots(figsize=(12, 8))
            pnl_values = [trade['pnl'] for trade in self.trades]
            ax.hist(pnl_values, bins=min(50, len(self.trades) // 10 + 5))
            ax.axvline(x=0, color='r', linestyle='--')
            ax.set_title('Trade PnL Distribution')
            ax.set_xlabel('PnL')
            ax.set_ylabel('Frequency')
            plt.tight_layout()
            plt.savefig(f"{output_prefix}_pnl_distribution.png", dpi=150)
            plt.close()
            logger.info(f"PnL分布のプロット完了：所要時間 {datetime.now() - start_time}")
            
            # 4. 累積PnL
            start_time = datetime.now()
            fig, ax = plt.subplots(figsize=(12, 8))
            # トレードを時間でソート
            sorted_trades = sorted(self.trades, key=lambda x: x['exit_time'])
            cumulative_pnl = [0]
            for trade in sorted_trades:
                cumulative_pnl.append(cumulative_pnl[-1] + trade['pnl'])
            ax.plot(range(len(cumulative_pnl)), cumulative_pnl)
            ax.set_title('Cumulative PnL')
            ax.set_xlabel('Trade #')
            ax.set_ylabel('Cumulative PnL')
            plt.tight_layout()
            plt.savefig(f"{output_prefix}_cumulative_pnl.png", dpi=150)
            plt.close()
            logger.info(f"累積PnLのプロット完了：所要時間 {datetime.now() - start_time}")
            
            # 5. トレードタイプ分布
            start_time = datetime.now()
            fig, ax = plt.subplots(figsize=(12, 8))
            position_counts = {'buy': 0, 'sell': 0}
            for trade in self.trades:
                position = trade['position']
                if position in position_counts:
                    position_counts[position] += 1
                else:
                    position_counts[position] = 1
            ax.bar(position_counts.keys(), position_counts.values())
            ax.set_title('Trade Type Distribution')
            ax.set_xlabel('Position Type')
            ax.set_ylabel('Count')
            plt.tight_layout()
            plt.savefig(f"{output_prefix}_trade_types.png", dpi=150)
            plt.close()
            logger.info(f"トレードタイプ分布のプロット完了：所要時間 {datetime.now() - start_time}")
            
            # 6. トレード期間比較
            start_time = datetime.now()
            fig, ax = plt.subplots(figsize=(12, 8))
            profit_durations = [(trade['exit_time'] - trade['entry_time']).total_seconds() / 3600 
                                for trade in self.trades if trade['pnl'] > 0]  # 時間単位
            loss_durations = [(trade['exit_time'] - trade['entry_time']).total_seconds() / 3600 
                              for trade in self.trades if trade['pnl'] <= 0]  # 時間単位
            
            data = []
            labels = []
            if profit_durations:
                data.append(profit_durations)
                labels.append('Profit Trades')
            if loss_durations:
                data.append(loss_durations)
                labels.append('Loss Trades')
            
            if data:
                ax.boxplot(data, labels=labels)
                ax.set_title('Trade Duration by Outcome')
                ax.set_ylabel('Duration (hours)')
                plt.tight_layout()
                plt.savefig(f"{output_prefix}_trade_duration.png", dpi=150)
                plt.close()
            logger.info(f"トレード期間比較のプロット完了：所要時間 {datetime.now() - start_time}")
        
        # 7. パフォーマンス指標の概要
        if hasattr(self, 'performance_metrics') and self.performance_metrics:
            start_time = datetime.now()
            fig, ax = plt.subplots(figsize=(12, 10))
            
            # 表示する指標
            display_metrics = [
                'initial_balance', 'final_balance', 'net_profit', 'total_return_pct', 'annual_return_pct',
                'total_trades', 'winning_trades', 'losing_trades', 'win_rate',
                'profit_factor', 'avg_profit', 'avg_loss', 'risk_reward_ratio',
                'max_drawdown_pct', 'sharpe_ratio', 'sortino_ratio'
            ]
            
            display_names = {
                'initial_balance': '初期資金',
                'final_balance': '最終資金',
                'net_profit': '純利益',
                'total_return_pct': '総リターン (%)',
                'annual_return_pct': '年間リターン (%)',
                'total_trades': 'トレード数',
                'winning_trades': '勝ちトレード',
                'losing_trades': '負けトレード',
                'win_rate': '勝率 (%)',
                'profit_factor': 'プロフィットファクター',
                'avg_profit': '平均利益',
                'avg_loss': '平均損失',
                'risk_reward_ratio': 'リスク/リワード比',
                'max_drawdown_pct': '最大ドローダウン (%)',
                'sharpe_ratio': 'シャープレシオ',
                'sortino_ratio': 'ソルティノレシオ'
            }
            
            # 表示する指標のみ抽出
            metrics_to_display = []
            for key in display_metrics:
                if key in self.performance_metrics:
                    metrics_to_display.append((display_names.get(key, key), self.performance_metrics[key]))
            
            metrics_df = pd.DataFrame(metrics_to_display, columns=['指標', '値'])
            
            # テーブルとして表示
            ax.axis('tight')
            ax.axis('off')
            table = ax.table(cellText=metrics_df.values, colLabels=metrics_df.columns,
                            loc='center', cellLoc='center')
            table.auto_set_font_size(False)
            table.set_fontsize(12)
            table.scale(1, 1.5)
            
            plt.title('バックテストパフォーマンス指標', fontsize=16)
            plt.tight_layout()
            plt.savefig(f"{output_prefix}_performance_metrics.png", dpi=150)
            plt.close()
            logger.info(f"パフォーマンス指標のプロット完了：所要時間 {datetime.now() - start_time}")
        
        logger.info(f"バックテスト結果の可視化が完了しました。出力ディレクトリ: {self.output_dir}")
        
        return

    def save_results(self):
        """
        バックテスト結果をCSVファイルとして保存します。
        トレード履歴、資金曲線、パフォーマンス指標などを保存します。
        """
        logger.info("バックテスト結果を保存しています...")
        
        if self.data is None or len(self.data) == 0:
            logger.error("データがありません。結果を保存できません。")
            return
            
        # 出力ディレクトリの確認と作成
        os.makedirs(self.output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 1. シミュレーション結果の保存
        if 'equity' in self.data.columns:
            # 保存するデータの選択
            columns_to_save = ['equity']
            if 'signal' in self.data.columns:
                columns_to_save.append('signal')
            if 'position' in self.data.columns:
                columns_to_save.append('position')
                
            # 価格データがあれば追加
            price_columns = ['open', 'high', 'low', 'close']
            for col in price_columns:
                if col in self.data.columns:
                    columns_to_save.append(col)
                    
            # ボリュームデータがあれば追加
            if 'volume' in self.data.columns:
                columns_to_save.append('volume')
                
            # インデックスをリセット（タイムスタンプをカラムに追加）
            result_df = self.data[columns_to_save].copy()
            if isinstance(result_df.index, pd.DatetimeIndex):
                result_df = result_df.reset_index()
                result_df.rename(columns={'index': 'timestamp'}, inplace=True)
                
            # 結果の保存
            sim_results_path = os.path.join(self.output_dir, f"simulation_results_{timestamp}.csv")
            result_df.to_csv(sim_results_path, index=False)
            logger.info(f"シミュレーション結果を保存しました: {sim_results_path}")
            
        # 2. トレード履歴の保存
        if hasattr(self, 'trades') and len(self.trades) > 0:
            trades_df = pd.DataFrame(self.trades)
            
            # 日時列をタイムスタンプ形式に変換
            datetime_cols = ['entry_time', 'exit_time']
            for col in datetime_cols:
                if col in trades_df.columns:
                    try:
                        trades_df[col] = pd.to_datetime(trades_df[col])
                    except:
                        pass  # 変換できない場合はそのまま
                        
            trades_path = os.path.join(self.output_dir, f"trades_{timestamp}.csv")
            trades_df.to_csv(trades_path, index=False)
            logger.info(f"トレード履歴を保存しました: {trades_path}")
            
        # 3. パフォーマンス指標の保存
        if hasattr(self, 'performance_metrics') and self.performance_metrics:
            metrics_df = pd.DataFrame(list(self.performance_metrics.items()), columns=['Metric', 'Value'])
            metrics_path = os.path.join(self.output_dir, f"performance_metrics_{timestamp}.csv")
            metrics_df.to_csv(metrics_path, index=False)
            logger.info(f"パフォーマンス指標を保存しました: {metrics_path}")
            
        # 4. 設定情報の保存
        config = {
            'pred_data_path': self.pred_data_path,
            'model_path': self.model_path,
            'initial_balance': self.initial_balance,
            'position_size': self.position_size,
            'commission': self.commission,
            'spread_cost': self.spread_cost,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit,
            'probability_threshold': self.probability_threshold,
            'max_holding_time': self.max_holding_time,
            'min_time_between_trades': self.min_time_between_trades
        }
        
        config_df = pd.DataFrame(list(config.items()), columns=['Parameter', 'Value'])
        config_path = os.path.join(self.output_dir, f"config_{timestamp}.csv")
        config_df.to_csv(config_path, index=False)
        logger.info(f"設定情報を保存しました: {config_path}")
        
        return self.output_dir

    def generate_markdown_report(self):
        """
        バックテスト結果を含むMarkdownレポートを生成します。
        パフォーマンス指標、グラフ画像、トレード統計などを含みます。
        
        Returns:
            str: 生成されたMarkdownレポートのファイルパス
        """
        logger.info("Markdownレポートを生成しています...")
        
        # 出力ファイルパスの設定
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_filename = f"backtest_report_{timestamp}.md"
        report_path = os.path.join(self.output_dir, report_filename)
        
        # 画像ファイル名のパターン
        image_pattern = os.path.join(self.output_dir, "backtest_*")
        image_files = glob.glob(image_pattern + ".png")
        
        # 相対パス変換のための関数
        def get_relative_path(path):
            return os.path.relpath(path, os.path.dirname(report_path))
        
        # タイトルと日時
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # レポート内容の作成
        report_content = [
            f"# EURUSDバックテストレポート\n",
            f"**生成日時**: {current_time}\n\n",
            f"## バックテスト設定\n",
            f"- **予測データ**: {self.pred_data_path}\n",
            f"- **モデル**: {self.model_path}\n",
            f"- **初期資金**: {self.initial_balance:,.2f}\n",
            f"- **ポジションサイズ**: {self.position_size:.2%}\n",
            f"- **取引手数料**: {self.commission:.4f}\n",
            f"- **スプレッド**: {self.spread_cost if self.spread_cost is not None else 'なし'}\n\n",
            
            f"## パフォーマンス概要\n\n"
        ]
        
        # パフォーマンス指標がある場合
        if hasattr(self, 'performance_metrics') and self.performance_metrics:
            metrics = self.performance_metrics
            
            # 基本統計
            report_content.extend([
                f"### 基本統計\n\n",
                f"| 指標 | 値 |\n",
                f"|------|------|\n",
                f"| 初期資金 | {metrics.get('initial_balance', 'N/A'):,.2f} |\n",
                f"| 最終資金 | {metrics.get('final_balance', 'N/A'):,.2f} |\n",
                f"| 純利益 | {metrics.get('net_profit', 'N/A'):,.2f} |\n",
                f"| 総リターン | {metrics.get('total_return_pct', 'N/A'):.2f}% |\n",
                f"| 年間リターン | {metrics.get('annual_return_pct', 'N/A'):.2f}% |\n\n"
            ])
            
            # トレード統計
            report_content.extend([
                f"### トレード統計\n\n",
                f"| 指標 | 値 |\n",
                f"|------|------|\n",
                f"| 総トレード数 | {metrics.get('total_trades', 'N/A')} |\n",
                f"| 勝ちトレード | {metrics.get('winning_trades', 'N/A')} |\n",
                f"| 負けトレード | {metrics.get('losing_trades', 'N/A')} |\n",
                f"| 勝率 | {metrics.get('win_rate', 'N/A'):.2%} |\n",
                f"| プロフィットファクター | {metrics.get('profit_factor', 'N/A'):.4f} |\n",
                f"| 平均利益 | {metrics.get('avg_profit', 'N/A'):,.4f} |\n",
                f"| 平均損失 | {metrics.get('avg_loss', 'N/A'):,.4f} |\n",
                f"| 平均トレード | {metrics.get('avg_trade', 'N/A'):,.4f} |\n",
                f"| リスクリワード比 | {metrics.get('risk_reward_ratio', 'N/A'):.4f} |\n\n"
            ])
            
            # リスク統計
            report_content.extend([
                f"### リスク統計\n\n",
                f"| 指標 | 値 |\n",
                f"|------|------|\n",
                f"| 最大ドローダウン | {metrics.get('max_drawdown_pct', 'N/A'):.2f}% |\n",
                f"| 最大ドローダウン期間 | {metrics.get('max_drawdown_duration', 'N/A')} |\n",
                f"| シャープレシオ | {metrics.get('sharpe_ratio', 'N/A'):.4f} |\n",
                f"| ソルティノレシオ | {metrics.get('sortino_ratio', 'N/A'):.4f} |\n\n"
            ])
            
            # 時間統計
            report_content.extend([
                f"### 時間統計\n\n",
                f"| 指標 | 値 |\n",
                f"|------|------|\n",
                f"| 平均トレード期間 | {metrics.get('avg_trade_duration', 'N/A')} |\n",
                f"| 平均勝ちトレード期間 | {metrics.get('avg_winning_trade_duration', 'N/A')} |\n",
                f"| 平均負けトレード期間 | {metrics.get('avg_losing_trade_duration', 'N/A')} |\n\n"
            ])
            
            # BUY/SELL別の指標
            if 'buy_metrics' in metrics and metrics['buy_metrics']:
                buy_metrics = metrics['buy_metrics']
                report_content.extend([
                    f"### BUY取引の指標\n\n",
                    f"| 指標 | 値 |\n",
                    f"|------|------|\n",
                    f"| 総トレード数 | {buy_metrics.get('total_trades', 'N/A')} |\n",
                    f"| 勝ちトレード | {buy_metrics.get('winning_trades', 'N/A')} |\n",
                    f"| 負けトレード | {buy_metrics.get('losing_trades', 'N/A')} |\n",
                    f"| 勝率 | {buy_metrics.get('win_rate', 'N/A'):.2f}% |\n",
                    f"| プロフィットファクター | {buy_metrics.get('profit_factor', 'N/A'):.4f} |\n",
                    f"| 平均利益 | {buy_metrics.get('avg_profit', 'N/A'):,.4f} |\n",
                    f"| 平均損失 | {buy_metrics.get('avg_loss', 'N/A'):,.4f} |\n",
                    f"| 平均トレード | {buy_metrics.get('avg_trade', 'N/A'):,.4f} |\n",
                    f"| 平均トレード期間 | {buy_metrics.get('avg_trade_duration', 'N/A')} |\n",
                    f"| 合計損益 | {buy_metrics.get('total_pnl', 'N/A'):,.2f} |\n\n"
                ])
                
                # 決済理由の分布
                if 'exit_reasons' in buy_metrics:
                    report_content.append(f"#### BUY取引の決済理由\n\n")
                    report_content.append(f"| 決済理由 | 回数 |\n")
                    report_content.append(f"|------|------|\n")
                    for reason, count in buy_metrics['exit_reasons'].items():
                        report_content.append(f"| {reason} | {count} |\n")
                    report_content.append("\n")
            
            if 'sell_metrics' in metrics and metrics['sell_metrics']:
                sell_metrics = metrics['sell_metrics']
                report_content.extend([
                    f"### SELL取引の指標\n\n",
                    f"| 指標 | 値 |\n",
                    f"|------|------|\n",
                    f"| 総トレード数 | {sell_metrics.get('total_trades', 'N/A')} |\n",
                    f"| 勝ちトレード | {sell_metrics.get('winning_trades', 'N/A')} |\n",
                    f"| 負けトレード | {sell_metrics.get('losing_trades', 'N/A')} |\n",
                    f"| 勝率 | {sell_metrics.get('win_rate', 'N/A'):.2f}% |\n",
                    f"| プロフィットファクター | {sell_metrics.get('profit_factor', 'N/A'):.4f} |\n",
                    f"| 平均利益 | {sell_metrics.get('avg_profit', 'N/A'):,.4f} |\n",
                    f"| 平均損失 | {sell_metrics.get('avg_loss', 'N/A'):,.4f} |\n",
                    f"| 平均トレード | {sell_metrics.get('avg_trade', 'N/A'):,.4f} |\n",
                    f"| 平均トレード期間 | {sell_metrics.get('avg_trade_duration', 'N/A')} |\n",
                    f"| 合計損益 | {sell_metrics.get('total_pnl', 'N/A'):,.2f} |\n\n"
                ])
                
                # 決済理由の分布
                if 'exit_reasons' in sell_metrics:
                    report_content.append(f"#### SELL取引の決済理由\n\n")
                    report_content.append(f"| 決済理由 | 回数 |\n")
                    report_content.append(f"|------|------|\n")
                    for reason, count in sell_metrics['exit_reasons'].items():
                        report_content.append(f"| {reason} | {count} |\n")
                    report_content.append("\n")
        
        # グラフセクション
        report_content.append(f"## パフォーマンスグラフ\n\n")
        
        # 画像ファイルを検索して追加
        image_types = {
            "equity_curve": "資金曲線",
            "drawdown": "ドローダウン",
            "pnl_distribution": "損益分布",
            "cumulative_pnl": "累積損益",
            "trade_types": "トレードタイプ分布",
            "trade_duration": "トレード期間分布"
        }
        
        for img_type, img_title in image_types.items():
            matching_files = [f for f in image_files if img_type in f]
            if matching_files:
                img_path = matching_files[0]  # 最初のマッチするファイルを使用
                rel_path = get_relative_path(img_path)
                report_content.extend([
                    f"### {img_title}\n\n",
                    f"![{img_title}]({rel_path})\n\n"
                ])
        
        # トレードサマリー
        if hasattr(self, 'trades') and len(self.trades) > 0:
            # 上位5つの勝ちトレード
            profitable_trades = sorted([t for t in self.trades if 'pnl' in t and t['pnl'] > 0], 
                                      key=lambda x: x['pnl'], reverse=True)
            
            # 上位5つの負けトレード
            losing_trades = sorted([t for t in self.trades if 'pnl' in t and t['pnl'] <= 0], 
                                  key=lambda x: x['pnl'])
            
            if profitable_trades:
                report_content.extend([
                    f"## トレード詳細\n\n",
                    f"### 上位5つの勝ちトレード\n\n",
                    f"| エントリー時間 | 決済時間 | タイプ | エントリー価格 | 決済価格 | P&L |\n",
                    f"|-------------|---------|------|------------|-----------|------|\n"
                ])
                
                for trade in profitable_trades[:5]:
                    entry_time = trade.get('entry_time', 'N/A')
                    exit_time = trade.get('exit_time', 'N/A')
                    trade_type = trade.get('type', 'N/A')
                    entry_price = trade.get('entry_price', 'N/A')
                    exit_price = trade.get('exit_price', 'N/A')
                    pnl = trade.get('pnl', 'N/A')
                    
                    report_content.append(f"| {entry_time} | {exit_time} | {trade_type} | {entry_price:.5f} | {exit_price:.5f} | {pnl:.4f} |\n")
                
                report_content.append("\n")
            
            if losing_trades:
                report_content.extend([
                    f"### 上位5つの負けトレード\n\n",
                    f"| エントリー時間 | 決済時間 | タイプ | エントリー価格 | 決済価格 | P&L |\n",
                    f"|-------------|---------|------|------------|-----------|------|\n"
                ])
                
                for trade in losing_trades[:5]:
                    entry_time = trade.get('entry_time', 'N/A')
                    exit_time = trade.get('exit_time', 'N/A')
                    trade_type = trade.get('type', 'N/A')
                    entry_price = trade.get('entry_price', 'N/A')
                    exit_price = trade.get('exit_price', 'N/A')
                    pnl = trade.get('pnl', 'N/A')
                    
                    report_content.append(f"| {entry_time} | {exit_time} | {trade_type} | {entry_price:.5f} | {exit_price:.5f} | {pnl:.4f} |\n")
                
                report_content.append("\n")
        
        # 結論と改善提案
        report_content.extend([
            f"## 結論と改善提案\n\n",
            f"### 全体評価\n\n",
        ])
        
        # パフォーマンスに基づいた自動評価
        if hasattr(self, 'performance_metrics') and self.performance_metrics:
            metrics = self.performance_metrics
            net_profit = metrics.get('net_profit', 0)
            win_rate = metrics.get('win_rate', 0)
            
            if net_profit > 0:
                report_content.append(f"このバックテストでは、初期資金 {self.initial_balance:,.2f} から最終資金 {metrics.get('final_balance', 0):,.2f} まで増加し、純利益 {net_profit:,.2f} ({metrics.get('total_return_pct', 0):.2f}%) を達成しました。\n\n")
                
                if win_rate > 0.5:
                    report_content.append(f"勝率は {win_rate:.2%} と良好であり、戦略が効果的に機能していることを示しています。\n\n")
                else:
                    report_content.append(f"勝率は {win_rate:.2%} とやや低いですが、リスクリワード比が良好なため全体としては利益を上げています。\n\n")
            else:
                report_content.append(f"このバックテストでは、初期資金 {self.initial_balance:,.2f} から最終資金 {metrics.get('final_balance', 0):,.2f} に減少し、損失 {abs(net_profit):,.2f} ({abs(metrics.get('total_return_pct', 0)):.2f}%) が発生しました。\n\n")
                
                if win_rate < 0.3:
                    report_content.append(f"勝率は {win_rate:.2%} と非常に低く、戦略が市場の動きを適切に予測できていないことを示しています。\n\n")
                else:
                    report_content.append(f"勝率は {win_rate:.2%} であり、リスク管理を改善することで収益性を向上させる余地があります。\n\n")
            
            # 改善提案
            report_content.extend([
                f"### 改善提案\n\n",
                f"1. **予測精度の向上**: ",
                f"{'予測精度を高めるために特徴量の選択とモデルの最適化を検討する。' if win_rate < 0.4 else '現在の予測精度は良好だが、さらに改善の余地がある。'}\n",
                f"2. **シグナルフィルタリング**: 高確率の予測のみに基づいて取引することで、勝率を向上させる。\n",
                f"3. **ポジションサイジング**: {'リスク管理を強化するために、各トレードのポジションサイズを最適化する。' if net_profit < 0 else '利益を最大化するために、ポジションサイズ戦略をさらに洗練させる。'}\n",
                f"4. **{'取引頻度の見直し' if len(self.trades) > 500 else '市場条件の分析'}**: {'トレード数が多すぎるため、より質の高いシグナルに焦点を絞る。' if len(self.trades) > 500 else '異なる市場条件での戦略のパフォーマンスを分析し、適応させる。'}\n",
                f"5. **{'損切り・利益確定の最適化' if 'stop_loss' not in self.performance_metrics else '異なる時間枠での検証'}**: {'適切な損切りと利益確定レベルを設定することで、リスクリワード比を改善する。' if 'stop_loss' not in self.performance_metrics else '複数の時間枠で戦略をテストし、最適な取引環境を特定する。'}\n\n"
            ])
        
        # ファイルに書き込む
        with open(report_path, 'w') as f:
            f.write(''.join(report_content))
            
        logger.info(f"Markdownレポートを生成しました: {report_path}")
        
        return report_path