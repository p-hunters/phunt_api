

class Backtest:
    def __init__(self):
        pass

    def run(self):
        pass