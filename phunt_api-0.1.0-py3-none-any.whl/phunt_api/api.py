# -*- coding: utf-8 -*-

# Google Colabでのみ実行を想定したpackage
# Workspaceドメインのユーザーのみがアクセスできる
# 難読化する方法は、pyarmorを使う
# wheelファイルを作成して、pip installする

import os
import inspect
import textwrap
import pandas as pd
import subprocess
from pathlib import Path
import time
import warnings
from typing import List, Dict, Any, Callable, Tuple, Optional, Literal, Type, TypeVar, Generic, TYPE_CHECKING, Union
import requests
import logging
import datetime
from functools import wraps

# Pydantic V1スタイルの警告を抑制
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pydantic")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="mlflow")

from .auth import PHuntAuth
from .datasource import DataSourceManager
from .dataset import PublicDatasetManager, DatasetManager
from .feature import FeatureManager
from .model import ModelManager
from .target import TargetManager
from .exceptions import PHuntAPIException, AuthenticationError, DatasetError, FeatureError, ModelError, TargetError
from .utils import FeastManager, read_s3_file

# プラグインシステムをインポート
from .plugin_api import PluginFeatureAPI, PluginTargetAPI


# 抽出したユーティリティクラスをインポート
from .misc.cache import CacheManager
from .misc.server_utils import ServerUtils
from .misc.data_utils import DataUtils
from .misc.validation import ValidationUtils, ProcessingCodeProtocol
from .misc.signal_utils import SignalUtils
from .misc.submission_utils import SubmissionUtils
from .misc.decorators import handle_api_exceptions, with_cache

warnings.simplefilter("ignore")

logger = logging.getLogger(__name__)

class PHuntAPI:
    """Main API client for P-Hunter.
    
    This class provides a comprehensive interface for interacting with the P-Hunter
    trading system, including authentication, dataset management, and model operations."""
    
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(PHuntAPI, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, debug=False, 
                 cache_type: Literal["memory", "file"] = "file",
                 plugin_cache_dir: Optional[str] = None):
        if not self._initialized:
            self._initialize(debug, cache_type, plugin_cache_dir)
            
    def _initialize(self, debug=False, 
                 cache_type: Literal["memory", "file"] = "file",
                 plugin_cache_dir: Optional[str] = None):
        self.debug = debug
        self.auth = PHuntAuth(debug=debug)
        self.tmp_creds = None  # 認証情報（GCP認証情報も含む）
        self.repo_path = os.getenv("PHUNT_REPO_PATH", ".")
        self.reset_managers()
        self.validation_year = None

        # 抽出したユーティリティクラスの初期化
        self._cache_manager = CacheManager(cache_type)
        self._server_utils = ServerUtils()
        self._signal_utils = SignalUtils()
        
        # プラグインシステムの初期化
        self._plugin_feature_api = PluginFeatureAPI(plugin_cache_dir=plugin_cache_dir)
        self._plugin_target_api = PluginTargetAPI(plugin_cache_dir=plugin_cache_dir)
        self._initialized = True

        DataUtils.setup_plt()


    def setup_logging_plt(self, logging, plt, SCRIPT_DIR, MODEL_NAME):
        """ロギングとMatplotlibの設定を行う"""
        return DataUtils.setup_logging_plt(logging, plt, SCRIPT_DIR, MODEL_NAME)
    
    def reset_managers(self):
        self._dataset_manager = DatasetManager(self.repo_path)
        self._dataset_manager.set_creds(self.tmp_creds)
        self._feature_manager = FeatureManager(self._dataset_manager)
        self._target_manager = TargetManager(self._dataset_manager)
        self._model_manager = ModelManager(self._dataset_manager, self._feature_manager, self._target_manager)
        self._feast_manager = FeastManager(self.repo_path)

    # キャッシュ操作用のヘルパーメソッド
    def exists_in_cache(self, cache_key: str) -> bool:
        """キャッシュに指定されたキーが存在するかどうかをチェック"""
        return self._cache_manager.exists(cache_key)

    def get_from_cache(self, cache_key: str, default=None):
        """キャッシュから値を取得"""
        return self._cache_manager.get(cache_key, default)

    def set_to_cache(self, cache_key: str, value) -> None:
        """キャッシュに値を設定"""
        self._cache_manager.set(cache_key, value)

    def login(self, p12_path: Optional[str] = None, p12_password: Optional[str] = None):
        try:
            self.tmp_creds = self.auth.login(p12_path, p12_password)
            self._dataset_manager.set_creds(self.tmp_creds['aws'])
            
            # GCP認証情報が含まれているかログに出力
            if 'service_account_email' in self.tmp_creds['gcp']:
                logger.info("Google Cloud認証情報が認証レスポンスに含まれています")
                if self.debug:
                    logger.info("デバッグモードでGoogle Cloud認証情報が利用可能です")
            else:
                logger.warning("Google Cloud認証情報が認証レスポンスに含まれていません")
                if self.debug:
                    logger.warning("デバッグモードでもGoogle Cloud認証情報が取得できませんでした")
            self.reset_managers()

        except AuthenticationError as e:
            raise PHuntAPIException(f"認証エラー: {str(e)}")

    def is_logged_in(self):
        if self.debug:
            return True
        return self.tmp_creds is not None

    def has_gcp_access_token(self):
        """Google Cloud認証情報が利用可能かどうかを確認する"""
        return (self.tmp_creds is not None and 
                'gcp' in self.tmp_creds and 
                'token' in self.tmp_creds['gcp'] and 
                'service_account_email' in self.tmp_creds['gcp'])
    
    def get_gcp_access_token(self):
        """Google Cloud認証情報を取得する
        
        Returns:
            Dict: Google Cloud認証情報を含む辞書。認証情報がない場合はNone。
        """
        if self.has_gcp_access_token():
            return self.tmp_creds['gcp']
        return None
    
    def refresh_gcp_access_token_if_needed(self):
        """Google Cloud認証情報が期限切れまたは期限切れ間近の場合に更新する
        
        Returns:
            bool: 更新が成功した場合はTrue、それ以外はFalse
        """
        if not self.has_gcp_access_token():
            logger.warning("Google Cloud認証情報がありません。ログインしてください。")
            return False
            
        # 現在時刻を取得
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 有効期限を取得
        gcp_creds = self.get_gcp_access_token()
        expiration = None
        if 'expiration' in gcp_creds:
            try:
                # ISO 8601形式の文字列からdatetimeオブジェクトに変換
                if isinstance(gcp_creds['expiration'], str):
                    expiration = datetime.datetime.fromisoformat(gcp_creds['expiration'].replace('Z', '+00:00'))
                else:
                    # すでにdatetimeオブジェクトの場合
                    expiration = gcp_creds['expiration']
            except Exception as e:
                logger.warning(f"有効期限の解析に失敗しました: {str(e)}")
                
        # 有効期限が取得できない、または期限切れまたは30分以内に期限切れになる場合は更新
        if expiration is None or (expiration - now).total_seconds() < 1800:
            try:
                gcp_response = requests.post(
                    f"{self.auth.auth_server_url}/gcp-credentials",
                    verify=self.auth.ca_path if hasattr(self.auth, 'ca_path') and self.auth.ca_path else True,
                    cert=(self.auth.cert_path, self.auth.key_path) if hasattr(self.auth, 'cert_path') and hasattr(self.auth, 'key_path') else None,
                    timeout=10,
                    json={'email': self.tmp_creds.get('email', '')}
                )
                
                if gcp_response.status_code == 200:
                    # tmp_credsのGCP認証情報を更新
                    self.tmp_creds['gcp_access_token'] = gcp_response.json()
                    logger.info("Google Cloud認証情報を更新しました")
                    return True
                else:
                    logger.warning(f"Google Cloud認証情報の更新に失敗しました: {gcp_response.status_code} {gcp_response.text}")
                    return False
            except Exception as e:
                logger.warning(f"Google Cloud認証情報の更新中にエラーが発生しました: {str(e)}")
                return False
                
        return True
        
    def set_validation_year(self, year: int):
        self.validation_year = year
        
    def _validate_processing_code(self, processing_code: Callable, error_class: Type[PHuntAPIException] = PHuntAPIException) -> bool:
        """処理コードを検証する"""
        return ValidationUtils.validate_processing_code(processing_code, error_class)

    @PHuntAuth.login_required
    def get_data_from_source(self, symbol, start_date, end_date, provider='Dukascopy',  granularity='1MIN'):
        try:
            # Convert string dates to datetime objects if they're strings
            if isinstance(start_date, str):
                start_date = pd.to_datetime(start_date)
            if isinstance(end_date, str):
                end_date = pd.to_datetime(end_date)
            
            # Calculate the date difference
            date_diff = (end_date - start_date).days
            
            # Check if the date range is more than 1 year (365 days)
            if date_diff > 365:
                # Get available datasets that might contain data for this symbol
                available_datasets = self.list_datasets(include=symbol)
                
                # Format the available datasets message
                datasets_msg = ""
                if available_datasets:
                    datasets_msg = "利用可能なデータセット:\n" + "\n".join([f"  - {dataset}" for dataset in available_datasets])
                else:
                    datasets_msg = f"{symbol}に関する利用可能なデータセットが見つかりません。"
                
                # Raise an exception with guidance
                raise PHuntAPIException(
                    f"要求された期間が1年以上（{date_diff}日）です。\n"
                    f"長期間のデータ取得には、get_dataset()メソッドを使用してください。\n"
                    f"{datasets_msg}\n"
                    f"例: df = api.get_dataset('dataset_name')"
                )
            
            return DataSourceManager(provider, symbol, granularity).get_data(start_date, end_date)
        except Exception as e:
            raise PHuntAPIException(f"データソース操作エラー: {str(e)}")

    # Dataset関連のメソッド
    @PHuntAuth.login_required
    def list_datasets(self, include='', exclude=''):
        try:
            datasets = self._dataset_manager.list_datasets(view_type='dataset')
            datasets = [dataset.name for dataset in datasets if 'sample' not in dataset.name]
            if include:
                datasets = [dataset for dataset in datasets if include in dataset]
            if exclude:
                datasets = [dataset for dataset in datasets if exclude not in dataset]
            return datasets
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def get_sample_data(self, dataset_id):
        try:
            # DatasetManagerにget_sample_dataメソッドがない場合のフォールバック
            if hasattr(self._dataset_manager, 'get_sample_data') and callable(getattr(self._dataset_manager, 'get_sample_data')):
                return self._dataset_manager.get_sample_data(dataset_id)  # type: ignore
            else:
                # フォールバック: データセットを取得して先頭の数行を返す
                dataset = self._dataset_manager.get_dataset(dataset_id)
                return dataset.head() if dataset is not None else None
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def create_dataset_from_local(self, name, local_path):
        try:
            result = self._dataset_manager.create_dataset_from_local(name, local_path)
            return result
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")

    @PHuntAuth.login_required
    def get_dataset_spec(self, dataset_id):
        try:
            return self._dataset_manager.get_dataset_spec(dataset_id)
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        
    @PHuntAuth.login_required
    def get_dataset(self, dataset_id):
        try:
            return self._dataset_manager.get_dataset(dataset_id).copy()
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    # Feature関連のメソッド
    @PHuntAuth.login_required
    @handle_api_exceptions(FeatureError, "特徴量操作エラー")
    def list_features(self):
        return self._feature_manager.list_features()
        
    # @PHuntAuth.login_required
    def get_feature_code_path(self, feature_name: str) -> Optional[str]:
        try:
            return self._feature_manager.get_feature_code_path(feature_name)
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        
    def get_feature_code(self, feature_name: str) -> Optional[Callable]:
        # キャッシュキー
        cache_key = f"feature_code_{feature_name}"
        
        # キャッシュをチェック
        cached_result = self.get_from_cache(cache_key)
        if cached_result is not None:
            return cached_result
                
        # キャッシュになければ取得して保存
        code_path = self.get_feature_code_path(feature_name)
        if code_path is None:
            return None
            
        code = read_s3_file(code_path)
        code = textwrap.dedent(code)
        print(code)
        
        # 文字列からコードを実行可能な関数に変換
        local_dict = {}
        exec(code, globals(), local_dict)
        print(local_dict.keys())
        create_feature = local_dict[list(local_dict.keys())[0]]
        
        # キャッシュに保存
        self.set_to_cache(cache_key, create_feature)
            
        return create_feature

    @PHuntAuth.login_required
    def submit_feature(self, name: str, processing_code: Optional[ProcessingCodeProtocol[pd.DataFrame]]=None, df: Optional[pd.DataFrame]=None) -> str:
        try:
            if processing_code is not None:
                # SubmissionUtils を使用して処理コードでの提出を行う
                return SubmissionUtils.submit_with_processing_code(
                    name=name,
                    processing_code=processing_code,
                    api_instance=self,
                    manager_method=self._feature_manager.submit_feature,
                    cache_manager=self,
                    prefix="feature",
                    error_class=FeatureError,
                    validate_func=self._validate_processing_code
                )
            elif df is not None:
                # SubmissionUtils を使用してDataFrameでの提出を行う
                return SubmissionUtils.submit_with_dataframe(
                    name=name,
                    df=df,
                    manager_method=self._feature_manager.submit_feature,
                    cache_manager=self,
                    prefix="feature"
                )
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    @handle_api_exceptions(FeatureError, "特徴量操作エラー")
    def get_feature(self, feature_id, use_cache: bool=True):
        df = self._feature_manager.get_feature(feature_id, use_cache=use_cache).copy()
        if self.validation_year is not None:
            df['___year___'] = pd.to_datetime(df.index).year
            train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
            val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
            return train_df, val_df
        else:
            return df

    # Target関連のメソッド
    @PHuntAuth.login_required
    @handle_api_exceptions(TargetError, "目的変数操作エラー")
    def list_targets(self):
        return self._target_manager.list_targets()

    @PHuntAuth.login_required
    def submit_target(self, name: str, processing_code: Optional[ProcessingCodeProtocol[pd.DataFrame]]=None, df: Optional[pd.DataFrame]=None) -> str:
        try:
            if processing_code is not None:
                # SubmissionUtils を使用して処理コードでの提出を行う
                return SubmissionUtils.submit_with_processing_code(
                    name=name,
                    processing_code=processing_code,
                    api_instance=self,
                    manager_method=self._target_manager.submit_target,
                    cache_manager=self,
                    prefix="target",
                    error_class=TargetError,
                    validate_func=self._validate_processing_code
                )
            elif df is not None:
                # SubmissionUtils を使用してDataFrameでの提出を行う
                return SubmissionUtils.submit_with_dataframe(
                    name=name,
                    df=df,
                    manager_method=self._target_manager.submit_target,
                    cache_manager=self,
                    prefix="target"
                )
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except TargetError as e:
            raise PHuntAPIException(f"目的変数操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    @handle_api_exceptions(TargetError, "目的変数操作エラー")
    def get_target(self, target_id):
        df = self._target_manager.get_target(target_id).copy()
        if self.validation_year is not None:
            df['___year___'] = pd.to_datetime(df.index).year
            train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
            val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
            return train_df, val_df
        else:
            return df

    # Model関連のメソッド
    @PHuntAuth.login_required
    def submit_model(self, name: str, processing_code: Optional[ProcessingCodeProtocol[Dict[str, Any]]] = None):
        try:
            if processing_code is None:
                raise PHuntAPIException("処理コードを指定してください")
                
            # SubmissionUtils を使用して処理コードでの提出を行う
            return SubmissionUtils.submit_with_processing_code(
                name=name,
                processing_code=processing_code,
                api_instance=self,
                manager_method=self._model_manager.submit_model,
                cache_manager=self,
                prefix="model",
                error_class=ModelError,
                validate_func=self._validate_processing_code
            )
        except ModelError as e:
            raise PHuntAPIException(f"モデル操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")

    @PHuntAuth.login_required
    @handle_api_exceptions(ModelError, "モデル操作エラー")
    def list_models(self):
        # ModelManagerにlist_modelsメソッドがない場合のフォールバック
        if hasattr(self._model_manager, 'list_models') and callable(getattr(self._model_manager, 'list_models')):
            return self._model_manager.list_models()  # type: ignore
        else:
            # フォールバック: 空のリストを返す
            return []
        
    @handle_api_exceptions(ModelError, "モデル操作エラー")
    def load_model(self, run_id: str, model_name: str):
        model_id = f"{run_id}_{model_name}"
        
        # キャッシュから取得
        cached_result = self.get_from_cache(model_id)
        if cached_result is not None:
            print(f"Cache hit for model load: {model_id}")
            return cached_result
                
        model, feature_names = self._model_manager.load_model(run_id, model_name)
        
        # キャッシュに保存
        self.set_to_cache(model_id, (model, feature_names))
            
        return model, feature_names

    def run_auth_server(self, host="0.0.0.0", port=8000, workers=1, reload=False, block=True):
        """認証サーバーを起動する"""
        self._server_utils.run_auth_server(host, port, workers, reload, block)

    def run_feast_ui(self, host="0.0.0.0", port=8888, block=True):
        """Feast UIを起動する"""
        self._server_utils.run_feast_ui(host, port, block)

    def stop_auth_server(self):
        """認証サーバーを停止する"""
        self._server_utils.stop_auth_server()

    def stop_feast_ui(self):
        """Feast UIを停止する"""
        self._server_utils.stop_feast_ui()

    def create_feature_store_yaml(self):
        """Feast用のfeature_store.yamlファイルを作成する"""
        self._server_utils.create_feature_store_yaml()

    def join_and_drop(self, feature_df: pd.DataFrame, target_df: pd.DataFrame):
        """特徴量データフレームと目的変数データフレームを結合し、欠損値を削除する"""
        return DataUtils.join_and_drop(feature_df, target_df)
    
    def get_years(self, feature_df: pd.DataFrame):
        """データフレームから年のリストを取得する"""
        return DataUtils.get_years(feature_df)
    
    def add_signal(self, name: str, datasource: Optional[DataSourceManager]=None):
        """シグナルを追加する"""
        self._signal_utils.add_signal(name, datasource)

    def get_signal(self, name: str, start_date: str, end_date: str):
        """シグナルデータを取得する"""
        return self._signal_utils.get_signal(name, start_date, end_date)

    def serve_model(self, run_id:str, model_name:str, **kwargs):
        from .predict import serve_model
        serve_model(run_id, model_name, **kwargs)

    def __del__(self):
        """デストラクタ：プロセスのクリーンアップ"""
        self._server_utils.cleanup()

    @PHuntAuth.login_required
    def get_mlflow_client(self):
        return self._model_manager.mlflow_client
        
    def get_gcp_service_account_email(self):
        """Google Cloud Service Accountのメールアドレスを取得する
        
        Returns:
            str: Service Accountのメールアドレス
        
        Raises:
            PHuntAPIException: GCP認証情報が利用できない場合
        """
        if not self.has_gcp_access_token():
            if not self.is_logged_in():
                raise PHuntAPIException("このメソッドを使用するには、まずログインしてください。")
            raise PHuntAPIException("このメソッドを使用するには、Google Cloud認証情報が必要です。")
        
        # 認証情報が期限切れの場合は更新を試みる
        self.refresh_gcp_access_token_if_needed()
        
        gcp_creds = self.get_gcp_access_token()
        if gcp_creds and 'service_account_email' in gcp_creds:
            return gcp_creds['service_account_email']
        return None

    # プラグイン関連のメソッド

    def install_plugin_from_github(self, repo_url: str, branch: str = 'main', force_update: bool = False) -> bool:
        """
        GitHubリポジトリからプラグインをインストール
        
        Args:
            repo_url: GitHubリポジトリのURL（https://github.com/user/repo 形式）
            branch: ブランチ名またはタグ名
            force_update: Trueの場合、既にインストールされていても強制的に更新
        
        Returns:
            インストールが成功したかどうか
            
        例:
            >>> api = PHuntAPI()
            >>> api.install_plugin_from_github('https://github.com/user/awesome-phunt-plugin')
        """
        return self._plugin_feature_api.install_plugin_from_github(
            repo_url=repo_url, 
            branch=branch, 
            force_update=force_update
        )
    
    def list_github_plugins(self) -> List[Dict[str, str]]:
        """
        インストール済みのGitHubプラグインを一覧表示
        
        Returns:
            インストール済みプラグインの情報リスト
            
        例:
            >>> api = PHuntAPI()
            >>> plugins = api.list_github_plugins()
            >>> for plugin in plugins:
            ...     print(f"{plugin['id']} - {plugin['repo_url']}")
        """
        return self._plugin_feature_api.list_github_plugins()
    
    def uninstall_github_plugin(self, plugin_id: str) -> bool:
        """
        インストール済みのGitHubプラグインをアンインストール
        
        Args:
            plugin_id: プラグインID（username_repo_name形式）
            
        Returns:
            アンインストールが成功したかどうか
            
        例:
            >>> api = PHuntAPI()
            >>> api.uninstall_github_plugin('user_awesome-phunt-plugin')
        """
        return self._plugin_feature_api.uninstall_github_plugin(plugin_id)
    
    def update_plugin_catalog(self, force: bool = False, plugin_type: Optional[str] = None) -> bool:
        """
        プラグインカタログを更新
        
        Args:
            force: 強制的に更新するかどうか
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は両方更新
            
        Returns:
            更新が成功したかどうか
            
        例:
            >>> api = PHuntAPI()
            >>> api.update_plugin_catalog()
            >>> # 特定のタイプのみ更新
            >>> api.update_plugin_catalog(plugin_type='target')
        """
        success = True
        
        # Feature plugin catalog
        if plugin_type is None or plugin_type.lower() == 'feature':
            feature_success = self._plugin_feature_api.update_plugin_catalog(force)
            success = success and feature_success
        
        # Target plugin catalog
        if plugin_type is None or plugin_type.lower() == 'target':
            target_success = self._plugin_target_api.update_plugin_catalog(force)
            success = success and target_success
        
        return success
    
    def search_plugins(self, query: str = '', tags: List[str] = None, plugin_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        プラグインカタログを検索
        
        Args:
            query: 検索クエリ
            tags: 検索するタグのリスト
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は両方から検索
            
        Returns:
            プラグインのリスト
            
        例:
            >>> api = PHuntAPI()
            >>> plugins = api.search_plugins(query="technical indicator")
            >>> # 特定のタイプのみ検索
            >>> target_plugins = api.search_plugins(tags=["price", "movement"], plugin_type='target')
            >>> for plugin in plugins:
            ...     print(f"{plugin['name']} - {plugin['description']}")
        """
        results = []
        
        # Feature plugins
        if plugin_type is None or plugin_type.lower() == 'feature':
            feature_results = self._plugin_feature_api.search_plugins(query=query, tags=tags)
            for plugin in feature_results:
                plugin['plugin_type'] = 'feature'
                results.append(plugin)
        
        # Target plugins
        if plugin_type is None or plugin_type.lower() == 'target':
            target_results = self._plugin_target_api.search_plugins(query=query, tags=tags)
            for plugin in target_results:
                plugin['plugin_type'] = 'target'
                results.append(plugin)
        
        return results
    
    def install_plugin_from_catalog(self, plugin_id: str, plugin_type: Optional[str] = None) -> bool:
        """
        カタログからプラグインをインストール
        
        Args:
            plugin_id: プラグインID
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は自動判別
            
        Returns:
            インストールが成功したかどうか
            
        例:
            >>> api = PHuntAPI()
            >>> api.install_plugin_from_catalog('username_repo-name')
            >>> # 特定のタイプを指定してインストール
            >>> api.install_plugin_from_catalog('username_repo-name', plugin_type='target')
        """
        # プラグインタイプが指定されている場合
        if plugin_type is not None:
            if plugin_type.lower() == 'feature':
                return self._plugin_feature_api.install_plugin_from_catalog(plugin_id)
            elif plugin_type.lower() == 'target':
                return self._plugin_target_api.install_plugin_from_catalog(plugin_id)
            else:
                logger.warning(f"Unknown plugin_type: {plugin_type}. Must be 'feature' or 'target'")
                return False
        
        # プラグインタイプが指定されていない場合は両方試す
        # まずFeatureとして試す
        try:
            if self._plugin_feature_api.install_plugin_from_catalog(plugin_id):
                return True
        except Exception as e:
            logger.debug(f"Failed to install as feature plugin: {e}")
        
        # 次にTargetとして試す
        try:
            if self._plugin_target_api.install_plugin_from_catalog(plugin_id):
                return True
        except Exception as e:
            logger.debug(f"Failed to install as target plugin: {e}")
        
        logger.error(f"Failed to install plugin: {plugin_id}")
        return False
    
    def list_plugins(self, plugin_type: Optional[str] = None, include_signatures: bool = False) -> List[Dict[str, Any]]:
        """
        インストール済みのプラグインを一覧表示
        
        Args:
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は両方
            include_signatures: 関数のシグニチャを含めるかどうか
            
        Returns:
            プラグインのリスト
            
        例:
            >>> api = PHuntAPI()
            >>> plugins = api.list_plugins()
            >>> # 特定のタイプのみリスト
            >>> target_plugins = api.list_plugins(plugin_type='target')
            >>> # 関数シグニチャを含む
            >>> plugins_with_signatures = api.list_plugins(include_signatures=True)
            >>> for plugin in plugins:
            ...     print(f"{plugin['name']} - {plugin['info']['description']}")
        """
        results = []
        
        # Feature plugins
        if plugin_type is None or plugin_type.lower() == 'feature':
            feature_plugins = self._plugin_feature_api.list_plugins(include_signatures=include_signatures)
            for plugin in feature_plugins:
                plugin['plugin_type'] = 'feature'
                results.append(plugin)
        
        # Target plugins
        if plugin_type is None or plugin_type.lower() == 'target':
            target_plugins = self._plugin_target_api.list_plugins(include_signatures=include_signatures)
            for plugin in target_plugins:
                plugin['plugin_type'] = 'target'
                results.append(plugin)
        
        return results
    
    def get_plugin_functions(self, plugin_name: str, plugin_type: Optional[str] = None, include_signatures: bool = False) -> Union[List[str], Dict[str, Any]]:
        """
        プラグインの関数一覧を取得
        
        Args:
            plugin_name: プラグイン名
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は自動判別
            include_signatures: 関数のシグニチャを含めるかどうか
            
        Returns:
            関数名のリストまたは関数名と詳細情報の辞書
            
        例:
            >>> api = PHuntAPI()
            >>> functions = api.get_plugin_functions('awesome_plugin')
            >>> # 特定のタイプを指定
            >>> target_functions = api.get_plugin_functions('price_targets', plugin_type='target')
            >>> # 関数シグニチャを含む
            >>> functions_with_signatures = api.get_plugin_functions('awesome_plugin', include_signatures=True)
            >>> for func_name, details in functions_with_signatures.items():
            ...     print(f"{func_name}: {details['parameters']}")
        """
        # プラグインタイプが指定されている場合
        if plugin_type is not None:
            if plugin_type.lower() == 'feature':
                return self._plugin_feature_api.get_plugin_functions(plugin_name, include_signatures=include_signatures)
            elif plugin_type.lower() == 'target':
                return self._plugin_target_api.get_plugin_functions(plugin_name, include_signatures=include_signatures)
            else:
                logger.warning(f"Unknown plugin_type: {plugin_type}. Must be 'feature' or 'target'")
                return [] if not include_signatures else {}
        
        # プラグインタイプが指定されていない場合は両方試す
        # まずFeatureとして試す
        try:
            feature_functions = self._plugin_feature_api.get_plugin_functions(plugin_name, include_signatures=include_signatures)
            if feature_functions:
                return feature_functions
        except Exception:
            pass
        
        # 次にTargetとして試す
        try:
            target_functions = self._plugin_target_api.get_plugin_functions(plugin_name, include_signatures=include_signatures)
            if target_functions:
                return target_functions
        except Exception:
            pass
        
        # 見つからなかった場合
        logger.warning(f"Plugin not found: {plugin_name}")
        return [] if not include_signatures else {}
    
    def get_plugin_feature(
        self, 
        plugin_name: str, 
        function_name: str, 
        *args, 
        **kwargs
    ):
        """
        プラグイン機能を使用して特徴量を計算
        
        Args:
            plugin_name: プラグイン名
            function_name: 関数名
            *args: 関数の位置引数
            **kwargs: 関数のキーワード引数
            
        Returns:
            計算された特徴量
            
        例:
            >>> api = PHuntAPI()
            >>> result = api.get_plugin_feature(
            ...     plugin_name='awesome_plugin',
            ...     function_name='calculate_awesome_feature',
            ...     prices=prices,
            ...     window=20
            ... )
        """
        return self._plugin_feature_api.get_plugin_feature(
            plugin_name=plugin_name,
            function_name=function_name,
            *args,
            **kwargs
        )
    
    def get_plugin_target(
        self,
        plugin_name: str,
        data: pd.DataFrame,
        **kwargs
    ) -> pd.DataFrame:
        """
        プラグインを使用してターゲットを計算
        
        Args:
            plugin_name: プラグイン名
            data: 入力データフレーム
            **kwargs: プラグイン関数に渡す追加引数
            
        Returns:
            計算されたターゲット
            
        例:
            >>> api = PHuntAPI()
            >>> result = api.get_plugin_target(
            ...     plugin_name='price_targets',
            ...     data=price_data,
            ...     target_type='future_return',
            ...     periods=[1, 5, 10],
            ...     price_col='close',
            ...     threshold=0.01
            ... )
        """
        return self._plugin_target_api.calculate_target(
            plugin_name=plugin_name,
            data=data,
            **kwargs
        )
    
    def register_plugin_feature(self, feature_name: str, plugin_name: str, 
                               function_name: str, **kwargs) -> str:
        """
        プラグイン関数を使用して特徴量を計算し、登録する
        
        Args:
            feature_name: 登録する特徴量の名前
            plugin_name: プラグイン名
            function_name: 関数名
            **kwargs: 関数に渡す引数
            
        Returns:
            登録された特徴量のID
            
        Raises:
            RuntimeError: 登録に失敗した場合
        """
        try:
            # プラグイン関数を使用して特徴量を計算
            result_df = self._plugin_feature_api.calculate_plugin_feature(
                plugin_name=plugin_name,
                function_name=function_name,
                **kwargs
            )
            
            # 特徴量として登録
            registered_id = self.submit_feature(name=feature_name, df=result_df)
            
            return registered_id
            
        except Exception as e:
            logger.error(f"Error registering plugin feature: {str(e)}")
            raise RuntimeError(f"Failed to register plugin feature: {str(e)}")
    
    def register_plugin_target(
        self,
        target_name: str,
        plugin_name: str,
        data: pd.DataFrame,
        target_id: str = None,
        description: str = None,
        tags: List[str] = None,
        **kwargs
    ) -> str:
        """
        プラグインを使用してターゲットを計算し、登録する
        
        Args:
            target_name: 登録するターゲットの名前
            plugin_name: プラグイン名
            data: 入力データフレーム
            target_id: ターゲットID (指定しない場合は自動生成)
            description: ターゲットの説明
            tags: タグのリスト
            **kwargs: プラグイン関数に渡す追加引数
            
        Returns:
            登録されたターゲットのID
            
        Raises:
            RuntimeError: 登録に失敗した場合
            
        例:
            >>> api = PHuntAPI()
            >>> target_id = api.register_plugin_target(
            ...     target_name='future_returns_5_10_days',
            ...     plugin_name='price_targets',
            ...     data=price_data,
            ...     description='5日後と10日後の価格リターン',
            ...     tags=['price', 'return', 'prediction'],
            ...     target_type='future_return',
            ...     periods=[5, 10],
            ...     price_col='close'
            ... )
        """
        try:
            return self._plugin_target_api.register_target(
                data=data,
                plugin_name=plugin_name,
                target_name=target_name,
                target_id=target_id,
                description=description,
                tags=tags,
                **kwargs
            )
        except Exception as e:
            logger.error(f"Error registering plugin target: {str(e)}")
            raise RuntimeError(f"Failed to register plugin target: {str(e)}")
    
    def _get_plugin_version(self, plugin_name: str, plugin_type: Optional[str] = None) -> str:
        """
        プラグインのバージョンを取得
        
        Args:
            plugin_name: プラグイン名
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は自動判別
            
        Returns:
            プラグインのバージョン、または不明な場合は'unknown'
        """
        # プラグインタイプが指定されている場合
        if plugin_type is not None:
            if plugin_type.lower() == 'feature':
                try:
                    plugin = self._plugin_feature_api._plugin_registry.get_plugin(plugin_name)
                    if plugin:
                        return plugin.PLUGIN_INFO.get('version', 'unknown')
                except Exception:
                    pass
            elif plugin_type.lower() == 'target':
                try:
                    plugin = self._plugin_target_api._plugin_registry.get_plugin(plugin_name)
                    if plugin:
                        return plugin.PLUGIN_INFO.get('version', 'unknown')
                except Exception:
                    pass
            return 'unknown'
        
        # プラグインタイプが指定されていない場合は両方試す
        try:
            # まずFeatureとして試す
            plugin = self._plugin_feature_api._plugin_registry.get_plugin(plugin_name)
            if plugin:
                return plugin.PLUGIN_INFO.get('version', 'unknown')
        except Exception:
            pass
        
        try:
            # 次にTargetとして試す
            plugin = self._plugin_target_api._plugin_registry.get_plugin(plugin_name)
            if plugin:
                return plugin.PLUGIN_INFO.get('version', 'unknown')
        except Exception:
            pass
        
        return 'unknown'
    
    def generate_plugin_docs(self, output_dir: str = None, plugin_type: Optional[str] = None) -> List[str]:
        """
        プラグインのドキュメントを生成
        
        Args:
            output_dir: ドキュメント出力ディレクトリ（指定しない場合はデフォルトディレクトリ）
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は両方
            
        Returns:
            生成したドキュメントファイルのパスのリスト
            
        例:
            >>> api = PHuntAPI()
            >>> docs = api.generate_plugin_docs()
            >>> # 特定のタイプのみドキュメント生成
            >>> target_docs = api.generate_plugin_docs(plugin_type='target')
        """
        paths = []
        
        # Feature plugins
        if plugin_type is None or plugin_type.lower() == 'feature':
            feature_paths = self._plugin_feature_api.generate_plugin_docs(output_dir)
            paths.extend(feature_paths)
        
        # Target plugins
        if plugin_type is None or plugin_type.lower() == 'target':
            # TargetPluginAPIにgenerate_plugin_docsメソッドが実装されていることを前提
            if hasattr(self._plugin_target_api, 'generate_plugin_docs'):
                target_paths = self._plugin_target_api.generate_plugin_docs(output_dir)
                paths.extend(target_paths)
        
        return paths
    
    def generate_plugin_doc(self, plugin_name: str, output_dir: str = None, plugin_type: Optional[str] = None) -> Optional[str]:
        """
        指定したプラグインのドキュメントを生成
        
        Args:
            plugin_name: プラグイン名
            output_dir: ドキュメント出力ディレクトリ（指定しない場合はデフォルトディレクトリ）
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は自動判別
            
        Returns:
            生成したドキュメントファイルのパス、または生成に失敗した場合はNone
            
        例:
            >>> api = PHuntAPI()
            >>> doc_path = api.generate_plugin_doc('awesome_plugin')
            >>> # 特定のタイプを指定
            >>> target_doc = api.generate_plugin_doc('price_targets', plugin_type='target')
        """
        # プラグインタイプが指定されている場合
        if plugin_type is not None:
            if plugin_type.lower() == 'feature':
                return self._plugin_feature_api.generate_plugin_doc(plugin_name, output_dir)
            elif plugin_type.lower() == 'target':
                # TargetPluginAPIにgenerate_plugin_docメソッドが実装されていることを前提
                if hasattr(self._plugin_target_api, 'generate_plugin_doc'):
                    return self._plugin_target_api.generate_plugin_doc(plugin_name, output_dir)
                return None
            else:
                logger.warning(f"Unknown plugin_type: {plugin_type}. Must be 'feature' or 'target'")
                return None
        
        # プラグインタイプが指定されていない場合は両方試す
        # まずFeatureとして試す
        try:
            feature_doc = self._plugin_feature_api.generate_plugin_doc(plugin_name, output_dir)
            if feature_doc:
                return feature_doc
        except Exception:
            pass
        
        # 次にTargetとして試す
        try:
            if hasattr(self._plugin_target_api, 'generate_plugin_doc'):
                target_doc = self._plugin_target_api.generate_plugin_doc(plugin_name, output_dir)
                if target_doc:
                    return target_doc
        except Exception:
            pass
        
        logger.warning(f"Plugin not found: {plugin_name}")
        return None
    
    def get_plugin_version_conflicts(self, plugin_type: Optional[str] = None) -> Dict[str, List[str]]:
        """
        プラグインのバージョン競合情報を取得
        
        Args:
            plugin_type: プラグインタイプ ('feature' または 'target')。指定しない場合は両方
            
        Returns:
            プラグイン名をキー、競合バージョンのリストを値とする辞書
            
        例:
            >>> api = PHuntAPI()
            >>> conflicts = api.get_plugin_version_conflicts()
            >>> # 特定のタイプの競合のみ取得
            >>> target_conflicts = api.get_plugin_version_conflicts(plugin_type='target')
        """
        conflicts = {}
        
        # Feature plugins
        if plugin_type is None or plugin_type.lower() == 'feature':
            feature_conflicts = self._plugin_feature_api.get_plugin_version_conflicts()
            for plugin_name, versions in feature_conflicts.items():
                conflicts[f"feature:{plugin_name}"] = versions
        
        # Target plugins
        if plugin_type is None or plugin_type.lower() == 'target':
            target_conflicts = self._plugin_target_api.get_plugin_version_conflicts()
            for plugin_name, versions in target_conflicts.items():
                conflicts[f"target:{plugin_name}"] = versions
        
        return conflicts

if __name__ == "__main__":
    api = PHuntAPI(debug=True)
    api.login(p12_path='/Users/shin/workspace/MT4_ARB/phunt/client.p12', p12_password='aaa')
    print(api.get_mlflow_client())
    
