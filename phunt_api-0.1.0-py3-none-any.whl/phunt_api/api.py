# -*- coding: utf-8 -*-

# Google Colabでのみ実行を想定したpackage
# Workspaceドメインのユーザーのみがアクセスできる
# 難読化する方法は、pyarmorを使う
# wheelファイルを作成して、pip installする

import os
import inspect
import textwrap
import pandas as pd
import subprocess
from pathlib import Path
import time
import warnings
from typing import List, Dict, Any, Callable, Tuple, Optional, Literal, Type, TypeVar, Generic, TYPE_CHECKING

# Pydantic V1スタイルの警告を抑制
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pydantic")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="mlflow")

from .auth import PHuntAuth
from .datasource import DataSourceManager
from .dataset import PublicDatasetManager, DatasetManager
from .feature import FeatureManager
from .model import ModelManager
from .target import TargetManager
from .exceptions import PHuntAPIException, AuthenticationError, DatasetError, FeatureError, ModelError, TargetError
from .utils import FeastManager, read_s3_file

# 抽出したユーティリティクラスをインポート
from .misc.cache import CacheManager
from .misc.server_utils import ServerUtils
from .misc.data_utils import DataUtils
from .misc.validation import ValidationUtils, ProcessingCodeProtocol
from .misc.signal_utils import SignalUtils
from .misc.submission_utils import SubmissionUtils
from .misc.decorators import handle_api_exceptions, with_cache

warnings.simplefilter("ignore")

class PHuntAPI:
    """Main API client for P-Hunter.
    
    This class provides a comprehensive interface for interacting with the P-Hunter
    trading system, including authentication, dataset management, and model operations."""

    def __init__(self,debug=False, 
                 cache_type: Literal["memory", "file"] = "file"):
        self.debug = debug
        self.auth = PHuntAuth(debug=debug)
        self.repo_path = os.getenv("PHUNT_REPO_PATH", ".")
        self._dataset_manager = DatasetManager(self.repo_path)
        self._feature_manager = FeatureManager(self._dataset_manager)
        self._target_manager = TargetManager(self._dataset_manager)
        self._model_manager = ModelManager(self._dataset_manager, self._feature_manager, self._target_manager)
        self._feast_manager = FeastManager(self.repo_path)
        self.validation_year = None
        
        # 抽出したユーティリティクラスの初期化
        self._cache_manager = CacheManager(cache_type)
        self._server_utils = ServerUtils()
        self._signal_utils = SignalUtils()

    def setup_logging_plt(self, logging, plt, SCRIPT_DIR, MODEL_NAME):
        """ロギングとMatplotlibの設定を行う"""
        return DataUtils.setup_logging_plt(logging, plt, SCRIPT_DIR, MODEL_NAME)

    # キャッシュ操作用のヘルパーメソッド
    def exists_in_cache(self, cache_key: str) -> bool:
        """キャッシュに指定されたキーが存在するかどうかをチェック"""
        return self._cache_manager.exists(cache_key)

    def get_from_cache(self, cache_key: str, default=None):
        """キャッシュから値を取得"""
        return self._cache_manager.get(cache_key, default)

    def set_to_cache(self, cache_key: str, value) -> None:
        """キャッシュに値を設定"""
        self._cache_manager.set(cache_key, value)

    def login(self, p12_path: Optional[str] = None, p12_password: Optional[str] = None):
        try:
            self.tmp_creds = self.auth.login(p12_path, p12_password)
            self._dataset_manager.set_creds(self.tmp_creds)
        except AuthenticationError as e:
            raise PHuntAPIException(f"認証エラー: {str(e)}")

    def is_logged_in(self):
        if self.debug:
            return True
        return self.tmp_creds is not None

    def set_validation_year(self, year: int):
        self.validation_year = year
        
    def _validate_processing_code(self, processing_code: Callable, error_class: Type[PHuntAPIException] = PHuntAPIException) -> bool:
        """処理コードを検証する"""
        return ValidationUtils.validate_processing_code(processing_code, error_class)

    @PHuntAuth.login_required
    def get_data_from_source(self, symbol, start_date, end_date, provider='Dukascopy',  granularity='1MIN'):
        try:
            # Convert string dates to datetime objects if they're strings
            if isinstance(start_date, str):
                start_date = pd.to_datetime(start_date)
            if isinstance(end_date, str):
                end_date = pd.to_datetime(end_date)
            
            # Calculate the date difference
            date_diff = (end_date - start_date).days
            
            # Check if the date range is more than 1 year (365 days)
            if date_diff > 365:
                # Get available datasets that might contain data for this symbol
                available_datasets = self.list_datasets(include=symbol)
                
                # Format the available datasets message
                datasets_msg = ""
                if available_datasets:
                    datasets_msg = "利用可能なデータセット:\n" + "\n".join([f"  - {dataset}" for dataset in available_datasets])
                else:
                    datasets_msg = f"{symbol}に関する利用可能なデータセットが見つかりません。"
                
                # Raise an exception with guidance
                raise PHuntAPIException(
                    f"要求された期間が1年以上（{date_diff}日）です。\n"
                    f"長期間のデータ取得には、get_dataset()メソッドを使用してください。\n"
                    f"{datasets_msg}\n"
                    f"例: df = api.get_dataset('dataset_name')"
                )
            
            return DataSourceManager(provider, symbol, granularity).get_data(start_date, end_date)
        except Exception as e:
            raise PHuntAPIException(f"データソース操作エラー: {str(e)}")

    # Dataset関連のメソッド
    @PHuntAuth.login_required
    def list_datasets(self, include='', exclude=''):
        try:
            datasets = self._dataset_manager.list_datasets(view_type='dataset')
            datasets = [dataset.name for dataset in datasets if 'sample' not in dataset.name]
            if include:
                datasets = [dataset for dataset in datasets if include in dataset]
            if exclude:
                datasets = [dataset for dataset in datasets if exclude not in dataset]
            return datasets
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def get_sample_data(self, dataset_id):
        try:
            # DatasetManagerにget_sample_dataメソッドがない場合のフォールバック
            if hasattr(self._dataset_manager, 'get_sample_data') and callable(getattr(self._dataset_manager, 'get_sample_data')):
                return self._dataset_manager.get_sample_data(dataset_id)  # type: ignore
            else:
                # フォールバック: データセットを取得して先頭の数行を返す
                dataset = self._dataset_manager.get_dataset(dataset_id)
                return dataset.head() if dataset is not None else None
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def create_dataset_from_local(self, name, local_path):
        try:
            result = self._dataset_manager.create_dataset_from_local(name, local_path)
            return result
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")

    @PHuntAuth.login_required
    def get_dataset_spec(self, dataset_id):
        try:
            return self._dataset_manager.get_dataset_spec(dataset_id)
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        
    @PHuntAuth.login_required
    def get_dataset(self, dataset_id):
        try:
            return self._dataset_manager.get_dataset(dataset_id).copy()
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    # Feature関連のメソッド
    @PHuntAuth.login_required
    @handle_api_exceptions(FeatureError, "特徴量操作エラー")
    def list_features(self):
        return self._feature_manager.list_features()
        
    # @PHuntAuth.login_required
    def get_feature_code_path(self, feature_name: str) -> Optional[str]:
        try:
            return self._feature_manager.get_feature_code_path(feature_name)
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        
    def get_feature_code(self, feature_name: str) -> Optional[Callable]:
        # キャッシュキー
        cache_key = f"feature_code_{feature_name}"
        
        # キャッシュをチェック
        cached_result = self.get_from_cache(cache_key)
        if cached_result is not None:
            return cached_result
                
        # キャッシュになければ取得して保存
        code_path = self.get_feature_code_path(feature_name)
        if code_path is None:
            return None
            
        code = read_s3_file(code_path)
        code = textwrap.dedent(code)
        print(code)
        
        # 文字列からコードを実行可能な関数に変換
        local_dict = {}
        exec(code, globals(), local_dict)
        print(local_dict.keys())
        create_feature = local_dict[list(local_dict.keys())[0]]
        
        # キャッシュに保存
        self.set_to_cache(cache_key, create_feature)
            
        return create_feature

    @PHuntAuth.login_required
    def submit_feature(self, name: str, processing_code: Optional[ProcessingCodeProtocol[pd.DataFrame]]=None, df: Optional[pd.DataFrame]=None) -> str:
        try:
            if processing_code is not None:
                # SubmissionUtils を使用して処理コードでの提出を行う
                return SubmissionUtils.submit_with_processing_code(
                    name=name,
                    processing_code=processing_code,
                    api_instance=self,
                    manager_method=self._feature_manager.submit_feature,
                    cache_manager=self,
                    prefix="feature",
                    error_class=FeatureError,
                    validate_func=self._validate_processing_code
                )
            elif df is not None:
                # SubmissionUtils を使用してDataFrameでの提出を行う
                return SubmissionUtils.submit_with_dataframe(
                    name=name,
                    df=df,
                    manager_method=self._feature_manager.submit_feature,
                    cache_manager=self,
                    prefix="feature"
                )
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    @handle_api_exceptions(FeatureError, "特徴量操作エラー")
    def get_feature(self, feature_id, use_cache: bool=True):
        df = self._feature_manager.get_feature(feature_id, use_cache=use_cache).copy()
        if self.validation_year is not None:
            df['___year___'] = pd.to_datetime(df.index).year
            train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
            val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
            return train_df, val_df
        else:
            return df

    # Target関連のメソッド
    @PHuntAuth.login_required
    @handle_api_exceptions(TargetError, "目的変数操作エラー")
    def list_targets(self):
        return self._target_manager.list_targets()

    @PHuntAuth.login_required
    def submit_target(self, name: str, processing_code: Optional[ProcessingCodeProtocol[pd.DataFrame]]=None, df: Optional[pd.DataFrame]=None) -> str:
        try:
            if processing_code is not None:
                # SubmissionUtils を使用して処理コードでの提出を行う
                return SubmissionUtils.submit_with_processing_code(
                    name=name,
                    processing_code=processing_code,
                    api_instance=self,
                    manager_method=self._target_manager.submit_target,
                    cache_manager=self,
                    prefix="target",
                    error_class=TargetError,
                    validate_func=self._validate_processing_code
                )
            elif df is not None:
                # SubmissionUtils を使用してDataFrameでの提出を行う
                return SubmissionUtils.submit_with_dataframe(
                    name=name,
                    df=df,
                    manager_method=self._target_manager.submit_target,
                    cache_manager=self,
                    prefix="target"
                )
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except TargetError as e:
            raise PHuntAPIException(f"目的変数操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    @handle_api_exceptions(TargetError, "目的変数操作エラー")
    def get_target(self, target_id):
        df = self._target_manager.get_target(target_id).copy()
        if self.validation_year is not None:
            df['___year___'] = pd.to_datetime(df.index).year
            train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
            val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
            return train_df, val_df
        else:
            return df

    # Model関連のメソッド
    @PHuntAuth.login_required
    def submit_model(self, name: str, processing_code: Optional[ProcessingCodeProtocol[Dict[str, Any]]] = None):
        try:
            if processing_code is None:
                raise PHuntAPIException("処理コードを指定してください")
                
            # SubmissionUtils を使用して処理コードでの提出を行う
            return SubmissionUtils.submit_with_processing_code(
                name=name,
                processing_code=processing_code,
                api_instance=self,
                manager_method=self._model_manager.submit_model,
                cache_manager=self,
                prefix="model",
                error_class=ModelError,
                validate_func=self._validate_processing_code
            )
        except ModelError as e:
            raise PHuntAPIException(f"モデル操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")

    @PHuntAuth.login_required
    @handle_api_exceptions(ModelError, "モデル操作エラー")
    def list_models(self):
        # ModelManagerにlist_modelsメソッドがない場合のフォールバック
        if hasattr(self._model_manager, 'list_models') and callable(getattr(self._model_manager, 'list_models')):
            return self._model_manager.list_models()  # type: ignore
        else:
            # フォールバック: 空のリストを返す
            return []
        
    @handle_api_exceptions(ModelError, "モデル操作エラー")
    def load_model(self, run_id: str, model_name: str):
        model_id = f"{run_id}_{model_name}"
        
        # キャッシュから取得
        cached_result = self.get_from_cache(model_id)
        if cached_result is not None:
            print(f"Cache hit for model load: {model_id}")
            return cached_result
                
        model, feature_names = self._model_manager.load_model(run_id, model_name)
        
        # キャッシュに保存
        self.set_to_cache(model_id, (model, feature_names))
            
        return model, feature_names

    def run_auth_server(self, host="0.0.0.0", port=8000, workers=1, reload=False, block=True):
        """認証サーバーを起動する"""
        self._server_utils.run_auth_server(host, port, workers, reload, block)

    def run_feast_ui(self, host="0.0.0.0", port=8888, block=True):
        """Feast UIを起動する"""
        self._server_utils.run_feast_ui(host, port, block)

    def stop_auth_server(self):
        """認証サーバーを停止する"""
        self._server_utils.stop_auth_server()

    def stop_feast_ui(self):
        """Feast UIを停止する"""
        self._server_utils.stop_feast_ui()

    def create_feature_store_yaml(self):
        """Feast用のfeature_store.yamlファイルを作成する"""
        self._server_utils.create_feature_store_yaml()

    def join_and_drop(self, feature_df: pd.DataFrame, target_df: pd.DataFrame):
        """特徴量データフレームと目的変数データフレームを結合し、欠損値を削除する"""
        return DataUtils.join_and_drop(feature_df, target_df)
    
    def get_years(self, feature_df: pd.DataFrame):
        """データフレームから年のリストを取得する"""
        return DataUtils.get_years(feature_df)
    
    def add_signal(self, name: str, datasource: Optional[DataSourceManager]=None):
        """シグナルを追加する"""
        self._signal_utils.add_signal(name, datasource)

    def get_signal(self, name: str, start_date: str, end_date: str):
        """シグナルデータを取得する"""
        return self._signal_utils.get_signal(name, start_date, end_date)

    def serve_model(self, run_id:str, model_name:str, **kwargs):
        from .predict import serve_model
        serve_model(run_id, model_name, **kwargs)

    def __del__(self):
        """デストラクタ：プロセスのクリーンアップ"""
        self._server_utils.cleanup()

    @PHuntAuth.login_required
    def get_mlflow_client(self):
        return self._model_manager.mlflow_client

if __name__ == "__main__":
    api = PHuntAPI(debug=True)
    api.login(p12_path='/Users/shin/workspace/MT4_ARB/phunt/client.p12', p12_password='aaa')
    print(api.get_mlflow_client())
    
