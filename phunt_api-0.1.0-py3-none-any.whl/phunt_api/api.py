# -*- coding: utf-8 -*-

# Google Colabでのみ実行を想定したpackage
# Workspaceドメインのユーザーのみがアクセスできる
# 難読化する方法は、pyarmorを使う
# wheelファイルを作成して、pip installする

import os
import inspect
import textwrap
import pandas as pd
import subprocess
from pathlib import Path
import time
import warnings
from typing import List, Dict, Any, Callable, Tuple, Optional, Literal

# Pydantic V1スタイルの警告を抑制
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pydantic")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="mlflow")

from .auth import PHuntAuth
from .datasource import DataSourceManager
from .dataset import PublicDatasetManager, DatasetManager
from .feature import FeatureManager
from .model import ModelManager
from .target import TargetManager
from .trade_signal import SignalManager
from .exceptions import PHuntAPIException, AuthenticationError, DatasetError, FeatureError, ModelError, TargetError
from .utils import FeastManager, read_s3_file, RedisCache, JsonFileCache

warnings.simplefilter("ignore")

class PHuntAPI:
    """Main API client for P-Hunter.
    
    This class provides a comprehensive interface for interacting with the P-Hunter
    trading system, including authentication, dataset management, and model operations."""

    def __init__(self, username=None, api_key=None, base_url="http://api.p-hunter.com/v1", debug=False, 
                 cache_type: Literal["memory", "file"] = "file"):
        # self.username = username
        # self.api_key = api_key
        self.debug = debug
        self.base_url = base_url
        self._auth_server_process = None
        self._feast_ui_process = None 
        self.auth = PHuntAuth(debug=debug)
        self.tmp_creds = None
        self.repo_path = os.getenv("PHUNT_REPO_PATH", ".")
        self.dataset_manager = DatasetManager(self.repo_path)
        self.feature_manager = FeatureManager(self.dataset_manager)
        self.target_manager = TargetManager(self.dataset_manager)
        self.model_manager = ModelManager(self.dataset_manager, self.feature_manager, self.target_manager)
        self.feast_manager = FeastManager(self.repo_path)
        self.validation_year = None
        self.signal_manager = SignalManager()
        
        # キャッシュタイプの設定
        self.cache_type = cache_type
        
        # キャッシュの初期化
        if cache_type == "file":
            # JSONファイルキャッシュを使用
            self.cache = JsonFileCache(namespace=self.username)
            print(f"Using JSON file cache for user: {self.username}")
        else:
            # メモリ内キャッシュを使用（デフォルト）
            self.cache = {}
            print("Using in-memory cache")

    # キャッシュ操作用のヘルパーメソッド
    def exists_in_cache(self, cache_key: str) -> bool:
        """キャッシュに指定されたキーが存在するかどうかをチェック"""
        if cache_key is None:
            return False
        
        if self.cache_type == "memory":
            return cache_key in self.cache
        else:
            return self.cache.exists(cache_key)

    def get_from_cache(self, cache_key: str, default=None):
        """キャッシュから値を取得"""
        if cache_key is None:
            return default
        
        if not self.exists_in_cache(cache_key):
            return default
        
        if self.cache_type == "memory":
            return self.cache[cache_key]
        else:
            return self.cache.get(cache_key, default)

    def set_to_cache(self, cache_key: str, value) -> None:
        """キャッシュに値を設定"""
        if cache_key is None:
            return
        
        if self.cache_type == "memory":
            self.cache[cache_key] = value
        else:
            self.cache.set(cache_key, value)

    def login(self, p12_path: Optional[str] = None, p12_password: Optional[str] = None):
        try:
            self.tmp_creds = self.auth.login(p12_path, p12_password)
            self.dataset_manager.set_creds(self.tmp_creds)
        except AuthenticationError as e:
            raise PHuntAPIException(f"認証エラー: {str(e)}")

    def is_logged_in(self):
        if self.debug:
            return True
        return self.tmp_creds is not None

    def set_validation_year(self, year: int):
        self.validation_year = year

    @PHuntAuth.login_required
    def get_data_from_source(self, symbol, start_date, end_date, provider='Dukascopy',  granularity='1MIN'):
        try:
            return DataSourceManager(provider, symbol, granularity).get_data(start_date, end_date)
        except Exception as e:
            raise PHuntAPIException(f"データソース操作エラー: {str(e)}")

    # Dataset関連のメソッド
    @PHuntAuth.login_required
    def list_datasets(self):
        try:
            return self.dataset_manager.list_datasets(view_type='dataset')
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def get_sample_data(self, dataset_id):
        try:
            return self.dataset_manager.get_sample_data(dataset_id)
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def create_dataset_from_local(self, name, local_path):
        try:
            result = self.dataset_manager.create_dataset_from_local(name, local_path)
            return result
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")

    @PHuntAuth.login_required
    def get_dataset_spec(self, dataset_id):
        try:
            return self.dataset_manager.get_dataset_spec(dataset_id)
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")
        
    @PHuntAuth.login_required
    def get_dataset(self, dataset_id):
        try:
            return self.dataset_manager.get_dataset(dataset_id).copy()
        except DatasetError as e:
            raise PHuntAPIException(f"データセット操作エラー: {str(e)}")

    # Feature関連のメソッド
    @PHuntAuth.login_required
    def list_features(self):
        try:
            return self.feature_manager.list_features()
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        
    # @PHuntAuth.login_required
    def get_feature_code_path(self, feature_name: str) -> str:
        try:
            return self.feature_manager.get_feature_code_path(feature_name)
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        
    def get_feature_code(self, feature_name: str) -> str:
        # キャッシュキー
        cache_key = f"feature_code_{feature_name}"
        
        # キャッシュをチェック
        cached_result = self.get_from_cache(cache_key)
        if cached_result is not None:
            return cached_result
                
        # キャッシュになければ取得して保存
        code_path = self.get_feature_code_path(feature_name)
        if code_path is None:
            return None
            
        code = read_s3_file(code_path)
        code = textwrap.dedent(code)
        print(code)
        
        # 文字列からコードを実行可能な関数に変換
        local_dict = {}
        exec(code, globals(), local_dict)
        print(local_dict.keys())
        create_feature = local_dict[list(local_dict.keys())[0]]
        
        # キャッシュに保存
        self.set_to_cache(cache_key, create_feature)
            
        return create_feature

    @PHuntAuth.login_required
    def submit_feature(self, name: str, processing_code: Callable=None, df: pd.DataFrame=None) -> str:
        try:
            # キャッシュキーの生成
            cache_key = None
            if processing_code is not None:
                # 処理コードを文字列に変換
                code_string = inspect.getsource(processing_code)
                # name と code_string のハッシュ値を計算
                import hashlib
                hash_object = hashlib.md5((name + code_string).encode())
                cache_key = f"feature_{hash_object.hexdigest()}"
                
                # キャッシュに存在するか確認
                if self.exists_in_cache(cache_key):
                    print(f"Cache hit for feature: {name}")
                    return name
                
                # 処理コードをファイルに保存
                file_path = f"/tmp/{name}_feature_processing_code.py"
                with open(file_path, 'w') as f:
                    f.write(code_string)
                print(f"Processing code saved to: {file_path}")
                
                # 処理コードにAPIインスタンスを渡して特徴量マネージャーのメソッドを呼び出す
                result = self.feature_manager.submit_feature(name, processing_code, api_instance=self)
                # 結果をキャッシュに格納
                self.set_to_cache(cache_key, result)
                return result
            elif df is not None:
                # DataFrameが直接提供された場合
                # DataFrameのハッシュ値を計算
                import hashlib
                df_hash = hashlib.md5(pd.util.hash_pandas_object(df).values).hexdigest()
                cache_key = f"feature_df_{name}_{df_hash}"
                
                # キャッシュに存在するか確認
                if self.exists_in_cache(cache_key):
                    print(f"Cache hit for feature dataframe: {name}")
                    return name
                
                df.to_parquet(f"/tmp/{name}_feature_data.parquet")
                result = self.feature_manager.submit_feature(name, df=df)
                # 結果をキャッシュに格納
                self.set_to_cache(cache_key, result)
                return result
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    def get_feature(self, feature_id, use_cache: bool=True):
        #        y_train, y_val = api.get_target('USDJPY_1MIN_RETURN')
        try:
            df = self.feature_manager.get_feature(feature_id, use_cache=use_cache).copy()
            if self.validation_year is not None:
                df['___year___'] = pd.to_datetime(df.index).year
                train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
                val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
                return train_df, val_df
            else:
                return df
        except FeatureError as e:
            raise PHuntAPIException(f"特徴量操作エラー: {str(e)}")

    # Target関連のメソッド
    @PHuntAuth.login_required
    def list_targets(self):
        try:
            return self.target_manager.list_targets()
        except TargetError as e:
            raise PHuntAPIException(f"目的変数操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def submit_target(self, name, processing_code: Callable=None, df: pd.DataFrame =None) -> str:
        try:
            # キャッシュキーの生成
            cache_key = None
            if processing_code is not None:
                # 処理コードを文字列に変換
                code_string = inspect.getsource(processing_code)
                # name と code_string のハッシュ値を計算
                import hashlib
                hash_object = hashlib.md5((name + code_string).encode())
                cache_key = f"target_{hash_object.hexdigest()}"
                
                # キャッシュに存在するか確認
                if self.exists_in_cache(cache_key):
                    print(f"Cache hit for target: {name}")
                    return name
                
                # 処理コードをファイルに保存
                file_path = f"/tmp/{name}_target_processing_code.py"
                with open(file_path, 'w') as f:
                    f.write(code_string)
                print(f"Processing code saved to: {file_path}")
                
                # 処理コードにAPIインスタンスを渡してターゲットマネージャーのメソッドを呼び出す
                result = self.target_manager.submit_target(name, processing_code, api_instance=self)
                # 結果をキャッシュに格納
                self.set_to_cache(cache_key, result)
                return name
            elif df is not None:
                # DataFrameが直接提供された場合
                # DataFrameのハッシュ値を計算
                import hashlib
                df_hash = hashlib.md5(pd.util.hash_pandas_object(df).values).hexdigest()
                cache_key = f"target_df_{name}_{df_hash}"
                
                # キャッシュに存在するか確認
                if self.exists_in_cache(cache_key):
                    print(f"Cache hit for target dataframe: {name}")
                    return name
                
                result = self.target_manager.submit_target(name, df=df)
                # 結果をキャッシュに格納
                self.set_to_cache(cache_key, result)
                return name
            else:
                raise PHuntAPIException("処理コードまたはデータフレームを指定してください")
        except TargetError as e:
            raise PHuntAPIException(f"目的変数操作エラー: {str(e)}")
        except Exception as e:
            raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        
    @PHuntAuth.login_required
    def get_target(self, target_id):
        try:
            df = self.target_manager.get_target(target_id).copy()
            if self.validation_year is not None:
                df['___year___'] = pd.to_datetime(df.index).year
                train_df = df[df['___year___'] != self.validation_year].drop(columns=['___year___']).copy()
                val_df = df[df['___year___'] == self.validation_year].drop(columns=['___year___']).copy()
                return train_df, val_df
            else:
                return df
        except TargetError as e:
            raise PHuntAPIException(f"目的変数操作エラー: {str(e)}")

    # Model関連のメソッド
    @PHuntAuth.login_required
    def submit_model(self, name: str, processing_code: Callable):
        try:
            # 処理コードを文字列に変換
            code_string = inspect.getsource(processing_code)
            # name と code_string のハッシュ値を計算
            import hashlib
            hash_object = hashlib.md5((name + code_string).encode())
            cache_key = f"model_{hash_object.hexdigest()}"
            
            # キャッシュに存在するか確認
            cached_result = self.get_from_cache(cache_key)
            if cached_result is not None:
                print(f"Cache hit for model: {name}")
                return cached_result
            
            # 自身のインスタンス(self)をModelManagerのsubmit_modelメソッドに渡す
            result = self.model_manager.submit_model(name, processing_code, api_instance=self)
            # 結果をキャッシュに格納
            self.set_to_cache(cache_key, result)
            return result
        except ModelError as e:
            raise PHuntAPIException(f"モデル操作エラー: {str(e)}")

    @PHuntAuth.login_required
    def list_models(self):
        try:
            return self.model_manager.list_models()
        except ModelError as e:
            raise PHuntAPIException(f"モデル操作エラー: {str(e)}")
        
    def load_model(self, run_id: str, model_name: str):
        model_id = f"{run_id}_{model_name}"
        
        # キャッシュから取得
        cached_result = self.get_from_cache(model_id)
        if cached_result is not None:
            print(f"Cache hit for model load: {model_id}")
            return cached_result
                
        try:
            model, feature_names = self.model_manager.load_model(run_id, model_name)
            
            # キャッシュに保存
            self.set_to_cache(model_id, (model, feature_names))
                
            return model, feature_names
        except ModelError as e:
            raise PHuntAPIException(f"モデル操作エラー: {str(e)}")


        
    def run_auth_server(self, 
                       host: str = "0.0.0.0",
                       port: int = 8000,
                       workers: int = 1,
                       reload: bool = False,
                       block: bool = True):
        """認証サーバーを起動する

        Args:
            host (str): バインドするホスト
            port (int): 認証サーバーのポート
            workers (int): ワーカープロセス数
            reload (bool): ホットリロードを有効にするかどうか
            block (bool): Trueの場合、サーバープロセスが終了するまでブロックします
        """
        from .auth_server.service import AuthServer, AuthServerConfig
        
        try:
            config = AuthServerConfig(
                host=host,
                port=port,
                workers=workers,
                reload=reload
            )
            
            server = AuthServer(config)
            server.run(block=block)
            
        except Exception as e:
            raise PHuntAPIException(f"認証サーバーの起動に失敗しました: {str(e)}")

    def run_feast_ui(self, host: str = "0.0.0.0", port: int = 8888, block: bool = True):
        """Feast UIを起動する

        Args:
            host (str): バインドするホスト
            port (int): Feast UIのポート
            block (bool): Trueの場合、UIプロセスが終了するまでブロックします
        """
        from .feast_ui.service import FeastUIServer, FeastUIConfig
        
        try:
            config = FeastUIConfig(
                host=host,
                port=port
            )
            
            server = FeastUIServer(config)
            server.run(block=block)
            
        except Exception as e:
            raise PHuntAPIException(f"Feast UIの起動に失敗しました: {str(e)}")

    def stop_auth_server(self):
        """認証サーバーを停止する"""
        if hasattr(self, '_auth_server') and self._auth_server:
            self._auth_server.stop()
            self._auth_server = None

    def stop_feast_ui(self):
        """Feast UIを停止する"""
        if hasattr(self, '_feast_ui') and self._feast_ui:
            self._feast_ui.stop()
            self._feast_ui = None

    def create_feature_store_yaml(self):
        # todo: utilsに移行
        with open('feature_store.yaml', 'w') as f:
            body = """
entity_key_serialization_version: 2
offline_store:
  type: duckdb
online_store:
  connection_string: feast-online-store.gnr8wb.0001.apne1.cache.amazonaws.com:6379,db=0
  type: redis
project: p_hunters_feast
provider: aws
registry:
  cache_ttl_seconds: 60
  path: postgresql+psycopg2://postgres:your_secure_password_here@feast-registry.c9jdh8eweihk.ap-northeast-1.rds.amazonaws.com:5432/feast
  registry_type: sql
  sqlalchemy_config_kwargs:
    echo: false
    pool_pre_ping: true
"""
            f.write(body)

    def join_and_drop(self, feature_df: pd.DataFrame, target_df: pd.DataFrame):
        feature_columns = feature_df.columns
        target_columns = target_df.columns
        data = pd.merge(feature_df, target_df, on='timestamp', how='inner')
        data.dropna(inplace=True)
        try:
            data = data.sample(n=10000)
        except Exception as e:
            print(f"Sample Error: {e}")
        return data[feature_columns], data[target_columns]
    
    def get_years(self, feature_df: pd.DataFrame):
        years = pd.to_datetime(feature_df.index).year
        years = sorted(years.unique())
        print(f"Years: {years}")
        return years
    

    def add_signal(self, name: str, datasource: DataSourceManager=None):
        if datasource is None and name=='dukascopy':
            datasource = DataSourceManager(provider='Dukascopy', symbol='USDJPY', granularity='1min')
        self.signal_manager.add_feed(name, datasource)

    def get_signal(self, name: str, start_date: str, end_date: str):
        if self.signal_manager.feeds.get(name) is None:
            self.add_signal(name=name)
        return self.signal_manager.get_data(name, start_date, end_date)

    def serve_model(self, run_id:str, model_name:str, **kwargs):
        from .predict import serve_model
        serve_model(run_id, model_name, **kwargs)

    def __del__(self):
        """デストラクタ：プロセスのクリーンアップ"""
        self.stop_auth_server()
        self.stop_feast_ui()

if __name__ == "__main__":
    api = PHuntAPI(debug=True)
    # 認証サーバーとFeast UIを別々に起動
    api.run_auth_server(block=False)  # ブロックしないように設定
    api.run_feast_ui(block=True)  # UIをブロックして実行
    time.sleep(1000)
    
