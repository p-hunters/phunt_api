# -*- coding: utf-8 -*-
"""
Refactored PHuntAPI using facade pattern with manager classes.

This refactored version maintains backward compatibility while delegating
responsibilities to specialized manager classes.
"""

import os
import warnings
from typing import Optional, Literal, Any, List, Dict, Tuple, Callable
import pandas as pd
import logging

# Suppress warnings as in original
# Filter all warnings from specific modules to be safe
warnings.filterwarnings("ignore", module="holidays")
warnings.filterwarnings("ignore", module="feast")
warnings.filterwarnings("ignore", module="passlib")
warnings.filterwarnings("ignore", module="pydantic")
warnings.filterwarnings("ignore", module="mlflow")

# Specific categories just in case
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

# Suppress Pydantic V2 migration warnings often emitted by other libs
try:
    from pydantic import PydanticDeprecatedSince20, PydanticDeprecationWarning
    warnings.filterwarnings("ignore", category=PydanticDeprecatedSince20)
    warnings.filterwarnings("ignore", category=PydanticDeprecationWarning)
except ImportError:
    pass
warnings.simplefilter("ignore")

# Import managers
from .managers import (
    AuthManager,
    DatasetManager,
    FeatureManager,
    ModelManager,
    PluginManager,
    CacheManager,
    TargetManager,
    TargetManager,
    TargetManager,
    TargetManager,
    CompetitionManager,
    NautilusCatalogManager
)
from .target_defs import TargetFactory, TargetDefinition

# Import utilities that are still used directly
from .misc.server_utils import ServerUtils
from .misc.data_utils import DataUtils
from .misc.signal_utils import SignalUtils
from .misc.submission_utils import SubmissionUtils

logger = logging.getLogger(__name__)


class PHuntAPI:
    """Main API client for P-Hunter - Refactored version.
    
    This refactored class uses the facade pattern to delegate responsibilities
    to specialized manager classes while maintaining backward compatibility.
    """
    
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        """Singleton pattern implementation."""
        if cls._instance is None:
            cls._instance = super(PHuntAPI, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
        
    def __init__(self, debug=False,
                 cache_type: Literal["memory", "file", "pickle"] = "pickle",
                 plugin_cache_dir: Optional[str] = None,
                 api_key: Optional[str] = None,
                 mock: bool = False,
                 headless: bool = False):
        """Initialize the PHuntAPI.
        
        Args:
            debug: Enable debug mode
            cache_type: Type of cache to use
            plugin_cache_dir: Directory for plugin cache
            api_key: API key for authentication
            mock: Use mock authentication
            headless: Run in headless mode
        """
        if not hasattr(self, '_initialized') or not self._initialized:
            self._initialize(debug, cache_type, plugin_cache_dir, api_key, mock, headless)
            
    def _initialize(self, debug=False,
                   cache_type: Literal["memory", "file", "pickle"] = "pickle",
                   plugin_cache_dir: Optional[str] = None,
                   api_key: Optional[str] = None,
                   mock: bool = False,
                   headless: bool = False):
        """Initialize all managers and utilities."""
        self.debug = debug
        self.repo_path = os.getenv("PHUNT_REPO_PATH", ".")
        self.validation_year = None
        
        # Initialize managers
        self._auth_manager = AuthManager(
            debug=debug,
            api_key=api_key,
            mock=mock,
            headless=headless
        )
        self._auth_manager.initialize()
        
        self._dataset_manager = DatasetManager(
            auth_provider=self._auth_manager,
            repo_path=self.repo_path,
            debug=debug
        )
        self._dataset_manager.initialize()
        
        self._feature_manager = FeatureManager(
            auth_provider=self._auth_manager,
            dataset_manager=self._dataset_manager,
            validation_year=self.validation_year,
            core_api=self,
            debug=debug
        )
        self._feature_manager.initialize()
        
        self._model_manager = ModelManager(
            auth_provider=self._auth_manager,
            debug=debug
        )
        self._model_manager.initialize()
        
        self._plugin_manager = PluginManager(
            auth_provider=self._auth_manager,
            plugin_cache_dir=plugin_cache_dir,
            core_api=self,
            debug=debug
        )
        self._plugin_manager.initialize()
        
        self._cache_manager = CacheManager(
            cache_type=cache_type,
            debug=debug
        )
        self._cache_manager.initialize()
        
        self._target_manager = TargetManager(
            auth_provider=self._auth_manager,
            dataset_manager=self._dataset_manager,
            validation_year=self.validation_year,
            core_api=self,
            debug=debug
        )
        self._target_manager.initialize()
        
        self._competition_manager = CompetitionManager(
            auth_provider=self._auth_manager,
            repo_path=self.repo_path,
            debug=debug
        )
        self._competition_manager.initialize()

        self._nautilus_catalog_manager = NautilusCatalogManager(
            auth_provider=self._auth_manager,
            debug=debug
        )
        self._nautilus_catalog_manager.initialize()
        
        # Initialize utilities
        self._server_utils = ServerUtils()
        self._signal_utils = SignalUtils()
        
        # Setup matplotlib
        DataUtils.setup_plt()
        
        self._initialized = True
        
    # ========== Authentication Methods ==========
    
    @property
    def auth(self):
        """Get the underlying PHuntAuth instance for compatibility."""
        return self._auth_manager.phunt_auth
        
    @property
    def tmp_creds(self):
        """Get temporary credentials for compatibility."""
        return self._auth_manager.get_credentials()
        
    def login(self, **kwargs):
        """Perform user login."""
        return self._auth_manager.login(**kwargs)
        
    def is_logged_in(self):
        """Check if user is logged in."""
        return self._auth_manager.is_logged_in()
        
    def has_gcp_access_token(self):
        """Check if GCP access token is available."""
        return self._auth_manager.has_gcp_access_token()
        
    def get_gcp_access_token(self):
        """Get GCP access token."""
        return self._auth_manager.get_gcp_access_token()
        
    def refresh_gcp_access_token_if_needed(self):
        """Refresh GCP access token if needed."""
        return self._auth_manager.refresh_gcp_access_token_if_needed()
        
    def get_gcp_service_account_email(self):
        """Get GCP service account email."""
        return self._auth_manager.get_gcp_service_account_email()
        
    # ========== Dataset Methods ==========
    
    def list_datasets(self):
        """List all available datasets."""
        return self._dataset_manager.list_datasets()
        
    def get_sample_data(self, dataset_name: str, n: int = 100):
        """Get sample data from a dataset."""
        return self._dataset_manager.get_sample_data(dataset_name, n)
        
    def get_dataset(self, dataset_name: str, max_rows: Optional[int] = None):
        """Get full dataset."""
        print(f"Getting dataset {dataset_name}")
        return self._dataset_manager.get_dataset(dataset_name, max_rows)
        
    def create_dataset_from_local(self, name: str, local_path: str, description: str = ""):
        """Create dataset from local file (alias for backward compatibility)."""
        return self._dataset_manager.create_dataset_from_local(local_path, name, description)
        
    def get_dataset_spec(self, dataset_name: str):
        """Get dataset specification."""
        return self._dataset_manager.get_dataset_spec(dataset_name)

    def get_dataset_info(self, dataset_name: str):
        """Get dataset metadata."""
        return self._dataset_manager.get_dataset_info(dataset_name)
        
    def create_dataset_from_local(self, file_path: str, dataset_name: str,
                                 description: str = ""):
        """Create dataset from local file."""
        return self._dataset_manager.create_dataset_from_local(
            file_path, dataset_name, description
        )
        
    def get_data_from_source(self, symbol: str, start_date: str, end_date: str, 
                            provider: str = 'Dukascopy', granularity: str = '1MIN', **kwargs):
        """Get data from external source."""
        # Backward compatibility - convert parameters
        kwargs.update({
            'symbol': symbol,
            'start_date': start_date,
            'end_date': end_date,
            'granularity': granularity
        })
        return self._dataset_manager.get_data_from_source(provider, **kwargs)
        
    # ========== Feature Methods ==========
    
    def list_features(self):
        """List all available features."""
        return self._feature_manager.list_features()
        
    def get_feature_code_path(self, feature_name: str):
        """Get feature code path."""
        return self._feature_manager.get_feature_code_path(feature_name)
        
    def get_feature_code(self, feature_name: str) -> Optional[Callable]:
        """Get feature processing function."""
        # Cache key
        cache_key = f"feature_code_{feature_name}"
        
        # Check cache
        cached_result = self.get_from_cache(cache_key)
        if cached_result is not None:
            return cached_result
            
        # Get the code path first (to check if feature exists)
        try:
            code_path = self._feature_manager.get_feature_code_path(feature_name)
            if not code_path:
                return None
        except Exception:
            # If any error (including auth), return None for backward compatibility
            return None
            
        # Get the code as string
        try:
            code_str = self._feature_manager.get_feature_code(feature_name)
            if not code_str:
                return None
        except Exception:
            # If any error, return None
            return None
            
        # Parse and compile the code to get the function
        try:
            # Create a namespace for execution
            namespace = {}
            exec(code_str, namespace)
            
            # Find the processing function
            for name, obj in namespace.items():
                if callable(obj) and not name.startswith('_'):
                    # Cache and return
                    self.set_to_cache(cache_key, obj)
                    return obj
        except Exception:
            pass
            
        return None
        
    def submit_feature(self, feature_name: str, processing_code: Callable,
                      feature_type: str = "timeseries",
                      description: str = "", depends_on: List[str] = None):
        """Submit a new feature."""
        return self._feature_manager.submit_feature(
            feature_name, processing_code, feature_type, description, depends_on
        )
        
    def get_feature(self, feature_name: str, df: Optional[pd.DataFrame] = None, use_cache: bool = True):
        """Get feature from Feast or calculate feature for dataframe."""
        return self._feature_manager.get_feature(feature_name, df, use_cache)
        
    # ========== Model Methods ==========
    
    def submit_model(self, model_name: str, model_code: Callable,
                    feature_names: List[str], target_name: str,
                    model_type: str = "classification",
                    description: str = "", hyperparameters: Dict[str, Any] = None):
        """Submit a new model."""
        return self._model_manager.submit_model(
            model_name, model_code, feature_names, target_name,
            model_type, description, hyperparameters
        )
        
    def list_models(self):
        """List all available models."""
        return self._model_manager.list_models()
        
    def load_model(self, model_name: str, version: Optional[str] = None):
        """Load a model and its feature names."""
        return self._model_manager.load_model(model_name, version)
        
    def get_mlflow_client(self):
        """Get MLflow client."""
        return self._model_manager.get_mlflow_client()
        
    def serve_model(self, model_name: str, input_data: pd.DataFrame = None,
                   version: Optional[str] = None, run_id: str = None, **kwargs):
        """Serve model predictions."""
        # If run_id is provided, use the legacy serve_model from predict module
        if run_id is not None:
            from .predict import serve_model
            return serve_model(run_id, model_name, **kwargs)
        # Otherwise use the model manager
        return self._model_manager.serve_model(model_name, input_data, version)
        
    # ========== Plugin Methods ==========
    
    def install_plugin_from_github(self, repo_url: str, branch: str = "main"):
        """Install plugin from GitHub."""
        return self._plugin_manager.install_plugin_from_github(repo_url, branch)
        
    def list_github_plugins(self):
        """List installed GitHub plugins."""
        return self._plugin_manager.list_github_plugins()
        
    def uninstall_github_plugin(self, repo_url: str):
        """Uninstall GitHub plugin."""
        return self._plugin_manager.uninstall_github_plugin(repo_url)
        
    def update_plugin_catalog(self):
        """Update plugin catalog."""
        return self._plugin_manager.update_plugin_catalog()
        
    def search_plugins(self, query: str, plugin_type: Optional[str] = None):
        """Search plugins in catalog."""
        return self._plugin_manager.search_plugins(query, plugin_type)
        
    def install_plugin_from_catalog(self, plugin_name: str, version: Optional[str] = None):
        """Install plugin from catalog."""
        return self._plugin_manager.install_plugin_from_catalog(plugin_name, version)
        
    def list_plugins(self, plugin_type: Optional[str] = None):
        """List all available plugins."""
        return self._plugin_manager.list_plugins(plugin_type)
        
    def get_plugin_functions(self, plugin_name: str):
        """Get plugin function list."""
        return self._plugin_manager.get_plugin_functions(plugin_name)
        
    def get_plugin_feature(self, plugin_name: str, function_name: str,
                          df: pd.DataFrame, **kwargs):
        """Calculate feature using plugin."""
        return self._plugin_manager.get_plugin_feature(
            plugin_name, function_name, df, **kwargs
        )
        
    def get_plugin_target(self, plugin_name: str, function_name: str,
                         df: pd.DataFrame, **kwargs):
        """Calculate target using plugin."""
        return self._plugin_manager.get_plugin_target(
            plugin_name, function_name, df, **kwargs
        )
        
    # ========== Target Methods ==========
    
    def list_targets(self):
        """List all available targets."""
        return self._target_manager.list_targets()
        
    def submit_target(self, target_name: str, processing_code: Callable,
                     target_type: str = "regression",
                     description: str = "", depends_on: List[str] = None):
        """Submit a new target."""
        return self._target_manager.submit_target(
            target_name, processing_code, target_type, description, depends_on
        )
        
    def get_target(self, target_name: str, df: pd.DataFrame):
        """Calculate target for dataframe."""
        return self._target_manager.get_target(target_name, df)

    def get_target_definition(self, name: str, **kwargs) -> TargetDefinition:
        """
        Get a target definition instance.
        """
        return TargetFactory.create(name, **kwargs)

    def generate_target(self, data: pd.DataFrame, target_def: TargetDefinition) -> pd.Series:
        """
        Generate target values for data.
        """
        return target_def.calculate(data)
        
    # ========== Competition Methods ==========
    
    def create_competition(
        self,
        competition_id: str,
        name: str,
        description: str,
        problem_description: str,
        problem_type: str = "classification",
        created_by: str = "",
        **kwargs
    ):
        """Create a new competition."""
        return self._competition_manager.create_competition(
            competition_id, name, description, problem_description,
            problem_type, created_by, **kwargs
        )
    
    def get_competition(self, competition_id: str):
        """Get a competition by ID."""
        return self._competition_manager.get_competition(competition_id)
    
    def list_competitions(self, status=None, tags=None):
        """List all competitions, optionally filtered."""
        return self._competition_manager.list_competitions(status=status, tags=tags)
    
    def update_competition(self, competition_id: str, **kwargs):
        """Update competition attributes."""
        return self._competition_manager.update_competition(competition_id, **kwargs)
    
    def delete_competition(self, competition_id: str):
        """Delete a competition."""
        return self._competition_manager.delete_competition(competition_id)
    
    def add_competition_dataset(self, competition_id: str, dataset_name: str):
        """Add a dataset to a competition."""
        return self._competition_manager.add_dataset(competition_id, dataset_name)
    
    def remove_competition_dataset(self, competition_id: str, dataset_name: str):
        """Remove a dataset from a competition."""
        return self._competition_manager.remove_dataset(competition_id, dataset_name)
    
    def add_competition_model(self, competition_id: str, model_name: str):
        """Add a model to a competition."""
        return self._competition_manager.add_model(competition_id, model_name)
    
    def remove_competition_model(self, competition_id: str, model_name: str):
        """Remove a model from a competition."""
        return self._competition_manager.remove_model(competition_id, model_name)
    
    def add_competition_feature(self, competition_id: str, feature_name: str):
        """Add a feature to a competition."""
        return self._competition_manager.add_feature(competition_id, feature_name)
    
    def remove_competition_feature(self, competition_id: str, feature_name: str):
        """Remove a feature from a competition."""
        return self._competition_manager.remove_feature(competition_id, feature_name)
    
    def add_leaderboard_entry(
        self,
        competition_id: str,
        participant_id: str,
        participant_name: str,
        score: float,
        model_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Add an entry to the competition leaderboard."""
        return self._competition_manager.add_leaderboard_entry(
            competition_id, participant_id, participant_name, score, model_name, metadata
        )
    
    def get_leaderboard(self, competition_id: str, top_n: Optional[int] = None):
        """Get leaderboard for a competition."""
        return self._competition_manager.get_leaderboard(competition_id, top_n)
    
    def remove_leaderboard_entry(self, competition_id: str, participant_id: str):
        """Remove an entry from the leaderboard."""
        return self._competition_manager.remove_leaderboard_entry(competition_id, participant_id)
    
    def update_competition_rules(self, competition_id: str, rules: Dict[str, Any]):
        """Update competition rules."""
        return self._competition_manager.update_rules(competition_id, rules)
    
    def get_competition_rules(self, competition_id: str):
        """Get competition rules."""
        return self._competition_manager.get_rules(competition_id)
        
    # ========== Nautilus Method ==========

    def get_nautilus_catalog(self):
        """Get the Nautilus Data Catalog instance."""
        return self._nautilus_catalog_manager.get_catalog()

    def ingest_nautilus_bars(self, instrument_id: str, bars_df: pd.DataFrame, 
                             bar_type_spec: str = "1-MINUTE-LAST-EXTERNAL"):
        """Ingest bars into Nautilus Data Catalog."""
        return self._nautilus_catalog_manager.ingest_bars(
            instrument_id, bars_df, bar_type_spec
        )

    def load_nautilus_bars(self, instrument_ids: List[str], start: Optional[pd.Timestamp] = None, 
                           end: Optional[pd.Timestamp] = None, 
                           bar_type_specs: Optional[List[str]] = None) -> List[Any]:
        """Load bars from Nautilus Data Catalog (robustly)."""
        return self._nautilus_catalog_manager.load_bars(
            instrument_ids, start, end, bar_type_specs
        )
    
    def add_discussion_post(
        self,
        competition_id: str,
        post_id: str,
        author_id: str,
        author_name: str,
        content: str,
        parent_post_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Add a discussion post to the competition."""
        return self._competition_manager.add_discussion_post(
            competition_id, post_id, author_id, author_name, content, parent_post_id, metadata
        )
    
    def get_discussion(self, competition_id: str):
        """Get all discussion posts for a competition."""
        return self._competition_manager.get_discussion(competition_id)
    
    def update_discussion_post(self, competition_id: str, post_id: str, content: str):
        """Update a discussion post."""
        return self._competition_manager.update_discussion_post(competition_id, post_id, content)
    
    def delete_discussion_post(self, competition_id: str, post_id: str):
        """Delete a discussion post."""
        return self._competition_manager.delete_discussion_post(competition_id, post_id)
        
    # ========== Cache Methods ==========
    
    def exists_in_cache(self, key: str):
        """Check if key exists in cache."""
        return self._cache_manager.exists(key)
        
    def get_from_cache(self, key: str, default: Any = None):
        """Get value from cache."""
        return self._cache_manager.get(key, default)
        
    def set_to_cache(self, key: str, value: Any):
        """Set value in cache."""
        return self._cache_manager.set(key, value)
        
    # ========== Validation Methods ==========
    
    def set_validation_year(self, year: Optional[int]):
        """Set validation year for train/validation split."""
        self.validation_year = year
        self._feature_manager.set_validation_year(year)
        self._target_manager.set_validation_year(year)
        
    # ========== Plugin Methods ==========
    
    def list_available_plugins(self):
        """List all available plugins."""
        return self._plugin_manager.list_available_plugins()
        
    def install_plugin(self, plugin_id: str, version: Optional[str] = None):
        """Install a plugin."""
        return self._plugin_manager.install_plugin(plugin_id, version)
        
    def list_installed_plugins(self):
        """List all installed plugins."""
        return self._plugin_manager.list_installed_plugins()
        
    def get_plugin_features(self, plugin_id: Optional[str] = None):
        """Get features from plugins."""
        return self._plugin_manager.get_plugin_features(plugin_id)
        
    def get_plugin_targets(self, plugin_id: Optional[str] = None):
        """Get targets from plugins."""
        return self._plugin_manager.get_plugin_targets(plugin_id)
        
    def get_plugin_feature(self, plugin_name: str, feature_name: str, df: pd.DataFrame, **kwargs):
        """Get a specific feature from a plugin."""
        return self._plugin_manager.get_plugin_feature(plugin_name, feature_name, df, **kwargs)
        
    def get_plugin_target(self, plugin_name: str, target_name: str, df: pd.DataFrame, **kwargs):
        """Get a specific target from a plugin."""
        return self._plugin_manager.get_plugin_target(plugin_name, target_name, df, **kwargs)
        
    def generate_plugin_docs(self, output_dir: Optional[str] = None, plugin_type: Optional[str] = None) -> List[str]:
        """Generate documentation for all plugins."""
        return self._plugin_manager.generate_plugin_docs(output_dir, plugin_type)
        
    def generate_plugin_doc(self, plugin_name: str, output_dir: Optional[str] = None, plugin_type: Optional[str] = None) -> Optional[str]:
        """Generate documentation for a specific plugin."""
        return self._plugin_manager.generate_plugin_doc(plugin_name, output_dir, plugin_type)
        
    def get_plugin_functions(self, plugin_name: str, plugin_type: Optional[str] = None, include_signatures: bool = False):
        """Get available functions from a plugin."""
        return self._plugin_manager.get_plugin_functions(plugin_name, plugin_type, include_signatures)
        
    def _get_plugin_version(self, plugin_name: str, plugin_type: Optional[str] = None) -> str:
        """Get version of a plugin."""
        return self._plugin_manager._get_plugin_version(plugin_name, plugin_type)
        
    def search_plugin_catalog(self, query: str, plugin_type: Optional[str] = None):
        """Search for plugins in the catalog."""
        return self._plugin_manager.search_catalog(query, plugin_type)
        
    def install_plugin_from_catalog(self, plugin_name: str, version: Optional[str] = None):
        """Install a plugin from the catalog."""
        return self._plugin_manager.install_plugin_from_catalog(plugin_name, version)
        
    # ========== Server Methods ==========
    
    def run_auth_server(self, host: str = "localhost", port: int = 7080):
        """Run authentication server."""
        return self._server_utils.run_auth_server(host, port)
        
    def stop_auth_server(self):
        """Stop authentication server."""
        return self._server_utils.stop_auth_server()
        
    def run_feast_ui(self, host: str = "localhost", port: int = 8889):
        """Run Feast UI server."""
        return self._server_utils.run_feast_ui(host, port)
        
    def stop_feast_ui(self):
        """Stop Feast UI server."""
        return self._server_utils.stop_feast_ui()
        
    def start_jupyter_server(self, host: str = "localhost", port: int = 8888):
        """Start Jupyter server."""
        return self._server_utils.start_jupyter_server(host, port)
        
    def start_feast_ui(self, host: str = "localhost", port: int = 8889):
        """Start Feast UI server (alias for run_feast_ui)."""
        return self.run_feast_ui(host, port)
        
    def clear_cache(self):
        """Clear all cache entries."""
        return self._cache_manager.clear()
        
    def backtest(self, df: pd.DataFrame, signal_func: Callable, **kwargs):
        """Run backtest on trading signal."""
        from .backtest import BacktestEngine
        engine = BacktestEngine()
        return engine.run(df, signal_func, **kwargs)
        
    def create_trade_signal(self, name: str, logic_func: Callable):
        """Create a new trade signal."""
        from .trade_signal import TradeSignal
        return TradeSignal(name, logic_func)
        
    def add_signal(self, name: str, datasource: Optional[Any] = None):
        """Add a signal to the signal manager."""
        return self._signal_utils.add_signal(name, datasource)
        
    def get_signal(self, name: str, start_date: str, end_date: str):
        """Get signal data for a date range."""
        return self._signal_utils.get_signal(name, start_date, end_date)
        
    def _validate_processing_code(self, processing_code: Callable, error_class = None):
        """Validate processing code."""
        from .misc.validation import ValidationUtils
        from .exceptions import PHuntAPIException
        if error_class is None:
            error_class = PHuntAPIException
        return ValidationUtils._validate_processing_code(processing_code, error_class)
        
    def create_feature_store_yaml(self):
        """Create feature store YAML configuration."""
        return self._server_utils.create_feature_store_yaml()
        
    # ========== Utility Methods ==========
    
    def setup_logging_plt(self, logging, plt, SCRIPT_DIR, MODEL_NAME):
        """Setup logging and matplotlib."""
        return DataUtils.setup_logging_plt(logging, plt, SCRIPT_DIR, MODEL_NAME)
        
    def get_years(self, df: pd.DataFrame) -> List[int]:
        """Extract years from dataframe."""
        return DataUtils.get_years(df)
        
    def join_and_drop(self, df: pd.DataFrame, feature_df: pd.DataFrame,
                     feature_name: str) -> pd.DataFrame:
        """Join dataframes and drop duplicate columns."""
        return DataUtils.join_and_drop(df, feature_df, feature_name)
        
    def add_signal(self, df: pd.DataFrame, signal_name: str,
                  signal_func: Callable) -> pd.DataFrame:
        """Add trading signal to dataframe."""
        return self._signal_utils.add_signal(df, signal_name, signal_func)
        
    def get_signal(self, signal_name: str, df: pd.DataFrame) -> pd.DataFrame:
        """Get signal data."""
        return self._signal_utils.get_signal(signal_name, df)
        
    # ========== Cleanup ==========
    
    def __del__(self):
        """Cleanup resources on deletion."""
        if hasattr(self, '_initialized') and self._initialized:
            # Cleanup all managers
            for manager in [
                self._auth_manager,
                self._dataset_manager,
                self._feature_manager,
                self._model_manager,
                self._plugin_manager,
                self._cache_manager,
                self._target_manager,
                self._competition_manager
            ]:
                if hasattr(manager, 'cleanup'):
                    manager.cleanup()
            
            # Cleanup Nautilus manager
            if hasattr(self, '_nautilus_catalog_manager'):
                self._nautilus_catalog_manager.cleanup()
                    
            # Stop any running servers
            if hasattr(self._server_utils, 'stop_all_servers'):
                self._server_utils.stop_all_servers()
            
    # ========== Additional compatibility methods ==========
    
    @property
    def _plugin_feature_api(self):
        """Get plugin feature API for compatibility."""
        return self._plugin_manager._plugin_feature_api
        
    @property
    def _plugin_target_api(self):
        """Get plugin target API for compatibility."""
        return self._plugin_manager._plugin_target_api
        
    def reset_managers(self):
        """Reset internal managers for compatibility."""
        # Re-initialize managers
        self._dataset_manager.initialize()
        self._feature_manager.initialize()
        self._model_manager.initialize()
        self._target_manager.initialize()
        self._competition_manager.initialize()