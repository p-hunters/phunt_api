"""
プラグインのドキュメント生成機能のテスト

このスクリプトは、プラグインのドキュメント生成機能をテストします。
"""

import logging
import os
from phunt_api import PHuntAPI
from phunt_api.plugin_system.registry import FeaturePluginRegistry
from phunt_api.plugin_system.sample_plugin import SampleFeaturePlugin
from phunt_api.plugin_system.doc_generator import PluginDocGenerator

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_doc_generator():
    """
    ドキュメント生成機能をテストする
    """
    logger.info("=== プラグインのドキュメント生成機能のテスト ===")
    
    # PHuntAPIを初期化
    logger.info("PHuntAPIを初期化...")
    api = PHuntAPI(debug=True)
    
    # プラグイン一覧を取得
    plugins = api.list_plugins()
    logger.info(f"登録済みプラグイン数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']} (v{plugin['info']['version']}): {plugin['info']['description']}")
    
    # ドキュメント出力ディレクトリを設定
    output_dir = os.path.join(os.path.expanduser("~"), ".phunt", "docs")
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"ドキュメント出力ディレクトリ: {output_dir}")
    
    # すべてのプラグインのドキュメントを生成
    logger.info("\n1. すべてのプラグインのドキュメントを生成...")
    doc_files = api.generate_plugin_docs(output_dir)
    
    logger.info(f"生成されたドキュメントファイル数: {len(doc_files)}")
    for doc_file in doc_files:
        logger.info(f"- {doc_file}")
    
    # 特定のプラグインのドキュメントを生成
    if plugins:
        first_plugin = plugins[0]['name']
        logger.info(f"\n2. プラグイン '{first_plugin}' のドキュメントを生成...")
        doc_file = api.generate_plugin_doc(first_plugin, output_dir)
        
        if doc_file:
            logger.info(f"生成されたドキュメントファイル: {doc_file}")
            
            # ドキュメントファイルの内容を表示
            logger.info(f"\nドキュメントファイルの内容:")
            try:
                with open(doc_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # 最初の500文字だけ表示
                    logger.info(content[:500] + "...")
            except Exception as e:
                logger.error(f"ドキュメントファイルの読み込み中にエラーが発生: {str(e)}")
        else:
            logger.warning(f"プラグイン '{first_plugin}' のドキュメント生成に失敗しました")
    
    # バージョン競合の確認
    logger.info("\n3. バージョン競合の確認...")
    conflicts = api.get_plugin_version_conflicts()
    if conflicts:
        logger.info(f"バージョン競合: {len(conflicts)} プラグイン")
        for name, versions in conflicts.items():
            logger.info(f"- {name}: {', '.join(versions)}")
    else:
        logger.info("バージョン競合はありません")
    
    logger.info("\n=== テスト完了 ===")

if __name__ == "__main__":
    test_doc_generator() 