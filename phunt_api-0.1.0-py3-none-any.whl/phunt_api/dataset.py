# -*- coding: utf-8 -*-

# データセット操作のためのクラス
# データセットの作成、更新、削除、ダウンロード、アップロードなどの操作を行う
# データセットの種類は、パブリックデータセットと内部データセットがある
# パブリックデータセットは、パブリックAPIから取得できるデータセット
# 内部データセットは、PHuntの内部で使用するデータセット 
# パブリックデータセットは、PHuntの外部に公開されているデータセット
# feastを使用してデータセットを管理する

# TODO
# ローカルのparquetをS3にアップロードしてから、Feastにデータソースとして追加する
#  - 同時にサンプルデータソースの追加ロジックを実装する


import requests
from .auth import PHuntAuth
import os
from feast import FeatureStore, FeatureView, Field, FileSource 
from feast.data_format import ParquetFormat
from feast.repo_config import RepoConfig
from feast.data_source import DataSource
from feast.data_format import ParquetFormat
from .utils import upload_to_s3, create_from_local_base
from typing import List, Dict, Optional
import pandas as pd
from datetime import datetime
from .exceptions import DatasetError
from .utils import FeastManager, query_s3_duckdb

class TypedFeatureView:
    def __init__(self, feature_view: FeatureView, view_type: str):
        self.feature_view = feature_view
        self.view_type = view_type

class DatasetManager:
    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.feast_manager = FeastManager(repo_path)
        self.sample_ratio = 0.1  # サンプルデータの比率（10%）
        self.creds = None
        self.cache = {}
        self.list_datasets()
    def set_creds(self, creds: Dict):
        self.creds = creds

    def list_datasets(self, view_type=None):
        try:
            print(f"list_datasets: {self.feast_manager.list_feature_views(view_type)}")
            return self.feast_manager.list_feature_views(view_type)
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"データセットのリスト取得中にエラーが発生しました: {str(e)}")

    def create_dataset(self, name: str, entities: List[str], schema: List[Field], view_type: str, **kwargs):
        try:
            return self.feast_manager.create_feature_view(name, entities, schema, view_type, **kwargs)
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"データセットの作成中にエラーが発生しました: {str(e)}")

    def get_dataset_spec(self, dataset_id):
        return self.feast_manager.get_feature_view(dataset_id)
    
    def get_dataset(self, dataset_id):
        if dataset_id in self.cache:
            return self.cache[dataset_id]
        feature_view = self.feast_manager.get_feature_view(dataset_id)
        print(feature_view)
        entity_df = self._get_entity_df_for_feature_view(feature_view)
        print(entity_df)
        features_df = self.feast_manager.get_historical_features(dataset_id, entity_df)
        self.cache[dataset_id] = features_df
        return features_df

    def delete_dataset(self, dataset_id):
        self.feast_manager.delete_feature_view(dataset_id)

    def _get_entity_df_for_feature_view(self, feature_view):
        path_to_parquet = f'{feature_view.batch_source.name}'
        entity_df = query_s3_duckdb(path_to_parquet, self.creds)
        return entity_df

    def get_dataset_split(self, dataset_id: str, split_type: str, test_year: Optional[int] = None):
        feature_view = self.feast_manager.get_feature_view(dataset_id)
        entity_df = self._get_entity_df_for_feature_view(feature_view)
        full_df = self.feast_manager.get_historical_features(dataset_id, entity_df)
        
        if feature_view.tags.get("type") == "dataset":
            return full_df  # データセットの場合は全期間のデータを返す
        
        # 日付列の存在を確認し、なけば追加
        if 'date' not in full_df.columns:
            full_df['date'] = pd.to_datetime(full_df.index)
        
        if split_type == "sample":
            return full_df.sample(frac=self.sample_ratio)
        elif split_type == "train":
            if test_year:
                return full_df[full_df['date'].dt.year != test_year]
            else:
                train_size = int(len(full_df) * 0.8)
                return full_df.iloc[:train_size]
        elif split_type == "test":
            if test_year:
                return full_df[full_df['date'].dt.year == test_year]
            else:
                test_size = int(len(full_df) * 0.2)
                return full_df.iloc[-test_size:]
        else:
            raise ValueError("Invalid split_type. Choose from 'sample', 'train', or 'test'.")

    def set_sample_ratio(self, ratio: float):
        if 0 < ratio < 1:
            self.sample_ratio = ratio
        else:
            raise ValueError("Sample ratio must be between 0 and 1.")

    def download_dataset_split(self, dataset_id: str, split_type: str, save_path: str, test_year: Optional[int] = None):
        split_df = self.get_dataset_split(dataset_id, split_type, test_year)
        split_df.to_csv(save_path, index=False)
        return save_path

    def create_dataset_from_local(self, name: str, local_path: str):
        return create_from_local_base(self.feast_manager, name, local_path, "dataset", self.sample_ratio)

class PublicDatasetManager:
    def __init__(self, repo_path):
        self._dataset_manager = DatasetManager(repo_path)

    def list_datasets(self, view_type=None):
        try:
            return self._dataset_manager.list_datasets(view_type)
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"公開データセットのリスト取得中にエラーが発生しました: {str(e)}")

    def get_dataset(self, dataset_id):
        return self._dataset_manager.get_dataset(dataset_id)

    def get_sample_data(self, dataset_id: str):
        return self._dataset_manager.get_dataset_split(dataset_id, "sample")

    def set_sample_ratio(self, ratio: float):
        self._dataset_manager.set_sample_ratio(ratio)

class InternalDatasetManager:
    def __init__(self, repo_path):
        self._dataset_manager = DatasetManager(repo_path)

if __name__ == "__main__":
    # 使用例（内部用）
    try:
        internal_dataset_manager = DatasetManager("/path/to/feast/repo")
        # 使用例（内部用）
        internal_dataset_manager = DatasetManager("/path/to/feast/repo")

        # 使用例（公開用）
        public_dataset_manager = PublicDatasetManager("/path/to/feast/repo")

        # 公開APIからのサンプルデータの取得
        sample_data = public_dataset_manager.get_sample_data("stock_features")

        # 内部使用のみ可能な操作
        train_data = internal_dataset_manager.get_dataset_split("stock_features", "train", test_year=2023)
        test_data = internal_dataset_manager.get_dataset_split("stock_features", "test", test_year=2023)

    except DatasetError as e:
        print(f"データセット操作中にエラーが発生しました: {str(e)}")

