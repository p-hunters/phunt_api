# -*- coding: utf-8 -*-

import requests
from .auth import PHuntAuth
import os
from typing import List, Dict, Optional, Any
import pandas as pd
from datetime import datetime
from .exceptions import DatasetError
from .utils import query_s3_duckdb
import json
from .models import DatasetMetadata
from .types import Field
from .adapters.datacatalog_adapter import DatacatalogAdapter

class TypedFeatureView:
    def __init__(self, feature_view: Any, view_type: str):
        self.feature_view = feature_view
        self.view_type = view_type
        
class DatasetManager:
    def __init__(self, repo_path, backend: str = "datacatalog"):
        self.repo_path = repo_path
        self.backend = "datacatalog" # Enforce datacatalog
        self.creds = None
        self.cache = {}
        
        # Initialize Adapter
        bucket = os.getenv("DATACATALOG_BUCKET", "porory-data")
        db = os.getenv("DATACATALOG_DB", "phunt_datacatalog")
        self.adapter = DatacatalogAdapter(bucket, db)
            
        self.sample_ratio = 0.1

    def set_creds(self, creds: Dict):
        self.creds = creds

    def list_datasets(self, view_type=None):
        try:
            return self.adapter.list_feature_views(tags={"type": view_type} if view_type else None)
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"Failed to list datasets: {str(e)}")

    def create_dataset(self, name: str, entities: List[str], schema: List[Field], view_type: str, metadata: Optional[Dict] = None, **kwargs):
        try:
            # Create feature view via adapter
            fv = self.adapter.create_feature_view(name, entities, schema, view_type=view_type, **kwargs)
            
            # Save metadata if provided
            if metadata:
                self._save_metadata(name, metadata)
                
            return fv
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"Failed to create dataset: {str(e)}")

    def update_dataset(self, feature_view: Any):
        try:
            self.adapter.update_feature_view(feature_view)
        except Exception as e:
            raise DatasetError(f"Failed to update dataset: {str(e)}")

    def _get_metadata_path(self, dataset_name: str) -> str:
        meta_dir = os.path.join(self.repo_path, "metadata")
        os.makedirs(meta_dir, exist_ok=True)
        return os.path.join(meta_dir, f"{dataset_name}_meta.json")

    def _save_metadata(self, dataset_name: str, metadata: Dict):
        path = self._get_metadata_path(dataset_name)
        with open(path, 'w') as f:
            json.dump(metadata, f, default=str)

    def get_dataset_info(self, dataset_id: str) -> DatasetMetadata:
        path = self._get_metadata_path(dataset_id)
        if os.path.exists(path):
            with open(path, 'r') as f:
                data = json.load(f)
            if 'name' not in data:
                data['name'] = dataset_id
            return DatasetMetadata(**data)
        else:
            try:
                fv = self.adapter.get_feature_view(dataset_id)
                tags = getattr(fv, "tags", {})
                return DatasetMetadata(
                    name=dataset_id,
                    description=tags.get("description", ""),
                    tags=list(tags.keys())
                )
            except:
                return DatasetMetadata(name=dataset_id, description="No metadata available")
    
    def get_dataset(self, dataset_id):
        if dataset_id in self.cache:
            return self.cache[dataset_id]
            
        features_df = self.adapter.get_historical_features(entity_df=None, feature_refs=[dataset_id])
        
        if 'ts' not in features_df.columns:
            features_df['ts'] = features_df.index
        self.cache[dataset_id] = features_df
        return features_df

    def delete_dataset(self, dataset_id):
        self.adapter.delete_feature_view(dataset_id)

    def get_dataset_split(self, dataset_id: str, split_type: str, test_year: Optional[int] = None):
        feature_view = self.adapter.get_feature_view(dataset_id)
        full_df = self.adapter.get_historical_features(entity_df=None, feature_refs=[dataset_id])
        
        tags = getattr(feature_view, "tags", {}) if not isinstance(feature_view, dict) else feature_view.get("tags", {})
        
        if tags.get("type") == "dataset":
            return full_df
        
        if 'date' not in full_df.columns:
            try:
                full_df['date'] = pd.to_datetime(full_df.index)
            except:
                pass # Can't convert index to date
        
        if split_type == "sample":
            return full_df.sample(frac=self.sample_ratio)
        elif split_type == "train":
            if test_year and 'date' in full_df.columns:
                return full_df[full_df['date'].dt.year != test_year]
            else:
                train_size = int(len(full_df) * 0.8)
                return full_df.iloc[:train_size]
        elif split_type == "test":
            if test_year and 'date' in full_df.columns:
                return full_df[full_df['date'].dt.year == test_year]
            else:
                test_size = int(len(full_df) * 0.2)
                return full_df.iloc[-test_size:]
        else:
            raise ValueError("Invalid split_type. Choose from 'sample', 'train', or 'test'.")

    def set_sample_ratio(self, ratio: float):
        if 0 < ratio < 1:
            self.sample_ratio = ratio
        else:
            raise ValueError("Sample ratio must be between 0 and 1.")

    def download_dataset_split(self, dataset_id: str, split_type: str, save_path: str, test_year: Optional[int] = None):
        split_df = self.get_dataset_split(dataset_id, split_type, test_year)
        split_df.to_csv(save_path, index=False)
        return save_path

    def create_dataset_from_local(self, name: str, local_path: str, description: str = "", **kwargs):
         # Implementation for datacatalog local import
         try:
             if local_path.endswith('.csv'):
                 df = pd.read_csv(local_path)
             else:
                 df = pd.read_parquet(local_path)
         except Exception as e:
             raise DatasetError(f"Failed to read local file {local_path}: {str(e)}")
             
         # Save via catalog
         metadata = {
             "feature_id": name,
             "feature_name": name,
             "feature_group": kwargs.get("group", "default"), 
             "description": description,
             "tags": kwargs.get("tags", {"type": "dataset"})
         }
         
         try:
             s3_path = self.adapter.catalog.save_feature(name, df, metadata)
             return {"name": name, "s3_path": s3_path, "status": "success"}
         except Exception as e:
             raise DatasetError(f"Failed to save dataset to catalog: {str(e)}")

    def upload_file(self, dataset_id: str, file_path: str):
         # Datacatalog: 
         # Load file
         try:
             if file_path.endswith('.csv'):
                 df = pd.read_csv(file_path)
             else:
                 df = pd.read_parquet(file_path)
         except Exception as e:
              raise DatasetError(f"Failed to read file {file_path}: {str(e)}")
         
         # Get existing metadata
         try:
             existing_meta = self.adapter.catalog.metadata.get_feature(dataset_id)
         except:
             existing_meta = None
             
         metadata = existing_meta if existing_meta else {
             "feature_id": dataset_id,
             "feature_name": dataset_id,
             "tags": {"type": "dataset"} 
         }
         
         # Save (Overwrite)
         try:
             self.adapter.catalog.save_feature(dataset_id, df, metadata)
         except Exception as e:
             raise DatasetError(f"Failed to upload file to catalog: {str(e)}")

    def download_dataset(self, dataset_id: str, save_path: str):
        self.download_dataset_split(dataset_id, "dataset", save_path)
        
    def register_sample_dataset(self, name: str, entities: List[str], schema: List[Field]):
        raise NotImplementedError("deprecated")

if __name__ == "__main__":
    pass
