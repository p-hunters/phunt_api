# -*- coding: utf-8 -*-

# データセット操作のためのクラス
# データセットの作成、更新、削除、ダウンロード、アップロードなどの操作を行う
# データセットの種類は、パブリックデータセットと内部データセットがある
# パブリックデータセットは、パブリックAPIから取得できるデータセット
# 内部データセットは、PHuntの内部で使用するデータセット 
# パブリックデータセットは、PHuntの外部に公開されているデータセット
# feastを使用してデータセットを管理する

# TODO
# ローカルのparquetをS3にアップロードしてから、Feastにデータソースとして追加する
#  - 同時にサンプルデータソースの追加ロジックを実装する


import requests
from .auth import PHuntAuth
import os
from feast import FeatureStore, FeatureView, Field, FileSource 
from feast.data_format import ParquetFormat
from feast.repo_config import RepoConfig
from feast.data_source import DataSource
from feast.data_format import ParquetFormat
from .utils import upload_to_s3, create_from_local_base
from typing import List, Dict, Optional, Any
import pandas as pd
from datetime import datetime
from .exceptions import DatasetError
from .utils import FeastManager, query_s3_duckdb # Kept for backward compatibility if accessed directly
import json
from .models import DatasetMetadata
import os

# Adapters
from .adapters.feast_adapter import FeastAdapter
from .adapters.datacatalog_adapter import DatacatalogAdapter

# Configuration
# Default to feast for backward compatibility during migration
FEATURE_STORE_BACKEND = os.getenv("FEATURE_STORE_BACKEND", "feast") 

class TypedFeatureView:
    def __init__(self, feature_view: FeatureView, view_type: str):
        self.feature_view = feature_view
        self.view_type = view_type
        
class DatasetManager:
    def __init__(self, repo_path, backend: str = FEATURE_STORE_BACKEND):
        self.repo_path = repo_path
        self.backend = backend
        self.creds = None
        self.cache = {}
        self.feature_store_yaml = os.path.join(repo_path, "feature_store.yaml") # Common
        
        # Initialize Adapter
        if self.backend == "datacatalog":
            # For Phase 2, hardcode bucket/db or read from env/config
            bucket = os.getenv("DATACATALOG_BUCKET", "porory-data")
            db = os.getenv("DATACATALOG_DB", "phunt_datacatalog")
            self.adapter = DatacatalogAdapter(bucket, db)
            # FeastManager is NOT available in this mode usually, but kept if code relies on self.feast_manager
            # Create a dummy or let it fail? 
            # Ideally self.feast_manager should be removed, but for "Dual Stack" transitional validation:
            try:
                self.feast_manager = FeastManager(repo_path)
            except:
                self.feast_manager = None
        else:
            self.adapter = FeastAdapter(repo_path)
            self.feast_manager = self.adapter.feast_manager
            
        self.sample_ratio = 0.1  # サンプルデータの比率（10%）

    def set_creds(self, creds: Dict):
        self.creds = creds

    def list_datasets(self, view_type=None):
        try:
            return self.adapter.list_feature_views(tags={"type": view_type} if view_type else None)
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"データセットのリスト取得中にエラーが発生しました: {str(e)}")

    def create_dataset(self, name: str, entities: List[str], schema: List[Field], view_type: str, metadata: Optional[Dict] = None, **kwargs):
        try:
            # Create feature view
            fv = self.adapter.create_feature_view(name, entities, schema, view_type=view_type, **kwargs)
            
            # Save metadata if provided
            if metadata:
                self._save_metadata(name, metadata)
                
            return fv
        except DatasetError as e:
            raise
        except Exception as e:
            raise DatasetError(f"データセットの作成中にエラーが発生しました: {str(e)}")

    def update_dataset(self, feature_view: Any):
        try:
            self.adapter.update_feature_view(feature_view)
        except Exception as e:
            raise DatasetError(f"データセットの更新中にエラーが発生しました: {str(e)}")

    def _get_metadata_path(self, dataset_name: str) -> str:
        # Store metadata in a local directory for now, ideally this should be in a DB or S3
        # Assuming repo_path is a directory where we can write
        meta_dir = os.path.join(self.repo_path, "metadata")
        os.makedirs(meta_dir, exist_ok=True)
        return os.path.join(meta_dir, f"{dataset_name}_meta.json")

    def _save_metadata(self, dataset_name: str, metadata: Dict):
        path = self._get_metadata_path(dataset_name)
        # Ensure it matches DatasetMetadata model
        # If it's a dict, we save it as is, but validation happens on read or we can validate here
        with open(path, 'w') as f:
            json.dump(metadata, f, default=str)

    def get_dataset_info(self, dataset_id: str) -> DatasetMetadata:
        """
        Get metadata for a dataset.
        """
        path = self._get_metadata_path(dataset_id)
        if os.path.exists(path):
            with open(path, 'r') as f:
                data = json.load(f)
            # Ensure name is present
            if 'name' not in data:
                data['name'] = dataset_id
            return DatasetMetadata(**data)
        else:
            # Return minimal metadata if file doesn't exist
            # Try to get info from Feast
            try:
                fv = self.feast_manager.get_feature_view(dataset_id)
                return DatasetMetadata(
                    name=dataset_id,
                    description=fv.tags.get("description", ""),
                    tags=list(fv.tags.keys())
                )
            except:
                return DatasetMetadata(name=dataset_id, description="No metadata available")

    def get_dataset_spec(self, dataset_id):
        return self.feast_manager.get_feature_view(dataset_id)
    
    def get_dataset(self, dataset_id):
        if dataset_id in self.cache:
            return self.cache[dataset_id]
            
        # Refactored to use adapter
        # Adapter's get_historical_features is designed to mock this fetch
        features_df = self.adapter.get_historical_features(entity_df=None, feature_refs=[dataset_id])
        
        # ts カラムがなければ index を ts に変換
        if 'ts' not in features_df.columns:
            features_df['ts'] = features_df.index
        self.cache[dataset_id] = features_df
        return features_df

    def delete_dataset(self, dataset_id):
        self.adapter.delete_feature_view(dataset_id)

    def _get_entity_df_for_feature_view(self, feature_view):
        path_to_parquet = f'{feature_view.batch_source.name}'
        print(f'path_to_parquet: {path_to_parquet}')
        entity_df = query_s3_duckdb(path_to_parquet, self.creds)
        return entity_df

    def get_dataset_split(self, dataset_id: str, split_type: str, test_year: Optional[int] = None):
        # We need tags to check type="dataset". 
        # Adapter.get_feature_view should return something with .tags attribute (Mock/Object)
        feature_view = self.adapter.get_feature_view(dataset_id)
        
        # Logic to get full_df currently relies on get_historical_features
        full_df = self.adapter.get_historical_features(entity_df=None, feature_refs=[dataset_id])
        
        # Handle tags access safely as Datacatalog adapter might return dict
        tags = getattr(feature_view, "tags", {}) if not isinstance(feature_view, dict) else feature_view.get("tags", {})
        
        if tags.get("type") == "dataset":
            return full_df  # データセットの場合は全期間のデータを返す
        
        # 日付列の存在を確認し、なけば追加
        if 'date' not in full_df.columns:
            full_df['date'] = pd.to_datetime(full_df.index)
        
        if split_type == "sample":
            return full_df.sample(frac=self.sample_ratio)
        elif split_type == "train":
            if test_year:
                return full_df[full_df['date'].dt.year != test_year]
            else:
                train_size = int(len(full_df) * 0.8)
                return full_df.iloc[:train_size]
        elif split_type == "test":
            if test_year:
                return full_df[full_df['date'].dt.year == test_year]
            else:
                test_size = int(len(full_df) * 0.2)
                return full_df.iloc[-test_size:]
        else:
            raise ValueError("Invalid split_type. Choose from 'sample', 'train', or 'test'.")

    def set_sample_ratio(self, ratio: float):
        if 0 < ratio < 1:
            self.sample_ratio = ratio
        else:
            raise ValueError("Sample ratio must be between 0 and 1.")

    def download_dataset_split(self, dataset_id: str, split_type: str, save_path: str, test_year: Optional[int] = None):
        split_df = self.get_dataset_split(dataset_id, split_type, test_year)
        split_df.to_csv(save_path, index=False)
        return save_path

    def create_dataset_from_local(self, name: str, local_path: str, description: str = "", **kwargs):
        if self.backend == "datacatalog":
             # Implementation for datacatalog local import
             try:
                 if local_path.endswith('.csv'):
                     df = pd.read_csv(local_path)
                 else:
                     df = pd.read_parquet(local_path)
             except Exception as e:
                 raise DatasetError(f"Failed to read local file {local_path}: {str(e)}")
                 
             # Save via catalog
             metadata = {
                 "feature_id": name,
                 "feature_name": name,
                 "feature_group": kwargs.get("group", "default"), 
                 "description": description,
                 "tags": kwargs.get("tags", {"type": "dataset"})
             }
             
             try:
                 s3_path = self.adapter.catalog.save_feature(name, df, metadata)
                 return {"name": name, "s3_path": s3_path, "status": "success"}
             except Exception as e:
                 raise DatasetError(f"Failed to save dataset to catalog: {str(e)}")

        return create_from_local_base(self.adapter.feast_manager, name, local_path, "dataset", self.sample_ratio)

    def upload_file(self, dataset_id: str, file_path: str):
        # Legacy Feast Logic: updates source for existing FV?
        # Tests say: add_data_source -> get_feature_view -> update_feature_view
        if self.backend == "feast":
            try:
                self.adapter.feast_manager.add_data_source(dataset_id, file_path)
                fv = self.adapter.get_feature_view(dataset_id)
                self.adapter.update_feature_view(fv)
            except Exception as e:
                raise DatasetError(f"ファイルのアップロード中にエラーが発生しました: {str(e)}")
        else:
             # Datacatalog: 
             # Load file
             try:
                 if file_path.endswith('.csv'):
                     df = pd.read_csv(file_path)
                 else:
                     df = pd.read_parquet(file_path)
             except Exception as e:
                  raise DatasetError(f"Failed to read file {file_path}: {str(e)}")
             
             # Get existing metadata to preserve ID/Group (if possible)
             # If not found, use dataset_id as default
             try:
                 existing_meta = self.adapter.catalog.metadata.get_feature(dataset_id)
             except:
                 existing_meta = None
                 
             metadata = existing_meta if existing_meta else {
                 "feature_id": dataset_id,
                 "feature_name": dataset_id,
                 "tags": {"type": "dataset"} # Default to dataset type
             }
             
             # Save (Overwrite)
             try:
                 self.adapter.catalog.save_feature(dataset_id, df, metadata)
             except Exception as e:
                 raise DatasetError(f"Failed to upload file to catalog: {str(e)}")

    def register_sample_dataset(self, name: str, entities: List[str], schema: List[Field]):
        raise NotImplementedError("deprecated")

    def download_dataset(self, dataset_id: str, save_path: str):
        self.download_dataset_split(dataset_id, "dataset", save_path)
        
    def download_public_dataset(self, dataset_id: str, save_path: str):
        raise NotImplementedError("deprecated")

if __name__ == "__main__":
    pass

