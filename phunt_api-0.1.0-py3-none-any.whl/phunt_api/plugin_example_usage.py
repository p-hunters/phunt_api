"""
Plugin Feature API使用例

このモジュールは、特徴量計算プラグインシステムの使用例を提供します。
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any

# 仮想的なPHuntAPIクラス（実際には他の機能も含まれる）
class PHuntAPI:
    """
    プラグイン機能を含むPHunt API
    
    実際のPHuntAPIクラスは、他の機能も含んでいます。
    この例では、プラグイン関連の機能のみを示しています。
    """
    
    def __init__(self):
        """
        PHuntAPIの初期化
        """
        # プラグインAPIをインポート
        from .plugin_api import PluginFeatureAPI
        
        # プラグイン機能を初期化
        self._plugin_feature_api = PluginFeatureAPI()
    
    # プラグイン関連のメソッドは、PluginFeatureAPIクラスのメソッドを呼び出すだけ
    
    def install_plugin_from_github(self, repo_url: str, branch: str = 'main', force_update: bool = False) -> bool:
        """
        GitHubリポジトリからプラグインをインストール
        """
        return self._plugin_feature_api.install_plugin_from_github(
            repo_url=repo_url, 
            branch=branch, 
            force_update=force_update
        )
    
    def list_github_plugins(self):
        """
        インストール済みのGitHubプラグインを一覧表示
        """
        return self._plugin_feature_api.list_github_plugins()
    
    def uninstall_github_plugin(self, plugin_id: str) -> bool:
        """
        GitHubプラグインをアンインストール
        """
        return self._plugin_feature_api.uninstall_github_plugin(plugin_id)
    
    def update_plugin_catalog(self, force: bool = False) -> bool:
        """
        プラグインカタログを更新
        """
        return self._plugin_feature_api.update_plugin_catalog(force)
    
    def search_plugins(self, query: str = '', tags: list = None):
        """
        プラグインカタログを検索
        """
        return self._plugin_feature_api.search_plugins(query=query, tags=tags)
    
    def install_plugin_from_catalog(self, plugin_id: str) -> bool:
        """
        カタログからプラグインをインストール
        """
        return self._plugin_feature_api.install_plugin_from_catalog(plugin_id)
    
    def list_plugins(self):
        """
        インストール済みのプラグインを一覧表示
        """
        return self._plugin_feature_api.list_plugins()
    
    def get_plugin_functions(self, plugin_name: str):
        """
        プラグインの関数一覧を取得
        """
        return self._plugin_feature_api.get_plugin_functions(plugin_name)
    
    def get_plugin_feature(self, plugin_name: str, function_name: str, *args, **kwargs):
        """
        プラグイン機能を使用して特徴量を計算
        """
        return self._plugin_feature_api.get_plugin_feature(
            plugin_name=plugin_name,
            function_name=function_name,
            *args,
            **kwargs
        )
    
    def register_plugin_feature(self, name: str, plugin_name: str, function_name: str, *args, **kwargs):
        """
        プラグイン機能を使用して特徴量を計算して登録
        """
        return self._plugin_feature_api.register_plugin_feature(
            name=name,
            plugin_name=plugin_name,
            function_name=function_name,
            *args,
            **kwargs
        )
    
    # 以下は通常のPHunt APIのメソッド（例示のみ）
    
    def get_dataset(self, dataset_id: str):
        """
        データセットを取得
        """
        # 実際にはデータストアからデータセットを取得
        # ここではサンプルデータを生成
        dates = pd.date_range(start='2022-01-01', periods=100)
        np.random.seed(42)
        close_prices = 100 + np.cumsum(np.random.normal(0, 1, 100))
        
        return pd.DataFrame({
            'date': dates,
            'close': close_prices
        }).set_index('date')
    
    def get_feature(self, feature_id: str):
        """
        特徴量を取得
        """
        # 実際には特徴量ストアから特徴量を取得
        # ここではダミーデータを返す
        data = np.random.normal(0, 1, 100)
        return pd.Series(data, index=pd.date_range(start='2022-01-01', periods=100))


def sample_plugin_usage_example():
    """
    サンプルプラグインの使用例
    
    この例では、組み込みのサンプルプラグインを使用します。
    実際のユースケースでは、GitHubからプラグインをインストールします。
    """
    # PHunt APIの初期化
    api = PHuntAPI()
    
    # データセットを取得
    prices = api.get_dataset('sample_dataset')
    
    print("サンプルデータセット:")
    print(prices.head())
    print()
    
    # インストール済みのプラグインを一覧表示
    plugins = api.list_plugins()
    print("インストール済みのプラグイン:")
    for plugin in plugins:
        print(f"- {plugin['name']}: {plugin['info']['description']}")
    print()
    
    # プラグインの関数一覧を取得
    plugin_name = 'sample_feature_plugin'
    functions = api.get_plugin_functions(plugin_name)
    print(f"{plugin_name} の関数一覧:")
    for func in functions:
        print(f"- {func}")
    print()
    
    # RSIを計算
    rsi_df = api.get_plugin_feature(
        plugin_name='sample_feature_plugin',
        function_name='calculate_rsi',
        prices=prices['close'],
        window=14
    )
    
    print("RSI 計算結果:")
    print(rsi_df.head())
    print()
    
    # ボリンジャーバンドを計算
    bb_df = api.get_plugin_feature(
        plugin_name='sample_feature_plugin',
        function_name='calculate_bollinger_bands',
        prices=prices['close'],
        window=20,
        num_std=2.0
    )
    
    print("ボリンジャーバンド 計算結果:")
    print(bb_df.head())
    print()
    
    # MACDを計算
    macd_df = api.get_plugin_feature(
        plugin_name='sample_feature_plugin',
        function_name='calculate_macd',
        prices=prices['close']
    )
    
    print("MACD 計算結果:")
    print(macd_df.head())
    print()
    
    # 特徴量として登録
    feature_id = api.register_plugin_feature(
        name='my_rsi',
        plugin_name='sample_feature_plugin',
        function_name='calculate_rsi',
        prices=prices['close'],
        window=14
    )
    
    print(f"特徴量を登録しました: {feature_id}")
    
    # 結果を可視化
    plt.figure(figsize=(12, 10))
    
    # 価格チャートとボリンジャーバンド
    plt.subplot(3, 1, 1)
    plt.plot(prices.index, prices['close'], label='Close Price')
    plt.plot(bb_df.index, bb_df['bb_middle'], label='Middle Band')
    plt.plot(bb_df.index, bb_df['bb_upper'], label='Upper Band')
    plt.plot(bb_df.index, bb_df['bb_lower'], label='Lower Band')
    plt.legend()
    plt.title('Price with Bollinger Bands')
    
    # RSI
    plt.subplot(3, 1, 2)
    plt.plot(rsi_df.index, rsi_df['rsi'])
    plt.axhline(y=70, color='r', linestyle='-')
    plt.axhline(y=30, color='g', linestyle='-')
    plt.title('RSI (14)')
    
    # MACD
    plt.subplot(3, 1, 3)
    plt.plot(macd_df.index, macd_df['macd'], label='MACD')
    plt.plot(macd_df.index, macd_df['macd_signal'], label='Signal')
    plt.bar(macd_df.index, macd_df['macd_histogram'], label='Histogram')
    plt.legend()
    plt.title('MACD')
    
    plt.tight_layout()
    plt.show()


def github_plugin_example():
    """
    GitHubプラグインの使用例
    
    この例では、GitHubからプラグインをインストールして使用する方法を示します。
    この例は実際のGitHubリポジトリを必要とするため、実行するとエラーになることがあります。
    """
    # PHunt APIの初期化
    api = PHuntAPI()
    
    # GitHubからプラグインをインストール
    success = api.install_plugin_from_github(
        repo_url='https://github.com/phunt-io/phunt-sample-plugin'
    )
    
    if not success:
        print("プラグインのインストールに失敗しました。")
        return
    
    print("プラグインを正常にインストールしました。")
    
    # インストール済みのGitHubプラグインを一覧表示
    github_plugins = api.list_github_plugins()
    print("インストール済みのGitHubプラグイン:")
    for plugin in github_plugins:
        print(f"- {plugin['id']} (v{plugin['version']}): {plugin['repo_url']}")
    
    # プラグインの関数一覧を取得
    plugin_name = 'github_sample_plugin'  # 仮想的なプラグイン名
    functions = api.get_plugin_functions(plugin_name)
    print(f"{plugin_name} の関数一覧:")
    for func in functions:
        print(f"- {func}")
    
    # プラグイン機能を使用
    prices = api.get_dataset('sample_dataset')
    
    # 仮想的なプラグイン関数を呼び出す
    result = api.get_plugin_feature(
        plugin_name=plugin_name,
        function_name='calculate_awesome_feature',
        prices=prices['close']
    )
    
    print("計算結果:")
    print(result.head())
    
    # プラグインをアンインストール
    api.uninstall_github_plugin('phunt-io_phunt-sample-plugin')
    print("プラグインをアンインストールしました。")


def catalog_plugin_example():
    """
    プラグインカタログの使用例
    
    この例では、公式カタログからプラグインを検索してインストールする方法を示します。
    """
    # PHunt APIの初期化
    api = PHuntAPI()
    
    # カタログを更新
    api.update_plugin_catalog()
    
    # プラグインを検索
    plugins = api.search_plugins(query="technical")
    print("検索結果:")
    for plugin in plugins:
        print(f"- {plugin['id']}: {plugin['name']} - {plugin['description']}")
    
    # 特定のタグを持つプラグインを検索
    tagged_plugins = api.search_plugins(tags=["machine-learning"])
    print("\n機械学習タグのあるプラグイン:")
    for plugin in tagged_plugins:
        print(f"- {plugin['id']}: {plugin['name']}")
    
    # カタログからプラグインをインストール
    if plugins:
        plugin_id = plugins[0]['id']
        print(f"\n{plugin_id} をインストールします...")
        success = api.install_plugin_from_catalog(plugin_id)
        
        if success:
            print("プラグインを正常にインストールしました。")
        else:
            print("プラグインのインストールに失敗しました。")


if __name__ == "__main__":
    # 組み込みのサンプルプラグインを使用する例
    sample_plugin_usage_example()
    
    # 以下の例はGitHubやカタログの実際のリポジトリを必要とするためコメントアウト
    # github_plugin_example()
    # catalog_plugin_example() 