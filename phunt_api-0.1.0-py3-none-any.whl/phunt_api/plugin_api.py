"""
Plugin Feature API

This module provides the API for plugin-based feature calculation.
"""

import logging
import os
import pandas as pd
import polars as pl
import numpy as np
from typing import Dict, Any, List, Optional, Callable, Union, Tuple, get_type_hints, TYPE_CHECKING
import traceback
import importlib
import pkgutil
import inspect
import sys

# 型チェック時のみインポート
if TYPE_CHECKING:
    from phunt_api import PHuntAPI

from phunt_api.plugin_system.registry import FeaturePluginRegistry, FeaturePluginBase
from phunt_api.plugin_system.target_registry import TargetPluginRegistry, TargetPluginBase
from phunt_api.plugin_system.catalog import PluginCatalog
from phunt_api.plugin_system.doc_generator import PluginDocGenerator
# PHuntAPIのグローバルインポートを削除し、循環参照を解消
# from phunt_api import PHuntAPI

logger = logging.getLogger(__name__)

class PluginFeatureAPI:
    """
    API for plugin-based feature calculation
    
    This class provides methods to discover, manage, and use feature calculation plugins.
    """
    
    def __init__(self, plugin_cache_dir: str = None, debug: bool = False, core_api: 'PHuntAPI' = None):
        """
        Initialize the plugin feature API
        
        Args:
            plugin_cache_dir: Directory to cache plugin data
            debug: Enable debug mode
        """
        self.debug = debug
        self.logger = logger
        self.core_api = core_api
        # Set up plugin cache directory
        if plugin_cache_dir is None:
            home_dir = os.path.expanduser("~")
            plugin_cache_dir = os.path.join(home_dir, ".phunt", "plugins")
        
        self.plugin_cache_dir = plugin_cache_dir
        os.makedirs(plugin_cache_dir, exist_ok=True)
        
        logger.info(f"Plugin cache directory: {plugin_cache_dir}")
        
        # Initialize plugin registry
        self._plugin_registry = FeaturePluginRegistry()
        
        # Initialize plugin catalog
        self._plugin_catalog = PluginCatalog(cache_dir=plugin_cache_dir, use_local_catalog=True)
        
        # Discover plugins
        self.discover_plugins()
    
    def discover_plugins(self):
        """
        Discover feature plugins from entry points
        """
        self.logger.info("Discovering feature plugins")
        plugins = self._plugin_registry.discover_plugins() or []
        self.logger.info(f"Discovered {len(plugins)} feature plugins from entry points")
        
        # Register built-in plugins
        self.logger.info("Registering built-in feature plugins")
        
        # 動的にプラグインを登録
        self.register_builtin_plugins()
        
        # 従来の個別登録メソッドも念のため実行（互換性のため）
        # メソッドの存在を確認してから呼び出す
        if hasattr(self, 'register_price_features_plugins'):
            self.register_price_features_plugins()
        
        if hasattr(self, 'register_time_features_plugin'):
            self.register_time_features_plugin()
        
        return self._plugin_registry.list_plugins()
    
    def register_builtin_plugins(self):
        """
        動的に .plugin_system.plugins.features 配下のプラグインを検出して登録
        """
        try:
            self.logger.info("Auto-discovering built-in feature plugins")
            
            # モジュールのベースパスを取得 - 修正版
            module_path = os.path.dirname(os.path.abspath(__file__))  # /path/to/phunt/api/src/phunt_api
            plugins_dir = os.path.join(module_path, "plugin_system", "plugins", "features")
            
            self.logger.info(f"Looking for feature plugins in: {plugins_dir}")
            
            if not os.path.exists(plugins_dir):
                self.logger.warning(f"Features plugins directory not found: {plugins_dir}")
                return
            
            # プラグインディレクトリ内のサブディレクトリを検索
            plugin_dirs = [d for d in os.listdir(plugins_dir) 
                        if os.path.isdir(os.path.join(plugins_dir, d)) and not d.startswith('__')]
            
            for plugin_dir in plugin_dirs:
                try:
                    # プラグインパッケージのインポートパスを構築
                    import_path = f"phunt_api.plugin_system.plugins.features.{plugin_dir}"
                    
                    # プラグインモジュールをインポート
                    self.logger.info(f"Attempting to import plugin module: {import_path}")
                    plugin_module = importlib.import_module(import_path)
                    
                    # get_plugin_class関数を探す
                    if hasattr(plugin_module, 'get_plugin_class'):
                        plugin_class = plugin_module.get_plugin_class()
                        
                        # プラグインをインスタンス化して登録
                        plugin_instance = plugin_class()
                        success = self._plugin_registry.register_plugin(plugin_instance)
                        
                        if success:
                            self.logger.info(f"Successfully registered plugin from {plugin_dir}: {plugin_instance.PLUGIN_INFO['name']} v{plugin_instance.PLUGIN_INFO['version']}")
                        else:
                            self.logger.warning(f"Failed to register plugin from {plugin_dir}")
                    else:
                        # __init__.pyでget_plugin_classが見つからない場合、サブモジュールを探す
                        for _, module_name, is_pkg in pkgutil.iter_modules([os.path.join(plugins_dir, plugin_dir)]):
                            if is_pkg:
                                continue
                                
                            # setup.pyを除外する
                            if module_name in ['setup']:
                                continue
                                
                            # サブモジュールのインポートパスを構築
                            sub_import_path = f"{import_path}.{module_name}"
                            try:
                                self.logger.info(f"Attempting to import plugin submodule: {sub_import_path}")
                                sub_module = importlib.import_module(sub_import_path)
                                
                                # get_plugin_class関数を探す
                                if hasattr(sub_module, 'get_plugin_class'):
                                    plugin_class = sub_module.get_plugin_class()
                                    
                                    # プラグインをインスタンス化して登録
                                    plugin_instance = plugin_class()
                                    success = self._plugin_registry.register_plugin(plugin_instance)
                                    
                                    if success:
                                        self.logger.info(f"Successfully registered plugin from {sub_import_path}: {plugin_instance.PLUGIN_INFO['name']} v{plugin_instance.PLUGIN_INFO['version']}")
                                    else:
                                        self.logger.warning(f"Failed to register plugin from {sub_import_path}")
                            except (ImportError, AttributeError) as e:
                                self.logger.debug(f"Could not import {sub_import_path}: {e}")
                
                except Exception as e:
                    self.logger.error(f"Error registering plugin from {plugin_dir}: {e}")
                    self.logger.debug(traceback.format_exc())
        
        except Exception as e:
            self.logger.error(f"Error auto-discovering plugins: {e}")
            self.logger.debug(traceback.format_exc())
    
    
    def list_plugins(self, include_signatures: bool = True) -> List[Dict[str, Any]]:
        """
        List all registered plugins
        
        Args:
            include_signatures: Whether to include function signatures in the result
        
        Returns:
            List of plugin information dictionaries, optionally with function signatures
        """
        plugins = self._plugin_registry.list_plugins()
        
        if include_signatures:
            for plugin_info in plugins:
                plugin_name = plugin_info['name']
                functions_with_signatures = self.get_plugin_functions(
                    plugin_name, include_signatures=True
                )
                plugin_info['functions'] = functions_with_signatures
        
        return plugins
    
    def get_plugin_functions(self, plugin_name: str, include_signatures: bool = False) -> Union[List[str], Dict[str, Any]]:
        """
        Get a list of feature calculation functions provided by a plugin
        
        Args:
            plugin_name: Name of the plugin
            include_signatures: Whether to include function signatures in the result
            
        Returns:
            If include_signatures is False: List of function names
            If include_signatures is True: Dictionary mapping function names to their signatures
        """
        if not include_signatures:
            return self._plugin_registry.get_plugin_functions(plugin_name)
        
        plugin = self._plugin_registry.get_plugin(plugin_name)
        if not plugin:
            return {}
        
        function_names = self._plugin_registry.get_plugin_functions(plugin_name)
        functions_with_signatures = {}
        
        for func_name in function_names:
            try:
                func = getattr(plugin, func_name)
                if not callable(func):
                    continue
                    
                # 関数のシグニチャを取得
                sig = inspect.signature(func)
                
                # 型ヒントを取得
                try:
                    type_hints = get_type_hints(func)
                except Exception:
                    type_hints = {}
                
                parameters = {}
                for name, param in sig.parameters.items():
                    if name == 'self':
                        continue
                        
                    param_info = {
                        'kind': str(param.kind),
                        'default': None if param.default is inspect.Parameter.empty else repr(param.default),
                        'required': param.default is inspect.Parameter.empty and param.kind != inspect.Parameter.VAR_POSITIONAL and param.kind != inspect.Parameter.VAR_KEYWORD,
                    }
                    
                    # 型ヒントがあれば追加
                    if name in type_hints:
                        param_info['type'] = str(type_hints[name])
                    
                    parameters[name] = param_info
                
                # 戻り値の型ヒントがあれば追加
                return_info = {}
                if 'return' in type_hints:
                    return_info['type'] = str(type_hints['return'])
                
                # 関数のドキュメント文字列から情報を抽出
                docstring = inspect.getdoc(func) or ""
                
                functions_with_signatures[func_name] = {
                    'parameters': parameters,
                    'return': return_info,
                    'docstring': docstring
                }
            except Exception as e:
                self.logger.debug(f"Error getting signature for {func_name}: {e}")
        
        return functions_with_signatures
    
    def calculate_plugin_feature(self, plugin_name: str, function_name: str, **kwargs) -> pd.DataFrame:
        """
        プラグイン関数を使用して特徴量を計算する
        
        Args:
            plugin_name: プラグイン名
            function_name: 関数名
            **kwargs: 関数に渡す引数
            
        Returns:
            pandas.DataFrame: 計算された特徴量
        """
        # Import calculate_hash inside the method to avoid circular imports
        from .utils import calculate_hash
                
        try:
            # プラグインが存在するか確認（_plugin_registryから取得）
            plugin = self._plugin_registry.get_plugin(plugin_name)
            if plugin is None:
                raise ValueError(f"Plugin '{plugin_name}' not found")
            
            # 関数が存在するか確認
            if function_name not in plugin.feature_functions:
                raise ValueError(f"Function '{function_name}' not found in plugin '{plugin_name}'")
            
            # 関数を取得して実行
            func = plugin.feature_functions[function_name]

            # 引数のハッシュ値を計算
            args_dict = {
                'plugin_name': plugin_name,
                'function_name': function_name,
                'kwargs': kwargs,
                'func': func
            }
            cache_key = f"plugin_feature:{calculate_hash(args_dict)}"
            logger.info(f"Calculating feature with cache key: {cache_key}")
            
            # PHuntAPIのインスタンスがあればキャッシュをチェック
            if hasattr(self, 'core_api') and self.core_api is not None:
                # キャッシュにあればそれを返す
                if self.core_api.exists_in_cache(cache_key):
                    return self.core_api.get_from_cache(cache_key)
                
                try:
                    df = self.core_api.get_feature(cache_key)
                    if df is not None:
                        return df
                except Exception as e:
                    logger.info(f"No cached feature found: {str(e)}")

            result = func(**kwargs)
            
            # 結果をDataFrameに変換
            if not isinstance(result, pd.DataFrame):
                if hasattr(result, 'to_pandas'):
                    # Polarisなどの場合
                    result = result.to_pandas()
                else:
                    raise ValueError(f"Plugin function '{function_name}' returned {type(result).__name__}, expected DataFrame")
            
            # PHuntAPIのインスタンスがあればキャッシュに保存
            if hasattr(self, 'core_api') and self.core_api is not None:
                self.core_api.set_to_cache(cache_key, result)
                self.core_api.submit_feature(name=cache_key, df=result)
                
            return result
            
        except Exception as e:
            logger.error(f"Error calculating feature using plugin '{plugin_name}.{function_name}': {str(e)}")
            raise
    
    def get_plugin_version_conflicts(self) -> Dict[str, List[str]]:
        """
        Get plugin version conflicts
        
        Returns:
            Dictionary mapping plugin names to lists of conflicting versions
        """
        return self._plugin_registry.get_plugin_version_conflicts()
    
    def update_plugin_catalog(self, force: bool = False) -> bool:
        """
        Update the plugin catalog
        
        Args:
            force: Force update even if the catalog is up-to-date
            
        Returns:
            True if updated successfully, False otherwise
        """
        try:
            self.logger.info("Updating plugin catalog")
            return self._plugin_catalog.update_catalog(force=force)
        except Exception as e:
            self.logger.error(f"Error updating plugin catalog: {e}")
            return False
    
    def search_plugins(self, query: str = None, tags: List[str] = None) -> List[Dict[str, Any]]:
        """
        Search for plugins in the catalog
        
        Args:
            query: Search query
            tags: List of tags to filter by
            
        Returns:
            List of plugin information dictionaries
        """
        return self._plugin_catalog.search_plugins(query, tags)
    
    def get_plugin_details(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed information about a plugin
        
        Args:
            plugin_id: ID of the plugin
            
        Returns:
            Plugin details or None if not found
        """
        return self._plugin_catalog.get_plugin_details(plugin_id)
    
    def generate_plugin_docs(self, output_dir: str = None) -> List[str]:
        """
        プラグインのドキュメントを生成する
        
        Args:
            output_dir: ドキュメント出力ディレクトリ（指定しない場合はデフォルトディレクトリ）
            
        Returns:
            生成したドキュメントファイルのパスのリスト
        """
        try:
            # ドキュメントジェネレータを初期化
            doc_generator = PluginDocGenerator(self._plugin_registry, output_dir)
            
            # すべてのプラグインのドキュメントを生成
            generated_files = doc_generator.generate_all_docs()
            
            logger.info(f"Generated documentation for {len(generated_files)} plugins")
            return generated_files
            
        except Exception as e:
            logger.error(f"Error generating plugin documentation: {str(e)}")
            logger.debug(traceback.format_exc())
            return []
    
    def generate_plugin_doc(self, plugin_name: str, output_dir: str = None) -> Optional[str]:
        """
        指定したプラグインのドキュメントを生成する
        
        Args:
            plugin_name: プラグイン名
            output_dir: ドキュメント出力ディレクトリ（指定しない場合はデフォルトディレクトリ）
            
        Returns:
            生成したドキュメントファイルのパス、または生成に失敗した場合はNone
        """
        try:
            # ドキュメントジェネレータを初期化
            doc_generator = PluginDocGenerator(self._plugin_registry, output_dir)
            
            # 指定したプラグインのドキュメントを生成
            doc_path = doc_generator.generate_plugin_doc(plugin_name)
            
            if doc_path:
                logger.info(f"Generated documentation for plugin '{plugin_name}' at {doc_path}")
            else:
                logger.warning(f"Failed to generate documentation for plugin '{plugin_name}'")
                
            return doc_path
            
        except Exception as e:
            logger.error(f"Error generating documentation for plugin '{plugin_name}': {str(e)}")
            logger.debug(traceback.format_exc())
            return None
    
    def get_plugin_feature(
        self, 
        plugin_name: str, 
        function_name: str, 
        *args, 
        **kwargs
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        プラグイン機能を使用して特徴量を計算
        
        Args:
            plugin_name: プラグイン名
            function_name: 関数名
            *args: 関数の位置引数
            **kwargs: 関数のキーワード引数
            
        Returns:
            計算された特徴量
            
        Raises:
            ValueError: プラグインや関数が見つからない場合
            RuntimeError: 計算が失敗した場合
        """
        # プラグインを取得
        plugin = self._plugin_registry.get_plugin(plugin_name)
        if not plugin:
            raise ValueError(f"プラグイン '{plugin_name}' が見つかりません")
        
        # 関数を取得
        func = self._plugin_registry.get_plugin_function(plugin_name, function_name)
        if not func:
            raise ValueError(f"関数 '{function_name}' がプラグイン '{plugin_name}' に見つかりません")
        
        try:
            # 関数を実行
            result = func(*args, **kwargs)
            return result
        except Exception as e:
            logger.error(f"プラグイン関数の実行中にエラーが発生: {str(e)}")
            logger.debug(traceback.format_exc())
            raise RuntimeError(f"プラグイン関数の実行中にエラーが発生: {str(e)}")

class PluginTargetAPI:
    """
    API for plugin-based target calculation
    
    This class provides methods to discover, manage, and use target calculation plugins.
    """
    
    def __init__(self, plugin_cache_dir: str = None, debug: bool = False):
        """
        Initialize the plugin target API
        
        Args:
            plugin_cache_dir: Directory to cache plugin data
            debug: Whether to enable debug mode
        """
        self.debug = debug
        self.logger = logging.getLogger(__name__)
        
        # プラグインカタログの初期化
        self.plugin_cache_dir = plugin_cache_dir or os.path.expanduser("~/.phunt/plugins")
        self.logger.info(f"Plugin cache directory: {self.plugin_cache_dir}")
        
        # PHuntAPIインスタンスの初期化（後でセットする）
        self._phunt_api = None
        
        # プラグインレジストリの初期化
        self._plugin_registry = TargetPluginRegistry()
        
        # プラグインの検出
        self.discover_plugins()
    
    def discover_plugins(self):
        """
        Discover target plugins from entry points
        """
        self.logger.info("Discovering target plugins")
        plugins = self._plugin_registry.discover_plugins() or []
        self.logger.info(f"Discovered {len(plugins)} target plugins from entry points")
        
        # Register built-in plugins
        self.logger.info("Registering built-in target plugins")
        
        # 動的にプラグインを登録
        self.register_builtin_plugins()
        
        # 従来の個別登録メソッドも念のため実行（互換性のため）
        # メソッドの存在を確認してから呼び出す
        if hasattr(self, 'register_price_targets_plugin'):
            self.register_price_targets_plugin()
        
        return self._plugin_registry.list_plugins()
    
    def register_builtin_plugins(self):
        """
        動的に .plugin_system.plugins.targets 配下のプラグインを検出して登録
        """
        try:
            self.logger.info("Auto-discovering built-in target plugins")
            
            # モジュールのベースパスを取得 - 修正版
            module_path = os.path.dirname(os.path.abspath(__file__))  # /path/to/phunt/api/src/phunt_api
            plugins_dir = os.path.join(module_path, "plugin_system", "plugins", "targets")
            
            self.logger.info(f"Looking for target plugins in: {plugins_dir}")
            
            if not os.path.exists(plugins_dir):
                self.logger.warning(f"Targets plugins directory not found: {plugins_dir}")
                return
            
            # プラグインディレクトリ内のサブディレクトリを検索
            plugin_dirs = [d for d in os.listdir(plugins_dir) 
                        if os.path.isdir(os.path.join(plugins_dir, d)) and not d.startswith('__')]
            
            # ディレクトリではなくファイルで提供されているプラグインをチェック
            plugin_files = [f for f in os.listdir(plugins_dir) 
                          if os.path.isfile(os.path.join(plugins_dir, f)) 
                          and f.endswith('.py') 
                          and not f.startswith('__')]
            
            # ディレクトリベースのプラグインを処理
            for plugin_dir in plugin_dirs:
                try:
                    # プラグインパッケージのインポートパスを構築
                    import_path = f"phunt_api.plugin_system.plugins.targets.{plugin_dir}"
                    
                    # プラグインモジュールをインポート
                    self.logger.info(f"Attempting to import plugin module: {import_path}")
                    plugin_module = importlib.import_module(import_path)
                    
                    # get_plugin_class関数を探す
                    if hasattr(plugin_module, 'get_plugin_class'):
                        plugin_class = plugin_module.get_plugin_class()
                        
                        # プラグインをインスタンス化して登録
                        plugin_instance = plugin_class()
                        success = self._plugin_registry.register_plugin(plugin_instance)
                        
                        if success:
                            self.logger.info(f"Successfully registered plugin from {plugin_dir}: {plugin_instance.PLUGIN_INFO['name']} v{plugin_instance.PLUGIN_INFO['version']}")
                        else:
                            self.logger.warning(f"Failed to register plugin from {plugin_dir}")
                    else:
                        # __init__.pyでget_plugin_classが見つからない場合、サブモジュールを探す
                        for _, module_name, is_pkg in pkgutil.iter_modules([os.path.join(plugins_dir, plugin_dir)]):
                            if is_pkg:
                                continue
                                
                            # setup.pyを除外する
                            if module_name in ['setup']:
                                continue
                                
                            # サブモジュールのインポートパスを構築
                            sub_import_path = f"{import_path}.{module_name}"
                            try:
                                self.logger.info(f"Attempting to import plugin submodule: {sub_import_path}")
                                sub_module = importlib.import_module(sub_import_path)
                                
                                # get_plugin_class関数を探す
                                if hasattr(sub_module, 'get_plugin_class'):
                                    plugin_class = sub_module.get_plugin_class()
                                    
                                    # プラグインをインスタンス化して登録
                                    plugin_instance = plugin_class()
                                    success = self._plugin_registry.register_plugin(plugin_instance)
                                    
                                    if success:
                                        self.logger.info(f"Successfully registered plugin from {sub_import_path}: {plugin_instance.PLUGIN_INFO['name']} v{plugin_instance.PLUGIN_INFO['version']}")
                                    else:
                                        self.logger.warning(f"Failed to register plugin from {sub_import_path}")
                            except (ImportError, AttributeError) as e:
                                self.logger.debug(f"Could not import {sub_import_path}: {e}")
                
                except Exception as e:
                    self.logger.error(f"Error registering plugin from {plugin_dir}: {e}")
                    self.logger.debug(traceback.format_exc())
            
            # ファイルベースのプラグインを処理
            for plugin_file in plugin_files:
                try:
                    # ファイル名から.pyを除去してモジュール名を取得
                    module_name = os.path.splitext(plugin_file)[0]
                    
                    # プラグインモジュールのインポートパスを構築
                    import_path = f"phunt_api.plugin_system.plugins.targets.{module_name}"
                    
                    # プラグインモジュールをインポート
                    self.logger.info(f"Attempting to import plugin file: {import_path}")
                    plugin_module = importlib.import_module(import_path)
                    
                    # get_plugin_class関数を探す
                    if hasattr(plugin_module, 'get_plugin_class'):
                        plugin_class = plugin_module.get_plugin_class()
                        
                        # プラグインをインスタンス化して登録
                        plugin_instance = plugin_class()
                        success = self._plugin_registry.register_plugin(plugin_instance)
                        
                        if success:
                            self.logger.info(f"Successfully registered plugin from {plugin_file}: {plugin_instance.PLUGIN_INFO['name']} v{plugin_instance.PLUGIN_INFO['version']}")
                        else:
                            self.logger.warning(f"Failed to register plugin from {plugin_file}")
                
                except Exception as e:
                    self.logger.error(f"Error registering plugin from {plugin_file}: {e}")
                    self.logger.debug(traceback.format_exc())
        
        except Exception as e:
            self.logger.error(f"Error auto-discovering plugins: {e}")
            self.logger.debug(traceback.format_exc())
    
    def register_price_targets_plugin(self):
        """
        Register built-in price targets plugin
        """
        try:
            # Import the plugin
            from .plugin_system.plugins.targets.price_targets import PriceTargetPlugin
            
            # Register Price Targets plugin
            self.logger.info("Registering Price Targets plugin")
            price_targets_plugin = PriceTargetPlugin()
            success = self._plugin_registry.register_plugin(price_targets_plugin)
            if success:
                self.logger.info(f"Registered Price Targets plugin: {price_targets_plugin.PLUGIN_INFO['name']} v{price_targets_plugin.PLUGIN_INFO['version']}")
            else:
                self.logger.warning("Failed to register Price Targets plugin")
        except Exception as e:
            self.logger.error(f"Error registering Price Targets plugin: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
    
    def list_plugins(self, include_signatures: bool = False) -> List[Dict[str, Any]]:
        """
        List all registered target plugins
        
        Args:
            include_signatures: Whether to include function signatures in the result
        
        Returns:
            List of plugin information dictionaries, optionally with function signatures
        """
        plugins = self._plugin_registry.list_plugins()
        
        if include_signatures:
            for plugin_info in plugins:
                plugin_name = plugin_info['name']
                functions_with_signatures = self.get_plugin_functions(
                    plugin_name, include_signatures=True
                )
                plugin_info['functions'] = functions_with_signatures
        
        return plugins
    
    def get_plugin_functions(self, plugin_name: str, include_signatures: bool = False) -> Union[List[str], Dict[str, Any]]:
        """
        Get the available functions for a target plugin
        
        Args:
            plugin_name: Name of the plugin
            include_signatures: Whether to include function signatures in the result
            
        Returns:
            If include_signatures is False: List of function names
            If include_signatures is True: Dictionary mapping function names to their signatures
        """
        if not include_signatures:
            return self._plugin_registry.get_plugin_functions(plugin_name)
        
        plugin = self._plugin_registry.get_plugin(plugin_name)
        if not plugin:
            return {}
        
        function_names = self._plugin_registry.get_plugin_functions(plugin_name)
        functions_with_signatures = {}
        
        for func_name in function_names:
            try:
                func = getattr(plugin, func_name)
                if not callable(func):
                    continue
                    
                # 関数のシグニチャを取得
                sig = inspect.signature(func)
                
                # 型ヒントを取得
                try:
                    type_hints = get_type_hints(func)
                except Exception:
                    type_hints = {}
                
                parameters = {}
                for name, param in sig.parameters.items():
                    if name == 'self':
                        continue
                        
                    param_info = {
                        'kind': str(param.kind),
                        'default': None if param.default is inspect.Parameter.empty else repr(param.default),
                        'required': param.default is inspect.Parameter.empty and param.kind != inspect.Parameter.VAR_POSITIONAL and param.kind != inspect.Parameter.VAR_KEYWORD,
                    }
                    
                    # 型ヒントがあれば追加
                    if name in type_hints:
                        param_info['type'] = str(type_hints[name])
                    
                    parameters[name] = param_info
                
                # 戻り値の型ヒントがあれば追加
                return_info = {}
                if 'return' in type_hints:
                    return_info['type'] = str(type_hints['return'])
                
                # 関数のドキュメント文字列から情報を抽出
                docstring = inspect.getdoc(func) or ""
                
                functions_with_signatures[func_name] = {
                    'parameters': parameters,
                    'return': return_info,
                    'docstring': docstring
                }
            except Exception as e:
                self.logger.debug(f"Error getting signature for {func_name}: {e}")
        
        return functions_with_signatures
    
    def calculate_target(
        self, 
        plugin_name: str, 
        function_name: str,
        data: pd.DataFrame = None,
        **kwargs
    ) -> pd.DataFrame:
        """
        プラグイン関数を使用して目標変数を計算する
        
        Args:
            plugin_name: プラグイン名
            function_name: 関数名
            data: 入力データ（後方互換性のために残しています）
            **kwargs: 関数に渡す追加の引数
            
        Returns:
            pandas.DataFrame: 計算された目標変数
        """
        # Import calculate_hash inside the method to avoid circular imports
        from .utils import calculate_hash
        
        # 後方互換性のため、dataが渡された場合はkwargsに追加
        if data is not None:
            kwargs['data'] = data
        
        # 引数のハッシュ値を計算
        args_dict = {
            'plugin_name': plugin_name,
            'function_name': function_name,
            'kwargs': kwargs
        }
        
        # データフレームがある場合はハッシュに含める（パフォーマンス考慮）
        if 'data' in kwargs and isinstance(kwargs['data'], pd.DataFrame):
            data_df = kwargs['data']
            if data_df.shape[0] < 1000:  # 小さいデータの場合のみ全体をハッシュ化
                args_dict['data'] = data_df
            else:
                # 大きいデータの場合は部分的な情報のみハッシュ化
                args_dict['data_shape'] = data_df.shape
                args_dict['data_sample'] = data_df.head(100).to_dict()
                args_dict['data_tail'] = data_df.tail(100).to_dict()
            
        cache_key = f"plugin_target:{calculate_hash(args_dict)}"
        
        # キャッシュをチェック
        if hasattr(self, '_phunt_api') and self._phunt_api is not None:
            if self._phunt_api.exists_in_cache(cache_key):
                logger.info(f"Using cached result for target plugin {plugin_name}.{function_name}")
                return self._phunt_api.get_from_cache(cache_key)
        
        try:
            # プラグインが存在するか確認（_plugin_registryから取得）
            plugin = self._plugin_registry.get_plugin(plugin_name)
            if plugin is None:
                raise ValueError(f"Target plugin '{plugin_name}' not found")
            
            # 関数が存在するか確認
            if not hasattr(plugin, function_name) and not hasattr(plugin, 'target_functions'):
                # 後方互換性のために calculate_target をデフォルトとして使用
                if function_name == 'calculate_target' and hasattr(plugin, 'calculate_target'):
                    func = plugin.calculate_target
                else:
                    raise ValueError(f"Function '{function_name}' not found in plugin '{plugin_name}'")
            elif hasattr(plugin, 'target_functions') and function_name in plugin.target_functions:
                # 新しいプラグイン形式 - target_functions 辞書から関数を取得
                func = plugin.target_functions[function_name]
            else:
                # プラグインのメソッドとして直接呼び出し
                func = getattr(plugin, function_name)
            
            # 関数を実行
            result = func(**kwargs)
            
            # 結果をDataFrameに変換
            if not isinstance(result, pd.DataFrame):
                try:
                    result = pd.DataFrame(result)
                except:
                    raise ValueError(f"Plugin '{plugin_name}' function '{function_name}' returned {type(result).__name__}, expected DataFrame or convertible to DataFrame")
            
            # キャッシュに保存
            if hasattr(self, '_phunt_api') and self._phunt_api is not None:
                self._phunt_api.set_to_cache(cache_key, result)
                
            return result
            
        except Exception as e:
            logger.error(f"Error calculating target using plugin '{plugin_name}.{function_name}': {str(e)}")
            raise
    
    def register_target(
        self, 
        data: pd.DataFrame,
        plugin_name: str,
        function_name: str = 'calculate_target',
        target_name: str = None,
        target_id: str = None,
        description: str = None,
        tags: List[str] = None,
        **kwargs
    ) -> str:
        """
        Calculate and register a target
        
        Args:
            data: Input DataFrame
            plugin_name: Name of the plugin to use
            function_name: Name of the function to call (default: calculate_target)
            target_name: Optional name for the target (default: auto-generated)
            target_id: Optional ID for the target (default: auto-generated)
            description: Optional description for the target
            tags: Optional tags for the target
            **kwargs: Additional parameters for the target calculation
            
        Returns:
            Target ID from the target API
        """
        # 必要なときだけPHuntAPIをインポート（循環参照を防ぐため）
        from phunt_api.api import PHuntAPI
        
        try:
            # Calculate the target using the specified function
            result_df = self.calculate_target(
                plugin_name=plugin_name,
                function_name=function_name,
                data=data,
                **kwargs
            )
            
            # Generate a name if not provided
            if not target_name:
                plugin_info = self._plugin_registry.get_plugin(plugin_name).PLUGIN_INFO
                target_type = kwargs.get('target_type', 'default')
                periods = kwargs.get('periods', [1])
                periods_str = '_'.join(map(str, periods))
                target_name = f"{plugin_info['name']}_{function_name}_{periods_str}"
            
            # Get API instance to register the target
            api = PHuntAPI()
            
            # Register the target
            return api._target_api.register_target(
                data=result_df,
                plugin_name=plugin_name,
                target_name=target_name,
                target_id=target_id,
                description=description,
                tags=tags or [],
                **kwargs
            )
        except Exception as e:
            self.logger.error(f"Error registering target: {e}")
            self.logger.error(traceback.format_exc())
            raise RuntimeError(f"Error registering target: {str(e)}")
    
    def get_plugin_version_conflicts(self) -> Dict[str, List[str]]:
        """
        Get information about plugin version conflicts
        
        Returns:
            Dictionary of plugin name to list of conflicting versions
        """
        return self._plugin_registry.get_plugin_version_conflicts()
    
    def update_plugin_catalog(self, force: bool = False) -> bool:
        """
        Update the plugin catalog
        
        Args:
            force: Force update even if the catalog is up-to-date
            
        Returns:
            True if updated successfully, False otherwise
        """
        try:
            self.logger.info("Updating plugin catalog")
            return self._plugin_catalog.update_catalog(force=force)
        except Exception as e:
            self.logger.error(f"Error updating plugin catalog: {e}")
            return False
    
    def search_plugins(self, query: str = None, tags: List[str] = None) -> List[Dict[str, Any]]:
        """
        Search for plugins in the catalog
        
        Args:
            query: Search query string
            tags: List of tags to filter by
            
        Returns:
            List of plugin information dictionaries
        """
        try:
            return self._plugin_catalog.search_plugins(query, tags)
        except Exception as e:
            self.logger.error(f"Error searching plugins: {e}")
            return []
    
    def get_plugin_details(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed information about a plugin
        
        Args:
            plugin_id: Plugin ID
            
        Returns:
            Dictionary with plugin details if found, None otherwise
        """
        try:
            return self._plugin_catalog.get_plugin_details(plugin_id)
        except Exception as e:
            self.logger.error(f"Error getting plugin details: {e}")
            return None 