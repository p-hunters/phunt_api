# -*- coding: utf-8 -*-

from .model import ModelManager
from datetime import datetime, timedelta
import time
import textwrap
import pandas as pd
import os 
from flask import Flask, request, jsonify
import json
from multiprocessing import Process
import hashlib
import numpy as np

app = Flask(__name__)

def run_prediction_loop(run_id: str, model_name: str, feature_name: str):
    from phunt_api.api import PHuntAPI
    api = PHuntAPI()
    feature_window_days = 90
    start_date = (datetime.now() - timedelta(days=feature_window_days)).strftime('%Y-%m-%d')
    df = api.get_signal('dukascopy', start_date=start_date, end_date=None)
    previous_df = df
    previous_time = df.timestamp.values[-1]
    pred_id = hashlib.sha256(f"{run_id}_{model_name}_{feature_name}".encode()).hexdigest()
    def mock(df):
        def mock_get_dataset(name: str):
            return df
        return mock_get_dataset
    
    def create_signal(api):
        # run_id = 'deec127d06e443b8ae6835830b02d085'
        # model_name = 'model_2007'
        model, feature_names = api.load_model(run_id, model_name)
        create_feature = api.get_feature_code(feature_name)
        features = create_feature(api).dropna()
        signal = model.predict(features[feature_names])
        features['signal'] = signal
        features['run_id'] = run_id
        features['model_name'] = model_name
        features['ts'] = pd.to_datetime(features['timestamp'] * 1000000, utc=True)
        features.set_index('ts', inplace=True)
        return features

    while True:
        try:
        # 1分ごとにデータを取得
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M')
            if previous_time != current_time:
                df = api.get_signal('dukascopy', start_date='2024-02-01', end_date=None)
                if previous_df is None or previous_df.timestamp.values[-1] != df.timestamp.values[-1]:
                    print(f"New data: {df.timestamp.values[-1]}")
                    previous_time = current_time
                    previous_df = df
                    print(df.tail())
                    # Do something with the new data
                    api.get_dataset = mock(df)
                    out = create_signal(api).tail()
                    print(out)
                    
                    # Convert DataFrame to list of records and add metadata
                    json_data = {
                        "data": out.reset_index().apply(
                            lambda x: {
                                col: str(x[col]) if isinstance(x[col], (pd.Timestamp, pd.Timedelta))
                                else int(x[col]) if isinstance(x[col], np.integer)
                                else float(x[col]) if isinstance(x[col], np.floating)
                                else str(x[col])
                                for col in x.index
                            },
                            axis=1
                        ).tolist(),
                        "lastupdated_at": str(out.timestamp.values[-1])
                    }

                    print(json_data)
                    
                    # Save to file
                    with open(f'/tmp/signal.json', 'w') as f:
                        json.dump(json_data, f)

                    print(f"Signal saved to /tmp/signal.json")
            else:
                pass
                # print(f"No new data: {df.timestamp.values[-1]}")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(1)


@app.route('/predict', methods=['GET'])
def predict_endpoint():
    try:
        run_id = request.args.get('run_id')
        model_name = request.args.get('model_name')
        feature_name = request.args.get('feature_name')
        pred_id = hashlib.sha256(f"{run_id}_{model_name}_{feature_name}".encode()).hexdigest()
        with open(f'/tmp/signal.json', 'r') as f:
            signal = json.load(f)
        return jsonify(signal), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def healthcheck():
    if not os.path.exists(os.path.join('/tmp', 'signal.json')):
        print('no signal.json')
        return jsonify({'status': '200'}), 200
    latest_signal = json.load(open(os.path.join('/tmp', 'signal.json')))
    lastupdated_at = latest_signal['lastupdated_at']
    #現在のunixtimeよりも３分以上前の場合は503を返す
    unixtime = int(datetime.now().timestamp())
    if unixtime - int(lastupdated_at) > 180:
        return jsonify({'status': '503', 'lastupdated_at': lastupdated_at, 'current_unixtime': unixtime}), 503
    else:
        return jsonify({'status': '200', 'lastupdated_at': lastupdated_at, 'current_unixtime': unixtime}), 200


def run_server():
    port = int(os.getenv('PHUNT_API_PORT', 5050))
    host = os.getenv('PHUNT_API_HOST', '0.0.0.0')
    debug = os.getenv('PHUNT_API_DEBUG', 'False').lower() == 'true'
    app.run(host=host, port=port, debug=debug)

def serve_model(run_id: str, model_name: str, feature_name: str):
    # 予測ループを別プロセスで開始
    params = {'run_id': run_id, 'model_name': model_name, 'feature_name': feature_name}
    prediction_process = Process(target=run_prediction_loop, kwargs=params)
    prediction_process.start()
    host = os.getenv('PHUNT_API_HOST', '0.0.0.0')
    port = int(os.getenv('PHUNT_API_PORT', 5050))
    print(f'please access http://{host}:{port}/predict?run_id={run_id}&model_name={model_name}&feature_name={feature_name}')
    run_server()
