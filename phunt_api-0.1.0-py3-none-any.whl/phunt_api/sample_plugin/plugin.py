"""
Sample Feature Plugin Implementation

This module implements a sample feature plugin for the PHunt API.
"""

import pandas as pd
import numpy as np
from typing import Union, Optional

from ..plugin_system import FeaturePluginBase

class SampleFeaturePlugin(FeaturePluginBase):
    """
    A sample feature plugin that demonstrates how to create a plugin for the PHunt API.
    
    This plugin provides various technical indicators and features that can be used
    for financial market analysis.
    """
    
    # Plugin information
    PLUGIN_INFO = {
        'name': 'sample_feature_plugin',
        'version': '0.1.0',
        'description': 'A sample feature plugin for the PHunt API',
        'author': 'PHunt Team',
        'backends': ['pandas', 'polars'],  # サポートするバックエンド
        'tags': ['technical-indicators', 'sample']  # カテゴリタグ
    }
    
    def __init__(self):
        """
        Initialize the plugin
        """
        super().__init__()
    
    def calculate_rsi(
        self, 
        prices: Union[pd.Series, pd.DataFrame], 
        window: int = 14,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate the Relative Strength Index (RSI)
        
        Args:
            prices: Price data (Series or DataFrame)
            window: Window period for RSI calculation
            price_column: Column name for price data (if DataFrame)
            
        Returns:
            DataFrame with RSI values
        """
        # Extract price series if DataFrame
        if isinstance(prices, pd.DataFrame):
            if price_column is None:
                raise ValueError("price_column must be specified when prices is a DataFrame")
            price_series = prices[price_column]
        else:
            price_series = prices
        
        # Calculate price changes
        delta = price_series.diff()
        
        # Separate gains and losses
        gain = delta.copy()
        loss = delta.copy()
        gain[gain < 0] = 0
        loss[loss > 0] = 0
        loss = abs(loss)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=window).mean()
        avg_loss = loss.rolling(window=window).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # Create result DataFrame
        result = pd.DataFrame(index=price_series.index)
        result['rsi'] = rsi
        
        return result
    
    def calculate_bollinger_bands(
        self, 
        prices: Union[pd.Series, pd.DataFrame], 
        window: int = 20, 
        num_std: float = 2.0,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate Bollinger Bands
        
        Args:
            prices: Price data (Series or DataFrame)
            window: Window period for moving average
            num_std: Number of standard deviations for bands
            price_column: Column name for price data (if DataFrame)
            
        Returns:
            DataFrame with Bollinger Bands (middle, upper, lower)
        """
        # Extract price series if DataFrame
        if isinstance(prices, pd.DataFrame):
            if price_column is None:
                raise ValueError("price_column must be specified when prices is a DataFrame")
            price_series = prices[price_column]
        else:
            price_series = prices
        
        # Calculate middle band (moving average)
        middle_band = price_series.rolling(window=window).mean()
        
        # Calculate standard deviation
        std = price_series.rolling(window=window).std()
        
        # Calculate upper and lower bands
        upper_band = middle_band + (std * num_std)
        lower_band = middle_band - (std * num_std)
        
        # Create result DataFrame
        result = pd.DataFrame(index=price_series.index)
        result['bb_middle'] = middle_band
        result['bb_upper'] = upper_band
        result['bb_lower'] = lower_band
        result['bb_width'] = (upper_band - lower_band) / middle_band  # Add bandwidth
        
        return result
    
    def calculate_macd(
        self, 
        prices: Union[pd.Series, pd.DataFrame], 
        fast_period: int = 12, 
        slow_period: int = 26, 
        signal_period: int = 9,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate Moving Average Convergence Divergence (MACD)
        
        Args:
            prices: Price data (Series or DataFrame)
            fast_period: Fast period for EMA
            slow_period: Slow period for EMA
            signal_period: Signal period for MACD
            price_column: Column name for price data (if DataFrame)
            
        Returns:
            DataFrame with MACD (macd, signal, histogram)
        """
        # Extract price series if DataFrame
        if isinstance(prices, pd.DataFrame):
            if price_column is None:
                raise ValueError("price_column must be specified when prices is a DataFrame")
            price_series = prices[price_column]
        else:
            price_series = prices
        
        # Calculate fast and slow EMAs
        fast_ema = price_series.ewm(span=fast_period, adjust=False).mean()
        slow_ema = price_series.ewm(span=slow_period, adjust=False).mean()
        
        # Calculate MACD
        macd_line = fast_ema - slow_ema
        
        # Calculate signal line
        signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
        
        # Calculate histogram
        histogram = macd_line - signal_line
        
        # Create result DataFrame
        result = pd.DataFrame(index=price_series.index)
        result['macd'] = macd_line
        result['macd_signal'] = signal_line
        result['macd_histogram'] = histogram
        
        return result
    
    def calculate_custom_oscillator(
        self, 
        prices: Union[pd.Series, pd.DataFrame], 
        window_short: int = 5, 
        window_long: int = 20,
        price_column: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Calculate a custom price oscillator
        
        Args:
            prices: Price data (Series or DataFrame)
            window_short: Short window period
            window_long: Long window period
            price_column: Column name for price data (if DataFrame)
            
        Returns:
            DataFrame with custom oscillator
        """
        # Extract price series if DataFrame
        if isinstance(prices, pd.DataFrame):
            if price_column is None:
                raise ValueError("price_column must be specified when prices is a DataFrame")
            price_series = prices[price_column]
        else:
            price_series = prices
        
        # Calculate short and long moving averages
        short_ma = price_series.rolling(window=window_short).mean()
        long_ma = price_series.rolling(window=window_long).mean()
        
        # Calculate oscillator (percent difference between short and long MA)
        oscillator = ((short_ma - long_ma) / long_ma) * 100
        
        # Create result DataFrame
        result = pd.DataFrame(index=price_series.index)
        result['custom_oscillator'] = oscillator
        
        # Add overbought/oversold threshold columns
        result['oscillator_overbought'] = 5.0  # 5% above long MA is overbought
        result['oscillator_oversold'] = -5.0   # 5% below long MA is oversold
        
        return result 