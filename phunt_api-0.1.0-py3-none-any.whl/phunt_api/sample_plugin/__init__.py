"""
Sample Plugin

This is a sample plugin that demonstrates how to create a plugin for the PHunt API.
"""

from .plugin import SampleFeaturePlugin

__all__ = [
    'SampleFeaturePlugin',
] 