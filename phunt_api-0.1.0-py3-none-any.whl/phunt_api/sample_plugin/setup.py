"""
Sample Plugin Setup

This file demonstrates how to configure a plugin package for distribution.
"""

from setuptools import setup, find_packages

setup(
    name="phunt-sample-plugin",
    version="0.1.0",
    description="A sample feature plugin for the PHunt API",
    author="PHunt Team",
    author_email="info@phunt.io",
    url="https://github.com/phunt-io/phunt-sample-plugin",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
    ],
    # エントリーポイントの設定 - 重要
    entry_points={
        "phunt.feature_plugins": [
            "sample_feature_plugin = phunt_sample_plugin.plugin:SampleFeaturePlugin",
        ],
    },
) 