# -*- coding: utf-8 -*-


def create_model(api, mlflow):
    import pandas as pd
    import numpy as np
    import optuna
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import mean_squared_error
    
    mlflow.autolog(log_input_examples=True)  # 自動ログ取得の拡張
    
    # データの取得
    api.set_validation_year(None)
    y = api.get_target('USDJPY_1MIN_RETURN')
    X = api.get_feature('USDJPY_1MIN_MOMENTUM')
    # 年の抽出
    years = api.get_years(X)[0:2]
    
    feature_names = ['momentum_1d', 'momentum_5d']
    target_names = ['next_day_return']
    
    def objective(trial):
        # ハイパーパラメータの定義
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 300),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 4)
        }
        
        scores = []
        pred_df = pd.DataFrame()
        
        # 年次バリデーション
        with mlflow.start_run(nested=True) as child_run:
            trial.set_user_attr('mlflow.run_id', child_run.info.run_id)
            models = []
            for val_year in years:
                try:  
                    api.set_validation_year(val_year)
                    # Train and validation data extraction
                    y_train, y_val = api.get_target('USDJPY_1MIN_RETURN')
                    X_train, X_val = api.get_feature('USDJPY_1MIN_MOMENTUM')

                    # Inner join, merge, filter timestamp which is in both X and y
                    X_train, y_train = api.join_and_drop(X_train, y_train)
                    X_val, y_val = api.join_and_drop(X_val, y_val)

                    # Print data shape and head
                    print(X_train.shape, y_train.shape)
                    print(X_train.head())
                    print(y_train.head())

                    # モデルの学習
                    model = RandomForestRegressor(**params)
                    model.fit(X_train[feature_names], y_train[target_names].values[:,0])
                    
                    # モデルの評価
                    pred = model.predict(X_val[feature_names])
                    score = mean_squared_error(y_val[target_names].values[:,0], pred)
                    scores.append(score)
                    models.append(model)

                    # 各年のメトリクスをログ
                    mlflow.log_metric(f"mse_{val_year}", score)
                    mlflow.sklearn.log_model(model, f"model_{val_year}")
                    
                    # df = pd.DataFrame({'pred': pred, 'actual': y_val[target_names].values[:,0]})
                    # df.set_index(X_val.index, inplace=True)
                    # pred_df = pd.concat([pred_df, df]) 
                except Exception as e:
                    print(f"Error in year {val_year}: {e}")
        
            avg_score = np.mean(scores)
            mlflow.log_metric("mean_mse_score", avg_score)
            mlflow.log_params(params)
            if avg_score < 0.001 or np.isnan(avg_score):
                avg_score = 0.001
        return avg_score
    
    # Optunaによる最適化
    with mlflow.start_run() as run:
        study = optuna.create_study(direction='minimize')
        study.optimize(objective, n_trials=3)
        
        # 最適なパラメータでの最終モデル
        best_params = study.best_params
        child_run_id = study.best_trial.user_attrs['mlflow.runId']
        final_models = {year: mlflow.sklearn.load_model(f"runs:/{child_run_id}/model_{year}") for year in years}        
        
        # 最終モデルでの予測
        pred_df = pd.DataFrame()
        for year in years:
            api.set_validation_year(year)
            model = final_models[year]
            feature_names = model.feature_names_in_
            y_train, y_val = api.get_target('USDJPY_1MIN_RETURN')
            X_train, X_val = api.get_feature('USDJPY_1MIN_MOMENTUM')
            # MUST be called before predict to get the same timestamp order
            X_val, y_val = api.join_and_drop(X_val, y_val)
            pred = model.predict(X_val[feature_names])
            df = pd.DataFrame({'pred': pred, 'actual': y_val[target_names].values[:,0]})
            df.set_index(X_val.index, inplace=True)
            pred_df = pd.concat([pred_df, df])
        
        pred_df.sort_index(inplace=True)
        pred_df['timestamp'] = pred_df.index
        
        return final_models, pred_df


def create_model_original(api, mlflow):
    from sklearn.ensemble import RandomForestRegressor
    params = {}
    y_train, y_val = api.get_target('USDJPY_1MIN_RETURN')
    X_train, X_val = api.get_feature('USDJPY_1MIN_MOMENTUM')
    model = RandomForestRegressor(**params)
    model.fit(X_train[['momentum_1d', 'momentum_5d']], y_train['next_day_return'])
    return model

