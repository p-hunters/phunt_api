"""
Target Plugin Registry

This module provides the target plugin registry system
to discover and manage target calculation plugins.
"""

import logging
import importlib
from typing import Dict, Any, List, Optional, Callable, Union

from .plugin_base import PluginBase, PHUNT_API_VERSION
import pandas as pd

logger = logging.getLogger(__name__)


class TargetPluginBase(PluginBase):
    """
    Base class for all target plugins
    
    All target calculation plugins must inherit from this class.
    """
    
    # Plugin information should be overridden by subclasses
    PLUGIN_INFO = {
        'name': 'target_base_plugin',
        'version': '0.0.0',
        'description': 'Base target plugin class, not meant to be used directly',
        'author': 'PHunt Team',
        'backends': ['pandas'],  # サポートするバックエンド
        'plugin_type': 'target',  # プラグインタイプを'target'に指定
        'tags': [],  # カテゴリタグ
        'compatibility': {  # 互換性情報
            'phunt_api_version': '>=0.7.0',  # 必要なPHunt APIバージョン
            'python_version': '>=3.7.0',  # 必要なPythonバージョン
        }
    }
    
    def calculate_target(self, data: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """
        ターゲット値を計算する基本メソッド
        
        Args:
            data: 入力データ
            **kwargs: 追加のパラメータ
            
        Returns:
            計算されたターゲット値を含むDataFrame
        """
        raise NotImplementedError("サブクラスでcalculate_targetを実装する必要があります")


class TargetPluginRegistry:
    """
    Target Plugin Registry
    
    Manages target plugin discovery and registration.
    """
    
    def __init__(self):
        """
        Initialize the target plugin registry
        """
        self._plugins = {}  # name -> plugin instance
        self._plugin_entry_points = []  # List of plugin entry points (for discovery)
        self._version_conflicts = {}  # name -> [version1, version2, ...]
    
    def discover_plugins(self):
        """
        Discover target plugins from entry points
        
        Searches for plugins registered under the 'phunt.target_plugins' entry point.
        """
        try:
            # Try to import entry_points from importlib.metadata (Python 3.8+)
            try:
                logger.info("Attempting to use importlib.metadata for entry point discovery")
                from importlib.metadata import entry_points
                has_entry_points = True
            except ImportError:
                # Fall back to pkg_resources for Python < 3.8
                logger.info("importlib.metadata not available, falling back to pkg_resources")
                import pkg_resources
                has_entry_points = False
            
            # Clear existing plugins
            self._plugins = {}
            self._version_conflicts = {}
            
            # Discover entry points
            if has_entry_points:
                # Python 3.8+ implementation
                logger.info("Searching for entry points in group 'phunt.target_plugins'")
                try:
                    # Python 3.10+ implementation
                    eps = entry_points(group='phunt.target_plugins')
                    logger.info(f"Found {len(list(eps))} entry points")
                    for ep in eps:
                        logger.info(f"Processing entry point: {ep.name}")
                        self._register_entry_point(ep.name, ep.load)
                except TypeError:
                    # Python 3.8-3.9 implementation
                    eps = entry_points()
                    plugin_eps = eps.get('phunt.target_plugins', [])
                    logger.info(f"Found {len(plugin_eps)} entry points")
                    for ep in plugin_eps:
                        logger.info(f"Processing entry point: {ep.name}")
                        self._register_entry_point(ep.name, ep.load)
            else:
                # Python < 3.8 implementation using pkg_resources
                logger.info("Using pkg_resources to find entry points")
                for ep in pkg_resources.iter_entry_points('phunt.target_plugins'):
                    logger.info(f"Processing entry point: {ep.name}")
                    self._register_entry_point(ep.name, ep.load)
            
            return list(self._plugins.values())
        except Exception as e:
            logger.error(f"Error discovering plugins: {e}")
            return []
    
    def _register_entry_point(self, plugin_name: str, load_func: Callable) -> None:
        """
        Register a plugin from an entry point
        
        Args:
            plugin_name: Name of the plugin
            load_func: Function to load the plugin class
        """
        try:
            logger.info(f"Loading plugin class for {plugin_name}")
            plugin_class = load_func()
            
            if not issubclass(plugin_class, TargetPluginBase):
                logger.warning(f"Plugin {plugin_name} does not inherit from TargetPluginBase, skipping")
                return
            
            logger.info(f"Instantiating plugin {plugin_name}")
            plugin_instance = plugin_class()
            
            success = self.register_plugin(plugin_instance)
            if success:
                logger.info(f"Registered plugin: {plugin_name} (version {plugin_instance.PLUGIN_INFO['version']})")
            else:
                logger.warning(f"Failed to register plugin: {plugin_name}")
        except Exception as e:
            logger.error(f"Error registering plugin {plugin_name}: {e}")
    
    def register_plugin(self, plugin_instance: TargetPluginBase) -> bool:
        """
        Register a target plugin
        
        Args:
            plugin_instance: Instance of TargetPluginBase
            
        Returns:
            True if registered successfully, False otherwise
        """
        try:
            # Validate plugin type
            if plugin_instance.PLUGIN_INFO.get('plugin_type') != 'target':
                logger.warning(f"Plugin {plugin_instance.PLUGIN_INFO['name']} is not a target plugin")
                return False
            
            plugin_name = plugin_instance.PLUGIN_INFO['name']
            plugin_version = plugin_instance.PLUGIN_INFO['version']
            
            # Check for version conflicts
            if plugin_name in self._plugins:
                existing_version = self._plugins[plugin_name].PLUGIN_INFO['version']
                
                # If versions match, keep the existing one
                if existing_version == plugin_version:
                    logger.info(f"Plugin {plugin_name} v{plugin_version} already registered")
                    return True
                
                # Version conflict - keep the higher version
                from packaging import version as pkg_version
                if pkg_version.parse(existing_version) >= pkg_version.parse(plugin_version):
                    logger.warning(
                        f"Version conflict for plugin {plugin_name}: "
                        f"keeping v{existing_version} over v{plugin_version}"
                    )
                    
                    # Track conflict
                    if plugin_name not in self._version_conflicts:
                        self._version_conflicts[plugin_name] = [existing_version]
                    
                    if plugin_version not in self._version_conflicts[plugin_name]:
                        self._version_conflicts[plugin_name].append(plugin_version)
                    
                    return False
                else:
                    logger.warning(
                        f"Version conflict for plugin {plugin_name}: "
                        f"replacing v{existing_version} with v{plugin_version}"
                    )
                    
                    # Track conflict
                    if plugin_name not in self._version_conflicts:
                        self._version_conflicts[plugin_name] = [existing_version]
                    
                    if plugin_version not in self._version_conflicts[plugin_name]:
                        self._version_conflicts[plugin_name].append(plugin_version)
            
            # Register the plugin
            self._plugins[plugin_name] = plugin_instance
            return True
        except Exception as e:
            logger.error(f"Error registering plugin: {e}")
            return False
    
    def get_plugin(self, plugin_name: str) -> Optional[TargetPluginBase]:
        """
        Get a target plugin by name
        
        Args:
            plugin_name: Name of the plugin
            
        Returns:
            Plugin instance if found, None otherwise
        """
        return self._plugins.get(plugin_name)
    
    def list_plugins(self) -> List[Dict[str, Any]]:
        """
        List all registered target plugins
        
        Returns:
            List of plugin information dictionaries
        """
        return [
            {
                "name": plugin.PLUGIN_INFO['name'],
                "version": plugin.PLUGIN_INFO['version'],
                "description": plugin.PLUGIN_INFO.get('description', ''),
                "author": plugin.PLUGIN_INFO.get('author', ''),
                "tags": plugin.PLUGIN_INFO.get('tags', []),
                "info": plugin.PLUGIN_INFO
            }
            for plugin in self._plugins.values()
        ]
    
    def get_plugin_functions(self, plugin_name: str) -> List[str]:
        """
        Get the available functions for a target plugin
        
        Args:
            plugin_name: Name of the plugin
            
        Returns:
            List of function names
        """
        plugin = self.get_plugin(plugin_name)
        if not plugin:
            return []
        
        return plugin.get_plugin_functions()
    
    def get_plugin_function(self, plugin_name: str, function_name: str) -> Optional[Callable]:
        """
        Get a specific function from a target plugin
        
        Args:
            plugin_name: Name of the plugin
            function_name: Name of the function
            
        Returns:
            Function if found, None otherwise
        """
        plugin = self.get_plugin(plugin_name)
        if not plugin:
            return None
        
        # フィルタリングせずに、すべての関数を取得
        func = getattr(plugin, function_name, None)
        if not func or not callable(func):
            return None
            
        return func
    
    def get_plugin_version_conflicts(self) -> Dict[str, List[str]]:
        """
        Get information about plugin version conflicts
        
        Returns:
            Dictionary of plugin name to list of conflicting versions
        """
        return self._version_conflicts.copy() 