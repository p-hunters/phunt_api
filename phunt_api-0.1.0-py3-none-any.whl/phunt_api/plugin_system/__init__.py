"""
Plugin System Package

This package provides the plugin system for PHunt API.
"""

from phunt_api.plugin_system.registry import FeaturePluginBase, FeaturePluginRegistry
from phunt_api.plugin_system.catalog import PluginCatalog
from phunt_api.plugin_system.doc_generator import PluginDocGenerator
from phunt_api.plugin_system.sample_plugin import SampleFeaturePlugin

__all__ = [
    'FeaturePluginBase',
    'FeaturePluginRegistry',
    'PluginCatalog',
    'PluginDocGenerator',
    'SampleFeaturePlugin',
] 