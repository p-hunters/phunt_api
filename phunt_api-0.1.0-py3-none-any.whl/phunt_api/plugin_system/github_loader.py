"""
GitHub Plugin Loader

This module provides functionality to load feature calculation plugins from GitHub repositories.
"""

import os
import sys
import tempfile
import subprocess
import logging
import re
import shutil
from typing import Optional, List, Dict, Any
import importlib

logger = logging.getLogger(__name__)

class GitHubPluginLoader:
    """
    GitHubで公開されているプラグインをロードするためのユーティリティクラス
    """
    
    def __init__(self, plugin_cache_dir: Optional[str] = None):
        """
        初期化
        
        Args:
            plugin_cache_dir: プラグインのキャッシュディレクトリ。Noneの場合は一時ディレクトリを使用
        """
        # キャッシュディレクトリの設定
        if plugin_cache_dir:
            self.plugin_cache_dir = plugin_cache_dir
            os.makedirs(plugin_cache_dir, exist_ok=True)
        else:
            # ユーザーのホームディレクトリ内にプラグインキャッシュディレクトリを作成
            home_dir = os.path.expanduser("~")
            self.plugin_cache_dir = os.path.join(home_dir, '.phunt', 'plugins')
            os.makedirs(self.plugin_cache_dir, exist_ok=True)
        
        logger.info(f"プラグインキャッシュディレクトリ: {self.plugin_cache_dir}")
    
    def install_from_github(self, repo_url: str, branch: str = 'main', force_update: bool = False) -> bool:
        """
        GitHubリポジトリからプラグインをインストール
        
        Args:
            repo_url: GitHubリポジトリのURL（https://github.com/user/repo 形式）
            branch: ブランチ名またはタグ名
            force_update: Trueの場合、既にインストールされていても強制的に更新
        
        Returns:
            インストールが成功したかどうか
        """
        # リポジトリURLからユーザー名とリポジトリ名を抽出
        match = re.match(r'https://github.com/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"無効なGitHubリポジトリURL: {repo_url}")
            return False
        
        username, repo_name = match.groups()
        plugin_id = f"{username}_{repo_name}"
        plugin_dir = os.path.join(self.plugin_cache_dir, plugin_id)
        
        # すでにインストールされているかチェック
        if os.path.exists(plugin_dir) and not force_update:
            logger.info(f"プラグイン {plugin_id} は既にインストールされています")
            return True
        
        # 既存のディレクトリを削除（更新の場合）
        if os.path.exists(plugin_dir):
            logger.info(f"既存のプラグインディレクトリを削除: {plugin_dir}")
            shutil.rmtree(plugin_dir)
        
        try:
            # GitリポジトリをクローンまたはPythonパッケージとしてインストール
            logger.info(f"GitHubリポジトリからプラグインをインストール: {repo_url}")
            
            # まずcloneを試みる
            result = self._clone_and_install(repo_url, branch, plugin_dir)
            if not result:
                # cloneに失敗した場合はpip installを試みる
                result = self._pip_install_from_github(repo_url, branch)
            
            return result
            
        except Exception as e:
            logger.error(f"プラグインのインストール中にエラーが発生: {str(e)}")
            # クリーンアップ - 部分的にインストールされたディレクトリを削除
            if os.path.exists(plugin_dir):
                shutil.rmtree(plugin_dir)
            return False
    
    def _clone_and_install(self, repo_url: str, branch: str, plugin_dir: str) -> bool:
        """
        Gitリポジトリをクローンして、ローカルでインストール
        
        Args:
            repo_url: GitHubリポジトリのURL
            branch: ブランチ名またはタグ名
            plugin_dir: クローン先ディレクトリパス
            
        Returns:
            成功したかどうか
        """
        try:
            # Gitリポジトリをクローン
            subprocess.run([
                'git', 'clone', '--branch', branch, '--single-branch', '--depth', '1',
                repo_url, plugin_dir
            ], check=True, capture_output=True)
            
            # setup.pyファイルが存在するか確認
            setup_py_path = os.path.join(plugin_dir, 'setup.py')
            if not os.path.exists(setup_py_path):
                logger.error(f"setup.pyファイルが見つかりません: {setup_py_path}")
                return False
            
            # プラグインをインストール (開発モード)
            subprocess.run([
                sys.executable, '-m', 'pip', 'install', '-e', plugin_dir
            ], check=True, capture_output=True)
            
            logger.info(f"プラグインを正常にインストールしました: {plugin_dir}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"プラグインのインストール中にコマンドエラーが発生: {e.stderr.decode('utf-8')}")
            return False
        except Exception as e:
            logger.error(f"プラグインのインストール中に予期せぬエラーが発生: {str(e)}")
            return False
    
    def _pip_install_from_github(self, repo_url: str, branch: str) -> bool:
        """
        pipを使ってGitHubから直接インストール
        
        Args:
            repo_url: GitHubリポジトリのURL
            branch: ブランチ名またはタグ名
            
        Returns:
            成功したかどうか
        """
        try:
            # GitHubからpipでインストール
            pip_url = f"git+{repo_url}.git@{branch}"
            subprocess.run([
                sys.executable, '-m', 'pip', 'install', pip_url
            ], check=True, capture_output=True)
            
            logger.info(f"プラグインをpipで正常にインストールしました: {pip_url}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"pipインストール中にエラーが発生: {e.stderr.decode('utf-8')}")
            return False
        except Exception as e:
            logger.error(f"pipインストール中に予期せぬエラーが発生: {str(e)}")
            return False
    
    def list_installed_plugins(self) -> List[Dict[str, str]]:
        """
        インストール済みのGitHubプラグインを一覧表示
        
        Returns:
            インストール済みプラグインの情報リスト
        """
        installed_plugins = []
        
        # キャッシュディレクトリ内のプラグインをスキャン
        if os.path.exists(self.plugin_cache_dir):
            for plugin_id in os.listdir(self.plugin_cache_dir):
                plugin_dir = os.path.join(self.plugin_cache_dir, plugin_id)
                if os.path.isdir(plugin_dir):
                    # ユーザー名とリポジトリ名を抽出
                    parts = plugin_id.split('_', 1)
                    if len(parts) == 2:
                        username, repo_name = parts
                        repo_url = f"https://github.com/{username}/{repo_name}"
                        
                        # バージョン情報を取得（存在する場合）
                        version = self._get_plugin_version(plugin_dir)
                        
                        installed_plugins.append({
                            'id': plugin_id,
                            'repo_url': repo_url,
                            'username': username,
                            'repo_name': repo_name,
                            'version': version,
                            'path': plugin_dir
                        })
        
        return installed_plugins
    
    def _get_plugin_version(self, plugin_dir: str) -> Optional[str]:
        """
        プラグインのバージョン情報を取得
        
        Args:
            plugin_dir: プラグインディレクトリのパス
            
        Returns:
            バージョン情報（見つからない場合はNone）
        """
        # setup.pyからバージョンを抽出を試みる
        setup_py_path = os.path.join(plugin_dir, 'setup.py')
        if os.path.exists(setup_py_path):
            try:
                with open(setup_py_path, 'r') as f:
                    content = f.read()
                    match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        return match.group(1)
            except Exception:
                pass
        
        return None
    
    def uninstall_plugin(self, plugin_id: str) -> bool:
        """
        プラグインをアンインストール
        
        Args:
            plugin_id: プラグインID（username_repo_name形式）
            
        Returns:
            アンインストールが成功したかどうか
        """
        plugin_dir = os.path.join(self.plugin_cache_dir, plugin_id)
        
        if not os.path.exists(plugin_dir):
            logger.error(f"プラグイン {plugin_id} は見つかりません")
            return False
        
        try:
            # プラグインのパッケージ名を特定
            setup_py_path = os.path.join(plugin_dir, 'setup.py')
            package_name = None
            
            if os.path.exists(setup_py_path):
                try:
                    with open(setup_py_path, 'r') as f:
                        content = f.read()
                        match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
                        if match:
                            package_name = match.group(1)
                except Exception:
                    pass
            
            # pipからアンインストール
            if package_name:
                subprocess.run([
                    sys.executable, '-m', 'pip', 'uninstall', '-y', package_name
                ], check=True, capture_output=True)
            
            # ディレクトリを削除
            shutil.rmtree(plugin_dir)
            
            logger.info(f"プラグイン {plugin_id} をアンインストールしました")
            return True
            
        except Exception as e:
            logger.error(f"プラグインのアンインストール中にエラーが発生: {str(e)}")
            return False 