"""
Plugin Base Classes

This module provides base classes for all plugins in the PHunt API.
"""

import logging
import inspect
from typing import Dict, Any, List, Optional

# PHunt API version
PHUNT_API_VERSION = "0.7.0"

logger = logging.getLogger(__name__)


class PluginBase:
    """
    Base class for all plugins
    
    All plugins must inherit from this class or its subclasses.
    """
    
    # Plugin information should be overridden by subclasses
    PLUGIN_INFO = {
        'name': 'plugin_base',
        'version': '0.0.0',
        'description': 'Base plugin class, not meant to be used directly',
        'author': 'PHunt Team',
        'backends': ['pandas'],  # Supported backends
        'plugin_type': 'base',  # Plugin type (feature, target, etc.)
        'tags': [],  # Category tags
        'compatibility': {  # Compatibility information
            'phunt_api_version': '>=0.7.0',  # Required PHunt API version
            'python_version': '>=3.7.0',  # Required Python version
        }
    }
    
    def __init__(self):
        """
        Initialize the plugin
        
        Validates plugin information.
        """
        self._validate_plugin_info()
    
    def _validate_plugin_info(self):
        """
        Validate plugin information
        
        Checks for required fields, valid values, and compatibility.
        """
        # Check required fields
        required_fields = ['name', 'version', 'description', 'author', 'backends', 'plugin_type']
        for field in required_fields:
            if field not in self.PLUGIN_INFO:
                raise ValueError(f"Missing required field '{field}' in plugin information")
        
        # Check backends
        valid_backends = ['pandas', 'polars', 'numpy', 'custom']
        for backend in self.PLUGIN_INFO['backends']:
            if backend not in valid_backends:
                raise ValueError(f"Invalid backend '{backend}'. Valid backends are: {valid_backends}")
        
        # Check version format
        if not self._is_valid_version(self.PLUGIN_INFO['version']):
            raise ValueError(f"Invalid version format: {self.PLUGIN_INFO['version']}")
        
        # Check compatibility
        if 'compatibility' in self.PLUGIN_INFO:
            self._check_compatibility()
    
    def _is_valid_version(self, version: str) -> bool:
        """
        Check if the version string is valid
        
        Args:
            version: Version string
            
        Returns:
            True if valid, False otherwise
        """
        import re
        pattern = r'^\d+\.\d+\.\d+(-[a-zA-Z0-9]+)?$'
        return bool(re.match(pattern, version))
    
    def _check_compatibility(self):
        """
        Check compatibility with PHunt API and Python versions
        """
        compatibility = self.PLUGIN_INFO['compatibility']
        
        # Check PHunt API version
        if 'phunt_api_version' in compatibility:
            requirement = compatibility['phunt_api_version']
            if not self._is_compatible_version(PHUNT_API_VERSION, requirement):
                logger.warning(
                    f"Plugin {self.PLUGIN_INFO['name']} may not be compatible with current PHunt API version. "
                    f"Required: {requirement}, Current: {PHUNT_API_VERSION}"
                )
        
        # Check Python version
        if 'python_version' in compatibility:
            import sys
            python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            requirement = compatibility['python_version']
            if not self._is_compatible_version(python_version, requirement):
                logger.warning(
                    f"Plugin {self.PLUGIN_INFO['name']} may not be compatible with current Python version. "
                    f"Required: {requirement}, Current: {python_version}"
                )
    
    def _is_compatible_version(self, current_version: str, requirement: str) -> bool:
        """
        Check if the current version meets the requirement
        
        Args:
            current_version: Current version string
            requirement: Version requirement (e.g. '>=1.0.0', '==1.2.0', etc.)
            
        Returns:
            True if compatible, False otherwise
        """
        from packaging import version as pkg_version
        import re
        
        # Parse requirement (e.g. '>=1.0.0', '==1.2.0', etc.)
        pattern = r'^([<>=!]=?|~=)(.+)$'
        match = re.match(pattern, requirement)
        
        if not match:
            # Default to exact match if no operator is specified
            operator = '=='
            version_str = requirement
        else:
            operator = match.group(1)
            version_str = match.group(2)
        
        # Parse versions
        current = pkg_version.parse(current_version)
        required = pkg_version.parse(version_str)
        
        # Check compatibility based on operator
        if operator == '==':
            return current == required
        elif operator == '!=':
            return current != required
        elif operator == '>':
            return current > required
        elif operator == '>=':
            return current >= required
        elif operator == '<':
            return current < required
        elif operator == '<=':
            return current <= required
        elif operator == '~=':  # PEP 440 compatible release
            # ~=1.2.3 is equivalent to >=1.2.3,<1.3.0
            major, minor, *rest = str(required).split('.')
            upper_bound = f"{major}.{int(minor) + 1}.0"
            return current >= required and current < pkg_version.parse(upper_bound)
        else:
            # Unknown operator, assume incompatible
            return False
    
    def get_plugin_functions(self) -> List[str]:
        """
        Get the list of available functions in this plugin
        
        Returns:
            List of function names
        """
        # Get all methods defined in this class
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        
        # Filter out private methods (starting with _)
        functions = [name for name, _ in methods if not name.startswith('_')]
        
        return functions 