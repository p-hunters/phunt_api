"""
Plugin Documentation Generator

This module provides functionality to generate documentation for plugins.
"""

import os
import inspect
import logging
from typing import Dict, Any, List, Optional, Callable, Type, Union
import datetime
import re
import json
from pathlib import Path

from phunt_api.plugin_system.registry import FeaturePluginBase, FeaturePluginRegistry

logger = logging.getLogger(__name__)

class PluginDocGenerator:
    """
    プラグインのドキュメントを自動生成するクラス
    
    プラグインのPLUGIN_INFO情報とdocstringsからドキュメントを生成します。
    """
    
    def __init__(self, registry: FeaturePluginRegistry, output_dir: str = None):
        """
        初期化
        
        Args:
            registry: プラグインレジストリ
            output_dir: ドキュメント出力ディレクトリ（指定しない場合はカレントディレクトリ）
        """
        self.registry = registry
        self.output_dir = output_dir or os.path.join(os.path.expanduser("~"), ".phunt", "docs")
        
        # 出力ディレクトリが存在しない場合は作成
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_all_docs(self) -> List[str]:
        """
        すべてのプラグインのドキュメントを生成
        
        Returns:
            生成したドキュメントファイルのパスのリスト
        """
        logger.info(f"Generating documentation for all plugins...")
        
        # プラグイン一覧を取得
        plugins = self.registry.list_plugins()
        
        # 各プラグインのドキュメントを生成
        generated_files = []
        for plugin_info in plugins:
            plugin_name = plugin_info['name']
            try:
                doc_path = self.generate_plugin_doc(plugin_name)
                if doc_path:
                    generated_files.append(doc_path)
            except Exception as e:
                logger.error(f"Error generating documentation for plugin '{plugin_name}': {str(e)}")
        
        # インデックスファイルを生成
        if generated_files:
            index_path = self._generate_index(plugins)
            if index_path:
                generated_files.append(index_path)
        
        return generated_files
    
    def generate_plugin_doc(self, plugin_name: str) -> Optional[str]:
        """
        指定したプラグインのドキュメントを生成
        
        Args:
            plugin_name: プラグイン名
            
        Returns:
            生成したドキュメントファイルのパス、または生成に失敗した場合はNone
        """
        logger.info(f"Generating documentation for plugin '{plugin_name}'...")
        
        # プラグインを取得
        plugin = self.registry.get_plugin(plugin_name)
        if not plugin:
            logger.warning(f"Plugin '{plugin_name}' not found")
            return None
        
        # プラグイン情報を取得
        plugin_info = plugin.PLUGIN_INFO
        
        # プラグイン関数一覧を取得
        functions = self.registry.get_plugin_functions(plugin_name)
        
        # ドキュメントを生成
        doc_content = self._generate_plugin_markdown(plugin, plugin_info, functions)
        
        # ファイルに保存
        file_name = f"{plugin_name}.md"
        file_path = os.path.join(self.output_dir, file_name)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(doc_content)
        
        logger.info(f"Documentation for plugin '{plugin_name}' saved to {file_path}")
        return file_path
    
    def _generate_plugin_markdown(self, plugin: FeaturePluginBase, 
                                 plugin_info: Dict[str, Any], 
                                 functions: List[str]) -> str:
        """
        プラグインのMarkdownドキュメントを生成
        
        Args:
            plugin: プラグインインスタンス
            plugin_info: プラグイン情報
            functions: プラグイン関数一覧
            
        Returns:
            生成したMarkdownドキュメント
        """
        # プラグインのクラスdocstring
        plugin_doc = inspect.getdoc(plugin.__class__) or "No description available."
        
        # 現在の日時
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # ヘッダー
        content = [
            f"# {plugin_info['name']} v{plugin_info['version']}",
            "",
            f"*{plugin_info['description']}*",
            "",
            f"**Author:** {plugin_info['author']}",
            "",
            f"**Generated:** {now}",
            "",
            "## Overview",
            "",
            plugin_doc,
            "",
            "## Plugin Information",
            "",
            "| Property | Value |",
            "| --- | --- |",
            f"| Name | {plugin_info['name']} |",
            f"| Version | {plugin_info['version']} |",
            f"| Description | {plugin_info['description']} |",
            f"| Author | {plugin_info['author']} |",
            f"| Backends | {', '.join(plugin_info['backends'])} |",
            f"| Tags | {', '.join(plugin_info['tags'])} |",
        ]
        
        # 互換性情報
        compatibility = plugin_info.get('compatibility', {})
        if compatibility:
            content.extend([
                "",
                "### Compatibility",
                "",
                "| Requirement | Value |",
                "| --- | --- |",
            ])
            
            for req, value in compatibility.items():
                content.append(f"| {req} | {value} |")
        
        # 関数一覧
        if functions:
            content.extend([
                "",
                "## Functions",
                "",
            ])
            
            for func_name in functions:
                content.extend(self._generate_function_doc(plugin, func_name))
        
        # 使用例
        content.extend([
            "",
            "## Usage Example",
            "",
            "```python",
            f"from phunt_api import PHuntAPI",
            "",
            f"# Initialize PHunt API",
            f"api = PHuntAPI()",
            "",
        ])
        
        # 最初の関数を使用例として使用
        if functions:
            first_func = functions[0]
            func = getattr(plugin, first_func)
            sig = inspect.signature(func)
            
            # 引数の例を生成
            args_example = []
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                if param_name == 'data':
                    args_example.append("data=df")
                else:
                    # デフォルト値があれば使用
                    if param.default is not inspect.Parameter.empty:
                        args_example.append(f"{param_name}={repr(param.default)}")
                    else:
                        # 型ヒントから適切な値を推測
                        if param.annotation is not inspect.Parameter.empty:
                            if param.annotation == int:
                                args_example.append(f"{param_name}=10")
                            elif param.annotation == float:
                                args_example.append(f"{param_name}=0.5")
                            elif param.annotation == str:
                                args_example.append(f"{param_name}='value'")
                            elif param.annotation == bool:
                                args_example.append(f"{param_name}=True")
                            else:
                                args_example.append(f"{param_name}=...")
                        else:
                            args_example.append(f"{param_name}=...")
            
            args_str = ", ".join(args_example)
            
            content.extend([
                f"# サンプルデータの準備",
                f"import pandas as pd",
                f"import numpy as np",
                f"",
                f"# サンプルデータを作成",
                f"dates = pd.date_range('2023-01-01', periods=10)",
                f"df = pd.DataFrame({{'close': np.random.randn(10).cumsum() + 100}})",
                f"df.index = dates",
                f"",
                f"# プラグイン関数を使用して特徴量を計算",
                f"result = api.calculate_plugin_feature(",
                f"    plugin_name='{plugin_info['name']}',",
                f"    function_name='{first_func}',",
                f"    {args_str}",
                f")",
                f"",
                f"# 結果を表示",
                f"print(result)",
                f"",
                f"# 特徴量として登録",
                f"feature_id = api.register_plugin_feature(",
                f"    feature_name='my_{first_func}',",
                f"    plugin_name='{plugin_info['name']}',",
                f"    function_name='{first_func}',",
                f"    {args_str}",
                f")",
                f"print(f'Registered feature ID: {{feature_id}}')",
            ])
        
        content.append("```")
        
        return "\n".join(content)
    
    def _generate_function_doc(self, plugin: FeaturePluginBase, func_name: str) -> List[str]:
        """
        プラグイン関数のドキュメントを生成
        
        Args:
            plugin: プラグインインスタンス
            func_name: 関数名
            
        Returns:
            生成したMarkdownドキュメント行のリスト
        """
        func = getattr(plugin, func_name)
        
        # 関数のdocstring
        func_doc = inspect.getdoc(func) or "No description available."
        
        # 関数のシグネチャ
        sig = inspect.signature(func)
        
        # パラメータ情報を抽出
        params = []
        for param_name, param in sig.parameters.items():
            if param_name == 'self':
                continue
                
            # デフォルト値
            default = ""
            if param.default is not inspect.Parameter.empty:
                default = f" (default: {repr(param.default)})"
            
            # 型ヒント
            type_hint = ""
            if param.annotation is not inspect.Parameter.empty:
                type_hint = f" ({param.annotation.__name__})"
            
            params.append(f"- `{param_name}`{type_hint}{default}")
        
        # 戻り値の型ヒント
        return_type = ""
        if sig.return_annotation is not inspect.Parameter.empty and sig.return_annotation is not None:
            if hasattr(sig.return_annotation, "__name__"):
                return_type = f" -> {sig.return_annotation.__name__}"
            else:
                return_type = f" -> {str(sig.return_annotation)}"
        
        # docstringからパラメータと戻り値の説明を抽出
        param_desc = {}
        return_desc = ""
        
        # docstringをパースしてパラメータと戻り値の説明を抽出
        if func_doc:
            # Googleスタイルのdocstring
            param_pattern = r"Args:\s*(.*?)(?:\n\s*(?:Returns|Raises|Yields|Examples|Notes|References|See Also):|$)"
            param_match = re.search(param_pattern, func_doc, re.DOTALL)
            if param_match:
                param_text = param_match.group(1)
                param_items = re.findall(r"(\w+):\s*(.*?)(?=\n\s*\w+:|$)", param_text, re.DOTALL)
                for name, desc in param_items:
                    param_desc[name] = desc.strip()
            
            # 戻り値の説明
            return_pattern = r"Returns:\s*(.*?)(?:\n\s*(?:Raises|Yields|Examples|Notes|References|See Also):|$)"
            return_match = re.search(return_pattern, func_doc, re.DOTALL)
            if return_match:
                return_desc = return_match.group(1).strip()
        
        # ドキュメント生成
        content = [
            f"### `{func_name}`{return_type}",
            "",
            func_doc,
            "",
            "**Parameters:**",
            "",
        ]
        
        if params:
            for param in params:
                content.append(param)
                
                # パラメータの説明があれば追加
                param_name = param.split('`')[1]
                if param_name in param_desc:
                    content.append(f"  - {param_desc[param_name]}")
        else:
            content.append("- None")
        
        content.extend([
            "",
            "**Returns:**",
            "",
        ])
        
        if return_desc:
            content.append(f"- {return_desc}")
        else:
            content.append("- No return value description available.")
        
        content.append("")
        return content
    
    def _generate_index(self, plugins: List[Dict[str, Any]]) -> Optional[str]:
        """
        プラグイン一覧のインデックスファイルを生成
        
        Args:
            plugins: プラグイン情報のリスト
            
        Returns:
            生成したインデックスファイルのパス、または生成に失敗した場合はNone
        """
        logger.info("Generating plugin index...")
        
        # 現在の日時
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # ヘッダー
        content = [
            "# PHunt Feature Plugins",
            "",
            f"*Generated: {now}*",
            "",
            "## Available Plugins",
            "",
            "| Plugin | Version | Description | Author | Tags |",
            "| --- | --- | --- | --- | --- |",
        ]
        
        # プラグイン一覧
        for plugin_info in plugins:
            info = plugin_info['info']
            name = info['name']
            version = info['version']
            description = info['description']
            author = info['author']
            tags = ', '.join(info['tags']) if info['tags'] else '-'
            
            content.append(f"| [{name}]({name}.md) | {version} | {description} | {author} | {tags} |")
        
        # ファイルに保存
        file_path = os.path.join(self.output_dir, "index.md")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write("\n".join(content))
        
        logger.info(f"Plugin index saved to {file_path}")
        return file_path 