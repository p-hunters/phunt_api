# -*- coding: utf-8 -*-
"""
Strategy Plugin Base Class
"""

import abc
import pandas as pd
from typing import Any, Dict, Optional
from .plugin_base import PluginBase

class StrategyPlugin(PluginBase, abc.ABC):
    """
    Base class for Strategy Plugins.
    
    Strategy plugins define trading strategies that can be trained and executed.
    """
    
    def __init__(self):
        super().__init__()
        # Ensure plugin_type is 'strategy'
        if self.PLUGIN_INFO.get('plugin_type') != 'strategy':
            raise ValueError("StrategyPlugin must have 'plugin_type' set to 'strategy'")

    @abc.abstractmethod
    def train(self, data: pd.DataFrame, **kwargs) -> Any:
        """
        Train the strategy model.
        
        Args:
            data: Training data.
            **kwargs: Additional arguments.
            
        Returns:
            Trained model object (can be anything serializable).
        """
        pass

    @abc.abstractmethod
    def predict(self, model: Any, data: pd.DataFrame, **kwargs) -> pd.Series:
        """
        Make predictions using the trained model.
        
        Args:
            model: Trained model object.
            data: Data to predict on.
            **kwargs: Additional arguments.
            
        Returns:
            Series of predictions (e.g., signals, probabilities).
        """
        pass
