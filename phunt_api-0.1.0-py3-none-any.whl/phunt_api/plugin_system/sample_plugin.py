"""
Sample Feature Plugin

This module provides a sample feature plugin for demonstration purposes.
"""

import pandas as pd
import numpy as np
from typing import Union, Optional

from phunt_api.plugin_system.registry import FeaturePluginBase

class SampleFeaturePlugin(FeaturePluginBase):
    """
    サンプル特徴量計算プラグイン
    
    このプラグインは、テクニカル指標の計算機能を提供します。
    """
    
    PLUGIN_INFO = {
        'name': 'sample_feature_plugin',
        'version': '1.0.0',
        'description': 'Sample plugin for technical indicators',
        'author': 'PHunt Team',
        'backends': ['pandas', 'polars'],
        'tags': ['sample', 'technical', 'indicator'],
        'compatibility': {
            'phunt_api_version': '>=0.5.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        Initialize the sample plugin
        """
        super().__init__()
    
    def calculate_rsi(self, data: pd.DataFrame, window: int = 14, column: str = 'close') -> pd.DataFrame:
        """
        相対力指数（RSI）を計算
        
        Args:
            data: 価格データを含むDataFrame
            window: 計算ウィンドウ（デフォルト: 14）
            column: 使用する価格カラム（デフォルト: 'close'）
            
        Returns:
            RSI値を含むDataFrame
        """
        # 価格の差分を計算
        delta = data[column].diff()
        
        # 上昇幅と下落幅を分ける
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # 平均上昇幅と平均下落幅を計算
        avg_gain = gain.rolling(window=window).mean()
        avg_loss = loss.rolling(window=window).mean()
        
        # RSIを計算
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # 結果をDataFrameとして返す
        result = pd.DataFrame(index=data.index)
        result['rsi'] = rsi
        
        return result
    
    def calculate_bollinger_bands(self, 
                                 data: pd.DataFrame, 
                                 window: int = 20, 
                                 num_std: float = 2.0,
                                 column: str = 'close') -> pd.DataFrame:
        """
        ボリンジャーバンドを計算
        
        Args:
            data: 価格データを含むDataFrame
            window: 移動平均の期間（デフォルト: 20）
            num_std: 標準偏差の倍率（デフォルト: 2.0）
            column: 使用する価格カラム（デフォルト: 'close'）
            
        Returns:
            ボリンジャーバンド（上限、中央、下限）を含むDataFrame
        """
        # 移動平均を計算
        middle_band = data[column].rolling(window=window).mean()
        
        # 標準偏差を計算
        std_dev = data[column].rolling(window=window).std()
        
        # 上限と下限を計算
        upper_band = middle_band + (std_dev * num_std)
        lower_band = middle_band - (std_dev * num_std)
        
        # 結果をDataFrameとして返す
        result = pd.DataFrame(index=data.index)
        result['bb_upper'] = upper_band
        result['bb_middle'] = middle_band
        result['bb_lower'] = lower_band
        
        return result
    
    def calculate_macd(self, 
                      data: pd.DataFrame, 
                      fast_period: int = 12, 
                      slow_period: int = 26,
                      signal_period: int = 9,
                      column: str = 'close') -> pd.DataFrame:
        """
        MACD（Moving Average Convergence Divergence）を計算
        
        Args:
            data: 価格データを含むDataFrame
            fast_period: 短期EMAの期間（デフォルト: 12）
            slow_period: 長期EMAの期間（デフォルト: 26）
            signal_period: シグナルラインの期間（デフォルト: 9）
            column: 使用する価格カラム（デフォルト: 'close'）
            
        Returns:
            MACD、シグナル、ヒストグラムを含むDataFrame
        """
        # 短期と長期のEMAを計算
        ema_fast = data[column].ewm(span=fast_period, adjust=False).mean()
        ema_slow = data[column].ewm(span=slow_period, adjust=False).mean()
        
        # MACDラインを計算
        macd_line = ema_fast - ema_slow
        
        # シグナルラインを計算
        signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
        
        # ヒストグラムを計算
        histogram = macd_line - signal_line
        
        # 結果をDataFrameとして返す
        result = pd.DataFrame(index=data.index)
        result['macd'] = macd_line
        result['macd_signal'] = signal_line
        result['macd_histogram'] = histogram
        
        return result
    
    def calculate_atr(self, 
                     data: pd.DataFrame, 
                     window: int = 14) -> pd.DataFrame:
        """
        ATR（Average True Range）を計算
        
        Args:
            data: 価格データを含むDataFrame（high, low, closeカラムが必要）
            window: 計算ウィンドウ（デフォルト: 14）
            
        Returns:
            ATR値を含むDataFrame
        """
        # 必要なカラムが存在するか確認
        required_columns = ['high', 'low', 'close']
        for col in required_columns:
            if col not in data.columns:
                raise ValueError(f"データに必要なカラム '{col}' がありません")
        
        # 前日終値
        prev_close = data['close'].shift(1)
        
        # True Rangeを計算
        tr1 = data['high'] - data['low']  # 当日高値 - 当日安値
        tr2 = (data['high'] - prev_close).abs()  # |当日高値 - 前日終値|
        tr3 = (data['low'] - prev_close).abs()  # |当日安値 - 前日終値|
        
        # 3つのうち最大値をTrue Rangeとする
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # ATRを計算（単純移動平均）
        atr = true_range.rolling(window=window).mean()
        
        # 結果をDataFrameとして返す
        result = pd.DataFrame(index=data.index)
        result['atr'] = atr
        
        return result 