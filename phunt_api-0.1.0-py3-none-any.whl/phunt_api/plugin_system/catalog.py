"""
Plugin Catalog

This module provides functionality to manage a catalog of available plugins.
"""

import os
import json
import logging
import requests
from typing import Dict, Any, List, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# カタログのデフォルトURL
DEFAULT_CATALOG_URL = "https://raw.githubusercontent.com/phunt-project/plugin-catalog/main/catalog.json"

# ローカルカタログのパス
LOCAL_CATALOG_PATH = os.path.join(os.path.dirname(__file__), "catalog_data.json")

class PluginCatalog:
    """
    プラグインカタログ
    
    利用可能なプラグインのカタログを管理します。
    """
    
    def __init__(self, cache_dir: str = None, catalog_url: str = None, use_local_catalog: bool = False):
        """
        初期化
        
        Args:
            cache_dir: キャッシュディレクトリ
            catalog_url: カタログURL
            use_local_catalog: ローカルカタログを使用するかどうか
        """
        # キャッシュディレクトリの設定
        if cache_dir is None:
            home_dir = os.path.expanduser("~")
            cache_dir = os.path.join(home_dir, ".phunt", "plugins")
        
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        # カタログURLの設定
        self.catalog_url = catalog_url or DEFAULT_CATALOG_URL
        
        # ローカルカタログを使用するかどうか
        self.use_local_catalog = use_local_catalog
        
        # カタログキャッシュファイルのパス
        self.cache_file = os.path.join(cache_dir, "catalog.json")
        
        # カタログデータ
        self.catalog_data = []
        
        # カタログを読み込む
        self._load_catalog()
    
    def _load_catalog(self):
        """
        カタログを読み込む
        """
        if self.use_local_catalog:
            # ローカルカタログを使用
            self._load_local_catalog()
        else:
            # キャッシュされたカタログを読み込む
            self._load_cached_catalog()
    
    def _load_local_catalog(self):
        """
        ローカルカタログを読み込む
        """
        try:
            if os.path.exists(LOCAL_CATALOG_PATH):
                with open(LOCAL_CATALOG_PATH, 'r', encoding='utf-8') as f:
                    self.catalog_data = json.load(f)
                logger.info(f"Loaded local catalog with {len(self.catalog_data)} plugins")
            else:
                logger.warning(f"Local catalog file not found at {LOCAL_CATALOG_PATH}")
                self.catalog_data = []
        except Exception as e:
            logger.error(f"Error loading local catalog: {str(e)}")
            self.catalog_data = []
    
    def _load_cached_catalog(self):
        """
        キャッシュされたカタログを読み込む
        """
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    self.catalog_data = json.load(f)
                logger.info(f"Loaded cached catalog with {len(self.catalog_data)} plugins")
            else:
                logger.info("Catalog cache not found, updating catalog")
                self.update_catalog()
        except Exception as e:
            logger.error(f"Error loading cached catalog: {str(e)}")
            self.catalog_data = []
    
    def update_catalog(self, force: bool = False) -> bool:
        """
        カタログを更新
        
        Args:
            force: 強制的に更新するかどうか
            
        Returns:
            更新が成功したかどうか
        """
        # ローカルカタログを使用している場合は更新しない
        if self.use_local_catalog:
            logger.info("Using local catalog, skipping update")
            return True
            
        try:
            # カタログをダウンロード
            logger.info(f"Downloading catalog from {self.catalog_url}")
            response = requests.get(self.catalog_url, timeout=10)
            response.raise_for_status()
            
            # JSONとして解析
            catalog_data = response.json()
            
            # カタログを保存
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(catalog_data, f, indent=2)
            
            # カタログデータを更新
            self.catalog_data = catalog_data
            
            logger.info(f"Updated catalog with {len(self.catalog_data)} plugins")
            return True
            
        except Exception as e:
            logger.error(f"Error updating catalog: {str(e)}")
            return False
    
    def search_plugins(self, query: str = None, tags: List[str] = None) -> List[Dict[str, Any]]:
        """
        プラグインを検索
        
        Args:
            query: 検索クエリ
            tags: 検索するタグのリスト
            
        Returns:
            プラグインのリスト
        """
        # クエリとタグが両方Noneの場合は全てのプラグインを返す
        if query is None and (tags is None or len(tags) == 0):
            return self.catalog_data
        
        # 検索結果
        results = []
        
        # クエリで検索
        if query:
            query = query.lower()
            for plugin in self.catalog_data:
                # 名前、説明、作者で検索
                if (query in plugin.get('name', '').lower() or
                    query in plugin.get('description', '').lower() or
                    query in plugin.get('author', '').lower()):
                    results.append(plugin)
        else:
            # クエリがない場合は全てのプラグインを対象にする
            results = self.catalog_data
        
        # タグでフィルタリング
        if tags and len(tags) > 0:
            filtered_results = []
            for plugin in results:
                plugin_tags = plugin.get('tags', [])
                # プラグインのタグに指定されたタグが全て含まれているかチェック
                if all(tag in plugin_tags for tag in tags):
                    filtered_results.append(plugin)
            results = filtered_results
        
        return results
    
    def get_plugin_details(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """
        プラグインの詳細情報を取得
        
        Args:
            plugin_id: プラグインID
            
        Returns:
            プラグインの詳細情報、または見つからない場合はNone
        """
        for plugin in self.catalog_data:
            if plugin.get('id') == plugin_id:
                return plugin
        return None 