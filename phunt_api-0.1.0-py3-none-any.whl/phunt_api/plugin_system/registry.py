"""
Feature Plugin Registry

This module provides the feature plugin registry system
to discover and manage plugins.
"""

import logging
import importlib
import pkgutil
import inspect
import sys
import re
import pkg_resources
from typing import Dict, Any, List, Type, Optional, Callable, Tuple, Union
from packaging import version

from .plugin_base import PluginBase, PHUNT_API_VERSION

logger = logging.getLogger(__name__)


class FeaturePluginBase(PluginBase):
    """
    Base class for feature plugins
    
    All feature plugins must inherit from this class.
    """
    
    # Plugin information should be overridden by subclasses
    PLUGIN_INFO = {
        'name': 'feature_base_plugin',
        'version': '0.0.0',
        'description': 'Base feature plugin class, not meant to be used directly',
        'author': 'PHunt Team',
        'backends': ['pandas'],  # サポートするバックエンド
        'plugin_type': 'feature',  # プラグインタイプを'feature'に指定
        'tags': [],  # カテゴリタグ
        'compatibility': {  # 互換性情報
            'phunt_api_version': '>=0.7.0',  # 必要なPHunt APIバージョン
            'python_version': '>=3.7.0',  # 必要なPythonバージョン
        }
    }


class FeaturePluginRegistry:
    """
    Feature Plugin Registry
    
    Manages feature plugin discovery and registration.
    """
    
    def __init__(self):
        """
        Initialize the plugin registry
        """
        self._plugins = {}  # name -> plugin instance
        self._plugin_entry_points = []  # List of plugin entry points (for discovery)
        self._version_conflicts = {}  # name -> [version1, version2, ...]
    
    def discover_plugins(self):
        """
        Discover plugins from entry points
        
        Searches for plugins registered under the 'phunt.feature_plugins' entry point.
        """
        try:
            # Try to import entry_points from importlib.metadata (Python 3.8+)
            try:
                logger.info("Attempting to use importlib.metadata for entry point discovery")
                from importlib.metadata import entry_points
                has_entry_points = True
            except ImportError:
                # Fall back to pkg_resources for Python < 3.8
                logger.info("importlib.metadata not available, falling back to pkg_resources")
                import pkg_resources
                has_entry_points = False
            
            # Clear existing plugins
            self._plugins = {}
            self._version_conflicts = {}
            
            # Discover entry points
            if has_entry_points:
                # Python 3.8+ implementation
                logger.info("Searching for entry points in group 'phunt.feature_plugins'")
                try:
                    # Python 3.10+ implementation
                    eps = entry_points(group='phunt.feature_plugins')
                    logger.info(f"Found {len(list(eps))} entry points")
                    for ep in eps:
                        logger.info(f"Processing entry point: {ep.name}")
                        self._register_entry_point(ep.name, ep.load)
                except TypeError:
                    # Python 3.8-3.9 implementation
                    logger.info("Using Python 3.8-3.9 entry_points API")
                    eps = entry_points()
                    if 'phunt.feature_plugins' in eps:
                        plugin_eps = eps['phunt.feature_plugins']
                        logger.info(f"Found {len(plugin_eps)} entry points")
                        for ep in plugin_eps:
                            logger.info(f"Processing entry point: {ep.name}")
                            self._register_entry_point(ep.name, ep.load)
                    else:
                        logger.info("No 'phunt.feature_plugins' entry points found")
            else:
                # Python < 3.8 implementation using pkg_resources
                logger.info("Using pkg_resources to discover entry points")
                eps = list(pkg_resources.iter_entry_points(group='phunt.feature_plugins'))
                logger.info(f"Found {len(eps)} entry points")
                for ep in eps:
                    logger.info(f"Processing entry point: {ep.name}")
                    self._register_entry_point(ep.name, ep.load)
                    
            logger.info(f"Discovered {len(self._plugins)} feature plugins")
            
            # バージョン競合の警告
            if self._version_conflicts:
                for name, versions in self._version_conflicts.items():
                    logger.warning(f"Plugin '{name}' has multiple versions: {', '.join(versions)}")
            
            # List installed packages for debugging
            self._list_installed_packages()
            
        except Exception as e:
            logger.error(f"Error discovering plugins: {str(e)}", exc_info=True)
    
    def _list_installed_packages(self):
        """
        List installed packages for debugging purposes
        """
        try:
            logger.info("Listing installed packages:")
            if sys.version_info >= (3, 8):
                from importlib.metadata import distributions
                dists = list(distributions())
                for dist in dists:
                    entry_points = dist.entry_points
                    phunt_eps = [ep for ep in entry_points if getattr(ep, 'group', None) == 'phunt.feature_plugins']
                    if phunt_eps:
                        logger.info(f"Package {dist.metadata['Name']} has PHunt entry points: {phunt_eps}")
            else:
                import pkg_resources
                dists = list(pkg_resources.working_set)
                for dist in dists:
                    entry_map = dist.get_entry_map()
                    if 'phunt.feature_plugins' in entry_map:
                        logger.info(f"Package {dist.project_name} has PHunt entry points: {entry_map['phunt.feature_plugins']}")
        except Exception as e:
            logger.error(f"Error listing installed packages: {str(e)}")
    
    def _register_entry_point(self, plugin_name: str, load_func: Callable) -> None:
        """
        Register a plugin from an entry point
        
        Args:
            plugin_name: Name of the plugin (from entry point)
            load_func: Function to load the plugin class
        """
        try:
            # Load the plugin class
            logger.info(f"Loading plugin class for {plugin_name}")
            plugin_class = load_func()
            
            # Check if it's a valid plugin
            if not inspect.isclass(plugin_class):
                logger.warning(f"Plugin '{plugin_name}' is not a class")
                return
                
            if not issubclass(plugin_class, FeaturePluginBase):
                logger.warning(f"Plugin '{plugin_name}' is not a subclass of FeaturePluginBase")
                return
            
            # Instantiate the plugin
            logger.info(f"Instantiating plugin {plugin_name}")
            plugin_instance = plugin_class()
            
            # Register the plugin
            actual_name = plugin_instance.PLUGIN_INFO['name']
            actual_version = plugin_instance.PLUGIN_INFO['version']
            
            # バージョン競合のチェック
            if actual_name in self._plugins:
                # 既存のプラグインのバージョンを取得
                existing_plugin = self._plugins[actual_name]
                existing_version = existing_plugin.PLUGIN_INFO['version']
                
                # 既存のプラグインよりも新しいバージョンかどうかをチェック
                if version.parse(actual_version) > version.parse(existing_version):
                    logger.info(f"Upgrading plugin '{actual_name}' from version {existing_version} to {actual_version}")
                    self._plugins[actual_name] = plugin_instance
                else:
                    logger.warning(f"Skipping plugin '{actual_name}' version {actual_version} (older than current version {existing_version})")
                
                # バージョン競合を記録
                if actual_name not in self._version_conflicts:
                    self._version_conflicts[actual_name] = [existing_version]
                self._version_conflicts[actual_name].append(actual_version)
                
                return
                
            self._plugins[actual_name] = plugin_instance
            logger.info(f"Registered plugin: {actual_name} (version {actual_version})")
            
        except Exception as e:
            logger.error(f"Error registering plugin '{plugin_name}': {str(e)}", exc_info=True)
    
    def register_plugin(self, plugin_instance: FeaturePluginBase) -> bool:
        """
        直接プラグインインスタンスを登録する
        
        Args:
            plugin_instance: 登録するプラグインインスタンス
            
        Returns:
            登録が成功したかどうか
        """
        try:
            # プラグイン名とバージョンを取得
            plugin_name = plugin_instance.PLUGIN_INFO['name']
            plugin_version = plugin_instance.PLUGIN_INFO['version']
            
            # 既に登録されているかチェック
            if plugin_name in self._plugins:
                # 既存のプラグインのバージョンを取得
                existing_plugin = self._plugins[plugin_name]
                existing_version = existing_plugin.PLUGIN_INFO['version']
                
                # 既存のプラグインよりも新しいバージョンかどうかをチェック
                if version.parse(plugin_version) > version.parse(existing_version):
                    logger.info(f"Upgrading plugin '{plugin_name}' from version {existing_version} to {plugin_version}")
                    self._plugins[plugin_name] = plugin_instance
                else:
                    logger.warning(f"Not registering plugin '{plugin_name}' version {plugin_version} (older than current version {existing_version})")
                    return False
                
                # バージョン競合を記録
                if plugin_name not in self._version_conflicts:
                    self._version_conflicts[plugin_name] = [existing_version]
                self._version_conflicts[plugin_name].append(plugin_version)
            else:
                # 新規登録
                self._plugins[plugin_name] = plugin_instance
            
            logger.info(f"Manually registered plugin: {plugin_name} (version {plugin_version})")
            return True
            
        except Exception as e:
            logger.error(f"Error manually registering plugin: {str(e)}")
            return False
    
    def get_plugin(self, plugin_name: str) -> Optional[FeaturePluginBase]:
        """
        Get a plugin by name
        
        Args:
            plugin_name: Name of the plugin to get
            
        Returns:
            Plugin instance or None if not found
        """
        return self._plugins.get(plugin_name)
    
    def list_plugins(self) -> List[Dict[str, Any]]:
        """
        List all registered plugins
        
        Returns:
            List of plugin information dictionaries
        """
        return [
            {
                'name': name,
                'info': plugin.PLUGIN_INFO
            }
            for name, plugin in self._plugins.items()
        ]
    
    def get_plugin_functions(self, plugin_name: str) -> List[str]:
        """
        Get a list of feature calculation functions provided by a plugin
        
        Args:
            plugin_name: Name of the plugin
            
        Returns:
            List of function names or empty list if plugin not found
        """
        plugin = self.get_plugin(plugin_name)
        if not plugin:
            return []
        
        # Get all methods that don't start with underscore and aren't part of FeaturePluginBase
        base_methods = set(dir(FeaturePluginBase))
        plugin_methods = [
            name for name in dir(plugin)
            if callable(getattr(plugin, name)) and not name.startswith('_') 
            and name not in base_methods
        ]
        
        return plugin_methods
    
    def get_plugin_function(self, plugin_name: str, function_name: str) -> Optional[Callable]:
        """
        Get a specific function from a plugin
        
        Args:
            plugin_name: Name of the plugin
            function_name: Name of the function to get
            
        Returns:
            Function or None if not found
        """
        plugin = self.get_plugin(plugin_name)
        if not plugin:
            return None
        
        func = getattr(plugin, function_name, None)
        if not func or not callable(func) or function_name.startswith('_'):
            return None
            
        return func
    
    def get_plugin_version_conflicts(self) -> Dict[str, List[str]]:
        """
        Get plugin version conflicts
        
        Returns:
            Dictionary mapping plugin names to lists of conflicting versions
        """
        return self._version_conflicts.copy() 