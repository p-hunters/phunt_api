"""
Time Features Plugin Implementation

This module implements the time features plugin, providing calculation functions for
time-based features including market sessions, holidays, economic events, and more.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

from phunt_api.plugin_system.registry import FeaturePluginBase
from phunt_api.features.time_features import (
    is_dst_in_bulk,
    get_sessions_for_all_timestamps,
    is_session_active_vec,
    calculate_session_features,
    calculate_time_features,
    calculate_advanced_time_features,
    calculate_holiday_features,
    calculate_economic_calendar_features,
    calculate_goto_features,
    calculate_all_time_features,
    calculate_event_features,
    calculate_volatility_regime_features,
    is_dst_london,
    is_dst_newyork,
    get_market_hours
)

# Market Sessions (UTC times, before DST adjustment)
DEFAULT_SESSIONS = {
    'tokyo': {'start': time(0, 0), 'end': time(9, 0)},
    'london': {'start': time(8, 0), 'end': time(16, 0)},
    'ny': {'start': time(13, 0), 'end': time(22, 0)},
    'sydney': {'start': time(22, 0), 'end': time(7, 0)},  # crosses midnight
    'frankfurt': {'start': time(7, 0), 'end': time(15, 0)}
}

# Lunch breaks by market (UTC)
DEFAULT_LUNCH_TIMES = {
    'tokyo': [4, 5],     # UTC 4-5 (JST 13-14)
    'london': [12, 13],  # UTC 12-13 (BST/GMT 12-13)
    'ny': [17, 18],      # UTC 17-18 (EST/EDT 12-13)
    'sydney': [3, 4],    # UTC 3-4 (AEST 13-14)
    'frankfurt': [11, 12]  # UTC 11-12 (CET/CEST 12-13)
}

class TimeFeaturePlugin(FeaturePluginBase):
    """
    時間特徴量計算プラグイン
    
    このプラグインは、時間ベースの特徴量計算機能を提供します。
    マーケットセッション、休日、経済指標イベントなどの情報を考慮した特徴量を計算します。
    """
    
    PLUGIN_INFO = {
        'name': 'time_features',
        'version': '1.0.0',
        'description': 'Time-based feature calculations for financial market analysis',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'tags': ['time', 'calendar', 'sessions', 'events', 'holidays'],
        'compatibility': {
            'phunt_api_version': '>=0.5.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        プラグインの初期化
        """
        super().__init__()
    
    def calculate_session_features(
        self,
        timestamps: pd.DatetimeIndex,
        sessions: Optional[Dict[str, Dict[str, time]]] = None,
        peak_vol_hour: int = 14,
        lunch_times: Optional[Dict[str, List[int]]] = None
    ) -> pd.DataFrame:
        """
        マーケットセッション関連の特徴量を計算
        
        各タイムスタンプが各マーケットセッション中かどうか、オーバーラップセッション中かどうか、
        ランチタイム中かどうかなどの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            sessions: セッション情報の辞書（指定しない場合はデフォルト設定を使用）
            peak_vol_hour: 最もボラティリティが高い時間（UTC時間）
            lunch_times: ランチタイム情報の辞書（指定しない場合はデフォルト設定を使用）
            
        Returns:
            セッション特徴量を含むDataFrame
        """
        return calculate_session_features(timestamps, sessions, peak_vol_hour, lunch_times)
    
    def calculate_time_features(self, timestamps: pd.DatetimeIndex) -> pd.DataFrame:
        """
        基本的な時間特徴量を計算
        
        曜日、時間、月、四半期などの基本的な時間特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            
        Returns:
            時間特徴量を含むDataFrame
        """
        return calculate_time_features(timestamps)
    
    def calculate_advanced_time_features(self, timestamps: pd.DatetimeIndex) -> pd.DataFrame:
        """
        高度な時間特徴量を計算
        
        基本的な時間特徴量に加えて、サイン・コサイン変換、特定時間までの距離などの
        より高度な時間特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            
        Returns:
            高度な時間特徴量を含むDataFrame
        """
        return calculate_advanced_time_features(timestamps)
    
    def calculate_holiday_features(
        self,
        timestamps: pd.DatetimeIndex,
        holiday_calendar: pd.DataFrame
    ) -> pd.DataFrame:
        """
        休日関連の特徴量を計算
        
        各タイムスタンプが休日かどうか、休日の前後かどうかなどの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            holiday_calendar: 休日情報を含むDataFrame
            
        Returns:
            休日特徴量を含むDataFrame
        """
        return calculate_holiday_features(timestamps, holiday_calendar)
    
    def calculate_economic_calendar_features(
        self,
        timestamps: pd.DatetimeIndex,
        economic_calendar: pd.DataFrame,
        impact_windows: List[int] = [5, 15]
    ) -> pd.DataFrame:
        """
        経済指標カレンダー関連の特徴量を計算
        
        各タイムスタンプが経済指標発表の前後かどうか、影響度合いなどの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            economic_calendar: 経済指標情報を含むDataFrame
            impact_windows: 影響を考慮する時間枠（分単位）のリスト
            
        Returns:
            経済指標特徴量を含むDataFrame
        """
        return calculate_economic_calendar_features(timestamps, economic_calendar, impact_windows)
    
    def calculate_goto_features(self, timestamps: pd.DatetimeIndex) -> pd.DataFrame:
        """
        GOTO（Global Overnight Trading Opportunity）特徴量を計算
        
        各タイムスタンプがGOTOタイミングかどうかの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            
        Returns:
            GOTO特徴量を含むDataFrame
        """
        return calculate_goto_features(timestamps)
    
    def calculate_event_features(
        self,
        timestamps: pd.DatetimeIndex,
        economic_calendar: pd.DataFrame,
        news_events: Optional[pd.DataFrame] = None,
        impact_windows: List[int] = [5, 15, 30, 60],
        importance_levels: List[str] = ['high', 'medium', 'low']
    ) -> pd.DataFrame:
        """
        イベント関連の特徴量を計算
        
        経済指標発表やニュースイベントの前後かどうか、影響度合いなどの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            economic_calendar: 経済指標情報を含むDataFrame
            news_events: ニュースイベント情報を含むDataFrame（オプション）
            impact_windows: 影響を考慮する時間枠（分単位）のリスト
            importance_levels: 考慮する重要度レベルのリスト
            
        Returns:
            イベント特徴量を含むDataFrame
        """
        return calculate_event_features(
            timestamps, 
            economic_calendar, 
            news_events, 
            impact_windows, 
            importance_levels
        )
    
    def calculate_volatility_regime_features(
        self,
        timestamps: pd.DatetimeIndex,
        volatility_data: Optional[pd.DataFrame] = None
    ) -> pd.DataFrame:
        """
        ボラティリティレジーム関連の特徴量を計算
        
        各タイムスタンプにおけるボラティリティレジームの特徴量を計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            volatility_data: ボラティリティデータを含むDataFrame（オプション）
            
        Returns:
            ボラティリティレジーム特徴量を含むDataFrame
        """
        return calculate_volatility_regime_features(timestamps, volatility_data)
    
    def calculate_all_time_features(
        self,
        timestamps: pd.DatetimeIndex,
        holiday_calendar: Optional[pd.DataFrame] = None,
        economic_calendar: Optional[pd.DataFrame] = None,
        news_events: Optional[pd.DataFrame] = None,
        volatility_data: Optional[pd.DataFrame] = None,
        sessions: Optional[Dict[str, Dict[str, time]]] = None,
        impact_windows: List[int] = [5, 15, 30, 60],
        peak_vol_hour: int = 14,
        lunch_times: Optional[Dict[str, List[int]]] = None
    ) -> pd.DataFrame:
        """
        すべての時間関連特徴量を計算
        
        基本時間特徴量、セッション特徴量、休日特徴量、経済指標特徴量など、
        すべての時間関連特徴量を一括で計算します。
        
        Args:
            timestamps: 特徴量計算対象の日時インデックス
            holiday_calendar: 休日情報を含むDataFrame（オプション）
            economic_calendar: 経済指標情報を含むDataFrame（オプション）
            news_events: ニュースイベント情報を含むDataFrame（オプション）
            volatility_data: ボラティリティデータを含むDataFrame（オプション）
            sessions: セッション情報の辞書（指定しない場合はデフォルト設定を使用）
            impact_windows: 影響を考慮する時間枠（分単位）のリスト
            peak_vol_hour: 最もボラティリティが高い時間（UTC時間）
            lunch_times: ランチタイム情報の辞書（指定しない場合はデフォルト設定を使用）
            
        Returns:
            すべての時間特徴量を含むDataFrame
        """
        return calculate_all_time_features(
            timestamps, 
            holiday_calendar, 
            economic_calendar, 
            news_events, 
            volatility_data, 
            sessions, 
            impact_windows, 
            peak_vol_hour, 
            lunch_times
        )
    
    def is_dst_london(self, dt: datetime) -> bool:
        """
        ロンドンが夏時間かどうかを判定
        
        Args:
            dt: 判定対象の日時
            
        Returns:
            夏時間の場合はTrue、そうでない場合はFalse
        """
        return is_dst_london(dt)
    
    def is_dst_newyork(self, dt: datetime) -> bool:
        """
        ニューヨークが夏時間かどうかを判定
        
        Args:
            dt: 判定対象の日時
            
        Returns:
            夏時間の場合はTrue、そうでない場合はFalse
        """
        return is_dst_newyork(dt)
    
    def get_market_hours(self, dt: datetime) -> dict:
        """
        指定された日時の主要マーケットの営業時間を取得
        
        Args:
            dt: 対象の日時
            
        Returns:
            マーケット名をキー、営業時間情報を値とする辞書
        """
        return get_market_hours(dt) 