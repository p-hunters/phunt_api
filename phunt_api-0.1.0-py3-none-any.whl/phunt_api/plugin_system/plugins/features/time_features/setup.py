"""
Time Features Plugin setup file
"""

from setuptools import setup, find_packages

setup(
    name="phunt-time-features-plugin",
    version="1.0.0",
    description="Time-based feature calculations for financial market analysis",
    author="PHunt Team",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
        "zoneinfo-shim;python_version<='3.8'",
    ],
    entry_points={
        "phunt.feature_plugins": [
            "time_features=phunt_api.plugin_system.plugins.time_features:TimeFeaturePlugin",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.7",
) 