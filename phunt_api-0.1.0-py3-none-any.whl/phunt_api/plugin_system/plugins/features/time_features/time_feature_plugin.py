"""
Time Feature Plugin

This module provides time-based feature calculations.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime, time, timedelta

from ....registry import FeaturePluginBase

logger = logging.getLogger(__name__)


class TimeFeaturePlugin(FeaturePluginBase):
    """
    Time Feature Plugin
    
    Provides various time-based feature calculations.
    """
    
    PLUGIN_INFO = {
        'name': 'time_features',
        'version': '0.1.0',
        'description': 'Provides time-based feature calculations, like session information',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'plugin_type': 'feature',
        'tags': ['time', 'calendar', 'session'],
        'compatibility': {
            'phunt_api_version': '>=0.7.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        Initialize the time feature plugin
        """
        super().__init__()
        logger.info("Initializing TimeFeaturePlugin")
    
    def calculate_basic_time_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate basic time features from the index
        
        Args:
            data: Input DataFrame with DatetimeIndex
            
        Returns:
            DataFrame with basic time features
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            raise ValueError("Input data must have DatetimeIndex")
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        
        # Extract basic time components
        result['year'] = data.index.year
        result['month'] = data.index.month
        result['day'] = data.index.day
        result['hour'] = data.index.hour
        result['minute'] = data.index.minute
        result['second'] = data.index.second
        
        # Day of week (0=Monday, 6=Sunday)
        result['day_of_week'] = data.index.dayofweek
        
        # Is weekend
        result['is_weekend'] = result['day_of_week'].isin([5, 6]).astype(int)
        
        # Day of year
        result['day_of_year'] = data.index.dayofyear
        
        # Week of year
        result['week_of_year'] = data.index.isocalendar().week
        
        # Quarter
        result['quarter'] = data.index.quarter
        
        return result
    
    def calculate_session_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate trading session features
        
        Args:
            data: Input DataFrame with DatetimeIndex
            
        Returns:
            DataFrame with session features
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            raise ValueError("Input data must have DatetimeIndex")
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        
        # Convert to UTC for consistent session calculation
        timestamps_utc = data.index.tz_localize('UTC') if data.index.tz is None else data.index.tz_convert('UTC')
        
        # Define session hours in UTC
        tokyo_start = time(0, 0)  # 9:00 JST = 0:00 UTC
        tokyo_end = time(9, 0)    # 18:00 JST = 9:00 UTC
        
        london_start = time(8, 0)  # 8:00 UTC
        london_end = time(16, 0)   # 16:00 UTC
        
        ny_start = time(13, 0)    # 8:00 EST = 13:00 UTC
        ny_end = time(21, 0)      # 16:00 EST = 21:00 UTC
        
        # Calculate session flags
        result['tokyo_session'] = ((timestamps_utc.time >= tokyo_start) & 
                                  (timestamps_utc.time < tokyo_end)).astype(int)
        
        result['london_session'] = ((timestamps_utc.time >= london_start) & 
                                   (timestamps_utc.time < london_end)).astype(int)
        
        result['ny_session'] = ((timestamps_utc.time >= ny_start) & 
                               (timestamps_utc.time < ny_end)).astype(int)
        
        # Calculate overlap sessions
        result['tokyo_london_overlap'] = (result['tokyo_session'] & result['london_session']).astype(int)
        result['london_ny_overlap'] = (result['london_session'] & result['ny_session']).astype(int)
        
        # Calculate active sessions count
        result['active_sessions'] = result['tokyo_session'] + result['london_session'] + result['ny_session']
        
        # Calculate session transitions
        result['session_transition'] = ((timestamps_utc.time >= time(7, 30)) & (timestamps_utc.time <= time(8, 30)) | 
                                       (timestamps_utc.time >= time(12, 30)) & (timestamps_utc.time <= time(13, 30)) | 
                                       (timestamps_utc.time >= time(20, 30)) & (timestamps_utc.time <= time(21, 30))).astype(int)
        
        return result
    
    def calculate_advanced_time_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate advanced time features
        
        Args:
            data: Input DataFrame with DatetimeIndex
            
        Returns:
            DataFrame with advanced time features
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            raise ValueError("Input data must have DatetimeIndex")
        
        # Get basic time features
        basic_features = self.calculate_basic_time_features(data)
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        
        # Day progress (0-1)
        result['day_progress'] = (basic_features['hour'] * 3600 + 
                                 basic_features['minute'] * 60 + 
                                 basic_features['second']) / 86400
        
        # Week progress (0-1)
        result['week_progress'] = (basic_features['day_of_week'] + result['day_progress']) / 7
        
        # Month progress (0-1)
        days_in_month = pd.Series(data.index).dt.days_in_month.values
        result['month_progress'] = (basic_features['day'] - 1 + result['day_progress']) / days_in_month
        
        # Year progress (0-1)
        is_leap_year = pd.Series(data.index).dt.is_leap_year.values
        days_in_year = np.where(is_leap_year, 366, 365)
        result['year_progress'] = (basic_features['day_of_year'] - 1 + result['day_progress']) / days_in_year
        
        # Time to specific events
        
        # London fix (16:00 London time = 16:00 UTC)
        london_fix_hour = 16
        london_fix_minute = 0
        
        # Calculate minutes to London fix
        hour_diff = (london_fix_hour - basic_features['hour']) % 24
        minute_diff = (london_fix_minute - basic_features['minute']) % 60
        
        if minute_diff < 0:
            hour_diff -= 1
            minute_diff += 60
            
        result['minutes_to_london_fix'] = hour_diff * 60 + minute_diff
        result['minutes_to_london_fix'] = np.where(
            result['minutes_to_london_fix'] == 0, 
            24 * 60, 
            result['minutes_to_london_fix']
        )
        
        # US NFP release (first Friday of month, 8:30 EST = 13:30 UTC)
        # This is a simplification - actual calculation would need to determine the first Friday
        
        # End of month
        result['days_to_month_end'] = days_in_month - basic_features['day']
        
        # End of quarter
        last_month_of_quarter = basic_features['quarter'] * 3
        months_to_quarter_end = last_month_of_quarter - basic_features['month']
        months_to_quarter_end = np.where(months_to_quarter_end < 0, months_to_quarter_end + 3, months_to_quarter_end)
        result['months_to_quarter_end'] = months_to_quarter_end
        
        # Merge with basic features
        result = pd.concat([result, basic_features], axis=1)
        
        return result
    
    def calculate_goto_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate GOTO (5th and 10th day) features
        
        Args:
            data: Input DataFrame with DatetimeIndex
            
        Returns:
            DataFrame with GOTO features
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            raise ValueError("Input data must have DatetimeIndex")
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        
        # Extract day of month
        day_of_month = data.index.day
        
        # GOTO days (5th and 10th of each month)
        result['is_gotobi'] = day_of_month.isin([5, 10]).astype(int)
        
        # Calculate days to next GOTO
        next_5th = np.where(day_of_month < 5, 5 - day_of_month, 
                           np.where(day_of_month < 10, 10 - day_of_month, 
                                   5 + (data.index + pd.DateOffset(months=1)).day - day_of_month))
        
        next_10th = np.where(day_of_month < 10, 10 - day_of_month, 
                            10 + (data.index + pd.DateOffset(months=1)).day - day_of_month)
        
        result['days_to_next_gotobi'] = np.minimum(next_5th, next_10th)
        
        return result
    
    def get_plugin_functions(self) -> List[str]:
        """
        Get the list of available functions in this plugin
        
        Returns:
            List of function names
        """
        return [
            'calculate_basic_time_features',
            'calculate_session_features',
            'calculate_advanced_time_features',
            'calculate_goto_features'
        ]


# エントリーポイント用関数
def get_plugin_class():
    """
    Entry point function to get the plugin class
    
    Returns:
        The plugin class
    """
    return TimeFeaturePlugin 