"""
Time Feature Plugin

This module provides time-based feature calculations.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime, time, timedelta

from ....registry import FeaturePluginBase

logger = logging.getLogger(__name__)


class TimeFeaturePlugin(FeaturePluginBase):
    """
    Time Feature Plugin
    
    Provides various time-based feature calculations.
    """
    
    PLUGIN_INFO = {
        'name': 'time_features',
        'version': '0.1.0',
        'description': 'Provides time-based feature calculations, like session information',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'plugin_type': 'feature',
        'tags': ['time', 'calendar', 'session'],
        'compatibility': {
            'phunt_api_version': '>=0.7.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        Initialize the time feature plugin
        """
        super().__init__()
        logger.info("Initializing TimeFeaturePlugin")
    
    def calculate_basic_time_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate basic time features from the index or ts column
        
        Args:
            data: Input DataFrame with DatetimeIndex or ts column
            
        Returns:
            DataFrame with basic time features
        """
        # DatetimeIndexの処理
        if isinstance(data.index, pd.DatetimeIndex):
            timestamps = data.index
        elif 'ts' in data.columns:
            # ts列がある場合はそれを使用
            if pd.api.types.is_datetime64_any_dtype(data['ts']):
                timestamps = data['ts']
            else:
                try:
                    timestamps = pd.to_datetime(data['ts'])
                except Exception as e:
                    logger.error(f"ts列を日時型に変換できません: {e}")
                    raise ValueError(f"ts列を日時型に変換できません: {e}")
        else:
            raise ValueError("DatetimeIndexかts列が必要です")
        
        # 結果用データフレーム（元のインデックスを維持）
        result = pd.DataFrame(index=data.index)
        
        # 基本的な時間コンポーネントを抽出
        result['year'] = timestamps.dt.year if hasattr(timestamps, 'dt') else timestamps.year
        result['month'] = timestamps.dt.month if hasattr(timestamps, 'dt') else timestamps.month
        result['day'] = timestamps.dt.day if hasattr(timestamps, 'dt') else timestamps.day
        result['hour'] = timestamps.dt.hour if hasattr(timestamps, 'dt') else timestamps.hour
        result['minute'] = timestamps.dt.minute if hasattr(timestamps, 'dt') else timestamps.minute
        result['second'] = timestamps.dt.second if hasattr(timestamps, 'dt') else timestamps.second
        
        # 曜日 (0=月曜, 6=日曜)
        result['day_of_week'] = timestamps.dt.dayofweek if hasattr(timestamps, 'dt') else timestamps.dayofweek
        
        # 週末か
        result['is_weekend'] = result['day_of_week'].isin([5, 6]).astype(int)
        
        # 年間通算日
        result['day_of_year'] = timestamps.dt.dayofyear if hasattr(timestamps, 'dt') else timestamps.dayofyear
        
        # 年間通算週
        if hasattr(timestamps, 'dt'):
            result['week_of_year'] = timestamps.dt.isocalendar().week
        else:
            result['week_of_year'] = timestamps.isocalendar().week.astype(int)
        
        # 四半期
        result['quarter'] = timestamps.dt.quarter if hasattr(timestamps, 'dt') else timestamps.quarter
        
        return result
    
    def calculate_session_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate trading session features
        
        Args:
            data: Input DataFrame with DatetimeIndex or ts column
            
        Returns:
            DataFrame with session features
        """
        # DatetimeIndexの処理
        if isinstance(data.index, pd.DatetimeIndex):
            timestamps = data.index
        elif 'ts' in data.columns:
            # ts列がある場合はそれを使用
            if pd.api.types.is_datetime64_any_dtype(data['ts']):
                timestamps = data['ts']
            else:
                try:
                    timestamps = pd.to_datetime(data['ts'])
                except Exception as e:
                    logger.error(f"ts列を日時型に変換できません: {e}")
                    raise ValueError(f"ts列を日時型に変換できません: {e}")
        else:
            raise ValueError("DatetimeIndexかts列が必要です")
        
        # 結果用データフレーム（元のインデックスを維持）
        result = pd.DataFrame(index=data.index)
        
        # UTCに変換（タイムゾーン処理）
        if isinstance(timestamps, pd.DatetimeIndex):
            timestamps_utc = timestamps.tz_localize('UTC') if timestamps.tz is None else timestamps.tz_convert('UTC')
        else:
            # SeriesをDatetimeIndexに変換
            datetime_idx = pd.DatetimeIndex(timestamps)
            timestamps_utc = datetime_idx.tz_localize('UTC') if datetime_idx.tz is None else datetime_idx.tz_convert('UTC')
        
        # 各種セッション時間（UTC）の定義
        tokyo_start = time(0, 0)  # JST 9:00 = UTC 0:00
        tokyo_end = time(9, 0)    # JST 18:00 = UTC 9:00
        
        london_start = time(8, 0)  # UTC 8:00
        london_end = time(16, 0)   # UTC 16:00
        
        ny_start = time(13, 0)    # EST 8:00 = UTC 13:00
        ny_end = time(21, 0)      # EST 16:00 = UTC 21:00
        
        # セッションフラグの計算
        if isinstance(timestamps_utc, pd.DatetimeIndex):
            time_series = pd.Series([t.time() for t in timestamps_utc])
        else:
            # Seriesの場合は各要素からtime()を抽出
            time_series = pd.Series([pd.Timestamp(t).time() for t in timestamps_utc])
        
        result['tokyo_session'] = ((time_series >= tokyo_start) & 
                                  (time_series < tokyo_end)).astype(int)
        
        result['london_session'] = ((time_series >= london_start) & 
                                   (time_series < london_end)).astype(int)
        
        result['ny_session'] = ((time_series >= ny_start) & 
                               (time_series < ny_end)).astype(int)
        
        # セッションの重複
        result['tokyo_london_overlap'] = (result['tokyo_session'] & result['london_session']).astype(int)
        result['london_ny_overlap'] = (result['london_session'] & result['ny_session']).astype(int)
        
        # アクティブなセッション数
        result['active_sessions'] = result['tokyo_session'] + result['london_session'] + result['ny_session']
        
        # セッションの移行期
        result['session_transition'] = ((time_series >= time(7, 30)) & (time_series <= time(8, 30)) | 
                                       (time_series >= time(12, 30)) & (time_series <= time(13, 30)) | 
                                       (time_series >= time(20, 30)) & (time_series <= time(21, 30))).astype(int)
        
        return result
    
    def calculate_advanced_time_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate advanced time features
        
        Args:
            data: Input DataFrame with DatetimeIndex or ts column
            
        Returns:
            DataFrame with advanced time features
        """
        # DatetimeIndexの処理
        if isinstance(data.index, pd.DatetimeIndex):
            timestamps = data.index
        elif 'ts' in data.columns:
            # ts列がある場合はそれを使用
            if pd.api.types.is_datetime64_any_dtype(data['ts']):
                timestamps = data['ts']
            else:
                try:
                    timestamps = pd.to_datetime(data['ts'])
                except Exception as e:
                    logger.error(f"ts列を日時型に変換できません: {e}")
                    raise ValueError(f"ts列を日時型に変換できません: {e}")
        else:
            raise ValueError("DatetimeIndexかts列が必要です")
            
        # 基本的な時間特徴量を内部で再利用
        basic_features_df = self.calculate_basic_time_features(data)
        
        # 結果用データフレーム（元のインデックスを維持）
        result = pd.DataFrame(index=data.index)
        
        # 一日の経過割合 (0-1)
        result['day_progress'] = (basic_features_df['hour'] * 3600 + 
                                 basic_features_df['minute'] * 60 + 
                                 basic_features_df['second']) / 86400
        
        # 週の経過割合 (0-1)
        result['week_progress'] = (basic_features_df['day_of_week'] + result['day_progress']) / 7
        
        # 月の経過割合 (0-1)
        if isinstance(timestamps, pd.DatetimeIndex):
            days_in_month = timestamps.days_in_month
        else:
            days_in_month = pd.Series(timestamps).dt.days_in_month.values
            
        result['month_progress'] = (basic_features_df['day'] - 1 + result['day_progress']) / days_in_month
        
        # 年の経過割合 (0-1)
        if isinstance(timestamps, pd.DatetimeIndex):
            is_leap_year = pd.Series(timestamps.year).apply(lambda y: (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0))
        else:
            is_leap_year = pd.Series(timestamps).dt.is_leap_year.values
            
        days_in_year = np.where(is_leap_year, 366, 365)
        result['year_progress'] = (basic_features_df['day_of_year'] - 1 + result['day_progress']) / days_in_year
        
        # 特定イベントまでの時間
        
        # ロンドンフィックス (16:00 ロンドン時間 = UTC 16:00)
        london_fix_hour = 16
        london_fix_minute = 0
        
        # ロンドンフィックスまでの時間を計算
        # 要素ごとに計算するために要素単位の条件処理を使用
        hour_diff = (london_fix_hour - basic_features_df['hour']) % 24
        minute_diff = (london_fix_minute - basic_features_df['minute']) % 60
        
        # minute_diffが0未満の場合の処理（Seriesの場合は要素ごとの条件処理が必要）
        # 以下の行を修正
        # if minute_diff < 0:
        #    hour_diff -= 1
        #    minute_diff += 60
        
        # 要素単位の条件処理に変更
        negative_minutes = minute_diff < 0
        hour_diff = hour_diff - negative_minutes.astype(int)
        minute_diff = minute_diff + (negative_minutes * 60).astype(int)
            
        result['minutes_to_london_fix'] = hour_diff * 60 + minute_diff
        
        # 0分の場合は24時間（1440分）に設定
        zero_minutes = result['minutes_to_london_fix'] == 0
        result['minutes_to_london_fix'] = np.where(
            zero_minutes, 
            24 * 60, 
            result['minutes_to_london_fix']
        )
        
        # 月末までの日数
        result['days_to_month_end'] = days_in_month - basic_features_df['day']
        
        # 四半期末までの月数
        last_month_of_quarter = basic_features_df['quarter'] * 3
        months_to_quarter_end = last_month_of_quarter - basic_features_df['month']
        
        # 負の値の場合は次の四半期の対応する月
        negative_months = months_to_quarter_end < 0
        months_to_quarter_end = np.where(negative_months, months_to_quarter_end + 3, months_to_quarter_end)
        
        result['months_to_quarter_end'] = months_to_quarter_end
        
        # 基本的な特徴量と結合
        result = pd.concat([result, basic_features_df], axis=1)
        
        return result
    
    def calculate_goto_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate GOTO (5th and 10th day) features
        
        Args:
            data: Input DataFrame with DatetimeIndex or ts column
            
        Returns:
            DataFrame with GOTO features
        """
        # DatetimeIndexの処理
        if isinstance(data.index, pd.DatetimeIndex):
            timestamps = data.index
        elif 'ts' in data.columns:
            # ts列がある場合はそれを使用
            if pd.api.types.is_datetime64_any_dtype(data['ts']):
                timestamps = data['ts']
            else:
                try:
                    timestamps = pd.to_datetime(data['ts'])
                except Exception as e:
                    logger.error(f"ts列を日時型に変換できません: {e}")
                    raise ValueError(f"ts列を日時型に変換できません: {e}")
        else:
            raise ValueError("DatetimeIndexかts列が必要です")
        
        # 結果用データフレーム
        result = pd.DataFrame(index=data.index)
        
        # 日付情報の抽出
        if isinstance(timestamps, pd.DatetimeIndex):
            day_of_month = timestamps.day
            next_month_day = (timestamps + pd.DateOffset(months=1)).day
        else:
            day_of_month = pd.Series(timestamps).dt.day
            next_month_day = (pd.Series(timestamps) + pd.DateOffset(months=1)).dt.day
        
        # 5日と10日が後場寄り付き(GOTO)日
        result['is_gotobi'] = day_of_month.isin([5, 10]).astype(int)
        
        # 次のGOTO日までの日数を計算（要素ごとの条件処理を使用）
        is_less_than_5 = day_of_month < 5
        is_between_5_and_10 = (day_of_month >= 5) & (day_of_month < 10)
        
        # 5日未満なら5-day、5-10日なら10-day、それ以外は翌月5日までの日数
        next_5th = np.where(
            is_less_than_5, 
            5 - day_of_month,
            np.where(
                is_between_5_and_10, 
                10 - day_of_month,
                (next_month_day.values * 0 + 5) + (next_month_day - day_of_month)
            )
        )
        
        # 10日未満なら10-day、それ以外は翌月10日までの日数
        next_10th = np.where(
            day_of_month < 10,
            10 - day_of_month,
            (next_month_day.values * 0 + 10) + (next_month_day - day_of_month)
        )
        
        # 近い方を選択
        result['days_to_next_gotobi'] = np.minimum(next_5th, next_10th)
        
        return result
    
    def get_plugin_functions(self) -> List[str]:
        """
        Get the list of available functions in this plugin
        
        Returns:
            List of function names
        """
        return [
            'calculate_basic_time_features',
            'calculate_session_features',
            'calculate_advanced_time_features',
            'calculate_goto_features'
        ]


# エントリーポイント用関数
def get_plugin_class():
    """
    Entry point function to get the plugin class
    
    Returns:
        The plugin class
    """
    return TimeFeaturePlugin 