"""
Time Features Plugin

This package provides time-based feature calculations.
"""

from .time_feature_plugin import TimeFeaturePlugin

__all__ = ['TimeFeaturePlugin'] 