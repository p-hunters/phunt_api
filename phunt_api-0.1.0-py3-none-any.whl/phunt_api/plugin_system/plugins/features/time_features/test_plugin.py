"""
Time Features Plugin Test

This module tests the time features plugin functionality.
"""

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

from phunt_api import PHuntAPI
from phunt_api.plugin_system.plugins.time_features import TimeFeaturePlugin

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_plugin_directly():
    """プラグインを直接使用したテスト"""
    logger.info("=== プラグインを直接使用したテスト ===")
    
    # プラグインのインスタンス化
    plugin = TimeFeaturePlugin()
    
    # サンプルデータの作成 - 1時間間隔、1週間分のデータ
    start_date = pd.Timestamp('2023-01-01')
    end_date = pd.Timestamp('2023-01-07')
    timestamps = pd.date_range(start=start_date, end=end_date, freq='1H')
    logger.info(f"サンプル日時データ: {len(timestamps)}行のデータを生成")
    
    # 基本時間特徴量の計算
    logger.info("\n基本時間特徴量の計算...")
    time_features = plugin.calculate_time_features(timestamps)
    logger.info(f"時間特徴量計算結果: {time_features.shape}, カラム: {time_features.columns.tolist()}")
    
    # セッション特徴量の計算
    logger.info("\nセッション特徴量の計算...")
    session_features = plugin.calculate_session_features(timestamps)
    logger.info(f"セッション特徴量計算結果: {session_features.shape}, カラム: {session_features.columns.tolist()}")
    
    # 高度な時間特徴量の計算
    logger.info("\n高度な時間特徴量の計算...")
    adv_time_features = plugin.calculate_advanced_time_features(timestamps)
    logger.info(f"高度な時間特徴量計算結果: {adv_time_features.shape}, カラム: {adv_time_features.columns.tolist()}")
    
    # GOTO特徴量の計算
    logger.info("\nGOTO特徴量の計算...")
    goto_features = plugin.calculate_goto_features(timestamps)
    logger.info(f"GOTO特徴量計算結果: {goto_features.shape}, カラム: {goto_features.columns.tolist()}")
    
    # 結果のプロット - セッション特徴量の可視化
    plt.figure(figsize=(15, 10))
    
    # 時間帯別のセッションアクティビティ
    plt.subplot(3, 1, 1)
    
    # 24時間の各時間帯ごとに、各セッションがアクティブな割合を計算
    hours = range(24)
    
    # 実際のセッションカラム名を使用
    sessions = ['tokyo_session', 'london_session', 'ny_session', 'tokyo_london_overlap', 'london_ny_overlap']
    active_ratios = {session: [] for session in sessions}
    
    for hour in hours:
        hour_data = session_features[session_features.index.hour == hour]
        if not hour_data.empty:
            for session in sessions:
                active_ratio = hour_data[session].mean()
                active_ratios[session].append(active_ratio)
        else:
            for session in sessions:
                active_ratios[session].append(0)
    
    # プロット
    for session in sessions:
        plt.plot(hours, active_ratios[session], label=session)
    
    plt.title('Session Activity by Hour (UTC)')
    plt.xlabel('Hour (UTC)')
    plt.ylabel('Active Ratio')
    plt.legend()
    plt.xticks(hours)
    plt.grid(True)
    
    # 曜日ごとの特徴量の可視化
    plt.subplot(3, 1, 2)
    
    # 曜日ごとの特徴量の平均値を計算
    day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day_features = time_features.copy()
    
    # day_nameを安全に取得
    try:
        day_features['day_name'] = day_features.index.day_name()
    except AttributeError:
        # 代替方法: 0=月曜、1=火曜...という値を使って曜日名に変換
        day_lookup = {0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 
                    4: 'Friday', 5: 'Saturday', 6: 'Sunday'}
        day_features['day_name'] = [day_lookup.get(d, 'Unknown') for d in day_features.index.dayofweek]
    
    day_averages = {}
    for feature in ['day_of_week', 'is_weekend', 'is_month_start', 'is_month_end', 'is_quarter_start']:
        if feature in day_features.columns:
            day_averages[feature] = [day_features[day_features['day_name'] == day][feature].mean() for day in day_names]
    
    # プロット
    width = 0.15
    x = np.arange(len(day_names))
    
    for i, (feature, values) in enumerate(day_averages.items()):
        plt.bar(x + i*width, values, width, label=feature)
    
    plt.title('Time Features by Day of Week')
    plt.xlabel('Day of Week')
    plt.ylabel('Feature Value')
    plt.xticks(x + width * (len(day_averages) - 1) / 2, day_names, rotation=45)
    plt.legend()
    plt.grid(True)
    
    # 時間帯ごとの特徴量の可視化
    plt.subplot(3, 1, 3)
    
    # 時間帯ごとの特徴量の平均値を計算
    hour_features = time_features.copy()
    
    hour_averages = {}
    for feature in ['hour_sin', 'hour_cos', 'is_business_hour']:
        if feature in hour_features.columns:
            hour_averages[feature] = [hour_features[hour_features.index.hour == hour][feature].mean() for hour in hours]
    
    # プロット
    for feature, values in hour_averages.items():
        plt.plot(hours, values, label=feature)
    
    plt.title('Time Features by Hour')
    plt.xlabel('Hour (UTC)')
    plt.ylabel('Feature Value')
    plt.xticks(hours)
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('time_features_test.png')
    logger.info("結果を'time_features_test.png'に保存しました")

def test_with_phunt_api():
    """PHuntAPIを通じたプラグインのテスト"""
    logger.info("\n=== PHuntAPIを通じたプラグインのテスト ===")
    
    # PHuntAPIのインスタンス化
    api = PHuntAPI(debug=True)
    
    # サンプルデータの作成 - 1時間間隔、1週間分のデータ
    start_date = pd.Timestamp('2023-01-01')
    end_date = pd.Timestamp('2023-01-07')
    timestamps = pd.date_range(start=start_date, end=end_date, freq='1H')
    logger.info(f"サンプル日時データ: {len(timestamps)}行のデータを生成")
    
    # プラグイン情報の取得
    logger.info("\nプラグイン情報の取得...")
    plugins = api.list_plugins()
    time_plugin = None
    for plugin in plugins:
        if plugin['name'] == 'time_features':
            time_plugin = plugin
            break
    
    if time_plugin:
        logger.info(f"time_featuresプラグインが見つかりました: {time_plugin['info']['version']}")
        
        # プラグイン関数の実行
        logger.info("\nプラグイン関数を実行...")
        time_features = api.get_plugin_feature(
            plugin_name='time_features',
            function_name='calculate_time_features',
            timestamps=timestamps
        )
        logger.info(f"時間特徴量計算結果: {time_features.shape}, カラム: {time_features.columns.tolist()}")

        session_features = api.get_plugin_feature(
            plugin_name='time_features',
            function_name='calculate_session_features',
            timestamps=timestamps
        )
        logger.info(f"セッション特徴量計算結果: {session_features.shape}, カラム: {session_features.columns.tolist()}")
        
        # タイムゾーン情報の統一 - インデックスのタイムゾーン情報を削除して統一
        time_features.index = time_features.index.tz_localize(None) if hasattr(time_features.index, 'tz') and time_features.index.tz else time_features.index
        session_features.index = session_features.index.tz_localize(None) if hasattr(session_features.index, 'tz') and session_features.index.tz else session_features.index
        
        # 結合して可視化
        combined_features = pd.concat([session_features, time_features], axis=1)
        
        # セッション情報とアクティビティの可視化
        fig, axes = plt.subplots(2, 1, figsize=(15, 10))
        
        # 1. セッション情報の可視化
        sessions = ['tokyo_session', 'london_session', 'ny_session', 'tokyo_london_overlap', 'london_ny_overlap']
        for session in sessions:
            if session in combined_features.columns:
                combined_features[session].astype(float).plot(ax=axes[0], label=session)
        
        axes[0].set_title('Session Activity by Hour (UTC)')
        axes[0].set_xlabel('Hour (UTC)')
        axes[0].set_ylabel('Active Ratio')
        axes[0].legend()
        axes[0].set_xticks(range(24))
        axes[0].grid(True)
        
        # 2. 曜日ごとの特徴量の可視化
        day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        day_features = time_features.copy()
        
        # day_nameを安全に取得
        try:
            day_features['day_name'] = day_features.index.day_name()
        except AttributeError:
            # 代替方法: 0=月曜、1=火曜...という値を使って曜日名に変換
            day_lookup = {0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 
                        4: 'Friday', 5: 'Saturday', 6: 'Sunday'}
            day_features['day_name'] = [day_lookup.get(d, 'Unknown') for d in day_features.index.dayofweek]
        
        day_averages = {}
        for feature in ['day_of_week', 'is_weekend', 'is_month_start', 'is_month_end', 'is_quarter_start']:
            if feature in day_features.columns:
                day_averages[feature] = [day_features[day_features['day_name'] == day][feature].mean() for day in day_names]
        
        # プロット
        width = 0.15
        x = np.arange(len(day_names))
        
        for i, (feature, values) in enumerate(day_averages.items()):
            axes[1].bar(x + i*width, values, width, label=feature)
        
        axes[1].set_title('Time Features by Day of Week')
        axes[1].set_xlabel('Day of Week')
        axes[1].set_ylabel('Feature Value')
        axes[1].set_xticks(x + width * (len(day_averages) - 1) / 2)
        axes[1].set_xticklabels(day_names, rotation=45)
        axes[1].legend()
        axes[1].grid(True)
        
        plt.tight_layout()
        plt.savefig('time_features_test.png')
        logger.info("結果を'time_features_test.png'に保存しました")
    else:
        logger.warning("time_featuresプラグインが見つかりませんでした")

def main():
    """メイン関数"""
    logger.info("=== Time Features Plugin Test ===")
    
    # 直接プラグインを使用したテスト
    test_plugin_directly()
    
    # PHuntAPIを通じたテスト
    test_with_phunt_api()
    
    logger.info("=== テスト完了 ===")

if __name__ == "__main__":
    main() 