"""
Price Features Plugin setup file
"""

from setuptools import setup, find_packages

setup(
    name="phunt-price-features-plugin",
    version="1.0.0",
    description="Financial price feature calculations with multi-backend support",
    author="PHunt Team",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
        "polars>=0.15.0",
    ],
    entry_points={
        "phunt.feature_plugins": [
            "price_features=phunt_api.plugin_system.plugins.price_features:PriceFeaturePlugin",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires=">=3.7",
) 