"""
Price Features Plugin Implementation

This module implements the price features plugin, providing calculation functions for financial price data
with support for multiple backends (pandas, polars, BigQuery, DuckDB).
"""

from typing import Union, List, Dict, Any, Optional, Callable, TypeVar
import pandas as pd
import polars as pl
import numpy as np

from phunt_api.plugin_system.registry import FeaturePluginBase
from phunt_api.features.price_features import (
    calculate_returns,
    calculate_moving_averages,
    calculate_statistical_moments,
    PriceFeatureBackend
)

class PriceFeaturePlugin(FeaturePluginBase):
    """
    価格特徴量計算プラグイン
    
    このプラグインは、金融価格データからの特徴量計算機能を提供します。
    複数のバックエンド（pandas、polars、BigQuery、DuckDB）をサポートしています。
    """
    
    PLUGIN_INFO = {
        'name': 'price_features',
        'version': '1.0.0',
        'description': 'Financial price feature calculations with multi-backend support',
        'author': 'PHunt Team',
        'backends': ['pandas', 'polars', 'bigquery', 'duckdb'],
        'tags': ['price', 'finance', 'technical', 'returns', 'moving-average', 'statistics'],
        'compatibility': {
            'phunt_api_version': '>=0.5.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        プラグインの初期化
        """
        super().__init__()
        # デフォルトのバックエンドを設定
        self._backend = PriceFeatureBackend(backend="pandas")
    
    def set_backend(self, backend: str, **backend_options) -> None:
        """
        使用するバックエンドを設定
        
        Args:
            backend: バックエンド名（'pandas', 'polars', 'bigquery', 'duckdb'）
            **backend_options: バックエンド固有のオプション
        """
        self._backend = PriceFeatureBackend(backend=backend, **backend_options)
    
    def calculate_returns(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        periods: Union[int, List[int]] = [1, 5, 10],
        method: str = 'arithmetic',
        date_column: Optional[str] = None,
        price_column: Optional[str] = None,
        backend: Optional[str] = None,
        **backend_options
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        リターン（収益率）を計算
        
        Args:
            prices: 価格データ。Series、DataFrameまたはテーブルを指定可能
            periods: リターン計算期間。整数または整数のリストを指定可能
            method: 計算方法（'arithmetic'または'log'）
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            backend: 使用するバックエンド（指定しない場合はデフォルト）
            **backend_options: バックエンド固有のオプション
            
        Returns:
            リターン計算結果を含むDataFrame
        """
        if backend is not None:
            # 一時的にバックエンドを切り替える
            temp_backend = PriceFeatureBackend(backend=backend, **backend_options)
            return temp_backend.calculate_returns(
                prices=prices,
                periods=periods,
                method=method,
                date_column=date_column,
                price_column=price_column
            )
        else:
            # デフォルトのバックエンドを使用
            return self._backend.calculate_returns(
                prices=prices,
                periods=periods,
                method=method,
                date_column=date_column,
                price_column=price_column
            )
    
    def calculate_moving_averages(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        windows: Union[int, List[int]] = [5, 10, 20, 50, 200],
        date_column: Optional[str] = None,
        price_column: Optional[str] = None,
        backend: Optional[str] = None,
        **backend_options
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        移動平均を計算
        
        Args:
            prices: 価格データ。Series、DataFrameまたはテーブルを指定可能
            windows: 移動平均期間。整数または整数のリストを指定可能
            date_column: 日付カラム名（DataFrameの場合）
            price_column: 価格カラム名（DataFrameの場合）
            backend: 使用するバックエンド（指定しない場合はデフォルト）
            **backend_options: バックエンド固有のオプション
            
        Returns:
            移動平均計算結果を含むDataFrame
        """
        if backend is not None:
            # 一時的にバックエンドを切り替える
            temp_backend = PriceFeatureBackend(backend=backend, **backend_options)
            return temp_backend.calculate_moving_averages(
                prices=prices,
                windows=windows,
                date_column=date_column,
                price_column=price_column
            )
        else:
            # デフォルトのバックエンドを使用
            return self._backend.calculate_moving_averages(
                prices=prices,
                windows=windows,
                date_column=date_column,
                price_column=price_column
            )
    
    def calculate_statistical_moments(
        self,
        returns: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        windows: List[int] = [20, 60, 120],
        date_column: Optional[str] = None,
        returns_column: Optional[str] = None,
        backend: Optional[str] = None,
        **backend_options
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        統計的モーメント（ボラティリティ、歪度、尖度）を計算
        
        Args:
            returns: リターンデータ。Series、DataFrameまたはテーブルを指定可能
            windows: 計算期間のリスト
            date_column: 日付カラム名（DataFrameの場合）
            returns_column: リターンカラム名（DataFrameの場合）
            backend: 使用するバックエンド（指定しない場合はデフォルト）
            **backend_options: バックエンド固有のオプション
            
        Returns:
            統計的モーメント計算結果を含むDataFrame
        """
        if backend is not None:
            # 一時的にバックエンドを切り替える
            temp_backend = PriceFeatureBackend(backend=backend, **backend_options)
            return temp_backend.calculate_statistical_moments(
                returns=returns,
                windows=windows,
                date_column=date_column,
                returns_column=returns_column
            )
        else:
            # デフォルトのバックエンドを使用
            return self._backend.calculate_statistical_moments(
                returns=returns,
                windows=windows,
                date_column=date_column,
                returns_column=returns_column
            )
    
    def calculate_technical_indicators(
        self,
        prices: Union[pl.Series, pl.DataFrame, pd.Series, pd.DataFrame],
        indicators: List[str] = ['rsi', 'macd', 'bollinger'],
        date_column: Optional[str] = None,
        ohlcv_columns: Optional[Dict[str, str]] = None,
        backend: Optional[str] = None,
        **params
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        テクニカル指標を計算 (新機能)
        
        Args:
            prices: 価格データ。Series、DataFrameまたはテーブルを指定可能
            indicators: 計算するテクニカル指標のリスト
            date_column: 日付カラム名（DataFrameの場合）
            ohlcv_columns: OHLCV列名の辞書（例: {'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close', 'volume': 'volume'}）
            backend: 使用するバックエンド（指定しない場合はデフォルト）
            **params: 各指標の計算パラメータ
            
        Returns:
            テクニカル指標計算結果を含むDataFrame
        """
        # 入力データを適切な形式に変換
        if isinstance(prices, (pd.Series, pl.Series)):
            # Seriesの場合はDataFrameに変換
            if isinstance(prices, pd.Series):
                prices_df = pd.DataFrame({
                    'close': prices.values
                }, index=prices.index)
            else:  # polars Series
                prices_df = pl.DataFrame({
                    'close': prices.values
                })
                if prices.index_was_set:
                    prices_df = prices_df.with_column(pl.Series(name='date', values=prices.index))
        else:
            prices_df = prices
        
        # デフォルトのcolumns
        if ohlcv_columns is None:
            ohlcv_columns = {
                'open': 'open', 
                'high': 'high', 
                'low': 'low', 
                'close': 'close', 
                'volume': 'volume'
            }
        
        # 必要なカラムの確認
        close_col = ohlcv_columns.get('close', 'close')
        
        # 計算結果を格納するためのDataFrameを初期化
        if isinstance(prices_df, pd.DataFrame):
            result = pd.DataFrame(index=prices_df.index)
        else:  # polars DataFrame
            result = prices_df.select([])
        
        # 各指標を計算
        for indicator in indicators:
            if indicator.lower() == 'rsi':
                window = params.get('rsi_window', 14)
                # リターンを計算
                returns_df = self.calculate_returns(
                    prices_df[close_col] if close_col in prices_df.columns else prices_df,
                    periods=1,
                    backend=backend
                )
                
                # RSIの計算（簡易版）
                delta = returns_df['return_1']
                
                if isinstance(delta, pd.Series):
                    gains = delta.where(delta > 0, 0)
                    losses = -delta.where(delta < 0, 0)
                    avg_gain = gains.rolling(window=window).mean()
                    avg_loss = losses.rolling(window=window).mean()
                    rs = avg_gain / avg_loss
                    rsi = 100 - (100 / (1 + rs))
                    
                    result['rsi'] = rsi
                else:
                    # polarsでの実装（簡略化）
                    rsi = returns_df.select(
                        pl.col('return_1').rolling_mean(window).alias('rsi')
                    )
                    result = result.join(rsi, how='left')
            
            elif indicator.lower() == 'macd':
                fast = params.get('macd_fast', 12)
                slow = params.get('macd_slow', 26)
                signal = params.get('macd_signal', 9)
                
                # 移動平均を計算
                ma_df = self.calculate_moving_averages(
                    prices_df[close_col] if close_col in prices_df.columns else prices_df,
                    windows=[fast, slow],
                    backend=backend
                )
                
                if isinstance(ma_df, pd.DataFrame):
                    # MACD計算
                    fast_ma = ma_df[f'ma_{fast}']
                    slow_ma = ma_df[f'ma_{slow}']
                    macd_line = fast_ma - slow_ma
                    
                    # シグナルライン計算
                    signal_line = macd_line.rolling(window=signal).mean()
                    
                    # ヒストグラム計算
                    histogram = macd_line - signal_line
                    
                    result['macd_line'] = macd_line
                    result['macd_signal'] = signal_line
                    result['macd_histogram'] = histogram
                else:
                    # polarsでの実装（簡略化）
                    fast_ma = ma_df.select(pl.col(f'ma_{fast}'))
                    slow_ma = ma_df.select(pl.col(f'ma_{slow}'))
                    # 以下、polars固有の実装は省略
            
            elif indicator.lower() == 'bollinger':
                window = params.get('bollinger_window', 20)
                num_std = params.get('bollinger_std', 2.0)
                
                # 移動平均と標準偏差を計算
                if isinstance(prices_df, pd.DataFrame):
                    price_series = prices_df[close_col] if close_col in prices_df.columns else prices_df.iloc[:, 0]
                    middle_band = price_series.rolling(window=window).mean()
                    std_dev = price_series.rolling(window=window).std()
                    
                    upper_band = middle_band + (std_dev * num_std)
                    lower_band = middle_band - (std_dev * num_std)
                    
                    result['bollinger_upper'] = upper_band
                    result['bollinger_middle'] = middle_band
                    result['bollinger_lower'] = lower_band
                else:
                    # polarsでの実装（簡略化）
                    # 以下、polars固有の実装は省略
                    pass
        
        return result 