"""
Price Features Plugin

This package provides price-based feature calculations.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional

from ....registry import FeaturePluginBase

logger = logging.getLogger(__name__)


class PriceFeaturePlugin(FeaturePluginBase):
    """
    Price Feature Plugin
    
    Provides various price-based feature calculations.
    """
    
    PLUGIN_INFO = {
        'name': 'price_features',
        'version': '0.1.0',
        'description': 'Provides price-based feature calculations, like technical indicators',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'plugin_type': 'feature',
        'tags': ['price', 'technical', 'indicator'],
        'compatibility': {
            'phunt_api_version': '>=0.7.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        Initialize the price feature plugin
        """
        super().__init__()
        logger.info("Initializing PriceFeaturePlugin")
    
    def calculate_rsi(self, data: pd.DataFrame, period: int = 14, price_col: str = 'close') -> pd.DataFrame:
        """
        Calculate Relative Strength Index (RSI)
        
        Args:
            data: Input DataFrame with price data
            period: RSI period
            price_col: Column name for price data
            
        Returns:
            DataFrame with RSI values
        """
        if price_col not in data.columns:
            raise ValueError(f"Price column '{price_col}' not found in data")
        
        # Calculate price changes
        delta = data[price_col].diff()
        
        # Separate gains and losses
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=period).mean()
        avg_loss = loss.rolling(window=period).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        result[f'rsi_{period}'] = rsi
        
        return result
    
    def calculate_bollinger_bands(
        self, data: pd.DataFrame, period: int = 20, std_dev: float = 2.0, price_col: str = 'close'
    ) -> pd.DataFrame:
        """
        Calculate Bollinger Bands
        
        Args:
            data: Input DataFrame with price data
            period: Moving average period
            std_dev: Standard deviation multiplier
            price_col: Column name for price data
            
        Returns:
            DataFrame with Bollinger Bands values
        """
        if price_col not in data.columns:
            raise ValueError(f"Price column '{price_col}' not found in data")
        
        # Calculate middle band (SMA)
        middle = data[price_col].rolling(window=period).mean()
        
        # Calculate standard deviation
        std = data[price_col].rolling(window=period).std()
        
        # Calculate upper and lower bands
        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)
        
        # Create result DataFrame
        result = pd.DataFrame(index=data.index)
        result[f'bb_middle_{period}'] = middle
        result[f'bb_upper_{period}'] = upper
        result[f'bb_lower_{period}'] = lower
        result[f'bb_width_{period}'] = (upper - lower) / middle
        
        return result
    
    def calculate_ema(
        self, data: pd.DataFrame, periods: List[int] = [9, 21, 50, 200], price_col: str = 'close'
    ) -> pd.DataFrame:
        """
        Calculate Exponential Moving Average (EMA)
        
        Args:
            data: Input DataFrame with price data
            periods: List of EMA periods
            price_col: Column name for price data
            
        Returns:
            DataFrame with EMA values
        """
        if price_col not in data.columns:
            raise ValueError(f"Price column '{price_col}' not found in data")
        
        result = pd.DataFrame(index=data.index)
        
        for period in periods:
            ema = data[price_col].ewm(span=period, adjust=False).mean()
            result[f'ema_{period}'] = ema
        
        return result
    
    def get_plugin_functions(self) -> List[str]:
        """
        Get the list of available functions in this plugin
        
        Returns:
            List of function names
        """
        return [
            'calculate_rsi',
            'calculate_bollinger_bands',
            'calculate_ema'
        ]


# エントリーポイント用関数
def get_plugin_class():
    """
    Entry point function to get the plugin class
    
    Returns:
        The plugin class
    """
    return PriceFeaturePlugin 