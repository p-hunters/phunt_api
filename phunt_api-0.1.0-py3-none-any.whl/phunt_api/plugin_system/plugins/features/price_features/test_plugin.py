"""
Price Features Plugin Test

This module tests the price features plugin functionality.
"""

import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from phunt_api import PHuntAPI
from phunt_api.plugin_system.plugins.price_features import PriceFeaturePlugin

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_plugin_directly():
    """プラグインを直接使用したテスト"""
    logger.info("=== プラグインを直接使用したテスト ===")
    
    # プラグインのインスタンス化
    plugin = PriceFeaturePlugin()
    
    # サンプルデータの作成
    dates = pd.date_range(start='2023-01-01', periods=100)
    prices = pd.Series(
        data=100 + np.cumsum(np.random.normal(0, 1, 100)),
        index=dates
    )
    logger.info(f"サンプルデータ: {len(prices)}行のデータを生成")
    
    # リターンの計算
    logger.info("\nリターンの計算...")
    returns = plugin.calculate_returns(prices, periods=[1, 5, 10])
    logger.info(f"リターン計算結果: {returns.shape}, カラム: {returns.columns.tolist()}")
    
    # 移動平均の計算
    logger.info("\n移動平均の計算...")
    ma = plugin.calculate_moving_averages(prices, windows=[5, 10, 20])
    logger.info(f"移動平均計算結果: {ma.shape}, カラム: {ma.columns.tolist()}")
    
    # 統計的モーメントの計算
    logger.info("\n統計的モーメントの計算...")
    moments = plugin.calculate_statistical_moments(returns['return_1'], windows=[10, 20])
    logger.info(f"統計的モーメント計算結果: {moments.shape}, カラム: {moments.columns.tolist()}")
    
    # テクニカル指標の計算
    logger.info("\nテクニカル指標の計算...")
    indicators = plugin.calculate_technical_indicators(
        prices, indicators=['rsi', 'macd', 'bollinger']
    )
    logger.info(f"テクニカル指標計算結果: {indicators.shape}, カラム: {indicators.columns.tolist()}")
    
    # 結果のプロット
    plt.figure(figsize=(15, 10))
    
    # 価格と移動平均
    plt.subplot(3, 1, 1)
    plt.plot(dates, prices, label='Price')
    plt.plot(dates, ma['ma_5'], label='MA(5)')
    plt.plot(dates, ma['ma_10'], label='MA(10)')
    plt.plot(dates, ma['ma_20'], label='MA(20)')
    plt.title('Price and Moving Averages')
    plt.legend()
    
    # RSI
    plt.subplot(3, 1, 2)
    plt.plot(dates, indicators['rsi'])
    plt.axhline(y=70, color='r', linestyle='-')
    plt.axhline(y=30, color='g', linestyle='-')
    plt.title('RSI(14)')
    
    # ボリンジャーバンド
    plt.subplot(3, 1, 3)
    plt.plot(dates, prices, label='Price')
    plt.plot(dates, indicators['bollinger_upper'], label='Upper Band')
    plt.plot(dates, indicators['bollinger_middle'], label='Middle Band')
    plt.plot(dates, indicators['bollinger_lower'], label='Lower Band')
    plt.title('Bollinger Bands')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('price_features_test.png')
    logger.info("結果を'price_features_test.png'に保存しました")

def test_with_phunt_api():
    """PHuntAPIを通じたプラグインのテスト"""
    logger.info("\n=== PHuntAPIを通じたプラグインのテスト ===")
    
    # PHuntAPIのインスタンス化
    api = PHuntAPI(debug=True)
    
    # サンプルデータの作成
    dates = pd.date_range(start='2023-01-01', periods=100)
    data = pd.DataFrame({
        'open': 100 + np.cumsum(np.random.normal(0, 1, 100)),
        'high': 100 + np.cumsum(np.random.normal(0, 1, 100)) + np.random.uniform(0, 2, 100),
        'low': 100 + np.cumsum(np.random.normal(0, 1, 100)) - np.random.uniform(0, 2, 100),
        'close': 100 + np.cumsum(np.random.normal(0, 1, 100)),
        'volume': np.random.uniform(1000, 5000, 100)
    }, index=dates)
    logger.info(f"サンプルOHLCVデータ: {data.shape}")
    
    # プラグイン情報の取得
    logger.info("\nプラグイン情報の取得...")
    plugins = api.list_plugins()
    price_plugin = None
    for plugin in plugins:
        if plugin['name'] == 'price_features':
            price_plugin = plugin
            break
    
    if price_plugin:
        logger.info(f"price_featuresプラグインが見つかりました: {price_plugin['info']['version']}")
        
        # プラグイン関数の取得
        functions = api.get_plugin_functions('price_features')
        logger.info(f"利用可能な関数: {functions}")
        
        # プラグイン関数の実行
        logger.info("\nプラグイン関数を実行...")
        
        # リターンの計算
        returns = api.get_plugin_feature(
            plugin_name='price_features',
            function_name='calculate_returns',
            prices=data['close'],
            periods=[1, 5, 10]
        )
        logger.info(f"リターン計算結果: {returns.shape}, カラム: {returns.columns.tolist()}")
        
        # テクニカル指標の計算
        indicators = api.get_plugin_feature(
            plugin_name='price_features',
            function_name='calculate_technical_indicators',
            prices=data,
            indicators=['rsi', 'macd', 'bollinger'],
            ohlcv_columns={
                'open': 'open',
                'high': 'high',
                'low': 'low',
                'close': 'close',
                'volume': 'volume'
            }
        )
        logger.info(f"テクニカル指標計算結果: {indicators.shape}, カラム: {indicators.columns.tolist()}")
        
        # 特徴量として登録
        feature_id = api.register_plugin_feature(
            feature_name='price_technicals',
            plugin_name='price_features',
            function_name='calculate_technical_indicators',
            prices=data,
            indicators=['rsi', 'macd']
        )
        logger.info(f"特徴量登録結果: {feature_id}")
    else:
        logger.warning("price_featuresプラグインが見つかりませんでした")

def test_with_different_backends():
    """異なるバックエンドでのテスト"""
    logger.info("\n=== 異なるバックエンドでのテスト ===")
    
    # プラグインのインスタンス化
    plugin = PriceFeaturePlugin()
    
    # サンプルデータの作成
    dates = pd.date_range(start='2023-01-01', periods=100)
    prices = pd.Series(
        data=100 + np.cumsum(np.random.normal(0, 1, 100)),
        index=dates
    )
    
    # pandasバックエンド
    logger.info("\npandasバックエンドでのテスト...")
    plugin.set_backend('pandas')
    returns_pandas = plugin.calculate_returns(prices, periods=[1, 5])
    logger.info(f"pandas結果: {returns_pandas.shape}, カラム: {returns_pandas.columns.tolist()}")
    
    # polarsバックエンド
    try:
        logger.info("\npolarsバックエンドでのテスト...")
        plugin.set_backend('polars')
        returns_polars = plugin.calculate_returns(prices, periods=[1, 5])
        logger.info(f"polars結果: {type(returns_polars)}, カラム: {returns_polars.columns}")
    except Exception as e:
        logger.error(f"polarsバックエンドでのエラー: {str(e)}")
    
    # DuckDBバックエンド（シンプルなテストのみ）
    try:
        logger.info("\nDuckDBバックエンドでのテスト...")
        results = plugin.calculate_returns(prices, periods=[1], backend='duckdb')
        logger.info(f"DuckDB結果: {type(results)}")
    except Exception as e:
        logger.error(f"DuckDBバックエンドでのエラー: {str(e)}")

def main():
    """メイン関数"""
    logger.info("=== Price Features Plugin Test ===")
    
    # 直接プラグインを使用したテスト
    test_plugin_directly()
    
    # PHuntAPIを通じたテスト
    test_with_phunt_api()
    
    # 異なるバックエンドでのテスト
    test_with_different_backends()
    
    logger.info("=== テスト完了 ===")

if __name__ == "__main__":
    main() 