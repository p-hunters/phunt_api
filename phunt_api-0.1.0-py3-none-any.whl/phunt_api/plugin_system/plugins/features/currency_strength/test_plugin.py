"""
通貨強弱計算プラグインのテスト

このスクリプトは、CurrencyStrengthPluginの機能をテストします。
"""

import os
import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 通貨強弱プラグインのインポート
from .plugin import CurrencyStrengthPlugin
from phunt_api.api import PHuntAPI


def test_plugin_directly():
    """プラグインを直接使用したテスト"""
    logger.info("=== 通貨強弱計算プラグイン テスト ===")
    logger.info("=== プラグインを直接使用したテスト ===")
    
    # プラグインのインスタンス化
    plugin = CurrencyStrengthPlugin()
    
    # テスト用サンプルデータの準備 (実行環境に依存)
    # 注: 実際のテストではデータディレクトリに該当ファイルが必要
    # サンプルではモックデータを使用
    
    # テストシンボルの定義
    symbols = ["USDJPY", "EURUSD", "GBPJPY", "AUDUSD", "EURJPY"]
    year = 2024
    
    # モックデータ作成（実際のデータが無い場合のフォールバック）
    if not os.path.exists(f'{plugin.data_dir}/{symbols[0]}_1MIN_{year}.parquet'):
        logger.warning(f"テスト用データが {plugin.data_dir} に見つかりません。モックデータを生成します。")
        create_mock_data(plugin.data_dir, symbols, year)
    
    try:
        # 通貨強弱の計算
        logger.info("\n基本通貨強弱の計算...")
        strengths = plugin.get_currency_strength(symbols, year)
        if strengths.empty:
            logger.warning("通貨強弱データが空です。テストを中止します。")
            return
        
        logger.info(f"通貨強弱計算結果: {strengths.shape}, カラム: {strengths.columns.tolist()}")
        
        # 特定の通貨の強弱
        selected_currencies = ["USD", "JPY", "EUR"]
        logger.info(f"\n特定通貨 {selected_currencies} の強弱を抽出...")
        selected_strengths = plugin.strength_selected(strengths, selected_currencies)
        logger.info(f"抽出結果: {selected_strengths.shape}, カラム: {selected_strengths.columns.tolist()}")
        
        # 複数時間枠の通貨強弱
        logger.info("\n複数時間枠の通貨強弱を計算...")
        multi_tf_strengths = plugin.calculate_multi_timeframe_strength(symbols, year, windows=[5, 15, 60])
        logger.info(f"複数時間枠結果: {multi_tf_strengths.shape}, カラム: {multi_tf_strengths.columns.tolist()}")
        
        # 通貨ペアの強弱比率
        logger.info("\n通貨ペアの強弱比率を計算...")
        pair_ratio = plugin.calculate_pair_strength_ratio(symbols, "EUR", "USD", year)
        logger.info(f"通貨ペア強弱比率結果: {pair_ratio.shape}, カラム: {pair_ratio.columns.tolist()}")
        
        # 結果の可視化
        visualize_results(strengths, selected_strengths, multi_tf_strengths, pair_ratio)
        
    except Exception as e:
        logger.error(f"テスト中にエラーが発生しました: {e}")
        import traceback
        logger.error(traceback.format_exc())
    

def test_with_phunt_api():
    """PHuntAPIを通じたプラグインのテスト"""
    logger.info("\n=== PHuntAPIを通じたプラグインのテスト ===")
    
    # PHuntAPIのインスタンス化
    api = PHuntAPI(debug=True)
    
    # テストシンボルの定義
    symbols = ["USDJPY", "EURUSD", "GBPJPY", "AUDUSD", "EURJPY"]
    year = 2024
    
    # プラグイン情報の取得
    logger.info("\nプラグイン情報の取得...")
    plugin_name = "currency_strength"
    
    # プラグインの関数を取得
    functions = api._plugin_feature_api.get_plugin_functions(plugin_name)
    if functions:
        logger.info(f"{plugin_name}プラグインの関数が見つかりました: {functions}")
    else:
        logger.error(f"{plugin_name}プラグインの関数が見つかりません")
        return
    
    try:
        # モックデータの準備（実際のデータがない場合）
        data_dir = os.environ.get('DATA_DIR', '../data')
        if not os.path.exists(f'{data_dir}/{symbols[0]}_1MIN_{year}.parquet'):
            logger.warning(f"テスト用データが {data_dir} に見つかりません。モックデータを生成します。")
            create_mock_data(data_dir, symbols, year)
            
        # プラグイン関数の実行
        logger.info("\nプラグイン関数を実行...")
        
        # 通貨強弱の計算
        strengths = api._plugin_feature_api.get_plugin_feature(
            plugin_name=plugin_name,
            function_name="get_currency_strength",
            symbols=symbols,
            year=year
        )
        logger.info(f"通貨強弱計算結果: {strengths.shape}, カラム: {strengths.columns.tolist()}")
        
        # 特定通貨の強弱を抽出
        selected_currencies = ["USD", "JPY", "EUR"]
        selected_strengths = api._plugin_feature_api.get_plugin_feature(
            plugin_name=plugin_name,
            function_name="strength_selected",
            strengths=strengths,
            currencies=selected_currencies
        )
        logger.info(f"特定通貨強弱結果: {selected_strengths.shape}, カラム: {selected_strengths.columns.tolist()}")
        
        # 特徴量として登録
        feature_id = api.register_plugin_feature(
            feature_name='currency_strength_feature',
            plugin_name=plugin_name,
            function_name='get_currency_strength',
            symbols=symbols,
            year=year
        )
        logger.info(f"特徴量登録結果: {feature_id}")
        
        # 結果の可視化
        plt.figure(figsize=(15, 10))
        
        # 通貨強弱の推移
        plt.subplot(2, 1, 1)
        for col in selected_strengths.columns:
            selected_strengths[col].plot(label=col)
        
        plt.title('通貨強弱の推移')
        plt.xlabel('時間')
        plt.ylabel('強度 (標準化済み)')
        plt.legend()
        plt.grid(True)
        
        # 通貨別の強度分布
        plt.subplot(2, 1, 2)
        selected_strengths.boxplot()
        plt.title('通貨別の強度分布')
        plt.ylabel('強度 (標準化済み)')
        plt.grid(True)
        
        plt.tight_layout()
        plt.savefig('currency_strength_test.png')
        logger.info("結果を'currency_strength_test.png'に保存しました")
        
    except Exception as e:
        logger.error(f"テスト中にエラーが発生しました: {e}")
        import traceback
        logger.error(traceback.format_exc())


def create_mock_data(data_dir, symbols, year):
    """テスト用のモックデータを作成する"""
    os.makedirs(data_dir, exist_ok=True)
    
    # 基準日時
    start_date = datetime(year, 1, 1)
    end_date = start_date + timedelta(days=3)  # 3日分のデータ
    
    # 1分足のタイムスタンプを生成
    minutes = int((end_date - start_date).total_seconds() / 60)
    timestamps = [(start_date + timedelta(minutes=i)).timestamp() * 1000 for i in range(minutes)]
    
    for symbol in symbols:
        # ランダムな価格データを生成
        base_price = 100.0 if "JPY" in symbol else 1.0  # 日本円ペアは3桁、それ以外は5桁
        decimals = 2 if "JPY" in symbol else 5
        
        # 価格系列を生成 (ランダムウォーク)
        np.random.seed(42)  # 再現性のため
        returns = np.random.normal(0, 0.0001, minutes)
        price_series = base_price * np.exp(np.cumsum(returns))
        
        # 価格を指定した小数点に丸める
        price_series = np.round(price_series, decimals)
        
        # スプレッドを生成
        spreads = np.random.uniform(0.1, 0.5, minutes) / (10**decimals)
        
        # DataFrame作成
        df = pd.DataFrame({
            'timestamp': timestamps,
            'open': price_series,
            'high': price_series * (1 + np.random.uniform(0, 0.001, minutes)),
            'low': price_series * (1 - np.random.uniform(0, 0.001, minutes)),
            'close': price_series,
            'volume': np.random.randint(1, 100, minutes),
            'spread': spreads
        })
        
        # パーケットファイルとして保存
        filepath = f'{data_dir}/{symbol}_1MIN_{year}.parquet'
        df.to_parquet(filepath, index=False)
        logger.info(f"モックデータを作成しました: {filepath}")


def visualize_results(strengths, selected_strengths, multi_tf_strengths, pair_ratio):
    """結果を可視化する"""
    plt.figure(figsize=(15, 15))
    
    # 1. すべての通貨強弱の推移
    plt.subplot(3, 1, 1)
    for col in strengths.columns:
        strengths[col].plot(label=col)
    
    plt.title('全通貨の強弱推移')
    plt.xlabel('時間')
    plt.ylabel('強度 (標準化済み)')
    plt.legend()
    plt.grid(True)
    
    # 2. 選択した通貨の強弱推移
    plt.subplot(3, 1, 2)
    for col in selected_strengths.columns:
        selected_strengths[col].plot(label=col)
    
    plt.title('選択通貨の強弱推移')
    plt.xlabel('時間')
    plt.ylabel('強度 (標準化済み)')
    plt.legend()
    plt.grid(True)
    
    # 3. 通貨ペアの強弱比率
    plt.subplot(3, 1, 3)
    pair_name = [col for col in pair_ratio.columns if 'ratio' in col][0]
    pair_ratio[pair_name].plot(label=pair_name)
    
    plt.title('通貨ペアの強弱比率')
    plt.xlabel('時間')
    plt.ylabel('比率')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('currency_strength_results.png')
    logger.info("結果を'currency_strength_results.png'に保存しました")


def main():
    """メイン実行関数"""
    try:
        test_plugin_directly()
        test_with_phunt_api()
        logger.info("=== テスト完了 ===")
    except Exception as e:
        logger.error(f"メイン実行中にエラーが発生しました: {e}")
        import traceback
        logger.error(traceback.format_exc())


if __name__ == "__main__":
    main() 