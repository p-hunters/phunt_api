"""
通貨強弱計算プラグイン

このモジュールは、外国為替市場における通貨の相対的な強さ・弱さを計算するための
プラグインを実装しています。
"""

import os
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timezone
from typing import List, Dict, Optional, Union, Tuple, Any

from phunt_api.plugin_system.registry import FeaturePluginBase


class CurrencyStrengthPlugin(FeaturePluginBase):
    """
    通貨強弱計算プラグイン
    
    このプラグインは、外国為替市場における通貨の相対的な強さ・弱さを計算する機能を提供します。
    複数の通貨ペアから各通貨の強度を抽出し、トレード戦略や市場分析に活用できる指標を生成します。
    """
    
    PLUGIN_INFO = {
        "name": "currency_strength",
        "version": "1.0.0",
        "description": "通貨強弱計算プラグイン",
        "author": "PHuntAPI Team",
        "license": "MIT",
        "backends": ["pandas"],
        "tags": ["forex", "currency", "analysis", "strength", "trading"],
        "dependencies": {
            "numpy": ">=1.20.0",
            "pandas": ">=1.3.0"
        },
        "compatibility": {
            "phunt_api_version": ">=0.5.0",
            "python_version": ">=3.7.0",
        }
    }
    
    def __init__(self):
        """通貨強弱計算プラグインの初期化"""
        super().__init__()
        self.data_dir = os.environ.get('DATA_DIR', '../data')
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"通貨強弱計算プラグインを初期化しました。データディレクトリ: {self.data_dir}")
    
    def get_1min_bar(self, symbol: str, year: int) -> pd.DataFrame:
        """
        指定された通貨ペアと年の1分足データを取得します。
        
        Args:
            symbol: 通貨ペア (例: "USDJPY")
            year: データの年 (例: 2024)
            
        Returns:
            整形された1分足データフレーム
        """
        df = pd.read_parquet(f'{self.data_dir}/{symbol}_1MIN_{year}.parquet')
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('datetime', inplace=True)
        pip_factor = 1/10**(max(df.close.astype(str).apply(lambda x: len(x.split('.')[1])).values)-1)
        df['spread'] = df['spread'] * pip_factor
        df['close'] = df['close'] - df['spread'] / 2
        self.logger.info(f'{symbol} spread_max: {df.spread.max()}, spread_min: {df.spread.min()}, pip_factor: {pip_factor}')
        return df
    
    def get_log_changes(self, symbols: List[str], year: int) -> pd.DataFrame:
        """
        複数の通貨ペアのログリターンを計算します。
        
        Args:
            symbols: 通貨ペアのリスト
            year: データの年
            
        Returns:
            各通貨ペアのログリターンを含むデータフレーム
        """
        dfs = []
        for symbol in symbols:
            try:
                df = self.get_1min_bar(symbol, year)
                df[symbol] = np.log(df['close'] / df['close'].iloc[0])
                dfs.append(df[[symbol]])
            except Exception as e:
                self.logger.error(f"{symbol}のデータ取得中にエラーが発生しました: {e}")
        
        if not dfs:
            self.logger.warning("有効なデータが取得できませんでした")
            return pd.DataFrame()
            
        return pd.concat(dfs, axis=1)
    
    def calc_strength(self, symbols: List[str], currency: str, year: int) -> pd.DataFrame:
        """
        特定の通貨の強さを計算します。
        
        Args:
            symbols: 通貨ペアのリスト
            currency: 強さを計算する通貨 (例: "USD")
            year: データの年
            
        Returns:
            通貨の強さを表すデータフレーム
        """
        df_changes = self.get_log_changes(symbols, year)
        
        def strength_sign(symbol, currency):
            # 通貨ペアの順序に基づいて、符号を決定
            base = symbol[:3]
            quote = symbol[3:]
            
            if base == currency:
                return 1  # 通貨がベース通貨の場合、正の符号
            elif quote == currency:
                return -1  # 通貨がクォート通貨の場合、負の符号
            else:
                return 0  # 通貨が含まれていない場合

        # 特定の通貨を含むシンボルを抽出
        currency_symbols = [s for s in symbols if currency in s[:3] or currency in s[3:]]
        
        # 各シンボルの符号を計算し、それに基づいて強度を計算
        df_strength = pd.DataFrame(index=df_changes.index)
        df_strength[f"{currency}_strength"] = sum(
            strength_sign(symbol, currency) * df_changes[symbol] 
            for symbol in currency_symbols if symbol in df_changes.columns
        )
        
        return df_strength
    
    def extract_currencies(self, symbols: List[str]) -> List[str]:
        """
        通貨ペアのリストから一意の通貨を抽出します。
        
        Args:
            symbols: 通貨ペアのリスト (例: ["USDJPY", "EURUSD"])
            
        Returns:
            一意の通貨のリスト (例: ["USD", "JPY", "EUR"])
        """
        currencies = set()
        for symbol in symbols:
            currencies.add(symbol[:3])
            currencies.add(symbol[3:])
        return sorted(list(currencies))
    
    def calc_all_currency_strength(self, symbols: List[str], year: int) -> pd.DataFrame:
        """
        すべての通貨の強さを計算します。
        
        Args:
            symbols: 通貨ペアのリスト
            year: データの年
            
        Returns:
            すべての通貨の強さを含むデータフレーム
        """
        currencies = self.extract_currencies(symbols)
        strengths = [self.calc_strength(symbols, currency, year) for currency in currencies]
        return pd.concat(strengths, axis=1)
    
    def get_currency_strength(self, symbols: List[str], year: int = 2024) -> pd.DataFrame:
        """
        通貨強弱特徴量を計算するメインメソッド。
        
        Args:
            symbols: 通貨ペアのリスト (例: ["USDJPY", "EURUSD", "GBPJPY"])
            year: データの年 (デフォルト: 2024)
            
        Returns:
            各通貨の強さを含むデータフレーム
        """
        self.logger.info(f"通貨強弱を計算します: {symbols}, 年: {year}")
        
        try:
            strengths = self.calc_all_currency_strength(symbols, year)
            # 通貨の強さを正規化（スケーリング）
            for col in strengths.columns:
                strengths[col] = (strengths[col] - strengths[col].mean()) / strengths[col].std()
            
            self.logger.info(f"通貨強弱計算完了: {len(strengths)} 行のデータを生成")
            return strengths
        except Exception as e:
            self.logger.error(f"通貨強弱計算中にエラーが発生しました: {e}")
            raise
    
    def strength_selected(self, strengths: pd.DataFrame, currencies: List[str] = None) -> pd.DataFrame:
        """
        特定の通貨のみの強度を抽出します。
        
        Args:
            strengths: 通貨強弱データフレーム
            currencies: 抽出する通貨のリスト (指定がなければすべて)
            
        Returns:
            選択された通貨の強さを含むデータフレーム
        """
        if currencies is None:
            return strengths
        
        selected_cols = [f"{currency}_strength" for currency in currencies 
                         if f"{currency}_strength" in strengths.columns]
        
        if not selected_cols:
            self.logger.warning(f"指定された通貨 {currencies} は通貨強弱データに存在しません")
            return pd.DataFrame(index=strengths.index)
            
        return strengths[selected_cols]
    
    def create_strength_target(self, strengths: pd.DataFrame, target_currency: str = 'JPY', 
                              min_period: int = 7) -> pd.DataFrame:
        """
        ターゲット通貨に対するリスク調整済みリターンを計算します。
        
        Args:
            strengths: 通貨強弱データフレーム
            target_currency: ターゲット通貨 (デフォルト: 'JPY')
            min_period: 最小期間 (分) (デフォルト: 7)
            
        Returns:
            特定通貨に対するターゲット値を含むデータフレーム
        """
        target_col = f"{target_currency}_strength"
        if target_col not in strengths.columns:
            self.logger.error(f"ターゲット通貨 {target_currency} のデータが存在しません")
            return pd.DataFrame(index=strengths.index)
        
        # ターゲット値の計算 (将来の値幅)
        result = pd.DataFrame(index=strengths.index)
        
        # 1分後から特定期間のリターンを計算
        future_return = strengths[target_col].shift(-1) - strengths[target_col].shift(-(min_period+1))
        
        # リスク調整済みリターン
        risk = strengths[target_col].rolling(min_period).std()
        result['target'] = future_return / (risk + 1e-8)  # ゼロ除算を防ぐ
        
        return result
    
    def calculate_pair_strength_ratio(self, symbols: List[str], base_currency: str, 
                                     quote_currency: str, year: int) -> pd.DataFrame:
        """
        通貨ペアの強弱比率を計算します。
        
        Args:
            symbols: 通貨ペアのリスト
            base_currency: ベース通貨 (例: "EUR")
            quote_currency: クォート通貨 (例: "USD")
            year: データの年
            
        Returns:
            通貨ペアの強弱比率を含むデータフレーム
        """
        strengths = self.get_currency_strength(symbols, year)
        
        base_col = f"{base_currency}_strength"
        quote_col = f"{quote_currency}_strength"
        
        if base_col not in strengths.columns or quote_col not in strengths.columns:
            self.logger.error(f"指定された通貨 {base_currency} または {quote_currency} のデータがありません")
            return pd.DataFrame(index=strengths.index)
        
        result = pd.DataFrame(index=strengths.index)
        result[f"{base_currency}{quote_currency}_ratio"] = strengths[base_col] - strengths[quote_col]
        result[f"{base_currency}_strength"] = strengths[base_col]
        result[f"{quote_currency}_strength"] = strengths[quote_col]
        
        return result
    
    def calculate_multi_timeframe_strength(self, symbols: List[str], year: int, 
                                          windows: List[int] = [5, 15, 60, 240]) -> pd.DataFrame:
        """
        複数の時間枠での通貨強弱を計算します。
        
        Args:
            symbols: 通貨ペアのリスト
            year: データの年
            windows: 移動平均の期間リスト（分）
            
        Returns:
            異なる時間枠での通貨強弱を含むデータフレーム
        """
        # 基本の通貨強弱を取得
        strengths = self.get_currency_strength(symbols, year)
        
        # 結果のデータフレーム
        result = pd.DataFrame(index=strengths.index)
        
        # 各通貨と時間枠について移動平均を計算
        for col in strengths.columns:
            currency = col.split('_')[0]
            result[col] = strengths[col]  # 元の値をコピー
            
            # 各時間枠で移動平均を計算
            for window in windows:
                result[f"{currency}_strength_{window}m"] = strengths[col].rolling(window).mean()
        
        return result 