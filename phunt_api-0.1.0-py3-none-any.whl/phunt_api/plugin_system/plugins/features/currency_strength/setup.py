from setuptools import setup, find_packages

setup(
    name="phunt-currency-strength",
    version="1.0.0",
    description="通貨強弱計算プラグイン for PHuntAPI",
    author="PHuntAPI Team",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.20.0",
        "pandas>=1.3.0",
        "matplotlib>=3.4.0",
    ],
    entry_points={
        "phunt.feature_plugins": [
            "currency_strength=currency_strength.plugin:CurrencyStrengthPlugin",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
) 