"""
PHunt API Target Plugins

This package contains target calculation plugins for the PHunt API.
""" 