"""
Price Targets Plugin

This plugin implements various price-based target calculations.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple, Optional

from ...target_registry import TargetPluginBase

logger = logging.getLogger(__name__)


class PriceTargetPlugin(TargetPluginBase):
    """
    Price Target Plugin
    
    Provides various price-based target calculations.
    """
    
    PLUGIN_INFO = {
        'name': 'price_targets',
        'version': '0.1.0',
        'description': 'Provides price-based target calculations, like future returns and price movements',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'plugin_type': 'target',
        'tags': ['price', 'target', 'return', 'movement'],
        'compatibility': {
            'phunt_api_version': '>=0.7.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def __init__(self):
        """
        Initialize the price target plugin
        """
        super().__init__()
        logger.info("Initializing PriceTargetPlugin")
    
    def calculate_target(self, data: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """
        Calculate a target based on the provided parameters
        
        Args:
            data: Input DataFrame with price data
            **kwargs: Additional parameters
                - target_type: Type of target to calculate ('future_return', 'price_movement', etc.)
                - periods: List of periods for calculation (e.g. [1, 5, 10])
                - price_col: Column name for price data (default: 'close')
                - threshold: Optional threshold for binary targets
                
        Returns:
            DataFrame with calculated targets
        """
        target_type = kwargs.get('target_type', 'future_return')
        periods = kwargs.get('periods', [1])
        price_col = kwargs.get('price_col', 'close')
        threshold = kwargs.get('threshold', None)
        
        if price_col not in data.columns:
            raise ValueError(f"Price column '{price_col}' not found in data")
        
        if target_type == 'future_return':
            return self.calculate_future_return(data, periods, price_col, threshold)
        elif target_type == 'price_movement':
            return self.calculate_price_movement(data, periods, price_col, threshold)
        elif target_type == 'volatility_target':
            return self.calculate_volatility_target(data, periods, price_col, threshold)
        else:
            raise ValueError(f"Unknown target type: {target_type}")
    
    def calculate_future_return(
        self, data: pd.DataFrame, periods: List[int], price_col: str, threshold: Optional[float] = None
    ) -> pd.DataFrame:
        """
        Calculate future returns for specified periods
        
        Args:
            data: Input DataFrame with price data
            periods: List of periods for calculation
            price_col: Column name for price data
            threshold: Optional threshold for binary targets
            
        Returns:
            DataFrame with future return targets
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            logger.warning("Input data does not have DatetimeIndex, some calculations may not work properly")
        
        result = pd.DataFrame(index=data.index)
        prices = data[price_col]
        
        for period in periods:
            # Calculate future return
            future_price = prices.shift(-period)
            pct_change = (future_price - prices) / prices
            result[f'future_return_{period}'] = pct_change
            
            # Add binary target if threshold is provided
            if threshold is not None:
                result[f'future_return_binary_{period}'] = np.where(pct_change > threshold, 1, 0)
        
        return result
    
    def calculate_price_movement(
        self, data: pd.DataFrame, periods: List[int], price_col: str, threshold: Optional[float] = None
    ) -> pd.DataFrame:
        """
        Calculate price movement direction for specified periods
        
        Args:
            data: Input DataFrame with price data
            periods: List of periods for calculation
            price_col: Column name for price data
            threshold: Optional threshold for significant movement (in percentage)
            
        Returns:
            DataFrame with price movement targets
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            logger.warning("Input data does not have DatetimeIndex, some calculations may not work properly")
        
        result = pd.DataFrame(index=data.index)
        prices = data[price_col]
        
        for period in periods:
            # Calculate future price
            future_price = prices.shift(-period)
            pct_change = (future_price - prices) / prices
            
            # Direction: 1 (up), 0 (down)
            result[f'price_direction_{period}'] = np.where(future_price > prices, 1, 0)
            
            # Movement with threshold: 1 (up significantly), 0 (flat), -1 (down significantly)
            if threshold is not None:
                movement = np.zeros_like(pct_change, dtype=int)
                movement = np.where(pct_change > threshold, 1, movement)
                movement = np.where(pct_change < -threshold, -1, movement)
                result[f'price_movement_{period}'] = movement
        
        return result
    
    def calculate_volatility_target(
        self, data: pd.DataFrame, periods: List[int], price_col: str, threshold: Optional[float] = None
    ) -> pd.DataFrame:
        """
        Calculate future volatility-based targets
        
        Args:
            data: Input DataFrame with price data
            periods: List of periods for calculation
            price_col: Column name for price data
            threshold: Optional threshold for high volatility (default: None)
            
        Returns:
            DataFrame with volatility-based targets
        """
        if not isinstance(data.index, pd.DatetimeIndex):
            logger.warning("Input data does not have DatetimeIndex, some calculations may not work properly")
        
        result = pd.DataFrame(index=data.index)
        prices = data[price_col]
        
        for period in periods:
            # Calculate future price
            future_prices = pd.DataFrame()
            for i in range(1, period + 1):
                future_prices[f'price_{i}'] = prices.shift(-i)
            
            # Calculate max movement
            min_future = future_prices.min(axis=1)
            max_future = future_prices.max(axis=1)
            
            max_down = (min_future - prices) / prices
            max_up = (max_future - prices) / prices
            
            result[f'max_down_{period}'] = max_down
            result[f'max_up_{period}'] = max_up
            result[f'volatility_range_{period}'] = max_up - max_down
            
            # High volatility target (binary)
            if threshold is not None:
                result[f'high_volatility_{period}'] = np.where((max_up - max_down) > threshold, 1, 0)
        
        return result
    
    def get_plugin_functions(self) -> List[str]:
        """
        Get the list of available functions in this plugin
        
        Returns:
            List of function names
        """
        return [
            'calculate_target',
            'calculate_future_return',
            'calculate_price_movement',
            'calculate_volatility_target'
        ]


# エントリーポイント用関数
def get_plugin_class():
    """
    Entry point function to get the plugin class
    
    Returns:
        The plugin class
    """
    return PriceTargetPlugin 