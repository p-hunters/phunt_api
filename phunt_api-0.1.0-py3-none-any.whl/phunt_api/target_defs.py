# -*- coding: utf-8 -*-
"""
Target definitions for prediction goals.
"""

import pandas as pd
import numpy as np
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, Type

class TargetDefinition(ABC):
    """
    Abstract base class for target definitions.
    """
    
    def __init__(self, horizon: int = 1):
        self.horizon = horizon
        
    @abstractmethod
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate the target variable from the data.
        """
        pass
    
    @property
    def name(self) -> str:
        return f"{self.__class__.__name__}_{self.horizon}"

class FutureReturn(TargetDefinition):
    """
    Target: Percentage change over the horizon.
    """
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        if 'close' not in data.columns:
            raise ValueError("Data must contain 'close' column.")
        
        # Return = (Price_t+h - Price_t) / Price_t
        # shift(-h) gives Price_t+h at time t
        return data['close'].pct_change(periods=self.horizon).shift(-self.horizon)

class PriceDirection(TargetDefinition):
    """
    Target: Binary direction (1 if up, 0 if down/flat) over the horizon.
    """
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        if 'close' not in data.columns:
            raise ValueError("Data must contain 'close' column.")
            
        future_return = data['close'].shift(-self.horizon) - data['close']
        return (future_return > 0).astype(int)

class Volatility(TargetDefinition):
    """
    Target: Volatility (std dev of returns) over the horizon.
    Note: This is usually a feature, but can be a target for volatility prediction.
    Here we define it as *future* volatility.
    """
    def calculate(self, data: pd.DataFrame) -> pd.Series:
        if 'close' not in data.columns:
            raise ValueError("Data must contain 'close' column.")
            
        returns = data['close'].pct_change()
        # Future volatility: rolling std of returns starting from t+1
        # We can use rolling on reversed series or shift.
        # rolling(window=h).std() gives std of [t-h+1, t].
        # We want std of [t+1, t+h].
        # So we shift back by h (to align t+h window end to t) -> No, wait.
        # t+h window end at t+h.
        # shift(-h) aligns t+h to t.
        
        indexer = pd.api.indexers.FixedForwardWindowIndexer(window_size=self.horizon)
        return returns.rolling(window=indexer).std()

class TargetFactory:
    """
    Factory to create targets.
    """
    _registry: Dict[str, Type[TargetDefinition]] = {
        'FutureReturn': FutureReturn,
        'PriceDirection': PriceDirection,
        'Volatility': Volatility
    }
    
    @classmethod
    def register(cls, name: str, target_cls: Type[TargetDefinition]):
        cls._registry[name] = target_cls
        
    @classmethod
    def create(cls, name: str, **kwargs) -> TargetDefinition:
        if name not in cls._registry:
            raise ValueError(f"Target '{name}' not found in registry.")
        return cls._registry[name](**kwargs)
