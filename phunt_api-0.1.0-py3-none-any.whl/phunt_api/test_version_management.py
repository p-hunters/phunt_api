"""
プラグインのバージョン管理機能のテスト

このスクリプトは、プラグインのバージョン管理機能をテストします。
"""

import logging
from phunt_api import PHuntAPI
from phunt_api.plugin_system import FeaturePluginBase, FeaturePluginRegistry

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# テスト用のプラグインクラスを定義
class TestPluginV1(FeaturePluginBase):
    """テスト用プラグイン（バージョン1.0.0）"""
    
    PLUGIN_INFO = {
        'name': 'test_version_plugin',
        'version': '1.0.0',
        'description': 'Test plugin for version management',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'tags': ['test', 'version'],
        'compatibility': {
            'phunt_api_version': '>=0.5.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def calculate_test_feature(self, data):
        """テスト用の特徴量計算関数"""
        return data * 2

class TestPluginV2(FeaturePluginBase):
    """テスト用プラグイン（バージョン2.0.0）"""
    
    PLUGIN_INFO = {
        'name': 'test_version_plugin',
        'version': '2.0.0',
        'description': 'Test plugin for version management (v2)',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'tags': ['test', 'version'],
        'compatibility': {
            'phunt_api_version': '>=0.6.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def calculate_test_feature(self, data):
        """テスト用の特徴量計算関数（v2）"""
        return data * 3
    
    def calculate_new_feature(self, data):
        """新バージョンで追加された関数"""
        return data + 10

class TestPluginV1_1(FeaturePluginBase):
    """テスト用プラグイン（バージョン1.1.0）"""
    
    PLUGIN_INFO = {
        'name': 'test_version_plugin',
        'version': '1.1.0',
        'description': 'Test plugin for version management (v1.1)',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'tags': ['test', 'version'],
        'compatibility': {
            'phunt_api_version': '>=0.5.0',
            'python_version': '>=3.7.0',
        }
    }
    
    def calculate_test_feature(self, data):
        """テスト用の特徴量計算関数（v1.1）"""
        return data * 2.5

class IncompatiblePlugin(FeaturePluginBase):
    """互換性のないプラグイン"""
    
    PLUGIN_INFO = {
        'name': 'incompatible_plugin',
        'version': '1.0.0',
        'description': 'Incompatible plugin',
        'author': 'PHunt Team',
        'backends': ['pandas'],
        'tags': ['test'],
        'compatibility': {
            'phunt_api_version': '>=99.0.0',  # 互換性のないバージョン
            'python_version': '>=3.7.0',
        }
    }

def test_version_management():
    """
    バージョン管理機能をテストする
    """
    logger.info("=== プラグインのバージョン管理機能のテスト ===")
    
    # レジストリを直接初期化
    registry = FeaturePluginRegistry()
    
    # バージョン1.0.0のプラグインを登録
    logger.info("\n1. バージョン1.0.0のプラグインを登録...")
    plugin_v1 = TestPluginV1()
    success = registry.register_plugin(plugin_v1)
    logger.info(f"登録結果: {'成功' if success else '失敗'}")
    
    # 登録されたプラグインを確認
    plugins = registry.list_plugins()
    logger.info(f"登録済みプラグイン数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']} (v{plugin['info']['version']}): {plugin['info']['description']}")
    
    # バージョン1.1.0のプラグインを登録（アップグレード）
    logger.info("\n2. バージョン1.1.0のプラグインを登録（アップグレード）...")
    plugin_v1_1 = TestPluginV1_1()
    success = registry.register_plugin(plugin_v1_1)
    logger.info(f"登録結果: {'成功' if success else '失敗'}")
    
    # 登録されたプラグインを確認
    plugins = registry.list_plugins()
    logger.info(f"登録済みプラグイン数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']} (v{plugin['info']['version']}): {plugin['info']['description']}")
    
    # バージョン2.0.0のプラグインを登録（メジャーアップグレード）
    logger.info("\n3. バージョン2.0.0のプラグインを登録（メジャーアップグレード）...")
    plugin_v2 = TestPluginV2()
    success = registry.register_plugin(plugin_v2)
    logger.info(f"登録結果: {'成功' if success else '失敗'}")
    
    # 登録されたプラグインを確認
    plugins = registry.list_plugins()
    logger.info(f"登録済みプラグイン数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']} (v{plugin['info']['version']}): {plugin['info']['description']}")
    
    # バージョン1.0.0のプラグインを再登録（ダウングレード - 失敗するはず）
    logger.info("\n4. バージョン1.0.0のプラグインを再登録（ダウングレード - 失敗するはず）...")
    plugin_v1_again = TestPluginV1()
    success = registry.register_plugin(plugin_v1_again)
    logger.info(f"登録結果: {'成功' if success else '失敗'}")
    
    # バージョン競合を確認
    logger.info("\n5. バージョン競合を確認...")
    conflicts = registry.get_plugin_version_conflicts()
    if conflicts:
        logger.info(f"バージョン競合: {len(conflicts)} プラグイン")
        for name, versions in conflicts.items():
            logger.info(f"- {name}: {', '.join(versions)}")
    else:
        logger.info("バージョン競合はありません")
    
    # 互換性のないプラグインを登録（例外が発生するはず）
    logger.info("\n6. 互換性のないプラグインを登録（例外が発生するはず）...")
    try:
        incompatible_plugin = IncompatiblePlugin()
        logger.info("互換性のないプラグインのインスタンス化に成功（エラーが発生するはず）")
    except ValueError as e:
        logger.info(f"予想通りのエラーが発生: {str(e)}")
    
    logger.info("\n=== テスト完了 ===")


if __name__ == "__main__":
    test_version_management() 