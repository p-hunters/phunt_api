# -*- coding: utf-8 -*-

from typing import List, Dict, Any, Callable, Optional, Union, TYPE_CHECKING
from feast import FeatureView, Field, Entity
from feast.types import Float32, Int64
from .dataset import DatasetManager, PublicDatasetManager
from .exceptions import FeatureError
from .utils import create_from_local_base, upload_script_to_s3, FeastManager, query_s3_duckdb
import pandas as pd
import os
import inspect

class FeatureManager:
    def __init__(self, dataset_manager: DatasetManager):
        self.dataset_manager = dataset_manager
        self.feast_manager = FeastManager(dataset_manager.repo_path)
        self.creds = dataset_manager.creds
        self.cache = {}
    def create_feature(self, name: str, local_path: str, code_path: Optional[str] = None):
        try:
            return self.create_feature_from_local(name, local_path, code_path)
        except Exception as e:
            raise FeatureError(f"特徴量の作成中にエラーが発生しました: {str(e)}")

    def list_features(self) -> List[FeatureView]:
        try:
            return self.dataset_manager.list_datasets(view_type="feature")
        except Exception as e:
            raise FeatureError(f"特徴量のリスト取得中にエラーが発生しました: {str(e)}")

    def get_feature(self, feature_name: str, use_cache: bool=True) -> FeatureView:
        if use_cache and feature_name in self.cache:
            return self.cache[feature_name]
        feature_view = self.feast_manager.get_feature_view(feature_name)
        print(feature_view)
        entity_df = self._get_entity_df_for_feature_view(feature_view)
        print(entity_df)
        features_df = self.feast_manager.get_historical_features(feature_name, entity_df)
        self.cache[feature_name] = features_df
        return features_df
    
    def get_feature_code_path(self, feature_name: str) -> Optional[str]:
        feature_view = self.feast_manager.get_feature_view(feature_name)
        return feature_view.tags.get("code_path", None)

    def _get_entity_df_for_feature_view(self, feature_view) -> pd.DataFrame:
        path_to_parquet = f'{feature_view.batch_source.name}'
        entity_df = query_s3_duckdb(path_to_parquet, self.creds if self.creds is not None else {})
        # Ensure we return a DataFrame
        if entity_df is None:
            return pd.DataFrame()
        return entity_df

    def update_feature(self, feature_name: str, updated_definition: Dict[str, Any]) -> FeatureView:
        try:
            feature_view = self.get_feature(feature_name)
            updated_schema = [
                Field(name=field_name, dtype=self._get_feast_type(field_type))
                for field_name, field_type in updated_definition.items()
            ]
            feature_view.schema = updated_schema
            # Note: DatasetManager.update_dataset is expected to exist at runtime
            # even though the type checker can't verify it
            self.dataset_manager.update_dataset(feature_view)  # type: ignore
            return feature_view
        except Exception as e:
            raise FeatureError(f"特徴量の更新中にエラーが発生しました: {str(e)}")

    def delete_feature(self, feature_name: str) -> None:
        try:
            self.dataset_manager.delete_dataset(feature_name)
        except Exception as e:
            raise FeatureError(f"特徴量の削除中にエラーが発生しました: {str(e)}")

    def _get_feast_type(self, type_str: str) -> Any:
        type_mapping = {
            "float": Float32,
            "int": Int64,
            "float64": Float32,
            "int64": Int64,
            "float32": Float32,
            "int32": Int64,
        }
        return type_mapping.get(type_str.lower(), Float32)

    def submit_feature(self, name: str, processing_code: Optional[Callable] = None, df: Optional[pd.DataFrame] = None, api_instance: Any = None) -> str:
        try:
            import hashlib
            code_path = None
            
            if df is not None:
                processed_data = df
            elif processing_code is not None:
                # 処理コードにAPIインスタンスを渡して実行
                api_to_use = api_instance
                try:
                    processed_data = processing_code(api_to_use)
                except TypeError as e:
                    # 型エラーの場合は明確なメッセージを表示
                    raise FeatureError(f"processing_codeがPHuntAPIオブジェクトを受け入れません: {str(e)}")
                except Exception as e:
                    raise FeatureError(f"特徴量の生成中にエラーが発生しました: {str(e)}")
                
                code_string = inspect.getsource(processing_code)
                hash_object = hashlib.md5(code_string.encode())
                code_hash = hash_object.hexdigest()
                file_path = f"/tmp/feature_{name}.py"
                with open(file_path, 'w') as f:
                    f.write(code_string)
                print(f"Processing code saved to: {file_path}")
                code_path = upload_script_to_s3(file_path, code_hash)

            local_path = f"/tmp/{name}.parquet"
            processed_data.to_parquet(local_path)
            self.create_feature(name, local_path, code_path)
            return name

        except Exception as e:
            raise FeatureError(f"特徴量の登録中にエラーが発生しました: {str(e)}")

    def _generate_and_register_features(self, feature_name: str, processing_code: Callable) -> None:
        try:
            train_data = self.dataset_manager.get_dataset_split(feature_name, "train")
            test_data = self.dataset_manager.get_dataset_split(feature_name, "test")
            
            processed_train = processing_code(train_data)
            processed_test = processing_code(test_data)
            
            self._register_features(feature_name, processed_train, processed_test)
        except Exception as e:
            raise FeatureError(f"特徴量の生成と登録中にエラーが発生しました: {str(e)}")

    def _register_features(self, feature_name: str, train_features: pd.DataFrame, test_features: pd.DataFrame) -> None:
        try:
            feature_view = self.get_feature(feature_name)
            new_schema = [
                Field(name=col, dtype=self._get_feast_type(str(train_features[col].dtype)))
                for col in train_features.columns
            ]
            feature_view.schema = new_schema
            # Note: DatasetManager.update_dataset is expected to exist at runtime
            self.dataset_manager.update_dataset(feature_view)  # type: ignore
            
            self._upload_feature_data(feature_name, train_features, "train")
            self._upload_feature_data(feature_name, test_features, "test")
        except Exception as e:
            raise FeatureError(f"特徴量の登録中にエラーが発生しました: {str(e)}")

    def _upload_feature_data(self, feature_name: str, feature_data: pd.DataFrame, data_type: str) -> None:
        try:
            temp_file = f"/tmp/{feature_name}_{data_type}_features.parquet"
            feature_data.to_parquet(temp_file)
            # Note: DatasetManager.upload_file is expected to exist at runtime
            self.dataset_manager.upload_file(feature_name, temp_file)  # type: ignore
            os.remove(temp_file)
        except Exception as e:
            raise FeatureError(f"特徴量データのアップロード中にエラーが発生しました: {str(e)}")

    def create_feature_from_local(self, name: str, local_path: str, code_path: Optional[str] = None):
        # Pass empty string if code_path is None to satisfy type requirements
        actual_code_path = code_path if code_path is not None else ""
        return create_from_local_base(self.feast_manager, name, local_path, "feature", self.dataset_manager.sample_ratio, actual_code_path)

if __name__ == "__main__":
    try:
        # 使用例（内部用）
        dataset_manager = DatasetManager("/path/to/feast/repo")
        internal_feature_manager = FeatureManager(dataset_manager)

        # 使用例（公開用）
        public_dataset_manager = PublicDatasetManager("/path/to/feast/repo")
        # Note: PublicFeatureManager is not defined in this file
        # public_feature_manager = PublicFeatureManager(public_dataset_manager)

        # 特徴量作成の例
        def create_momentum_features(data):
            data['momentum_1d'] = data['close'].pct_change(1)
            data['momentum_5d'] = data['close'].pct_change(5)
            data['momentum_20d'] = data['close'].pct_change(20)
            return data[['momentum_1d', 'momentum_5d', 'momentum_20d']]

        # 公開APIを使用した特徴量の登録
        # public_feature_manager.submit_feature("price_momentum", "stock", create_momentum_features)

        # 特徴量のリスト取得（公開API）
        # feature_list = public_feature_manager.list_features()
        # print(f"登録された特徴量: {feature_list}")

    except FeatureError as e:
        print(f"特徴量操作中にエラーが発生しました: {str(e)}")
