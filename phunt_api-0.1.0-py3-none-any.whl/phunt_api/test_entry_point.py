"""
エントリーポイント検出機能のテスト

このスクリプトは、PHunt APIのエントリーポイント検出機能をテストします。
"""

import logging
import sys
import os
import pandas as pd
import numpy as np
from phunt_api import PHuntAPI
from phunt_api.plugin_system import FeaturePluginRegistry

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_entry_point_discovery():
    """
    エントリーポイント検出機能をテストする
    """
    logger.info("=== エントリーポイント検出機能のテスト ===")
    
    # Python環境の情報を表示
    logger.info(f"Python version: {sys.version}")
    logger.info(f"Python executable: {sys.executable}")
    
    # PHuntAPIの初期化
    logger.info("\n1. PHuntAPIを初期化中...")
    api = PHuntAPI(debug=True)
    logger.info("PHuntAPIを初期化しました。")
    
    # インストール済みのプラグインを一覧表示
    logger.info("\n2. インストール済みのプラグインを一覧表示...")
    plugins = api.list_plugins()
    logger.info(f"プラグインの数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']}: {plugin['info']['description']}")
    
    # 直接レジストリを使用してエントリーポイントを検出
    logger.info("\n3. 直接レジストリを使用してエントリーポイントを検出...")
    registry = FeaturePluginRegistry()
    registry.discover_plugins()
    
    # テスト用プラグインの関数を使用
    logger.info("\n4. テスト用プラグインの関数を使用...")
    try:
        # テスト用プラグインが見つかるか確認
        plugin_name = 'test_feature_plugin'
        functions = api.get_plugin_functions(plugin_name)
        logger.info(f"{plugin_name} の関数一覧:")
        for func in functions:
            logger.info(f"- {func}")
        
        # サンプルデータを生成
        logger.info("\n5. テスト用のサンプルデータを生成...")
        dates = pd.date_range(start='2022-01-01', periods=100)
        np.random.seed(42)
        close_prices = 100 + np.cumsum(np.random.normal(0, 1, 100))
        sample_data = pd.DataFrame({
            'date': dates,
            'close': close_prices
        }).set_index('date')
        logger.info("サンプルデータを生成しました:")
        logger.info(sample_data.head())
        
        # プラグイン機能を使用
        if 'calculate_moving_average' in functions:
            logger.info("\n6. プラグイン機能を使用して移動平均を計算...")
            ma_df = api.get_plugin_feature(
                plugin_name=plugin_name,
                function_name='calculate_moving_average',
                prices=sample_data['close'],
                window=20
            )
            logger.info("移動平均 計算結果:")
            logger.info(ma_df.head())
            logger.info("\n移動平均の計算に成功しました。")
        else:
            logger.warning("calculate_moving_average 関数が見つかりません")
        
        # EMA機能を使用
        if 'calculate_exponential_moving_average' in functions:
            logger.info("\n7. プラグイン機能を使用してEMAを計算...")
            ema_df = api.get_plugin_feature(
                plugin_name=plugin_name,
                function_name='calculate_exponential_moving_average',
                prices=sample_data['close'],
                span=20
            )
            logger.info("EMA 計算結果:")
            logger.info(ema_df.head())
            logger.info("\nEMAの計算に成功しました。")
        else:
            logger.warning("calculate_exponential_moving_average 関数が見つかりません")
            
    except Exception as e:
        logger.error(f"テスト中にエラーが発生: {str(e)}", exc_info=True)
    
    logger.info("\n=== テスト完了 ===")


if __name__ == "__main__":
    test_entry_point_discovery() 