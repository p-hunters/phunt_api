from typing import Optional
from ..datasource import DataSourceManager
from ..trade_signal import SignalManager
from ..exceptions import PHuntAPIException

class SignalUtils:
    """シグナル管理ユーティリティクラス"""
    
    def __init__(self):
        self._signal_manager = SignalManager()
    
    def add_signal(self, name: str, datasource: Optional[DataSourceManager]=None):
        """シグナルを追加する
        
        Args:
            name: シグナル名
            datasource: データソースマネージャー
            
        Raises:
            PHuntAPIException: データソースがNoneの場合
        """
        if datasource is None and name=='dukascopy':
            datasource = DataSourceManager(provider='Dukascopy', symbol='USDJPY', granularity='1min')
        # Ensure datasource is not None before calling add_feed
        if datasource is not None:
            self._signal_manager.add_feed(name, datasource)
        else:
            raise PHuntAPIException(f"Cannot add signal '{name}': datasource is None")

    def get_signal(self, name: str, start_date: str, end_date: str):
        """シグナルデータを取得する
        
        Args:
            name: シグナル名
            start_date: 開始日
            end_date: 終了日
            
        Returns:
            DataFrame: シグナルデータ
        """
        if self._signal_manager.feeds.get(name) is None:
            self.add_signal(name=name)
        return self._signal_manager.get_data(name, start_date, end_date)
    
    @property
    def signal_manager(self):
        """SignalManagerへのアクセスを提供する（読み取り専用）"""
        return self._signal_manager 