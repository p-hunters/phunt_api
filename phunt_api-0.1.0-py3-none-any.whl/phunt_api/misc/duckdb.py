"""
DuckDB操作のための共通ユーティリティ

このモジュールは、DuckDBとの対話を簡素化するための基本的なコンポーネントを提供します。
テーブル管理、クエリ実行、エラー処理などの共通機能を含み、様々なDuckDB操作で再利用できます。
"""

import polars as pl
import pandas as pd
import numpy as np
from typing import Union, List, Dict, Optional, Any, Protocol, TypeVar, Callable, Tuple, cast
from dataclasses import dataclass, field
import logging
import time
from datetime import datetime
import re
import asyncio
import concurrent.futures
from contextlib import contextmanager
import abc
import os
import pathlib
import uuid
import tempfile

# ロガーの設定
logger = logging.getLogger(__name__)

try:
    import duckdb
    DUCKDB_AVAILABLE = True
except ImportError:
    DUCKDB_AVAILABLE = False
    # DuckDBがインストールされていない環境のためのモック
    class duckdb:
        class DuckDBPyConnection: pass

# =============================================================================
# エラー定義
# =============================================================================

class DuckDBResourceError(Exception):
    """DuckDB リソース操作に関するエラー"""
    pass

class QueryExecutionError(Exception):
    """クエリ実行中のエラー"""
    pass

class ValidationError(Exception):
    """入力データバリデーションエラー"""
    pass

# =============================================================================
# ベース抽象クラスとプロトコル
# =============================================================================

class ConnectionProvider(Protocol):
    """DuckDBコネクションを提供するインターフェース"""
    
    @property
    def connection(self) -> 'duckdb.DuckDBPyConnection':
        """DuckDBコネクションを返す"""
        ...

class ResourceManager(abc.ABC):
    """リソース管理の抽象基底クラス"""
    
    @abc.abstractmethod
    def __enter__(self):
        """コンテキストマネージャーのエントリーポイント"""
        pass
    
    @abc.abstractmethod
    def __exit__(self, exc_type, exc_val, exc_tb):
        """コンテキストマネージャーの終了処理"""
        pass
    
    @abc.abstractmethod
    def cleanup(self):
        """リソースのクリーンアップ"""
        pass

# =============================================================================
# 設定データクラス
# =============================================================================

@dataclass
class DuckDBConfig:
    """DuckDBの設定を管理するクラス"""

    def __init__(
        self,
        database_path: Optional[str] = None,
        memory_db: bool = False,
        temp_dir: Optional[str] = None,
        temp_prefix: str = "temp_phunt_",
        use_query_cache: bool = True,
        timeout_ms: int = 60000,
        retry_count: int = 3,
        enable_monitoring: bool = False,
    ):
        """
        DuckDBConfigクラスのコンストラクタ

        Args:
            database_path: DuckDBのデータベースファイルパス
            memory_db: メモリ内データベースを使用するかどうか
            temp_dir: 一時ファイルディレクトリ
            temp_prefix: 一時テーブル名のプレフィックス
            use_query_cache: クエリキャッシュを使用するかどうか
            timeout_ms: クエリのタイムアウト（ミリ秒単位）
            retry_count: リトライ回数
            enable_monitoring: モニタリングを有効にするかどうか
        """
        self.memory_db = memory_db
        
        if database_path is None and not memory_db:
            # デフォルトはカレントディレクトリにphunt.dbを作成
            self.database_path = "phunt.db"
        else:
            self.database_path = database_path
            
        if temp_dir is None:
            self.temp_dir = tempfile.gettempdir()
        else:
            self.temp_dir = temp_dir
            
        self.temp_prefix = temp_prefix
        self.use_query_cache = use_query_cache
        self.timeout_ms = timeout_ms
        self.retry_count = retry_count
        self.enable_monitoring = enable_monitoring

@dataclass
class PerformanceMetrics:
    """パフォーマンスを追跡するメトリクス"""
    query_count: int = 0
    total_query_time: float = 0.0
    total_rows_processed: int = 0
    total_bytes_processed: int = 0
    table_operations: int = 0
    
    def record_query(self, duration: float, rows: int = 0, bytes_processed: int = 0):
        """クエリ実行メトリクスを記録"""
        self.query_count += 1
        self.total_query_time += duration
        self.total_rows_processed += rows
        self.total_bytes_processed += bytes_processed
    
    def record_table_operation(self):
        """テーブル操作を記録"""
        self.table_operations += 1
    
    def summary(self) -> Dict[str, Any]:
        """メトリクスのサマリーを辞書で返す"""
        return {
            "query_count": self.query_count,
            "avg_query_time": self.total_query_time / max(1, self.query_count),
            "total_rows": self.total_rows_processed,
            "total_bytes_mb": self.total_bytes_processed / (1024 * 1024),
            "table_operations": self.table_operations
        }

# =============================================================================
# コアクラス：テーブル管理
# =============================================================================

class DuckDBTableManager(ResourceManager):
    """
    DuckDBテーブルのライフサイクル管理を専門とするクラス
    
    主な責務:
    - 一時テーブルの作成と命名
    - テーブルリソースの追跡と管理
    - リソースの適切なクリーンアップ
    """
    
    def __init__(self, config: DuckDBConfig):
        """
        Args:
            config: DuckDB接続設定
        """
        if not DUCKDB_AVAILABLE:
            raise ImportError(
                "DuckDB is not installed. "
                "Please install it with: pip install duckdb"
            )
        
        self.config = config
        
        # メモリデータベースかファイルデータベースかに応じてコネクション作成
        if config.memory_db:
            logger.info("メモリ内データベースに接続します")
            self.conn = duckdb.connect(":memory:")
        else:
            logger.info(f"データベースファイル '{config.database_path}' に接続します")
            db_path = pathlib.Path(config.database_path)
            # 親ディレクトリが存在しなければ作成
            if not db_path.parent.exists():
                db_path.parent.mkdir(parents=True, exist_ok=True)
            self.conn = duckdb.connect(str(db_path))
        
        self._temp_tables: List[str] = []
        self._metrics = PerformanceMetrics()
    
    def __enter__(self):
        """コンテキストマネージャーのエントリーポイント"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """コンテキストマネージャー終了時に一時テーブルをクリーンアップ"""
        self.cleanup()
        if self.config.enable_monitoring:
            logger.info(f"TableManager metrics: {self._metrics.summary()}")
    
    def cleanup(self):
        """作成したすべての一時テーブルを削除"""
        for table_name in self._temp_tables[:]:
            try:
                self.conn.execute(f"DROP TABLE IF EXISTS {table_name}")
                self._metrics.record_table_operation()
                self._temp_tables.remove(table_name)
                logger.debug(f"Deleted temporary table: {table_name}")
            except Exception as e:
                logger.warning(f"Failed to delete table {table_name}: {str(e)}")
    
    def create_temp_table_id(self, table_name: str) -> str:
        """
        ユニークな一時テーブルIDを生成
        
        Args:
            table_name: テーブルの基本名
            
        Returns:
            テーブル名
        """
        # 無効な文字を置換
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', table_name)
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_suffix = np.random.randint(0, 1000)
        
        table_id = f"{self.config.temp_prefix}{clean_name}_{timestamp}_{random_suffix}"
        self._temp_tables.append(table_id)
        logger.debug(f"Created temporary table ID: {table_id}")
        return table_id
    
    def load_dataframe(
        self, 
        df: Union[pd.DataFrame, pl.DataFrame], 
        table_id: str,
        schema: Optional[List[Dict[str, Any]]] = None,
        write_disposition: str = "WRITE_TRUNCATE"
    ) -> str:
        """
        DataFrameをDuckDBテーブルにロード
        
        Args:
            df: ロードするデータフレーム
            table_id: 対象テーブル名
            schema: テーブルスキーマ定義（オプション）
            write_disposition: 書き込みモード ('WRITE_TRUNCATE'または'WRITE_APPEND')
            
        Returns:
            ロード先のテーブル名
        
        Raises:
            DuckDBResourceError: データロード失敗時
        """
        start_time = time.time()
        
        try:
            # 既存テーブルが存在するか確認
            if write_disposition == "WRITE_TRUNCATE":
                self.conn.execute(f"DROP TABLE IF EXISTS {table_id}")
            
            # DuckDBはDataFrameを直接テーブルとして登録可能
            if isinstance(df, pl.DataFrame):
                # Polars DataFrameの場合
                pandas_df = df.to_pandas()
                self.conn.register(table_id, pandas_df)
            else:
                # Pandas DataFrameの場合
                self.conn.register(table_id, df)
            
            # 一時テーブルから永続テーブルを作成
            # CREATE TABLE AS SELECTでスキーマも含めてコピー
            if write_disposition == "WRITE_TRUNCATE":
                self.conn.execute(f"CREATE TABLE {table_id} AS SELECT * FROM {table_id}")
            else:
                # APPENDの場合はINSERT INTO
                self.conn.execute(f"INSERT INTO {table_id} SELECT * FROM {table_id}_temp")
                self.conn.execute(f"DROP VIEW IF EXISTS {table_id}_temp")
            
            # メトリクス記録
            duration = time.time() - start_time
            self._metrics.record_query(
                duration=duration,
                rows=len(df),
                bytes_processed=0  # DuckDBでは正確なバイト数計測が難しいため0
            )
            self._metrics.record_table_operation()
            
            logger.info(f"Loaded {len(df)} rows to {table_id} in {duration:.2f}s")
            return table_id
            
        except Exception as e:
            error_msg = f"Failed to load data to table {table_id}: {str(e)}"
            logger.error(error_msg)
            raise DuckDBResourceError(error_msg) from e
    
    @property
    def connection(self) -> 'duckdb.DuckDBPyConnection':
        """DuckDBコネクションを返す"""
        return self.conn

# =============================================================================
# コアクラス：データ取得と変換
# =============================================================================

class DuckDBDataFetcher:
    """
    DuckDBからデータを取得し適切な形式に変換するクラス
    
    主な責務:
    - クエリの実行と結果取得
    - 異なるデータ形式への変換
    - クエリ実行の最適化とモニタリング
    """
    
    def __init__(self, config: DuckDBConfig):
        """
        Args:
            config: DuckDB接続設定
        """
        if not DUCKDB_AVAILABLE:
            raise ImportError(
                "DuckDB is not installed. "
                "Please install it with: pip install duckdb"
            )
        
        self.config = config
        
        # メモリデータベースかファイルデータベースかに応じてコネクション作成
        if config.memory_db:
            logger.info("DataFetcher: メモリ内データベースに接続します")
            self.conn = duckdb.connect(":memory:")
        else:
            logger.info(f"DataFetcher: データベースファイル '{config.database_path}' に接続します")
            self.conn = duckdb.connect(config.database_path)
        
        self._metrics = PerformanceMetrics()
        self._query_cache = {}
        self._enable_query_cache = config.use_query_cache
        self._cache_ttl = 300  # 5分キャッシュ
    
    @property
    def enable_query_cache(self) -> bool:
        """クエリキャッシュが有効かどうか"""
        return self._enable_query_cache
    
    @enable_query_cache.setter
    def enable_query_cache(self, value: bool):
        """クエリキャッシュの有効/無効を設定"""
        self._enable_query_cache = value
    
    def clear_cache(self):
        """クエリキャッシュをクリア"""
        self._query_cache = {}
        logger.debug("Query cache cleared")
    
    def set_cache_ttl(self, seconds: int):
        """キャッシュの有効期限を設定"""
        self._cache_ttl = max(1, seconds)
    
    def execute_query(self, query: str) -> pd.DataFrame:
        """
        SQLクエリを実行しPandas DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPandas DataFrame
            
        Raises:
            QueryExecutionError: クエリ実行エラー時
        """
        # キャッシュチェック
        if self._enable_query_cache and query in self._query_cache:
            cache_entry = self._query_cache[query]
            cache_time, result_df = cache_entry
            
            # キャッシュが有効期限内か確認
            if time.time() - cache_time < self._cache_ttl:
                logger.debug("Query result returned from cache")
                return result_df.copy()
        
        start_time = time.time()
        retry_count = 0
        
        while retry_count <= self.config.retry_count:
            try:
                # DuckDBでクエリ実行
                result_df = self.conn.execute(query).fetchdf()
                
                # キャッシュ保存
                if self._enable_query_cache:
                    self._query_cache[query] = (time.time(), result_df.copy())
                
                # メトリクス記録
                duration = time.time() - start_time
                self._metrics.record_query(
                    duration=duration,
                    rows=len(result_df),
                    bytes_processed=0  # DuckDBでは正確なバイト数計測が難しいため0
                )
                
                logger.debug(f"Query executed in {duration:.2f}s, returned {len(result_df)} rows")
                return result_df
                
            except Exception as e:
                retry_count += 1
                if retry_count > self.config.retry_count:
                    error_msg = f"Failed to execute query after {retry_count} attempts: {str(e)}"
                    logger.error(error_msg)
                    raise QueryExecutionError(error_msg) from e
                
                wait_time = 2 ** retry_count  # 指数バックオフ
                logger.warning(f"Query failed, retrying in {wait_time}s... ({retry_count}/{self.config.retry_count})")
                time.sleep(wait_time)

    def execute_batch_queries(
        self, 
        queries: List[str], 
        sequential: bool = False,
        max_concurrency: int = 4
    ) -> List[pd.DataFrame]:
        """
        複数のクエリをバッチ処理
        
        Args:
            queries: 実行するクエリリスト
            sequential: 順次実行するかどうか
            max_concurrency: 最大同時実行数
            
        Returns:
            DataFrame結果のリスト
        """
        if not queries:
            return []
        
        if sequential:
            # 順次実行
            return [self.execute_query(query) for query in queries]
        
        # 並列実行（ThreadPoolExecutorを使用）
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_concurrency) as executor:
            futures = [executor.submit(self.execute_query, query) for query in queries]
            results = [future.result() for future in concurrent.futures.as_completed(futures)]
        
        return results
    
    def execute_query_to_polars(self, query: str) -> pl.DataFrame:
        """
        SQLクエリを実行しPolars DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPolars DataFrame
        """
        pandas_df = self.execute_query(query)
        return pl.from_pandas(pandas_df)
    
    async def execute_query_async(self, query: str) -> pd.DataFrame:
        """
        SQLクエリを非同期実行しPandas DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPandas DataFrame
        """
        loop = asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return await loop.run_in_executor(pool, self.execute_query, query)
    
    def get_metrics(self) -> Dict[str, Any]:
        """パフォーマンスメトリクスを取得"""
        return self._metrics.summary()
    
    @property
    def connection(self) -> 'duckdb.DuckDBPyConnection':
        """DuckDBコネクションを返す"""
        return self.conn

# =============================================================================
# サービスクラス：DuckDB機能サービス
# =============================================================================

class DuckDBService:
    """
    DuckDBデータベースのテーブル管理とデータ取得のためのサービスクラス
    
    主な責務:
    - テーブル管理とデータ取得の統合インターフェース提供
    - 共通設定の共有と初期化
    """
    
    def __init__(
        self, 
        database_path: Optional[str] = None,
        memory_db: bool = False,
        **kwargs
    ):
        """
        Args:
            database_path: DuckDBデータベースファイルパス
            memory_db: メモリ内データベースを使用するかどうか
            **kwargs: その他の設定パラメータ
        """
        # DuckDB設定オブジェクト作成
        self.config = DuckDBConfig(
            database_path=database_path,
            memory_db=memory_db,
            **kwargs
        )
        
        # テーブルマネージャとデータフェッチャのインスタンスはプロパティを初回アクセス時に初期化
        self._table_manager = None
        self._data_fetcher = None
    
    @property
    def table_manager(self) -> DuckDBTableManager:
        """テーブル管理クラスのインスタンスを取得・初期化"""
        if self._table_manager is None:
            self._table_manager = DuckDBTableManager(self.config)
        return self._table_manager
    
    @property
    def data_fetcher(self) -> DuckDBDataFetcher:
        """データ取得クラスのインスタンスを取得・初期化"""
        if self._data_fetcher is None:
            self._data_fetcher = DuckDBDataFetcher(self.config)
        return self._data_fetcher
    
    def connection(self) -> 'duckdb.DuckDBPyConnection':
        """DuckDBコネクションを取得"""
        # テーブルマネージャのコネクションを使用
        return self.table_manager.connection

# =============================================================================
# ユーティリティ関数
# =============================================================================

def is_duckdb_available() -> bool:
    """DuckDBライブラリが利用可能かを確認"""
    return DUCKDB_AVAILABLE

def check_duckdb_requirements():
    """
    DuckDBライブラリがインストールされているか確認し、
    インストールされていない場合は例外を発生させる
    
    Raises:
        ImportError: DuckDBライブラリがインストールされていない場合
    """
    if not DUCKDB_AVAILABLE:
        raise ImportError(
            "DuckDB is not installed. "
            "Please install it with: pip install duckdb"
        )

def prepare_dataframe_for_duckdb(
    df: Union[pd.DataFrame, pl.DataFrame]
) -> pd.DataFrame:
    """
    DataFrameをDuckDBに適した形式に変換
    
    Args:
        df: 変換するDataFrame
        
    Returns:
        DuckDBに適したPandas DataFrame
    """
    # Polarsの場合はPandasに変換
    if isinstance(df, pl.DataFrame):
        pandas_df = df.to_pandas()
    else:
        pandas_df = df.copy()
    
    # 日付列の処理
    for col in pandas_df.columns:
        if pd.api.types.is_datetime64_any_dtype(pandas_df[col]):
            # タイムゾーン情報を削除
            pandas_df[col] = pandas_df[col].dt.tz_localize(None)
    
    return pandas_df 