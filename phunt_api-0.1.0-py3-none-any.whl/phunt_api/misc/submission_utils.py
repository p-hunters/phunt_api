import hashlib
import inspect
import pandas as pd
from typing import Optional, Callable, Dict, Any, TypeVar, Generic, Type

T = TypeVar('T')

class SubmissionUtils:
    """
    提出操作（feature, target, model）の共通処理を提供するユーティリティクラス
    """
    
    @staticmethod
    def generate_cache_key(name: str, processing_code: Callable, prefix: str) -> str:
        """
        処理コードとその名前から一意のキャッシュキーを生成します
        
        Args:
            name: 項目の名前
            processing_code: 処理コード関数
            prefix: キャッシュプレフィックス（"feature", "target", "model"など）
            
        Returns:
            生成されたキャッシュキー
        """
        code_string = inspect.getsource(processing_code)
        hash_object = hashlib.md5((name + code_string).encode())
        return f"{prefix}_{hash_object.hexdigest()}"
    
    @staticmethod
    def calculate_df_hash(df: pd.DataFrame) -> str:
        """
        DataFrameのハッシュ値を計算します
        
        Args:
            df: ハッシュを計算するDataFrame
            
        Returns:
            DataFrameのハッシュ値
        """
        return hashlib.md5(str(pd.util.hash_pandas_object(df).values).encode()).hexdigest()
    
    @staticmethod
    def save_processing_code(name: str, processing_code: Callable, item_type: str) -> str:
        """
        処理コードをファイルに保存します
        
        Args:
            name: 項目の名前
            processing_code: 保存する処理コード
            item_type: 項目のタイプ（"feature", "target", "model"など）
            
        Returns:
            保存したファイルパス
        """
        code_string = inspect.getsource(processing_code)
        file_path = f"/tmp/{name}_{item_type}_processing_code.py"
        with open(file_path, 'w') as f:
            f.write(code_string)
        print(f"Processing code saved to: {file_path}")
        return file_path
    
    @staticmethod
    def submit_with_processing_code(
        name: str,
        processing_code: Callable,
        api_instance: Any,
        manager_method: Callable,
        cache_manager: Any,
        prefix: str,
        error_class: Type[Exception],
        validate_func: Optional[Callable] = None
    ) -> Any:
        """
        処理コードを使用してアイテム（特徴量、ターゲット、モデル）を提出する共通メソッド
        
        Args:
            name: 提出するアイテムの名前
            processing_code: 処理コード関数
            api_instance: APIインスタンス
            manager_method: 呼び出すマネージャーのsubmitメソッド
            cache_manager: キャッシュ管理オブジェクト
            prefix: キャッシュプレフィックス
            error_class: 使用するエラークラス
            validate_func: 検証関数（オプション）
            
        Returns:
            処理結果
        """
        # 処理コードを検証（必要に応じて）
        if validate_func:
            validate_func(processing_code, error_class)
        
        # キャッシュキーの生成
        cache_key = SubmissionUtils.generate_cache_key(name, processing_code, prefix)
        
        # キャッシュに存在するか確認
        if cache_manager.exists_in_cache(cache_key):
            print(f"Cache hit for {prefix}: {name}")
            return name if prefix in ["feature", "target"] else cache_manager.get_from_cache(cache_key)
        
        # 処理コードを保存
        SubmissionUtils.save_processing_code(name, processing_code, prefix)
        
        # マネージャーのメソッドを呼び出す
        result = manager_method(name, processing_code, api_instance=api_instance)
        
        # 結果をキャッシュに格納
        cache_manager.set_to_cache(cache_key, result)
        
        return name if prefix in ["feature", "target"] else result
    
    @staticmethod
    def submit_with_dataframe(
        name: str,
        df: pd.DataFrame,
        manager_method: Callable,
        cache_manager: Any,
        prefix: str
    ) -> str:
        """
        DataFrameを使用してアイテム（特徴量、ターゲット）を提出する共通メソッド
        
        Args:
            name: 提出するアイテムの名前
            df: 提出するDataFrame
            manager_method: 呼び出すマネージャーのsubmitメソッド
            cache_manager: キャッシュ管理オブジェクト
            prefix: キャッシュプレフィックス
            
        Returns:
            アイテム名
        """
        # DataFrameのハッシュ値を計算
        df_hash = SubmissionUtils.calculate_df_hash(df)
        cache_key = f"{prefix}_df_{name}_{df_hash}"
        
        # キャッシュに存在するか確認
        if cache_manager.exists_in_cache(cache_key):
            print(f"Cache hit for {prefix} dataframe: {name}")
            return name
        
        # 一時ファイルに保存（必要な場合）
        if prefix == "feature":
            df.to_parquet(f"/tmp/{name}_{prefix}_data.parquet")
        
        # マネージャーのメソッドを呼び出す
        result = manager_method(name, df=df)
        
        # 結果をキャッシュに格納
        cache_manager.set_to_cache(cache_key, name)
        
        return name 