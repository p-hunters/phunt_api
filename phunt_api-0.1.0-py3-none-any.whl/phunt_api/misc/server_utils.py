from typing import Optional
from ..exceptions import PHuntAPIException

class ServerUtils:
    """サーバー管理ユーティリティクラス"""
    
    def __init__(self):
        self._auth_server_process = None
        self._feast_ui_process = None
    
    def run_auth_server(self, 
                       host: str = "0.0.0.0",
                       port: int = 8000,
                       workers: int = 1,
                       reload: bool = False,
                       block: bool = True):
        """認証サーバーを起動する

        Args:
            host (str): バインドするホスト
            port (int): 認証サーバーのポート
            workers (int): ワーカープロセス数
            reload (bool): ホットリロードを有効にするかどうか
            block (bool): Trueの場合、サーバープロセスが終了するまでブロックします
        """
        from ..auth_server.service import AuthServer, AuthServerConfig
        
        try:
            config = AuthServerConfig(
                host=host,
                port=port,
                workers=workers,
                reload=reload
            )
            
            server = AuthServer(config)
            server.run(block=block)
            
        except Exception as e:
            raise PHuntAPIException(f"認証サーバーの起動に失敗しました: {str(e)}")

    def run_feast_ui(self, host: str = "0.0.0.0", port: int = 8888, block: bool = True):
        """Feast UIを起動する

        Args:
            host (str): バインドするホスト
            port (int): Feast UIのポート
            block (bool): Trueの場合、UIプロセスが終了するまでブロックします
        """
        from ..feast_ui.service import FeastUIServer, FeastUIConfig
        
        try:
            config = FeastUIConfig(
                host=host,
                port=port
            )
            
            server = FeastUIServer(config)
            server.run(block=block)
            
        except Exception as e:
            raise PHuntAPIException(f"Feast UIの起動に失敗しました: {str(e)}")

    def stop_auth_server(self):
        """認証サーバーを停止する"""
        if hasattr(self, '_auth_server') and self._auth_server:
            self._auth_server.stop()
            self._auth_server = None

    def stop_feast_ui(self):
        """Feast UIを停止する"""
        if hasattr(self, '_feast_ui') and self._feast_ui:
            self._feast_ui.stop()
            self._feast_ui = None
            
    def create_feature_store_yaml(self):
        """Feast用のfeature_store.yamlファイルを作成する"""
        with open('feature_store.yaml', 'w') as f:
            body = """
entity_key_serialization_version: 2
offline_store:
  type: duckdb
online_store:
  connection_string: feast-online-store.gnr8wb.0001.apne1.cache.amazonaws.com:6379,db=0
  type: redis
project: p_hunters_feast
provider: aws
registry:
  cache_ttl_seconds: 60
  path: postgresql+psycopg2://postgres:your_secure_password_here@feast-registry.c9jdh8eweihk.ap-northeast-1.rds.amazonaws.com:5432/feast
  registry_type: sql
  sqlalchemy_config_kwargs:
    echo: false
    pool_pre_ping: true
"""
            f.write(body)
            
    def cleanup(self):
        """サーバーリソースをクリーンアップする"""
        self.stop_auth_server()
        self.stop_feast_ui() 