import pandas as pd
import os
import warnings
import logging

class DataUtils:
    """データ操作ユーティリティクラス"""
    
    @staticmethod
    def setup_logging_plt(logging, plt, SCRIPT_DIR, MODEL_NAME):
        """ロギングとMatplotlibの設定を行う
        
        Args:
            logging: loggingモジュール
            plt: matplotlibのpltモジュール
            SCRIPT_DIR: スクリプトのディレクトリパス
            MODEL_NAME: モデル名
            
        Returns:
            tuple: (logger, plt) - 設定済みのロガーとpltオブジェクト
        """
        # ロギング設定
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(os.path.join(SCRIPT_DIR, f"{MODEL_NAME}.log"))
            ]
        )
        logger = logging.getLogger('eurusd_model_enhanced')
        warnings.filterwarnings('ignore')

        # Matplotlibの日本語フォント設定
        plt.rcParams['font.family'] = 'sans-serif'
        plt.rcParams['font.sans-serif'] = ['Hiragino Sans', 'Yu Gothic', 'Meiryo']
        plt.rcParams['axes.unicode_minus'] = False
        return logger, plt
    
    @staticmethod
    def join_and_drop(feature_df: pd.DataFrame, target_df: pd.DataFrame):
        """特徴量データフレームと目的変数データフレームを結合し、欠損値を削除する
        
        Args:
            feature_df: 特徴量のデータフレーム
            target_df: 目的変数のデータフレーム
            
        Returns:
            tuple: (feature_df, target_df) - 結合・クリーニング済みのデータフレーム
        """
        feature_columns = feature_df.columns
        target_columns = target_df.columns
        data = pd.merge(feature_df, target_df, on='timestamp', how='inner')
        data.dropna(inplace=True)
        try:
            data = data.sample(n=10000)
        except Exception as e:
            print(f"Sample Error: {e}")
        return data[feature_columns], data[target_columns]
    
    @staticmethod
    def get_years(feature_df: pd.DataFrame):
        """データフレームから年のリストを取得する
        
        Args:
            feature_df: 特徴量のデータフレーム
            
        Returns:
            list: ソートされた年のリスト
        """
        years = pd.to_datetime(feature_df.index).year
        years = sorted(years.unique())
        print(f"Years: {years}")
        return years 