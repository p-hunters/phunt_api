from typing import Literal, Optional, Dict, Any
from ..utils import JsonFileCache, PickleFileCache

class CacheManager:
    """APIのキャッシュ操作を担当するクラス"""
    
    def __init__(self, cache_type: Literal["memory", "file", "pickle"] = "pickle"):
        """キャッシュマネージャーを初期化
        
        Args:
            cache_type: キャッシュのタイプ("memory", "file" または "pickle")
                        "memory": メモリ内キャッシュ（セッション内のみ有効）
                        "file": JSONファイルキャッシュ（基本的なオブジェクト向け）
                        "pickle": Pickleファイルキャッシュ（DataFrameなど複雑なオブジェクト向け）
        """
        self.cache_type = cache_type
        
        # キャッシュの初期化
        if cache_type == "file":
            # JSONファイルキャッシュを使用
            self._cache = JsonFileCache()
            print(f"Using JSON file cache for user: {self._cache.namespace}")
        elif cache_type == "pickle":
            # Pickleファイルキャッシュを使用
            self._cache = PickleFileCache()
            print(f"Using Pickle file cache for user: {self._cache.namespace}")
        else:
            # メモリ内キャッシュを使用
            self._cache = {}
            print("Using in-memory cache")
    
    def exists(self, cache_key: str) -> bool:
        """キャッシュに指定されたキーが存在するかどうかをチェック"""
        if cache_key is None:
            return False
        
        if self.cache_type == "memory":
            # メモリキャッシュの場合
            if isinstance(self._cache, dict):
                return cache_key in self._cache
        else:
            # ファイルキャッシュの場合
            return self._cache.exists(cache_key) if hasattr(self._cache, 'exists') else False  # type: ignore
        return False
    
    def get(self, cache_key: str, default=None):
        """キャッシュから値を取得"""
        if cache_key is None:
            return default
            
        if self.cache_type == "memory":
            # メモリキャッシュの場合
            if isinstance(self._cache, dict):
                return self._cache.get(cache_key, default)
        else:
            # ファイルキャッシュの場合
            if hasattr(self._cache, 'get') and callable(getattr(self._cache, 'get')):
                return self._cache.get(cache_key, default)
            
        return default
    
    def set(self, cache_key: str, value) -> None:
        """キャッシュに値を設定"""
        if cache_key is None:
            return
            
        if self.cache_type == "memory":
            # メモリキャッシュの場合
            if isinstance(self._cache, dict):
                self._cache[cache_key] = value
        else:
            # ファイルキャッシュの場合
            if hasattr(self._cache, 'set') and callable(getattr(self._cache, 'set')):
                self._cache.set(cache_key, value)  # type: ignore
                
    @property
    def cache(self):
        """キャッシュオブジェクトへの直接アクセスを提供（読み取り専用）"""
        return self._cache 