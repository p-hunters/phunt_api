import functools
from typing import Type, Callable, Any, Optional, Union
from ..exceptions import PHuntAPIException

def handle_api_exceptions(func: Optional[Callable] = None, *, 
                         error_class: Optional[Type[Exception]] = None, 
                         error_message: Optional[str] = None):
    """
    共通の例外処理用デコレータ（引数あり・なし両対応）
    
    使用方法:
        @handle_api_exceptions  # 引数なし
        def my_method():
            pass
            
        @handle_api_exceptions(error_class=ValueError, error_message="Invalid value")  # 引数あり
        def my_method():
            pass
    
    Args:
        func: デコレートする関数（引数なしの場合）
        error_class: キャッチする特定の例外クラス（オプション）
        error_message: エラーメッセージのプレフィックス（オプション）
        
    Returns:
        例外処理を含むデコレーター関数
    """
    def decorator(f: Callable):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except Exception as e:
                # 特定の例外クラスが指定されている場合
                if error_class and isinstance(e, error_class):
                    if error_message:
                        raise PHuntAPIException(f"{error_message}: {str(e)}")
                    else:
                        raise PHuntAPIException(f"{f.__name__} failed: {str(e)}")
                # PHuntAPIExceptionは再度raiseする
                elif isinstance(e, PHuntAPIException):
                    raise
                # その他の例外
                else:
                    raise PHuntAPIException(f"Error in {f.__name__}: {str(e)}")
        return wrapper
    
    # 引数なしで使用された場合
    if func is not None:
        return decorator(func)
    # 引数ありで使用された場合
    else:
        return decorator

def with_cache(cache_key_prefix: str, cache_key_func: Optional[Callable] = None):
    """
    キャッシュ処理用デコレータ
    
    Args:
        cache_key_prefix: キャッシュキーのプレフィックス
        cache_key_func: キャッシュキーを生成するカスタム関数（オプション）
        
    Returns:
        キャッシュ処理を含むデコレーター関数
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            # self はAPI クラスのインスタンスであると仮定
            if not hasattr(self, 'exists_in_cache') or not hasattr(self, 'get_from_cache') or not hasattr(self, 'set_to_cache'):
                # キャッシュ機能が利用できない場合は、関数をそのまま実行
                return func(self, *args, **kwargs)
            
            # キャッシュキーの生成
            if cache_key_func:
                cache_key = cache_key_func(self, *args, **kwargs)
            else:
                # デフォルトのキャッシュキー生成ロジック
                # 第一引数を基にキャッシュキーを生成
                if len(args) > 0:
                    key_part = str(args[0])
                elif 'id' in kwargs:
                    key_part = str(kwargs['id'])
                elif 'name' in kwargs:
                    key_part = str(kwargs['name'])
                else:
                    # キャッシュキーを生成できない場合は、関数をそのまま実行
                    return func(self, *args, **kwargs)
                    
                cache_key = f"{cache_key_prefix}_{key_part}"
            
            # キャッシュをチェック
            if self.exists_in_cache(cache_key):
                print(f"Cache hit for: {cache_key}")
                cached_result = self.get_from_cache(cache_key)
                if cached_result is not None:
                    return cached_result
            
            # 関数を実行して結果を取得
            result = func(self, *args, **kwargs)
            
            # 結果をキャッシュに格納
            self.set_to_cache(cache_key, result)
            
            return result
        return wrapper
    return decorator 