import functools
from typing import Type, Callable, Any, Optional
from ..exceptions import PHuntAPIException

def handle_api_exceptions(error_class: Type[Exception], error_message: str):
    """
    共通の例外処理用デコレータ
    
    Args:
        error_class: キャッチする例外クラス
        error_message: エラーメッセージのプレフィックス
        
    Returns:
        例外処理を含むデコレーター関数
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except error_class as e:
                raise PHuntAPIException(f"{error_message}: {str(e)}")
            except Exception as e:
                raise PHuntAPIException(f"予期せぬエラーが発生しました: {str(e)}")
        return wrapper
    return decorator

def with_cache(cache_key_prefix: str, cache_key_func: Optional[Callable] = None):
    """
    キャッシュ処理用デコレータ
    
    Args:
        cache_key_prefix: キャッシュキーのプレフィックス
        cache_key_func: キャッシュキーを生成するカスタム関数（オプション）
        
    Returns:
        キャッシュ処理を含むデコレーター関数
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            # self はAPI クラスのインスタンスであると仮定
            if not hasattr(self, 'exists_in_cache') or not hasattr(self, 'get_from_cache') or not hasattr(self, 'set_to_cache'):
                # キャッシュ機能が利用できない場合は、関数をそのまま実行
                return func(self, *args, **kwargs)
            
            # キャッシュキーの生成
            if cache_key_func:
                cache_key = cache_key_func(self, *args, **kwargs)
            else:
                # デフォルトのキャッシュキー生成ロジック
                # 第一引数を基にキャッシュキーを生成
                if len(args) > 0:
                    key_part = str(args[0])
                elif 'id' in kwargs:
                    key_part = str(kwargs['id'])
                elif 'name' in kwargs:
                    key_part = str(kwargs['name'])
                else:
                    # キャッシュキーを生成できない場合は、関数をそのまま実行
                    return func(self, *args, **kwargs)
                    
                cache_key = f"{cache_key_prefix}_{key_part}"
            
            # キャッシュをチェック
            if self.exists_in_cache(cache_key):
                print(f"Cache hit for: {cache_key}")
                cached_result = self.get_from_cache(cache_key)
                if cached_result is not None:
                    return cached_result
            
            # 関数を実行して結果を取得
            result = func(self, *args, **kwargs)
            
            # 結果をキャッシュに格納
            self.set_to_cache(cache_key, result)
            
            return result
        return wrapper
    return decorator 