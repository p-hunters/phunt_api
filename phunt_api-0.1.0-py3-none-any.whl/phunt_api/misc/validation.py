import inspect
from typing import Callable, Type, Protocol, runtime_checkable, TypeVar, Generic

from ..exceptions import PHuntAPIException

# Define a generic type variable for the return type
T = TypeVar('T')

@runtime_checkable
class ProcessingCodeProtocol(Protocol, Generic[T]):
    """Protocol for processing code functions that accept a PHuntAPI object."""
    def __call__(self, api: 'PHuntAPI') -> T: ...

class ValidationUtils:
    """バリデーションユーティリティクラス"""
    
    @staticmethod
    def validate_processing_code(processing_code: Callable, error_class: Type[PHuntAPIException] = PHuntAPIException) -> bool:
        """processing_codeがPHuntAPIオブジェクトを受け入れるかを検証する
        
        Args:
            processing_code: 検証する処理コード
            error_class: 例外が発生した場合に投げる例外クラス
            
        Returns:
            bool: 処理コードが有効な場合はTrue、そうでない場合はFalse
            
        Raises:
            PHuntAPIException: 処理コードが無効な場合
        """
        # Protocolを使用した型チェック（runtime_checkableデコレータが必要）
        if isinstance(processing_code, ProcessingCodeProtocol):
            return True
            
        # 従来の方法でのチェック（後方互換性のため）
        # 関数のシグネチャをチェック
        sig = inspect.signature(processing_code)
        
        # 少なくとも1つのパラメータがあることを確認
        if len(sig.parameters) < 1:
            raise error_class("processing_codeは少なくとも1つのパラメータ（PHuntAPIオブジェクト）を受け入れる必要があります")
        
        # 型アノテーションがある場合は検証
        first_param = list(sig.parameters.values())[0]
        if first_param.annotation != inspect.Parameter.empty:
            # 型アノテーションに"PHuntAPI"という文字列が含まれているか確認
            if "PHuntAPI" not in str(first_param.annotation):
                raise error_class("processing_codeの最初の引数はPHuntAPI型である必要があります")
        
        return True 