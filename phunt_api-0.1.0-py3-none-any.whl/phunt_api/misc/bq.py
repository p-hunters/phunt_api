"""
BigQuery操作のための共通ユーティリティ

このモジュールは、BigQueryとの対話を簡素化するための基本的なコンポーネントを提供します。
テーブル管理、クエリ実行、エラー処理などの共通機能を含み、様々なBigQuery操作で再利用できます。
"""

import polars as pl
import pandas as pd
import numpy as np
from typing import Union, List, Dict, Optional, Any, Protocol, TypeVar, Callable, Tuple, cast
from dataclasses import dataclass, field
import logging
import time
from datetime import datetime
import re
import asyncio
import concurrent.futures
from contextlib import contextmanager
import abc
import os
import google.api_core.exceptions

# ロガーの設定
logger = logging.getLogger(__name__)

try:
    from google.cloud import bigquery
    from google.api_core.exceptions import GoogleAPIError
    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False
    # BigQueryがインストールされていない環境のためのモック
    class bigquery:
        class Client: pass
        class LoadJobConfig: pass
        class SchemaField: pass
        class QueryJobConfig: pass

# =============================================================================
# エラー定義
# =============================================================================

class BigQueryResourceError(Exception):
    """BigQuery リソース操作に関するエラー"""
    pass

class QueryExecutionError(Exception):
    """クエリ実行中のエラー"""
    pass

class ValidationError(Exception):
    """入力データバリデーションエラー"""
    pass

# =============================================================================
# ベース抽象クラスとプロトコル
# =============================================================================

class ClientProvider(Protocol):
    """BigQueryクライアントを提供するインターフェース"""
    
    @property
    def client(self) -> bigquery.Client:
        """BigQueryクライアントを返す"""
        ...

class ResourceManager(abc.ABC):
    """リソース管理の抽象基底クラス"""
    
    @abc.abstractmethod
    def __enter__(self):
        """コンテキストマネージャーのエントリーポイント"""
        pass
    
    @abc.abstractmethod
    def __exit__(self, exc_type, exc_val, exc_tb):
        """コンテキストマネージャーの終了処理"""
        pass
    
    @abc.abstractmethod
    def cleanup(self):
        """リソースのクリーンアップ"""
        pass

# =============================================================================
# 設定データクラス
# =============================================================================

@dataclass
class BigQueryConfig:
    """BigQueryの設定を管理するクラス"""

    def __init__(
        self,
        project_id: str,
        access_token: Optional[str] = None,
        service_account_email: Optional[str] = None,
        dataset_id: Optional[str] = None,
        location: str = "asia-northeast1",
        temp_prefix: str = "temp_phunt_",
        max_bytes_billed: Optional[int] = None,
        priority: str = "INTERACTIVE",
        use_query_cache: bool = True,
        timeout_ms: int = 60000,
        retry_count: int = 3,
        enable_monitoring: bool = False,
    ):
        """
        BigQueryConfigクラスのコンストラクタ

        Args:
            project_id: BigQueryのプロジェクトID
            access_token: GCPのアクセストークン
            service_account_email: サービスアカウントのメールアドレス
            dataset_id: BigQueryのデータセットID（指定しない場合はデフォルト値を使用）
            location: BigQueryのロケーション（デフォルトは東京リージョン）
            temp_prefix: 一時テーブル名のプレフィックス
            max_bytes_billed: クエリあたりの最大請求バイト数
            priority: クエリの優先度（"INTERACTIVE" または "BATCH"）
            use_query_cache: クエリキャッシュを使用するかどうか
            timeout_ms: クエリのタイムアウト（ミリ秒単位）
            retry_count: リトライ回数
            enable_monitoring: モニタリングを有効にするかどうか
        """
        self.project_id = project_id
        self.access_token = access_token
        self.service_account_email = service_account_email
        self.location = location
        self.temp_prefix = temp_prefix
        self.max_bytes_billed = max_bytes_billed
        self.priority = priority
        self.use_query_cache = use_query_cache
        self.timeout_ms = timeout_ms
        self.retry_count = retry_count
        self.enable_monitoring = enable_monitoring

        if dataset_id is None:
            self.dataset_id = f"{project_id.replace('-', '_')}_dataset"
            logger.info(f"dataset_idが指定されていないため、デフォルト値 '{self.dataset_id}' を使用します")
        else:
            self.dataset_id = dataset_id

@dataclass
class PerformanceMetrics:
    """パフォーマンスを追跡するメトリクス"""
    query_count: int = 0
    total_query_time: float = 0.0
    total_rows_processed: int = 0
    total_bytes_processed: int = 0
    table_operations: int = 0
    
    def record_query(self, duration: float, rows: int = 0, bytes_processed: int = 0):
        """クエリ実行メトリクスを記録"""
        self.query_count += 1
        self.total_query_time += duration
        self.total_rows_processed += rows
        self.total_bytes_processed += bytes_processed
    
    def record_table_operation(self):
        """テーブル操作を記録"""
        self.table_operations += 1
    
    def summary(self) -> Dict[str, Any]:
        """メトリクスのサマリーを辞書で返す"""
        return {
            "query_count": self.query_count,
            "avg_query_time": self.total_query_time / max(1, self.query_count),
            "total_rows": self.total_rows_processed,
            "total_bytes_mb": self.total_bytes_processed / (1024 * 1024),
            "table_operations": self.table_operations
        }

# =============================================================================
# コアクラス：テーブル管理
# =============================================================================

class BigQueryTableManager(ResourceManager):
    """
    BigQueryテーブルのライフサイクル管理を専門とするクラス
    
    主な責務:
    - 一時テーブルの作成と命名
    - テーブルリソースの追跡と管理
    - リソースの適切なクリーンアップ
    """
    
    def __init__(self, config: BigQueryConfig):
        """
        Args:
            config: BigQuery接続設定
        """
        if not BIGQUERY_AVAILABLE:
            raise ImportError(
                "Google Cloud BigQuery is not installed. "
                "Please install it with: pip install google-cloud-bigquery"
            )
        
        self.config = config
        # 認証情報に基づいてクライアントを初期化
        logger.info(f"認証情報の初期化を開始します: access_token={bool(config.access_token)}, service_account_email={bool(config.service_account_email)}")
        
        if config.access_token:
            # アクセストークンがある場合はそれを使用
            logger.info("アクセストークンを使用して認証します")
            from google.oauth2.credentials import Credentials
            credentials = Credentials(token=config.access_token)
            self.client = bigquery.Client(
                project=config.project_id, 
                location=config.location,
                credentials=credentials
            )
        else:
            # アクセストークンがない場合はデフォルト認証情報を使用
            logger.info("デフォルト認証情報を使用します")
            self.client = bigquery.Client(project=config.project_id, location=config.location)
        
        self._temp_tables: List[str] = []
        self._metrics = PerformanceMetrics()
        
        # データセットが存在するか確認し、存在しなければ作成
        self._ensure_dataset_exists()
    
    def _ensure_dataset_exists(self):
        """指定されたデータセットが存在するか確認し、存在しなければ作成"""
        dataset_id = f"{self.config.project_id}.{self.config.dataset_id}"
        try:
            # データセットの存在確認
            self.client.get_dataset(dataset_id)
            logger.info(f"データセット '{dataset_id}' は既に存在します")
        except Exception as e:
            # データセットが存在しない場合は作成
            logger.info(f"データセット '{dataset_id}' が存在しないため作成します")
            try:
                dataset = bigquery.Dataset(dataset_id)
                dataset.location = self.config.location
                dataset = self.client.create_dataset(dataset)
                logger.info(f"データセット '{dataset_id}' を作成しました（場所: {dataset.location}）")
            except google.api_core.exceptions.Conflict:
                # 409エラー: データセットが既に存在する場合は問題ないので、そのまま続行
                logger.info(f"データセット '{dataset_id}' は既に存在します（別プロセスで作成された可能性があります）")
            except Exception as create_error:
                logger.error(f"データセット '{dataset_id}' の作成に失敗しました: {create_error}")
                raise BigQueryResourceError(f"Failed to create dataset {dataset_id}: {str(create_error)}")
    
    def __enter__(self):
        """コンテキストマネージャーのエントリーポイント"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """コンテキストマネージャー終了時に一時テーブルをクリーンアップ"""
        self.cleanup()
        if self.config.enable_monitoring:
            logger.info(f"TableManager metrics: {self._metrics.summary()}")
    
    def cleanup(self):
        """作成したすべての一時テーブルを削除"""
        for table_id in self._temp_tables[:]:
            try:
                self.client.delete_table(table_id, not_found_ok=True)
                self._metrics.record_table_operation()
                self._temp_tables.remove(table_id)
                logger.debug(f"Deleted temporary table: {table_id}")
            except GoogleAPIError as e:
                logger.warning(f"Failed to delete table {table_id}: {str(e)}")
    
    def create_temp_table_id(self, table_name: str) -> str:
        """
        ユニークな一時テーブルIDを生成
        
        Args:
            table_name: テーブルの基本名
            
        Returns:
            完全修飾されたテーブルID
        """
        # 無効な文字を置換
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', table_name)
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_suffix = np.random.randint(0, 1000)
        
        table_id = f"{self.config.dataset_id}.{self.config.temp_prefix}{clean_name}_{timestamp}_{random_suffix}"
        self._temp_tables.append(table_id)
        logger.debug(f"Created temporary table ID: {table_id}")
        return table_id
    
    def load_dataframe(
        self, 
        df: Union[pd.DataFrame, pl.DataFrame], 
        table_id: str,
        schema: Optional[List[bigquery.SchemaField]] = None,
        write_disposition: str = "WRITE_TRUNCATE"
    ) -> str:
        """
        DataFrameをBigQueryテーブルにロード
        
        Args:
            df: ロードするデータフレーム
            table_id: 対象テーブルID
            schema: テーブルスキーマ定義
            write_disposition: 書き込みモード
            
        Returns:
            ロード先のテーブルID
        
        Raises:
            BigQueryResourceError: データロード失敗時
        """
        start_time = time.time()
        
        try:
            # Polars DataFrameをPandasに変換
            if isinstance(df, pl.DataFrame):
                pandas_df = df.to_pandas()
            else:
                pandas_df = df
            
            # ロード設定
            job_config = bigquery.LoadJobConfig(
                schema=schema,
                write_disposition=write_disposition
            )
            
            # データロード実行
            job = self.client.load_table_from_dataframe(
                pandas_df, table_id, job_config=job_config
            )
            result = job.result()  # 完了待機
            
            # メトリクス記録
            duration = time.time() - start_time
            self._metrics.record_query(
                duration=duration,
                rows=len(pandas_df),
                bytes_processed=0  # LoadJobにはestimated_bytes_processedがないため0を指定
            )
            self._metrics.record_table_operation()
            
            logger.info(f"Loaded {len(pandas_df)} rows to {table_id} in {duration:.2f}s")
            return table_id
            
        except Exception as e:
            error_msg = f"Failed to load data to table {table_id}: {str(e)}"
            logger.error(error_msg)
            raise BigQueryResourceError(error_msg) from e

# =============================================================================
# コアクラス：データ取得と変換
# =============================================================================

class BigQueryDataFetcher:
    """
    BigQueryからデータを取得し適切な形式に変換するクラス
    
    主な責務:
    - クエリの実行と結果取得
    - 異なるデータ形式への変換
    - クエリ実行の最適化とモニタリング
    """
    
    def __init__(self, config: BigQueryConfig):
        """
        Args:
            config: BigQuery接続設定
        """
        if not BIGQUERY_AVAILABLE:
            raise ImportError(
                "Google Cloud BigQuery is not installed. "
                "Please install it with: pip install google-cloud-bigquery"
            )
        
        self.config = config
        # 認証情報に基づいてクライアントを初期化
        logger.info(f"DataFetcher: 認証情報の初期化を開始します: access_token={bool(config.access_token)}, service_account_email={bool(config.service_account_email)}")
        
        if config.access_token:
            # アクセストークンがある場合はそれを使用
            logger.info("DataFetcher: アクセストークンを使用して認証します")
            from google.oauth2.credentials import Credentials
            credentials = Credentials(token=config.access_token)
            self.client = bigquery.Client(
                project=config.project_id, 
                location=config.location,
                credentials=credentials
            )
        else:
            # アクセストークンがない場合はデフォルト認証情報を使用
            logger.info("DataFetcher: デフォルト認証情報を使用します")
            self.client = bigquery.Client(project=config.project_id, location=config.location)
        
        self._metrics = PerformanceMetrics()
        self._query_cache = {}
        self._enable_query_cache = True
        self._cache_ttl = 300  # 5分キャッシュ
        
        # データセットが存在するか確認し、存在しなければ作成
        self._ensure_dataset_exists()
    
    def _ensure_dataset_exists(self):
        """指定されたデータセットが存在するか確認し、存在しなければ作成"""
        dataset_id = f"{self.config.project_id}.{self.config.dataset_id}"
        try:
            # データセットの存在確認
            self.client.get_dataset(dataset_id)
            logger.info(f"データセット '{dataset_id}' は既に存在します")
        except Exception as e:
            # データセットが存在しない場合は作成
            logger.info(f"データセット '{dataset_id}' が存在しないため作成します")
            try:
                dataset = bigquery.Dataset(dataset_id)
                dataset.location = self.config.location
                dataset = self.client.create_dataset(dataset)
                logger.info(f"データセット '{dataset_id}' を作成しました（場所: {dataset.location}）")
            except google.api_core.exceptions.Conflict:
                # 409エラー: データセットが既に存在する場合は問題ないので、そのまま続行
                logger.info(f"データセット '{dataset_id}' は既に存在します（別プロセスで作成された可能性があります）")
            except Exception as create_error:
                logger.error(f"データセット '{dataset_id}' の作成に失敗しました: {create_error}")
                raise BigQueryResourceError(f"Failed to create dataset {dataset_id}: {str(create_error)}")
    
    @property
    def enable_query_cache(self) -> bool:
        """クエリキャッシュが有効かどうか"""
        return self._enable_query_cache
    
    @enable_query_cache.setter
    def enable_query_cache(self, value: bool):
        """クエリキャッシュの有効/無効を設定"""
        self._enable_query_cache = value
    
    def clear_cache(self):
        """クエリキャッシュをクリア"""
        self._query_cache = {}
        logger.debug("Query cache cleared")
    
    def set_cache_ttl(self, seconds: int):
        """キャッシュの有効期限を設定"""
        self._cache_ttl = max(1, seconds)
    
    def execute_query(self, query: str) -> pd.DataFrame:
        """
        SQLクエリを実行しPandas DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPandas DataFrame
            
        Raises:
            QueryExecutionError: クエリ実行エラー時
        """
        # キャッシュチェック
        if self._enable_query_cache and query in self._query_cache:
            cache_entry = self._query_cache[query]
            cache_time, result_df = cache_entry
            
            # キャッシュが有効期限内か確認
            if time.time() - cache_time < self._cache_ttl:
                logger.debug("Query result returned from cache")
                return result_df.copy()
        
        start_time = time.time()
        retry_count = 0
        
        while retry_count <= self.config.retry_count:
            try:
                # クエリ設定
                job_config = bigquery.QueryJobConfig(
                    use_query_cache=self.config.use_query_cache,
                    priority=self.config.priority
                )
                
                if self.config.max_bytes_billed:
                    job_config.maximum_bytes_billed = self.config.max_bytes_billed
                
                # クエリ実行
                query_job = self.client.query(
                    query,
                    job_config=job_config,
                    timeout=self.config.timeout_ms / 1000
                )
                
                # 結果取得
                result_df = query_job.to_dataframe()
                
                # キャッシュ保存
                if self._enable_query_cache:
                    self._query_cache[query] = (time.time(), result_df.copy())
                
                # メトリクス記録
                duration = time.time() - start_time
                self._metrics.record_query(
                    duration=duration,
                    rows=len(result_df),
                    bytes_processed=query_job.total_bytes_processed or 0
                )
                
                logger.debug(f"Query executed in {duration:.2f}s, returned {len(result_df)} rows")
                return result_df
                
            except Exception as e:
                retry_count += 1
                if retry_count > self.config.retry_count:
                    error_msg = f"Failed to execute query after {retry_count} attempts: {str(e)}"
                    logger.error(error_msg)
                    raise QueryExecutionError(error_msg) from e
                
                wait_time = 2 ** retry_count  # 指数バックオフ
                logger.warning(f"Query failed, retrying in {wait_time}s... ({retry_count}/{self.config.retry_count})")
                time.sleep(wait_time)

    def execute_batch_queries(
        self, 
        queries: List[str], 
        sequential: bool = False,
        max_concurrency: int = 4
    ) -> List[pd.DataFrame]:
        """
        複数のクエリをバッチ処理
        
        Args:
            queries: 実行するクエリリスト
            sequential: 順次実行するかどうか
            max_concurrency: 最大同時実行数
            
        Returns:
            DataFrame結果のリスト
        """
        if not queries:
            return []
        
        if sequential:
            # 順次実行
            return [self.execute_query(query) for query in queries]
        
        # 並列実行（ThreadPoolExecutorを使用）
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_concurrency) as executor:
            futures = [executor.submit(self.execute_query, query) for query in queries]
            results = [future.result() for future in concurrent.futures.as_completed(futures)]
        
        return results
    
    def execute_query_to_polars(self, query: str) -> pl.DataFrame:
        """
        SQLクエリを実行しPolars DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPolars DataFrame
        """
        pandas_df = self.execute_query(query)
        return pl.from_pandas(pandas_df)
    
    async def execute_query_async(self, query: str) -> pd.DataFrame:
        """
        SQLクエリを非同期実行しPandas DataFrameとして結果を返す
        
        Args:
            query: 実行するSQLクエリ
            
        Returns:
            クエリ結果のPandas DataFrame
        """
        loop = asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return await loop.run_in_executor(pool, self.execute_query, query)
    
    def get_metrics(self) -> Dict[str, Any]:
        """パフォーマンスメトリクスを取得"""
        return self._metrics.summary()


# =============================================================================
# ユーティリティ関数
# =============================================================================

def is_bigquery_available() -> bool:
    """BigQueryライブラリが利用可能かを確認"""
    return BIGQUERY_AVAILABLE

def check_bigquery_requirements():
    """
    BigQueryライブラリがインストールされているか確認し、
    インストールされていない場合は例外を発生させる
    
    Raises:
        ImportError: BigQueryライブラリがインストールされていない場合
    """
    if not BIGQUERY_AVAILABLE:
        raise ImportError(
            "Google Cloud BigQuery is not installed. "
            "Please install it with: pip install google-cloud-bigquery"
        )

def prepare_dataframe_for_bigquery(
    df: Union[pd.DataFrame, pl.DataFrame]
) -> pd.DataFrame:
    """
    DataFrameをBigQueryに適した形式に変換
    
    Args:
        df: 変換するDataFrame
        
    Returns:
        BigQueryに適したPandas DataFrame
    """
    # Polarsの場合はPandasに変換
    if isinstance(df, pl.DataFrame):
        pandas_df = df.to_pandas()
    else:
        pandas_df = df.copy()
    
    # 日付列の処理
    for col in pandas_df.columns:
        if pd.api.types.is_datetime64_any_dtype(pandas_df[col]):
            # 日付の形式を確実にBigQueryと互換性を持たせる
            pandas_df[col] = pandas_df[col].dt.tz_localize(None)
    
    return pandas_df 