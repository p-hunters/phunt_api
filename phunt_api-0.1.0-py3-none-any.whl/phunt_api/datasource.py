from abc import ABC, abstractmethod
from typing import Callable, Optional, Dict, Any
from datetime import datetime
import pandas as pd
from enum import Enum, auto
import requests
import json
import pandas as pd
import time
class DataSourceError(Exception):
    """データソース関連の基本例外クラス"""
    pass

class ConnectionError(DataSourceError):
    """接続エラー"""
    pass

class DataError(DataSourceError):
    """データ取得エラー"""
    pass

class Provider(Enum):
    """サポートされているプロバイダーの列挙型"""
    DUKASCOPY = auto()
    OANDA = auto()
    MT5 = auto()

class BaseDataSourceClient(ABC):
    """データソースクライアントの基底クラス"""
    
    @abstractmethod
    def connect(self, symbol: str, granularity: str) -> None:
        """基本的な接続処理"""
        pass
        
    @abstractmethod
    def ws_connect(self, 
                   symbol: str,
                   granularity: str,
                   on_data: Callable[[Dict[str, Any]], None],
                   on_error: Callable[[Exception], None]) -> None:
        """WebSocket接続処理"""
        pass
        
    @abstractmethod
    def get_data(self,
                 symbol: str,
                 start_date: str,
                 end_date: str,
                 granularity: str) -> pd.DataFrame:
        """ヒストリカルデータ取得"""
        pass

class DataSourceManager:
    """データソースクライアントのファクトリークラス"""
    
    def __init__(self,
                 provider: str,
                 symbol: str,
                 granularity: str,
                 **provider_settings):
        self.provider = self._get_provider(provider, **provider_settings)
        self.symbol = symbol
        self.granularity = granularity
        
    def _get_provider(self, provider_name: str, **settings) -> BaseDataSourceClient:
        """プロバイダーの初期化"""
        try:
            provider = Provider[provider_name.upper()]
        except KeyError:
            raise ValueError(f"Unsupported provider: {provider_name}")
            
        providers = {
            Provider.DUKASCOPY: lambda: DukascopyProvider(**settings),
            Provider.OANDA: lambda: OandaProvider(**settings),
            Provider.MT5: lambda: MT5Provider(**settings)
        }
        
        return providers[provider]()
        
    def connect(self) -> None:
        """基本接続の確立"""
        try:
            self.provider.connect(
                symbol=self.symbol,
                granularity=self.granularity
            )
        except Exception as e:
            raise ConnectionError(f"Failed to connect: {str(e)}")
        
    def ws_connect(self,
                   on_data: Callable[[Dict[str, Any]], None],
                   on_error: Callable[[Exception], None]) -> None:
        """WebSocket接続の確立"""
        try:
            self.provider.ws_connect(
                symbol=self.symbol,
                granularity=self.granularity,
                on_data=on_data,
                on_error=on_error
            )
        except Exception as e:
            raise ConnectionError(f"Failed to establish WebSocket connection: {str(e)}")
        
    def get_data(self,
                 start_date: str,
                 end_date: str) -> pd.DataFrame:
        """ヒストリカルデータの取得"""
        try:
            return self.provider.get_data(
                symbol=self.symbol,
                start_date=start_date,
                end_date=end_date,
                granularity=self.granularity
            )
        except Exception as e:
            raise DataError(f"Failed to fetch data: {str(e)}")

class DukascopyProvider(BaseDataSourceClient):
    """Dukascopy固有の実装"""
    
    def __init__(self, 
                 host: str = "ds-api.p-hunters.com",
                 rest_port: int = 443,
                 ws_port: int = 445,
                 **kwargs):
        self.rest_base_url = f"https://{host}:{rest_port}/api/v1"
        self.ws_base_url = f"wss://{host}:{ws_port}/ticker"
        self.ws = None
        self.connected = False
        self.settings = kwargs

    def connect(self):
        # Implement the connection logic here
        pass

    def ws_connect(self):
        # Implement the WebSocket connection logic here
        pass

    def get_data(self, symbol: str, start_date: str, end_date: str=None, granularity: str='1min') -> pd.DataFrame:
        start_date_ms = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
        if end_date is not None:
            end_date_ms = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp() * 1000)
        else:
            # truncate to the nearest minute
            now_ms = int(datetime.now().timestamp() * 1000)
            end_date_ms = now_ms - (now_ms % (1000 * 60))
        url = f"{self.rest_base_url}/history"
        params = {
            "instID": symbol,
            "timeFrame": granularity.upper(),
            "from": start_date_ms,
            "to": end_date_ms
        }
        for i in range(3):
            response = requests.get(url, params=params)
            if response.status_code == 200:
                break
            else:
                print(f"API request failed with status code {response.status_code}: {response.text}")
                print(f"Retrying... ({i+1}/3)")
                time.sleep(1)

        if response.status_code != 200:
            raise DataError(f"API request failed with status code {response.status_code}: {response.text}")

        data = json.loads(response.text)
        
        # Check if data is empty or not in expected format
        if not data or not isinstance(data, list):
            raise DataError(f"Invalid data format received from API: {data}")
            
        try:
            df = pd.DataFrame(data)
            df['ts'] = pd.to_datetime(df['timestamp'] * 1000000, utc=True)
            return df
        except (KeyError, ValueError) as e:
            raise DataError(f"Failed to process API data: {str(e)}\nReceived data: {data}")

if __name__ == "__main__":  
    pass
