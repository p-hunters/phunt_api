# -*- coding: utf-8 -*-

from typing import List, Dict, Any, Callable
import platform
import os
# MacOSの場合、OpenBLASのスレッド数を設定
if platform.system() == 'Darwin':  # Darwinは MacOS のシステム名
    os.environ['OPENBLAS_NUM_THREADS'] = '1'

from .dataset import DatasetManager
from .feature import FeatureManager
from .target import TargetManager
from .backtest import Backtest
from .exceptions import ModelError
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os
import inspect
from openai import OpenAI 
from .model_example import create_model, create_model_original
import json

class ModelManager:
    def __init__(self, dataset_manager: DatasetManager, feature_manager: FeatureManager, target_manager: TargetManager):
        self.dataset_manager = dataset_manager
        self.feature_manager = feature_manager
        self.target_manager = target_manager
        self.mlflow_tracking_uri = os.getenv("MLFLOW_TRACKING_URI", "https://mlflow.p-hunters.com/")
        os.environ["MLFLOW_TRACKING_USERNAME"] = "admin"
        os.environ["MLFLOW_TRACKING_PASSWORD"] = "password"
        mlflow.set_tracking_uri(self.mlflow_tracking_uri)
        self.creds = {}
        # try:
        #     self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", self.creds.get('OPENAI_API_KEY')))
        # except Exception as e:
        #     pass

    def modify_code(self, code: Callable) -> str:
        """シンプルなモデル作成コードをMLflow対応の完全版に変換する"""
        # 元のコードの文字列を取得
        code_str = inspect.getsource(code)

        # コードの変換例
        original_code = inspect.getsource(create_model_original)
        modified_code = inspect.getsource(create_model)
        
        # AIによるコード変換のプロンプト
        modification_prompt = f"""
        以下のシンプルなモデル作成コードを、年次バリデーション、MLflowロギング、バックテストを含む完全版に変換してください：

        以下の要件を満たすように変換してください：
        0. 前処理
            - api.join_and_drop()を使用して、Xとyのtimestampを揃える
            - Print data shape and head
        1. 年次バリデーションの実装（各年でのトレーニングと評価）
            - 2年分のバリデーションを行う
        2. MLflowによる以下の要素のロギング：
           - 各年のモデルとスコア
           - ハイパーパラメータ
           - バックテスト結果
        3. Optunaによるハイパーパラメータ最適化
           - child_run.info.run_idをtrial.set_user_attr('mlflow.run_id', child_run.info.run_id)で設定
        4. バックテストの実行とパフォーマンス評価
           - join_and_drop MUST be called before predict to get the same timestamp order

        変換は以下のコードを参考にしてください：
        original:
        ```python
        {original_code}
        ```

        modified:
        ```python
        {modified_code}
        ```

        出力は、def create_model(api, mlflow)の中身だけでお願いします。
        import文はメソッド内で記述してください。

        元のコード：
        {code_str}
        """

        # OpenAI APIを使用してコードを変換
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "あなたは機械学習の専門家で、Pythonコードを最適化するAIアシスタントです。"},
                {"role": "user", "content": modification_prompt}
            ]
        )
        
        # 変換されたコードを取得して整形
        modified_code = response.choices[0].message.content
        modified_code = modified_code.replace('```python', '').replace('```', '').strip()
        print(modified_code)
        
        return modified_code
    
    def delete_experiment_permanently(self, name: str):
        from mlflow.tracking import MlflowClient    
        client = MlflowClient(tracking_uri=self.mlflow_tracking_uri)
        experiment = client.get_experiment_by_name(name)
        if experiment:
            client._tracking_client._tracking_store.delete_experiment(experiment.experiment_id)


    def is_experiment_exists_soft(self, name: str) -> bool:
        from mlflow.tracking import MlflowClient    
        client = MlflowClient(tracking_uri=self.mlflow_tracking_uri)
        experiment = client.get_experiment_by_name(name)
        if experiment:
            print(experiment.lifecycle_stage)
            return experiment.lifecycle_stage.upper() == 'DELETED'
        return False

    def submit_model(self, name: str, code: Callable, previous_code_error: str = None, retry: int = 3) -> Dict[str, Any]:
        if self.is_experiment_exists_soft(name):
            print(f"Experiment {name} already exists. Deleting...")
            self.delete_experiment_permanently(name)
        print(type(code) == Callable, type(code))
        if retry == 0:
            raise ModelError(f"モデルの登録中にエラーが発生しました: {previous_code_error}")
        try:
            from phunt_api import PHuntAPI
            
            api = PHuntAPI(debug=True)
            
            # コードの文字列を取得
            if previous_code_error:
                code_str = code
            else:
                code_str = inspect.getsource(code)

            code_str = self.modify_code(code)

            # AIによるコード最適化のプロンプト
            optimization_prompt = f"""
            以下の機械学習モデル作成コードを分析し、以下の観点で改善してください：
            - mlflowでmodel構築のログを取得する
            - mlflow.tensorflow.autolog() のように、mlflowによるログ取得を行う
            
            元のコード：
            {code_str}
            
            改善されたコードを Python コードとして出力してください。
            あなたの出力は、以下のようなPythonコードで利用されます。
            ---
            # 最適化されたコードを取得
            optimized_code_str = response.choices[0].message.content
            
            # 文字列からコードを実行可能な関数に変換
            local_dict = {{}}
            exec(optimized_code_str, globals(), local_dict)
            optimized_code = local_dict['create_model']
            
            # MLflow実験の開始
            mlflow.set_experiment(name)
            models, pred_df = optimized_code(api, mlflow)
            ---

            上記からわかるように、出力は、def create_model(api, mlflow)の中身だけでお願いします。
            import文はメソッド内で記述してください。
            previous_code_errorがある場合は、その内容をもとにコードを修正してください。
            previous_code_error: {previous_code_error}
            """
            # OpenAI API使用してコードを最適化
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "あなたは機械学習の専門家で、Pythonコードを最適化するAIアシスタントです。"},
                    {"role": "user", "content": optimization_prompt}
                ]
            )
            
            # 最適化されたコードを取得
            optimized_code_str = response.choices[0].message.content
            # ```python を削除
            optimized_code_str = optimized_code_str.replace('```python', '')
            optimized_code_str = optimized_code_str.replace('```', '')
            print(optimized_code_str)
            
            # 文字列からコードを実行可能な関数に変換
            local_dict = {}
            exec(optimized_code_str, globals(), local_dict)
            optimized_code = local_dict['create_model']
            
            # MLflow実験の開始
            mlflow.set_experiment(name)
            try:
                with open('optimized_code.py', 'w') as f:
                    f.write(optimized_code_str)
                models, pred_df = optimized_code(api, mlflow)
            except Exception as e:
                print(f"エラーが発生しました: {str(e)}")
                # エラーの内容をAPIに渡して、 コードを自動修正する
                previous_code_error = f"{previous_code_error}\n{str(e)}"
                self.submit_model(name, optimized_code, previous_code_error, retry - 1)
                
        except Exception as e:
            raise ModelError(f"モデルの登録中にエラーが発生しました: {str(e)}")
        
        api.submit_feature(name=name + '_PRED', df=pred_df)
        return models
    
    def backtest(self, name: str, code: Callable):
        backtest = Backtest(self.api)
        backtest.run()

    def load_model(self, run_id: str, model_name: str):
        logged_model = f'runs:/{run_id}/{model_name}'
        loaded_model = mlflow.pyfunc.load_model(logged_model)
        metadata = str(loaded_model.metadata)
        print(metadata)
        if 'sklearn' in metadata:
            _model = mlflow.sklearn.load_model(logged_model)
            feature_names = _model.feature_names_in_
        else:
            feature_names = None
        return loaded_model, feature_names


if __name__ == "__main__":
    from phunt_api import PHuntAPI
    api = PHuntAPI(debug=True)

    def create_model_original(api, mlflow):

        params = {}
        y_train, y_val = api.get_target('USDJPY_1MIN_RETURN')
        X_train, X_val = api.get_feature('USDJPY_1MIN_MOMENTUM')
        model = mlflow.sklearn.RandomForestRegressor(**params)
        model.fit(X_train[['momentum_1d', 'momentum_5d']], y_train['next_day_return'])
        return model
        
    models = api.model_manager.submit_model(name='USDJPY_1MIN_MODEL_2', code=create_model_original)

