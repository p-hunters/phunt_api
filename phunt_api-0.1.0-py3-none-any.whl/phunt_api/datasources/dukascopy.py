"""
Dukascopy data provider implementation
"""
import json
import time
import pandas as pd
import requests
from datetime import datetime
from typing import Dict, Any, Callable, Optional

from .base import BaseDataSourceClient, DataError

class DukascopyProvider(BaseDataSourceClient):
    """Dukascopy固有の実装"""
    
    def __init__(self, 
                 host: str = "ds-api.p-hunters.com",
                 rest_port: int = 443,
                 ws_port: int = 445,
                 **kwargs):
        """Dukascopyプロバイダーの初期化
        
        Args:
            host (str): APIホスト名
            rest_port (int): REST API用ポート
            ws_port (int): WebSocket API用ポート
            **kwargs: その他の設定パラメータ
        """
        self.rest_base_url = f"https://{host}:{rest_port}/api/v1"
        self.ws_base_url = f"wss://{host}:{ws_port}/ticker"
        self.ws = None
        self.connected = False
        self.settings = kwargs

    def connect(self, symbol: str, granularity: str) -> None:
        """基本的な接続処理
        
        Args:
            symbol (str): 通貨ペアなど、取得対象のシンボル
            granularity (str): データ粒度 (例: '1min', '1hour', 'daily')
        """
        # Basic connection implementation - can be expanded as needed
        # APIサーバへのGETなので、接続は不要
        pass

    def ws_connect(self, 
                  symbol: str,
                  granularity: str,
                  on_data: Callable[[Dict[str, Any]], None],
                  on_error: Callable[[Exception], None]) -> None:
        """WebSocket接続処理
        
        Args:
            symbol (str): 通貨ペアなど、取得対象のシンボル
            granularity (str): データ粒度 (例: '1min', '1hour', 'daily')
            on_data (Callable): 新しいデータを受信したときに呼び出されるコールバック
            on_error (Callable): エラー発生時に呼び出されるコールバック
        """
        # WebSocket connection implementation - can be expanded as needed
        pass

    def get_data(self, 
                symbol: str, 
                start_date: str, 
                end_date: str = None, 
                granularity: str = '1min') -> pd.DataFrame:
        """ヒストリカルデータ取得
        
        Args:
            symbol (str): 通貨ペアなど、取得対象のシンボル
            start_date (str): 開始日 (YYYY-MM-DD形式)
            end_date (str, optional): 終了日 (YYYY-MM-DD形式)。Noneの場合は現在時刻まで
            granularity (str, optional): データ粒度。デフォルトは '1min'
            
        Returns:
            pd.DataFrame: 取得したヒストリカルデータ
            
        Raises:
            DataError: データ取得に失敗した場合
        """
        start_date_ms = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
        if end_date is not None:
            end_date_ms = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp() * 1000)
        else:
            # truncate to the nearest minute
            now_ms = int(datetime.now().timestamp() * 1000)
            end_date_ms = now_ms - (now_ms % (1000 * 60))
            
        url = f"{self.rest_base_url}/history"
        params = {
            "instID": symbol,
            "timeFrame": granularity.upper(),
            "from": start_date_ms,
            "to": end_date_ms
        }
        
        # リトライロジック
        for i in range(3):
            response = requests.get(url, params=params)
            if response.status_code == 200:
                break
            else:
                print(f"API request failed with status code {response.status_code}: {response.text}")
                print(f"Retrying... ({i+1}/3)")
                time.sleep(1)

        if response.status_code != 200:
            raise DataError(f"API request failed with status code {response.status_code}: {response.text}")

        data = json.loads(response.text)
        
        # Check if data is empty or not in expected format
        if not data or not isinstance(data, list):
            raise DataError(f"Invalid data format received from API: {data}")
            
        try:
            df = pd.DataFrame(data)
            df['ts'] = pd.to_datetime(df['timestamp'] * 1000000, utc=True)
            # TODO スプレッドの考慮
            return df
        except (KeyError, ValueError) as e:
            raise DataError(f"Failed to process API data: {str(e)}\nReceived data: {data}") 