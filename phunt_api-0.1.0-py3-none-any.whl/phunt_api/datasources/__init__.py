"""
P-Hunter Data Source Providers Package

This package contains implementations for various data source providers.
"""

from .base import (
    BaseDataSourceClient,
    DataSourceError,
    ConnectionError,
    DataError,
    Provider
)

from .dukascopy import DukascopyProvider
# Import other provider implementations as they are added
# from .oanda import OandaProvider
# from .mt5 import MT5Provider

__all__ = [
    # Base classes and exceptions
    'BaseDataSourceClient',
    'DataSourceError',
    'ConnectionError',
    'DataError',
    'Provider',
    
    # Provider implementations
    'DukascopyProvider',
    # 'OandaProvider',
    # 'MT5Provider',
] 