"""
Base classes and common utilities for data source providers
"""

from abc import ABC, abstractmethod
from typing import Callable, Optional, Dict, Any
import pandas as pd
from enum import Enum, auto

class DataSourceError(Exception):
    """データソース関連の基本例外クラス"""
    pass

class ConnectionError(DataSourceError):
    """接続エラー"""
    pass

class DataError(DataSourceError):
    """データ取得エラー"""
    pass

class Provider(Enum):
    """サポートされているプロバイダーの列挙型"""
    DUKASCOPY = auto()
    OANDA = auto()
    MT5 = auto()
    # Add new providers here as they are supported

class BaseDataSourceClient(ABC):
    """データソースクライアントの基底クラス"""
    
    @abstractmethod
    def connect(self, symbol: str, granularity: str) -> None:
        """基本的な接続処理
        
        Args:
            symbol (str): 通貨ペアや商品など、取得対象のシンボル
            granularity (str): データ粒度 (例: '1min', '1hour', 'daily')
        """
        pass
        
    @abstractmethod
    def ws_connect(self, 
                  symbol: str,
                  granularity: str,
                  on_data: Callable[[Dict[str, Any]], None],
                  on_error: Callable[[Exception], None]) -> None:
        """WebSocket接続処理
        
        Args:
            symbol (str): 通貨ペアや商品など、取得対象のシンボル
            granularity (str): データ粒度 (例: '1min', '1hour', 'daily')
            on_data (Callable): 新しいデータを受信したときに呼び出されるコールバック
            on_error (Callable): エラー発生時に呼び出されるコールバック
        """
        pass
        
    @abstractmethod
    def get_data(self,
                symbol: str,
                start_date: str,
                end_date: str,
                granularity: str) -> pd.DataFrame:
        """ヒストリカルデータ取得
        
        Args:
            symbol (str): 通貨ペアや商品など、取得対象のシンボル
            start_date (str): 開始日 (YYYY-MM-DD形式)
            end_date (str): 終了日 (YYYY-MM-DD形式)
            granularity (str): データ粒度 (例: '1min', '1hour', 'daily')
            
        Returns:
            pd.DataFrame: 取得したヒストリカルデータ
        """
        pass 