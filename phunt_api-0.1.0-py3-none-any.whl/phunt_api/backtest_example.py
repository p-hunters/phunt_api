#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
バックテストシステムのサンプル実行スクリプト
EURUSD予測モデルの結果を使用してバックテストを実行します。
"""

import os
import argparse
import logging
from datetime import datetime
from pathlib import Path

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# インポートパスが正しく設定されるように調整
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# バックテストクラスのインポート
from phunt_api.backtest import Backtest

def parse_arguments():
    """
    コマンドライン引数をパースする関数
    
    Returns:
        argparse.Namespace: パースされた引数
    """
    parser = argparse.ArgumentParser(description='バックテスト実行スクリプト')
    parser.add_argument('--pred_data_path', type=str, required=True,
                        help='予測データのCSVファイルパス')
    parser.add_argument('--model_path', type=str, required=False,
                        help='学習済みモデルファイルのパス（必要な場合）')
    parser.add_argument('--output_dir', type=str, required=False,
                        help='出力ディレクトリ（指定しない場合は自動生成）')
    parser.add_argument('--initial_balance', type=float, default=10000.0,
                        help='初期資金')
    parser.add_argument('--position_size', type=float, default=0.1,
                        help='ポジションサイズ（資金に対する割合）')
    parser.add_argument('--commission', type=float, default=0.0,
                        help='取引手数料（片道）')
    parser.add_argument('--spread_cost', type=float, default=None,
                        help='スプレッドコスト（pips、データになければ指定）')
    parser.add_argument('--stop_loss', type=float, default=10.0,
                        help='損切り値（pips）')
    parser.add_argument('--take_profit', type=float, default=10.0,
                        help='利益確定値（pips）')
    parser.add_argument('--probability_threshold', type=float, default=0.55,
                        help='予測確率の閾値')
    parser.add_argument('--max_holding_time', type=int, default=30,
                        help='最大保有時間（分）')
    parser.add_argument('--min_time_between_trades', type=int, default=60,
                        help='取引間の最小時間（分）')
    
    return parser.parse_args()

def main():
    """
    メイン関数
    
    バックテストを実行し、結果を表示・保存します。
    """
    # コマンドライン引数の解析
    args = parse_arguments()
    
    # 実行開始のログ
    logger.info("EURUSDモデル予測結果のバックテストを開始します")
    logger.info(f"予測データ: {args.pred_data_path}")
    logger.info(f"モデル: {args.model_path}")
    
    # 出力ディレクトリの設定
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = None
    
    if args.output_dir:
        output_dir = os.path.join(args.output_dir, f"backtest_{timestamp}")
    
    # バックテストインスタンスの作成
    backtest = Backtest(
        pred_data_path=args.pred_data_path,
        model_path=args.model_path,
        output_dir=output_dir,
        initial_balance=args.initial_balance,
        position_size=args.position_size,
        commission=args.commission,
        spread_cost=args.spread_cost,
        stop_loss=args.stop_loss,
        take_profit=args.take_profit,
        probability_threshold=args.probability_threshold,
        max_holding_time=args.max_holding_time,
        min_time_between_trades=args.min_time_between_trades
    )
    
    try:
        # バックテスト実行開始時間
        start_time = datetime.now()
        
        # バックテストの実行
        backtest.run()
        
        # 実行時間の計算
        end_time = datetime.now()
        execution_time = end_time - start_time
        
        # 結果の表示
        logger.info(f"バックテスト結果を {output_dir} に保存しました")
        logger.info(f"実行時間: {execution_time}")
        
        # パフォーマンス指標の表示
        if hasattr(backtest, 'performance_metrics') and backtest.performance_metrics:
            logger.info("=== パフォーマンス指標の概要 ===")
            for key, value in backtest.performance_metrics.items():
                if key in ['total_return_pct', 'annual_return_pct', 'win_rate', 'max_drawdown_pct']:
                    logger.info(f"{key}: {value:.2f}%")
                elif isinstance(value, float):
                    logger.info(f"{key}: {value:.4f}")
                else:
                    logger.info(f"{key}: {value}")
    
    except Exception as e:
        logger.error(f"バックテスト実行中にエラーが発生しました: {str(e)}", exc_info=True)
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 