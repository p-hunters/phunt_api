from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import boto3
import logging
import traceback
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict
import json
# from apscheduler.schedulers.asyncio import AsyncIOScheduler
import httpx
import os
import uuid
import botocore
from google.oauth2 import service_account
from google.auth import impersonated_credentials
import google.auth.transport.requests
from google.auth.credentials import Credentials
from google.auth.transport.requests import Request as GoogleRequest
from google.auth.transport import requests
from google.auth import identity_pool
from googleapiclient.discovery import build
from google.auth.credentials import Credentials as GoogleCredentials
from google.auth.transport.requests import Request as GoogleRequest
from google.auth.transport import requests
import tempfile
import time
import socket
from google.auth.transport import requests as google_requests
import requests



# ロギングの設定
log_level = os.getenv("PHUNT_LOG_LEVEL", "INFO")
# Lambda環境ではファイルハンドラーを使わない（/var/taskは読み取り専用）
handlers = [logging.StreamHandler(sys.stdout)]
if not os.environ.get('AWS_LAMBDA_FUNCTION_NAME'):
    # Lambda環境でない場合のみファイルハンドラーを追加
    handlers.append(logging.FileHandler('auth_server.log'))
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=handlers
)
logger = logging.getLogger(__name__)

# FastAPIのデフォルトロガーも詳細に設定
uvicorn_logger = logging.getLogger("uvicorn")
uvicorn_logger.setLevel(getattr(logging, log_level, logging.INFO))

def create_app() -> FastAPI:
    """FastAPIアプリケーションを作成する関数"""
    app = FastAPI(
        title="PHunt Authentication Server",
        debug=True,
        docs_url="/docs",
        redoc_url="/redoc"
    )

    class CredentialResponse(BaseModel):
        access_key_id: str
        secret_access_key: str
        session_token: Optional[str] = None
        expiration: datetime

    class GCPCredentialResponse(BaseModel):
        """Google Cloud一時的認証情報のレスポンスモデル"""
        token: str
        expiration: datetime
        service_account_email: str

    class S3PolicyCleanupResult(BaseModel):
        """S3ポリシークリーンアップの結果を表すモデル"""
        removed_statements: List[Dict]
        updated_policy: Dict
        timestamp: datetime

    @app.get("/health")
    async def health_check():
        """ヘルスチェックエンドポイント"""
        logger.debug("Health check endpoint called")
        try:
            response = {
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat()
            }
            logger.debug(f"Returning response: {response}")
            return response
        except Exception as e:
            logger.error(f"Health check error: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    @app.post("/credentials")
    async def get_credentials(request: Request):
        try:
            # リクエストデータを取得
            data = await request.json()
            email = data.get('email', None)
            
            # Lambda環境ではIAMロールを使用、それ以外では環境変数を使用
            is_lambda = os.environ.get('AWS_LAMBDA_FUNCTION_NAME') is not None
            
            if is_lambda:
                # Lambda環境: IAMロールを使用
                session = boto3.Session(region_name='ap-northeast-1')
                logger.info("Using IAM role for AWS credentials (Lambda environment)")
            else:
                # 非Lambda環境: 環境変数を使用
                required_env_vars = ['AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY']
                missing_vars = [var for var in required_env_vars if not os.environ.get(var)]
                if missing_vars:
                    logger.error(f"Missing required AWS environment variables: {', '.join(missing_vars)}")
                    raise HTTPException(
                        status_code=500,
                        detail="AWS credentials not properly configured"
                    )
                session = boto3.Session(
                    aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
                    aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'],
                    region_name='ap-northeast-1'
                )
                logger.info("Using environment variables for AWS credentials (non-Lambda environment)")
            
            sts_client = session.client('sts')
            
            # ロールの引き受け
            try:
                logger.info(f"PHUNT_RESTRICTED_ROLE_ARN: {os.environ.get('PHUNT_RESTRICTED_ROLE_ARN')}")
                session_name = f'PHuntSession_{email}' if email else f'PHuntSession_{uuid.uuid4()}'
                response = sts_client.assume_role(
                    RoleArn=os.environ.get("PHUNT_RESTRICTED_ROLE_ARN"),  # 環境変数から制限付きロールのARNを取得,
                    RoleSessionName=session_name,
                    DurationSeconds=43200
                )
                
                return Response(
                    content=json.dumps({
                        'access_key_id': response['Credentials']['AccessKeyId'],
                        'secret_access_key': response['Credentials']['SecretAccessKey'],
                        'session_token': response['Credentials']['SessionToken'],
                        'expiration': response['Credentials']['Expiration'].isoformat()
                    }),
                    media_type='application/json'
                )
                
            except botocore.exceptions.ClientError as e:
                error_code = e.response['Error']['Code']
                error_message = e.response['Error']['Message']
                logger.error(f"AWS STS error: {error_code} - {error_message}")
                logger.error(f"Current AWS Access Key ID: {os.environ.get('AWS_ACCESS_KEY_ID', 'Not Set')[:5]}...")
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to assume role: {error_message}"
                )
                
        except Exception as e:
            logger.error(f"Error generating credentials: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail=f"Internal server error: {str(e)}"
            )

    async def cleanup_s3_bucket_policies():
        """期限切れのS3バケットポリシーをクリーンアップする"""
        try:
            logger.info("Starting S3 bucket policy cleanup")
            s3_client = boto3.client('s3')
            bucket_name = "phunt-data"
            
            # 現在のポリシーを取得
            try:
                policy = s3_client.get_bucket_policy(Bucket=bucket_name)
                policy_json = json.loads(policy['Policy'])
            except s3_client.exceptions.NoSuchBucketPolicy:
                logger.info(f"No policy found for bucket {bucket_name}")
                return
            
            current_time = datetime.now(timezone.utc)
            statements = policy_json.get('Statement', [])
            removed_statements = []
            new_statements = []
            
            # 各ステートメントをチェック
            for statement in statements:
                # PHuntSessionのステートメントのみを処理
                if statement.get('Sid', '').startswith('AllowPHuntSession_'):
                    # セッション名から有効期限を抽出（1時間）
                    creation_time_str = statement.get('Condition', {}).get('StringEquals', {}).get('aws:PrincipalTag/aws:RoleSessionName', '')
                    if creation_time_str:
                        # セッションの作成時刻を推定（1時間前）
                        session_creation_time = current_time - timedelta(hours=1)
                        
                        # 期限切れの場合、削除リストに追加
                        if current_time > session_creation_time + timedelta(hours=1):
                            removed_statements.append(statement)
                            continue
                
                new_statements.append(statement)
            
            # ポリシーが変更された場合のみ更新
            if removed_statements:
                policy_json['Statement'] = new_statements
                s3_client.put_bucket_policy(
                    Bucket=bucket_name,
                    Policy=json.dumps(policy_json)
                )
                logger.info(f"Removed {len(removed_statements)} expired policy statements")
            else:
                logger.info("No expired policy statements found")
            
            return S3PolicyCleanupResult(
                removed_statements=removed_statements,
                updated_policy=policy_json,
                timestamp=current_time
            )
            
        except Exception as e:
            logger.error(f"Error during S3 bucket policy cleanup: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail={
                    "error": str(e),
                    "traceback": traceback.format_exc()
                }
            )

    @app.on_event("startup")
    async def startup_event():
        """アプリケーション起動時の初期化処理"""
        logger.info("Starting PHunt Authentication Server")
        # logger.info("Debug mode enabled")
        # logger.debug("Python version: " + sys.version)
        # logger.debug("FastAPI version: " + app.version)
        
        # # アクセス方法の情報を表示
        # logger.info("=== Access Information ===")
        # logger.info("Available endpoints:")
        # logger.info("1. Health Check:")
        # logger.info("   GET /health")
        # logger.info("   Example: curl http://localhost:8000/health")
        
        # logger.info("\n2. Get Credentials:")
        # logger.info("   POST /credentials")
        # logger.info("   Example:")
        # logger.info("   curl -X POST http://localhost:8000/credentials")
        
        # logger.info("\n3. Feast UI Proxy (if enabled):")
        # logger.info("   Access via: http://localhost:8888/feast/")
        # logger.info("============================")
        
        # # クリーンアップスケジューラーの設定
        # scheduler = AsyncIOScheduler()
        # scheduler.add_job(cleanup_s3_bucket_policies, 'interval', minutes=15)
        # scheduler.start()
        # logger.info("S3 bucket policy cleanup scheduler started")




    @app.post("/gcp-credentials")
    async def get_gcp_access_token(request: Request):
        """
        AWS IAM Roleの一時認証情報を使用してGCPのサービスアカウントの認証情報を取得する
        Workload Identity Federationを使用
        """
        try:
            logger.info("Starting GCP credentials request processing")
            
            # リクエストデータの取得
            if request is not None and request.method == 'POST':
                try:
                    request_data = await request.json()
                    email = request_data.get('email', None)
                    logger.info(f"Request received with email: {email}")
                except Exception as e:
                    logger.error(f"Error parsing request JSON: {str(e)}")
                    email = None
            else:
                email = None
            
            # GCP認証情報を取得
            logger.info("Calling _get_gcp_access_token function")
            gcp_response = _get_gcp_access_token(email)
            logger.info("GCP credentials obtained successfully")

            # トークンの有効期限を設定
            expiration = datetime.now(timezone.utc) + timedelta(hours=1)
            if 'expireTime' in gcp_response:
                try:
                    # Google Cloudからのタイムスタンプをパース (ISO 8601 形式)
                    expiration = datetime.fromisoformat(gcp_response['expireTime'].replace('Z', '+00:00'))
                    logger.info(f"Using expiration time from GCP response: {expiration}")
                except Exception as e:
                    logger.warning(f"Failed to parse expiration time: {e}. Using default expiration.")
            
            return GCPCredentialResponse(
                token=gcp_response.get('accessToken', gcp_response.get('token', '')),
                expiration=expiration,
                service_account_email=os.environ.get('TARGET_SERVICE_ACCOUNT_EMAIL', "phunt-api-public@phunt-api.iam.gserviceaccount.com")
            )
            
        except Exception as e:
            logger.error(f"GCP認証情報の取得に失敗: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail=f"GCP認証情報の生成中にエラーが発生しました: {str(e)}"
            )
    
    @app.get("/admin/cleanup-policies")
    async def manual_cleanup():
        """手動でポリシークリーンアップを実行するエンドポイント"""
        try:
            result = await cleanup_s3_bucket_policies()
            return result
        except Exception as e:
            logger.error(f"Manual cleanup failed: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    @app.on_event("shutdown")
    async def shutdown_event():
        """アプリケーション終了時の処理"""
        logger.info("Shutting down PHunt Authentication Server")

    return app


def _get_gcp_access_token(email: str):
        """
        AWS認証情報を使用してGCPのサービスアカウントの認証情報を取得する
        Workload Identity Federationを使用
        正式なGoogle認証ライブラリのAWSサプライヤーパターンを実装
        """
        try:
            logger.info("Starting to get GCP credentials with AWS credential supplier")
            
            # Lambda環境ではIAMロールを使用、それ以外ではデフォルトの認証情報を使用
            is_lambda = os.environ.get('AWS_LAMBDA_FUNCTION_NAME') is not None
            if is_lambda:
                # Lambda環境: IAMロールを使用
                sts_client = boto3.client('sts', region_name='ap-northeast-1')
                logger.info("Using IAM role for STS client (Lambda environment)")
            else:
                # 非Lambda環境: デフォルトの認証情報を使用
                sts_client = boto3.client('sts', region_name='ap-northeast-1')
                logger.info("Using default credentials for STS client (non-Lambda environment)")
            
            # AWS STSからトークンを取得
            # PHuntRestrictedAccess Roleをassumeしてトークンを取得
            session_name = f'PHuntSession_{email}' if email else f'PHuntSession_{uuid.uuid4()}'
            
            logger.info(f"Assuming role with session name: {session_name}")
            response = sts_client.assume_role(
                RoleArn=os.environ.get("PHUNT_RESTRICTED_ROLE_ARN", "arn:aws:iam::856121715507:role/PHuntRestrictedAccess"),
                RoleSessionName=session_name,
                DurationSeconds=900
            )
            
            # トークンを取得
            aws_token = response['Credentials']
            logger.info(f"AWS credentials obtained with expiration: {aws_token['Expiration']}")
            
            # GCP設定を取得
            project_number = os.environ.get("GCP_PROJECT_NUMBER", "408218479246")
            workload_identity_pool_id = os.environ.get('WORKLOAD_IDENTITY_POOL_ID', "aws-pool")
            workload_identity_provider_id = os.environ.get('WORKLOAD_IDENTITY_PROVIDER_ID', "aws-provider")
            service_account_email = os.environ.get('TARGET_SERVICE_ACCOUNT_EMAIL', "phunt-api-public@phunt-api.iam.gserviceaccount.com")
            
            logger.info(f"Using project number: {project_number}")
            logger.info(f"Using workload identity pool: {workload_identity_pool_id}")
            logger.info(f"Using workload identity provider: {workload_identity_provider_id}")
            logger.info(f"Using service account: {service_account_email}")
            
            # AWS認証情報サプライヤーを作成
            from google.auth import aws
            from google.auth import exceptions as auth_exceptions
            
            class AwsCredentialSupplier(aws.AwsSecurityCredentialsSupplier):
                def __init__(self, credentials):
                    self.credentials = credentials
                
                def get_aws_security_credentials(self, context, request):
                    logger.info("Supplying AWS security credentials from assume_role response")
                    try:
                        return aws.AwsSecurityCredentials(
                            self.credentials["AccessKeyId"],
                            self.credentials["SecretAccessKey"],
                            self.credentials["SessionToken"]
                        )
                    except Exception as e:
                        logger.error(f"Error supplying AWS credentials: {str(e)}")
                        raise auth_exceptions.RefreshError(e, retryable=True)
                
                def get_aws_region(self, context, request):
                    return os.environ.get('AWS_REGION', 'ap-northeast-1')
            
            # 認証情報サプライヤーのインスタンスを作成
            supplier = AwsCredentialSupplier(aws_token)
            
            # GCPのWorkload Identity Federationのaudience
            audience = f"//iam.googleapis.com/projects/{project_number}/locations/global/workloadIdentityPools/{workload_identity_pool_id}/providers/{workload_identity_provider_id}"
            logger.info(f"Created audience: {audience}")
            
            
            # AWSフェデレーション認証情報を作成
            logger.info("Creating AWS federation credentials")
            credentials = aws.Credentials(
                audience=audience,
                subject_token_type="urn:ietf:params:aws:token-type:aws4_request",
                aws_security_credentials_supplier=supplier,
                service_account_impersonation_url=f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{service_account_email}:generateAccessToken",
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
                service_account_impersonation_options={
                    "token_lifetime_seconds": 3600  # 明示的に1時間のlifetimeを設定
                }
            )
            
            # リクエストオブジェクトとトランスポートを作成
            transport = google_requests.Request()
            
            # リフレッシュのタイムアウト設定
            logger.info("Setting socket timeout to 30 seconds for token refresh")
            original_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(300)  # 30秒のタイムアウト
            
            try:
                # 認証情報をリフレッシュしてGCPのアクセストークンを取得
                logger.info("Refreshing GCP credentials...")
                credentials.refresh(transport)
                logger.info(f"Successfully refreshed GCP credentials. Token expires at: {credentials.expiry}")
                
                # サービスアカウントのアクセストークンを取得
                token = credentials.token
                expiry = credentials.expiry
                
                # 結果を返す
                return {
                    "accessToken": token,
                    "expireTime": expiry.isoformat() if hasattr(expiry, "isoformat") else str(expiry)
                }
            finally:
                # タイムアウト設定を元に戻す
                socket.setdefaulttimeout(original_timeout)
            
        except Exception as e:
            logger.error(f"Error obtaining GCP credentials: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise

if __name__ == "__main__":
    # 既存のapp変数を作成
    # app = create_app()

    # ロギングレベルを上げる
    logging.basicConfig(level=logging.INFO)
    logger.setLevel(logging.DEBUG)
    logger.info("Starting standalone test of _get_gcp_access_token function")
    
    try:
        result = _get_gcp_access_token("test")
        logger.info(f"GCP credentials obtained successfully: {result}")
    except Exception as e:
        logger.error(f"Error obtaining GCP credentials: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")

