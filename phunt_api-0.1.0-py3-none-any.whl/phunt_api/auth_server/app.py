from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import boto3
import logging
import traceback
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict
import json
# from apscheduler.schedulers.asyncio import AsyncIOScheduler
import httpx
import os

# ロギングの設定
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('auth_server.log')
    ]
)
logger = logging.getLogger(__name__)

# FastAPIのデフォルトロガーも詳細に設定
uvicorn_logger = logging.getLogger("uvicorn")
uvicorn_logger.setLevel(logging.DEBUG)

def create_app() -> FastAPI:
    """FastAPIアプリケーションを作成する関数"""
    app = FastAPI(
        title="PHunt Authentication Server",
        debug=True,
        docs_url="/docs",
        redoc_url="/redoc"
    )

    class CredentialResponse(BaseModel):
        access_key_id: str
        secret_access_key: str
        session_token: Optional[str] = None
        expiration: datetime

    class S3PolicyCleanupResult(BaseModel):
        """S3ポリシークリーンアップの結果を表すモデル"""
        removed_statements: List[Dict]
        updated_policy: Dict
        timestamp: datetime

    @app.get("/health")
    async def health_check():
        """ヘルスチェックエンドポイント"""
        logger.debug("Health check endpoint called")
        try:
            response = {
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat()
            }
            logger.debug(f"Returning response: {response}")
            return response
        except Exception as e:
            logger.error(f"Health check error: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    @app.post("/credentials")
    async def get_credentials(request: Request):
        """一時的なAWSクレデンシャルを発行するエンドポイント"""
        try:
            logger.debug("Initializing STS client")
            sts_client = boto3.client('sts')
            
            logger.debug("Generating temporary credentials")
            response = sts_client.get_session_token(
                DurationSeconds=3600  # 1時間
            )
            
            credentials = response['Credentials']
            logger.info("Successfully generated temporary credentials")
            
            return CredentialResponse(
                access_key_id=credentials['AccessKeyId'],
                secret_access_key=credentials['SecretAccessKey'],
                session_token=credentials['SessionToken'],
                expiration=credentials['Expiration']
            )
            
        except Exception as e:
            logger.error(f"Error generating credentials: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail={
                    "error": str(e),
                    "traceback": traceback.format_exc()
                }
            )

    async def cleanup_s3_bucket_policies():
        """期限切れのS3バケットポリシーをクリーンアップする"""
        try:
            logger.info("Starting S3 bucket policy cleanup")
            s3_client = boto3.client('s3')
            bucket_name = "phunt-data"
            
            # 現在のポリシーを取得
            try:
                policy = s3_client.get_bucket_policy(Bucket=bucket_name)
                policy_json = json.loads(policy['Policy'])
            except s3_client.exceptions.NoSuchBucketPolicy:
                logger.info(f"No policy found for bucket {bucket_name}")
                return
            
            current_time = datetime.now(timezone.utc)
            statements = policy_json.get('Statement', [])
            removed_statements = []
            new_statements = []
            
            # 各ステートメントをチェック
            for statement in statements:
                # PHuntSessionのステートメントのみを処理
                if statement.get('Sid', '').startswith('AllowPHuntSession_'):
                    # セッション名から有効期限を抽出（1時間）
                    creation_time_str = statement.get('Condition', {}).get('StringEquals', {}).get('aws:PrincipalTag/aws:RoleSessionName', '')
                    if creation_time_str:
                        # セッションの作成時刻を推定（1時間前）
                        session_creation_time = current_time - timedelta(hours=1)
                        
                        # 期限切れの場合、削除リストに追加
                        if current_time > session_creation_time + timedelta(hours=1):
                            removed_statements.append(statement)
                            continue
                
                new_statements.append(statement)
            
            # ポリシーが変更された場合のみ更新
            if removed_statements:
                policy_json['Statement'] = new_statements
                s3_client.put_bucket_policy(
                    Bucket=bucket_name,
                    Policy=json.dumps(policy_json)
                )
                logger.info(f"Removed {len(removed_statements)} expired policy statements")
            else:
                logger.info("No expired policy statements found")
            
            return S3PolicyCleanupResult(
                removed_statements=removed_statements,
                updated_policy=policy_json,
                timestamp=current_time
            )
            
        except Exception as e:
            logger.error(f"Error during S3 bucket policy cleanup: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            raise HTTPException(
                status_code=500,
                detail={
                    "error": str(e),
                    "traceback": traceback.format_exc()
                }
            )

    @app.on_event("startup")
    async def startup_event():
        """アプリケーション起動時の初期化処理"""
        logger.info("Starting PHunt Authentication Server")
        logger.info("Debug mode enabled")
        logger.debug("Python version: " + sys.version)
        logger.debug("FastAPI version: " + app.version)
        
        # アクセス方法の情報を表示
        logger.info("=== Access Information ===")
        logger.info("Available endpoints:")
        logger.info("1. Health Check:")
        logger.info("   GET /health")
        logger.info("   Example: curl http://localhost:8000/health")
        
        logger.info("\n2. Get Credentials:")
        logger.info("   POST /credentials")
        logger.info("   Example:")
        logger.info("   curl -X POST http://localhost:8000/credentials")
        
        logger.info("\n3. Feast UI Proxy (if enabled):")
        logger.info("   Access via: http://localhost:8888/feast/")
        logger.info("============================")
        
        # # クリーンアップスケジューラーの設定
        # scheduler = AsyncIOScheduler()
        # scheduler.add_job(cleanup_s3_bucket_policies, 'interval', minutes=15)
        # scheduler.start()
        # logger.info("S3 bucket policy cleanup scheduler started")

    @app.get("/admin/cleanup-policies")
    async def manual_cleanup():
        """手動でポリシークリーンアップを実行するエンドポイント"""
        try:
            result = await cleanup_s3_bucket_policies()
            return result
        except Exception as e:
            logger.error(f"Manual cleanup failed: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    @app.on_event("shutdown")
    async def shutdown_event():
        """アプリケーション終了時の処理"""
        logger.info("Shutting down PHunt Authentication Server")

    return app

# 既存のapp変数を作成
app = create_app()

