from dataclasses import dataclass
from fastapi import FastAPI
import uvicorn
import logging
import sys
from typing import Optional
from pathlib import Path
import multiprocessing

# ロギングの設定
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

@dataclass
class AuthServerConfig:
    """認証サーバーの設定クラス"""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    reload: bool = False

class AuthServer:
    """認証サーバーのメインクラス"""
    def __init__(self, config: AuthServerConfig):
        self.config = config
        self.app = self._create_app()
        self._process: Optional[multiprocessing.Process] = None
        
    def _create_app(self) -> FastAPI:
        """FastAPIアプリケーションを作成"""
        from .app import create_app
        return create_app()
    
    def _run_server(self) -> None:
        """サーバープロセスを実行"""
        config_kwargs = {
            "app": self.app,
            "host": self.config.host,
            "port": self.config.port,
            "workers": self.config.workers,
            "reload": self.config.reload,
            "log_level": "debug"
        }
        
        config = uvicorn.Config(**config_kwargs)
        server = uvicorn.Server(config)
        server.run()
    
    def run(self, block: bool = True) -> None:
        """認証サーバーを起動
        
        Args:
            block (bool): Trueの場合はブロッキング実行、Falseの場合はバックグラウンド実行
        """
        try:
            logger.info(f"Starting Auth Server on {self.config.host}:{self.config.port}")
            
            if block:
                self._run_server()
            else:
                if self._process is not None and self._process.is_alive():
                    logger.warning("Server is already running")
                    return
                
                self._process = multiprocessing.Process(target=self._run_server)
                self._process.start()
                logger.info("Server started in background")
            
        except Exception as e:
            logger.error(f"Failed to start Auth Server: {str(e)}", exc_info=True)
            raise
    
    def stop(self) -> None:
        """バックグラウンドで実行中のサーバーを停止"""
        if self._process is not None and self._process.is_alive():
            logger.info("Stopping background server")
            self._process.terminate()
            self._process.join()
            self._process = None
            logger.info("Server stopped") 