from dataclasses import dataclass
from fastapi import FastAPI
import uvicorn
import logging
import sys
from typing import Optional
from pathlib import Path

# ロギングの設定
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

@dataclass
class AuthServerConfig:
    """認証サーバーの設定クラス"""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    enable_ssl: bool = False
    cert_path: Optional[str] = None
    key_path: Optional[str] = None
    reload: bool = False

class AuthServer:
    """認証サーバーのメインクラス"""
    def __init__(self, config: AuthServerConfig):
        self.config = config
        self.app = self._create_app()
        
    def _create_app(self) -> FastAPI:
        """FastAPIアプリケーションを作成"""
        from .app import create_app
        return create_app()
    
    def run(self, block: bool = True) -> None:
        """認証サーバーを起動"""
        try:
            logger.info(f"Starting Auth Server on {self.config.host}:{self.config.port}")
            
            config_kwargs = {
                "app": self.app,
                "host": self.config.host,
                "port": self.config.port,
                "workers": self.config.workers,
                "reload": self.config.reload,
                "log_level": "debug"
            }
            
            if self.config.enable_ssl:
                if not all([self.config.cert_path, self.config.key_path]):
                    raise ValueError("SSL is enabled but cert_path or key_path is missing")
                if not all([Path(p).exists() for p in [self.config.cert_path, self.config.key_path]]):
                    raise ValueError("SSL certificate or key file not found")
                
                config_kwargs.update({
                    "ssl_keyfile": self.config.key_path,
                    "ssl_certfile": self.config.cert_path
                })
                logger.info("SSL/TLS enabled")
            else:
                logger.info("Running without SSL/TLS")
            
            config = uvicorn.Config(**config_kwargs)
            server = uvicorn.Server(config)
            server.run()
            
        except Exception as e:
            logger.error(f"Failed to start Auth Server: {str(e)}", exc_info=True)
            raise 