import uvicorn
import ssl
import argparse
import logging
import sys
from pathlib import Path

# ロギングの設定
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

def run_auth_server(host: str = "0.0.0.0", port: int = 8000, workers: int = 1, reload: bool = False):
    """認証サーバーを起動する関数

    Args:
        host (str): バインドするホスト
        port (int): 認証サーバーのポート
        workers (int): ワーカープロセス数
        reload (bool): ホットリロードを有効にするかどうか
    """
    config_kwargs = {
        "app": "phunt_api.auth_server.app:app",
        "host": host,
        "port": port,
        "reload": reload,
        "workers": workers,
        "log_level": "debug"
    }
    
    logger.info("Running without SSL/TLS")
    logger.info(f"Starting Auth Server on {host}:{port}")
    
    config = uvicorn.Config(**config_kwargs)
    server = uvicorn.Server(config)
    server.run()

def main():
    try:
        parser = argparse.ArgumentParser(description='PHunt Authentication Server')
        parser.add_argument('--host', default='0.0.0.0', help='Host to bind')
        parser.add_argument('--port', type=int, default=8000, help='Port to bind')
        parser.add_argument('--reload', action='store_true', help='Enable auto-reload')
        parser.add_argument('--workers', type=int, default=1, help='Number of worker processes')
        
        args = parser.parse_args()
        run_auth_server(
            host=args.host,
            port=args.port,
            workers=args.workers,
            reload=args.reload
        )
        
    except Exception as e:
        logger.error(f"Failed to start server: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main() 