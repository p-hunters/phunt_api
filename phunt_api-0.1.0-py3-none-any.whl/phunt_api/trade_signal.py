# -*- coding: utf-8 -*-

from .datasource import DataSourceManager
from datetime import datetime, timedelta

class SignalManager:
    def __init__(self):
        self.feeds = {}

    def add_feed(self, name: str, datasource: DataSourceManager):
        self.feeds[name] = datasource

    def get_data(self, name: str, start_date: str, end_date: str):
        return self.feeds[name].get_data(start_date, end_date)

if __name__ == "__main__":
    pass

