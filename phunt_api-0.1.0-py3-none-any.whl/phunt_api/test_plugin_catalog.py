"""
プラグインカタログのテスト

このスクリプトは、プラグインカタログ機能をテストします。
"""

import logging
from phunt_api import PHuntAPI
from phunt_api.plugin_system import PluginCatalog

# ロギングの設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_plugin_catalog():
    """
    プラグインカタログ機能をテストする
    """
    logger.info("=== プラグインカタログのテスト ===")
    
    # PHuntAPIの初期化
    logger.info("\n1. PHuntAPIを初期化中...")
    api = PHuntAPI(debug=True)
    logger.info("PHuntAPIを初期化しました。")
    
    # カタログを直接初期化
    catalog = PluginCatalog(use_local_catalog=True)
    
    # カタログを更新
    logger.info("\n2. カタログを更新...")
    success = api.update_plugin_catalog()
    logger.info(f"カタログの更新: {'成功' if success else '失敗'}")
    
    # すべてのプラグインを検索
    logger.info("\n3. すべてのプラグインを検索...")
    plugins = api.search_plugins()
    logger.info(f"プラグインの数: {len(plugins)}")
    for plugin in plugins:
        logger.info(f"- {plugin['name']} ({plugin['id']}): {plugin['description']}")
    
    # キーワードでプラグインを検索
    logger.info("\n4. キーワード 'machine learning' でプラグインを検索...")
    ml_plugins = api.search_plugins(query="machine learning")
    logger.info(f"検索結果: {len(ml_plugins)} プラグイン")
    for plugin in ml_plugins:
        logger.info(f"- {plugin['name']}: {plugin['description']}")
    
    # タグでプラグインを検索
    logger.info("\n5. タグ 'finance' でプラグインを検索...")
    finance_plugins = api.search_plugins(tags=["finance"])
    logger.info(f"検索結果: {len(finance_plugins)} プラグイン")
    for plugin in finance_plugins:
        logger.info(f"- {plugin['name']}: {plugin['description']}")
    
    # プラグインの詳細情報を取得
    if plugins:
        plugin_id = plugins[0]['id']
        logger.info(f"\n6. プラグイン '{plugin_id}' の詳細情報を取得...")
        plugin_details = catalog.get_plugin_details(plugin_id)
        if plugin_details:
            logger.info(f"プラグイン名: {plugin_details['name']}")
            logger.info(f"説明: {plugin_details['description']}")
            logger.info(f"作者: {plugin_details['author']}")
            logger.info(f"バージョン: {plugin_details['version']}")
            logger.info(f"リポジトリURL: {plugin_details['repo_url']}")
            logger.info(f"タグ: {', '.join(plugin_details['tags'])}")
            logger.info(f"スター数: {plugin_details['stars']}")
            logger.info(f"ダウンロード数: {plugin_details['downloads']}")
        else:
            logger.error(f"プラグイン '{plugin_id}' の詳細情報が見つかりません")
    
    logger.info("\n=== テスト完了 ===")


if __name__ == "__main__":
    test_plugin_catalog() 