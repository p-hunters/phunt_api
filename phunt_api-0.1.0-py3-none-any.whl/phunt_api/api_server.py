
from fastapi import FastAPI, Request, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import os
from typing import List, Dict, Any

from .datacatalog.metadata import MetadataManager

app = FastAPI(title="PHunt API Feature Store")

# Determine templates directory
current_dir = os.path.dirname(os.path.abspath(__file__))
templates_dir = os.path.join(current_dir, "templates")
templates = Jinja2Templates(directory=templates_dir)

def get_metadata_manager():
    bucket = os.getenv("DATACATALOG_BUCKET", "porory-data")
    return MetadataManager(bucket)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/features")
async def list_features() -> List[Dict[str, Any]]:
    mgr = get_metadata_manager()
    return mgr.list_features()

@app.get("/api/features/{feature_id}")
async def get_feature(feature_id: str):
    mgr = get_metadata_manager()
    feature = mgr.get_feature(feature_id)
    if not feature:
        raise HTTPException(status_code=404, detail="Feature not found")
    return feature

@app.get("/api/search")
async def search_features(q: str = "") -> List[Dict[str, Any]]:
    mgr = get_metadata_manager()
    return mgr.search_features(q)

@app.get("/ui/features", response_class=HTMLResponse)
async def list_features_ui(request: Request, q: str = ""):
    mgr = get_metadata_manager()
    if q:
        features = mgr.search_features(q)
    else:
        features = mgr.list_features()
    return templates.TemplateResponse("partials/feature_list.html", {"request": request, "features": features})
